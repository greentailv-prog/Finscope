# -*- coding: utf-8 -*-
"""34 项财务指标抽取，每个数字都带回年报页码与原文。

抽取按优先级来：主要会计数据和财务指标表 > 合并三表 > 财务报表附注。
同名科目在多处出现时全记下来，按 (来源优先级, 别名匹配度, 页码) 选一个当主值，
其余留作交叉校验。

用法:
    python indicators.py                # 抽取 data/annual_reports 下全部年报
    python indicators.py --pdf <路径>    # 只抽一份并打印明细
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from decimal import Decimal
from pathlib import Path

import pdfplumber

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:          # 允许 -I 下直接跑本文件
    sys.path.insert(0, str(SRC))
import table_extract as te  # noqa: E402
import line_fallback          # noqa: E402

ROOT = SRC.parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
WORK_DIR = ROOT / "work"
OUT_DIR = ROOT / "data" / "extracted"

# 来源优先级：数字越小越权威
SRC_MAIN, SRC_STATEMENT, SRC_NOTE = 1, 2, 3

_HEADING_MAIN = ("主要会计数据和财务指标", "主要会计数据")
_HEADING_NOTES = ("财务报表附注", "合并财务报表项目注释", "财务报表主要项目注释")
# 三表标题各家写法不一：「合并资产负债表」「合并及公司利润表」「2025年度合并及公司现金流量表」
# 都算。只认合并口径；标题里只有「母公司」的页面是要排除的。
_STMT_TITLE_RE = re.compile(r"(?:20\d{2}\s*年度?)?\s*(合并及公司|合并)\s*(资产负债表|利润表|现金流量表)")
_SECTION_HEADING = re.compile(r"第[一二三四五六七八九十]+节\s*[^\s，。；、：（(]{2,14}")

_ENUM_PREFIX = re.compile(r"^\s*(?:[（(]?[一二三四五六七八九十\d]+[)）]?[、.]?\s*)+")
# 利润表用「减：营业成本」表示扣减、用「其中：营业收入」细分，这些是列示前缀，
# 不是科目名的一部分。不剥掉就会因为「减:营业成本」不等于「营业成本」而漏抽。
_PRESENT_PREFIX = re.compile(r"^\s*(?:减|加|其中|其中之|其他)[:：]")
_UNIT_TAIL = re.compile(r"[（(]\s*(?:人民币)?\s*(?:元/股|元／股|千元|百万元|万元|亿元|元)\s*[)）]\s*$")
_TAIL_NOISE = re.compile(r"[\s:：、，,。.]+$")
# 科目名里的插入语与斜杠：年报把「投资活动产生的现金流量净额」写成
# 「投资活动产生/(使用)的现金流量净额」，不剥掉就匹配不上别名。
_INLINE_PAREN = re.compile(r"[（(][^）)]{0,10}[)）]")
_SLASH = re.compile(r"[/／]")


# ------------------------------------------------------------------ 基础工具

def core_label(label: str) -> str:
    """剥掉序号前缀、尾部单位括号、行内插入语，得到可比对的科目名。"""
    s = te.normalize(label).strip()
    s = _ENUM_PREFIX.sub("", s)
    # 「（(11)）固定资产折旧…」这类双层括号序号，枚举前缀剥完会剩一个右括号。
    s = re.sub(r"^[）)】\]\s、.．]+", "", s)
    s = _PRESENT_PREFIX.sub("", s)
    s = _UNIT_TAIL.sub("", s)
    s = _INLINE_PAREN.sub("", s)
    s = re.sub(r"^[）)】\]\s、.．]+", "", s)
    s = _SLASH.sub("", s)
    return _TAIL_NOISE.sub("", s)


def _norm_alias(a: str) -> str:
    return core_label(a)


def load_aliases() -> dict:
    raw = json.loads((SRC / "aliases.json").read_text(encoding="utf-8"))
    metrics = {}
    for key, spec in raw["metrics"].items():
        metrics[key] = {
            "label": spec["label"],
            "kind": spec["kind"],
            "sign": spec.get("sign", "as_reported"),
            "aliases": [a for a in spec["aliases"]],
            "alias_norm": {_norm_alias(a) for a in spec["aliases"]},
            "forbidden": spec.get("forbidden", []),
            "prefer_max": bool(spec.get("prefer_max")),
            "avoid_cashflow": bool(spec.get("avoid_cashflow")),
            "note": spec.get("note", ""),
        }
    return metrics


def match_label(label: str, spec: dict) -> float:
    """返回科目名与该指标的匹配度，0 表示不匹配。

    顺序很关键：先认精确别名，再查禁用词。否则「归属于母公司所有者权益合计」
    会被自己的禁用词「所有者权益合计」误杀。
    """
    core = core_label(label)
    if not core:
        return 0.0
    if core in spec["alias_norm"]:
        return 1.0
    if any(f in core for f in spec["forbidden"]):
        return 0.0
    # 只认精确匹配和「别名 + 少量标点尾巴」。**不做子串匹配**：
    # 「可随时用于支付的其他货币资金」「实际核销的应收账款」这类附注明细都含目标
    # 词，一旦允许子串，附注里的细项就会盖过资产负债表上的正式科目，把 852 亿
    # 的货币资金换成 0.06 亿的明细项。宁可不报，也不能报错。
    best = 0.0
    for a in spec["alias_norm"]:
        if a and core.startswith(a):
            rest = core[len(a):]
            if len(rest) <= 4 and not re.search(r"[一-龥A-Za-z0-9]", rest):
                best = max(best, 0.9)
    return best


# ------------------------------------------------------------------ 文本与章节

def page_texts(pdf) -> list[str]:
    return [te.normalize(p.extract_text() or "") for p in pdf.pages]


def build_page_sections(texts: list[str]) -> list[str]:
    """逐页维护「当前章节」，供引用里标注来源章节。

    必须要求章节号在行首且整行够短：正文里的「详见第八节财务报告附注五(2)(b)」
    这类交叉引用会把当前章节劫持走。
    """
    sections, cur = [], "封面与目录"
    for t in texts:
        for ln in t.split("\n"):
            s = te.normalize(ln).strip()
            if len(s) > 30:
                continue
            m = _SECTION_HEADING.match(s)
            if m:
                cur = m.group(0).strip()
        sections.append(cur)
    return sections


def page_source_kind(text: str, section: str) -> tuple[int, str]:
    """判定该页属于哪类来源，返回 (优先级, 来源名)。"""
    compact = [te.normalize(x).strip() for x in text.split("\n") if x.strip()]
    head = "".join(compact[:10])
    m = _STMT_TITLE_RE.search(head)
    if m and m.start() < 40:
        return SRC_STATEMENT, f"合并{m.group(2)}"
    # 主数据表标题常排在页首若干行之后（茅台第 6 页先列会计师事务所、办公地址，
    # 第八行才是「七、主要会计数据和财务指标」）。按行判断，不用字符位置卡死。
    for ln in compact[:15]:
        for h in _HEADING_MAIN:
            if h in ln and len(ln) <= 40:
                return SRC_MAIN, h
    joined = "".join(compact[:60])
    for h in _HEADING_NOTES:
        if h in joined:
            return SRC_NOTE, h
    return SRC_NOTE, section


# ------------------------------------------------------------------ 抽取

def extract_company(pdf_path: Path, meta: dict, metrics: dict, pagemap: dict) -> dict:
    pm_pages = {p["pdf_index"]: p for p in pagemap["pages"]}

    with pdfplumber.open(pdf_path) as pdf:
        total = len(pdf.pages)
        texts = page_texts(pdf)
        sections = build_page_sections(texts)
        kinds = [page_source_kind(texts[i], sections[i]) for i in range(total)]
        # 只解析可能命中的页：先用纯文本筛掉绝大部分页面，省时间
        wanted: dict[int, set[str]] = {i: set() for i in range(total)}
        for key, spec in metrics.items():
            for i, t in enumerate(texts):
                # 必须去掉所有空白（含换行）：科目名折行时「购建…支付的」和「现金」
                # 会被拆到两行，只去空格拼不回别名。
                flat = "".join(t.split())
                if any("".join(a.split()) in flat for a in spec["aliases"]):
                    wanted[i].add(key)

        # 跨页续表：三表常跨两三页，续页上没有表头，自身推不出口径，必须继承。
        # 判据只留「相邻 ≤2 页」——不能比来源名：续页的页首是正文而不是报表标题，
        # 来源名与首页不同，一比就继承不上（万华化学的商誉就是这样丢的）。
        # 页面上有自己表头的不会被覆盖，所以误继承的风险只落在真正没表头的页上。
        parsed: dict[int, dict] = {}
        last_header, last_header_idx = None, -99
        last_unit, last_scale = "元", Decimal(1)
        for i in range(total):
            if not wanted[i]:
                continue
            override = last_header if (last_header and i - last_header_idx <= 2) else None
            tbl = te.parse_page_table(pdf.pages[i], header_override=override)
            # 续页没写单位时沿用首页的单位。宁德时代资产负债表首页写「单位：千元」，
            # 续页没写，不继承就会把商誉 837,328 千元当成 837,328 元。
            if not tbl["unit_explicit"] and override:
                tbl["unit"], tbl["scale"] = last_unit, last_scale

            # 跨页断裂的科目行：科目名前半截留在上一页（那一行的数值在本页），
            # 本页只剩「的扣除非经常性损益」这样的尾段。把上一页没归上行锚的科目行
            # 接回来——但只在这条拼接能对上某个别名时才采用，不做无根据的拼接。
            prev_page = parsed.get(i - 1)
            if prev_page and tbl["header_periods"]:
                prefixes = [o["label"] for o in prev_page.get("orphan_labels", [])]
                for row in tbl["rows"]:
                    if not row["values"] or not row["label"]:
                        continue
                    if row["label"][0] not in te._CONT_HEAD:
                        continue
                    for prefix in prefixes:
                        merged = prefix + row["label"]
                        if any(match_label(merged, spec) >= 0.9
                               for spec in metrics.values()):
                            row["label"] = merged
                            break
                    break

            parsed[i] = tbl
            if tbl["header_periods"]:
                last_header = {"periods": tbl["header_periods"],
                               "scopes": tbl["header_scopes"]}
                last_header_idx = i
            if tbl["unit_explicit"]:
                last_unit, last_scale = tbl["unit"], tbl["scale"]

    # 收集所有候选：同一指标在多个页面/多行命中。「科目在、但本期值为空」的行
    # 另收一份（orphan_pool），供缺失值语义判定用。
    hits: dict[str, list[dict]] = {k: [] for k in metrics}
    orphan_pool: list[dict] = []
    for i, table in parsed.items():
        for o in table.get("orphan_labels", []):
            orphan_pool.append({"label": o["label"], "pdf_page": i + 1,
                                "printed_page": pm_pages.get(i + 1, {}).get("printed_page")})
        kind_pri, kind_name = kinds[i]
        printed = pm_pages.get(i + 1, {}).get("printed_page")
        for row in table["rows"]:
            if not row["values"]:
                continue
            core = core_label(row["label"])
            if not core or len(core) > 40:
                continue
            for key, spec in metrics.items():
                score = match_label(row["label"], spec)
                if score <= 0:
                    continue
                # 单位优先取科目名里带的（「营业收入（千元）」），其次取表/页面的「单位：X」
                if row["unit_hint"]:
                    unit_hint = row["unit_hint"]
                    scale = te._UNIT_SCALE.get(unit_hint, table["scale"])
                else:
                    unit_hint = table["unit"]
                    scale = table["scale"]
                hits[key].append({
                    "pdf_page": i + 1,
                    "printed_page": printed,
                    "section": sections[i],
                    "source_kind": kind_name,
                    "priority": kind_pri,
                    "score": score,
                    "label_raw": row["label"],
                    "core": core,
                    "unit_raw": unit_hint,
                    "scale": scale,
                    "values": row["values"],
                    "kinds": row["kinds"],
                    "scopes": row.get("scopes", {}),
                    "top": row["top"],
                    "raw_text": row["raw"],
                })

    # 坐标表格漏值的兜底：只在合并三表页、且该科目没有拿到三表级候选时启用。
    # 不覆盖已经解析正确的表格值，避免兜底把好数据改坏。
    line_hits = line_fallback.candidates(
        texts, sections, pm_pages, metrics, int(meta.get("report_year", 2025)), SRC_STATEMENT)
    report_year = int(meta.get("report_year", 2025))
    for key, cands in line_hits.items():
        # 坐标解析有时会产出一个「三表级」候选但只有上期、没有本期（表头跨页、
        # 列没对齐）。这种候选不能挡住文本兜底，否则明明是「营业成本 9.1 亿」
        # 会被判成空值。
        has_current = any(
            c.get("priority", 99) <= SRC_STATEMENT
            and (c.get("values", {}).get(str(report_year)) is not None
                 or c.get("values", {}).get("本期") is not None)
            for c in hits[key])
        if cands and not has_current:
            hits[key].extend(cands)

    out_metrics = {}
    for key, spec in metrics.items():
        out_metrics[key] = _resolve_metric(key, spec, hits[key], meta, orphan_pool)

    # 所有者权益合计不能小于归母净资产。权益变动表里也有「所有者权益合计」，
    # 个别公司会抽到期初数；用资产总计 - 负债合计校正，并在备注里写清。
    year = str(meta.get("report_year", 2025))
    teq = out_metrics.get("total_equity", {})
    ep = out_metrics.get("equity_attr", {})
    ta = out_metrics.get("total_assets", {})
    tl = out_metrics.get("total_liabilities", {})
    if (teq.get("status") == "found" and ep.get("status") == "found"
            and ta.get("status") == "found" and tl.get("status") == "found"
            and teq.get("value") is not None and ep.get("value") is not None
            and teq["value"] < ep["value"]):
        derived = ta["value"] - tl["value"]
        if derived > 0:
            teq["value"] = derived
            teq.setdefault("series", {})[year] = derived
            teq["status_note"] = "报告权益低于归母权益，按资产总计-负债合计倒算"
            teq["confidence"] = 0.7
            teq["raw_text"] = (f"按资产总计 - 负债合计倒算："
                              f"{ta['value']:.2f} - {tl['value']:.2f} = {derived:.2f}")

    return {
        "company": _company_info(pdf_path, meta, texts, pagemap),
        "financials": out_metrics,
        "extraction_meta": {
            "pdf": pdf_path.name,
            "pdf_pages": pagemap["total_pdf_pages"],
            "pagemap_validation": pagemap["validation"],
            "extractor": "indicators.py",
        },
    }


def _to_yuan(value: Decimal | None, scale: Decimal) -> Decimal | None:
    return None if value is None else value * scale


def _num(d: Decimal | None):
    if d is None:
        return None
    if d == d.to_integral_value():
        return int(d)
    return float(d)


def _scope_rank(c: dict) -> int:
    """合并优先：0 合并，1 未知，2 母公司/公司。"""
    sk = str(c.get("source_kind") or "")
    if "母公司" in sk or "本公司" in sk:
        return 2
    if "合并" in sk:
        return 0
    vals = [str(v) for v in (c.get("scopes") or {}).values() if v]
    if any("合并" in v for v in vals):
        return 0
    if any("母公司" in v or v.strip() == "公司" for v in vals):
        return 2
    return 1


def _resolve_metric(key: str, spec: dict, cands: list[dict], meta: dict,
                    orphan_pool: list[dict] | None = None) -> dict:
    """在若干候选里定主值；没有可用候选时按缺失语义输出。"""
    def _fix(x: Decimal | None) -> Decimal | None:
        """成本/费用类科目取绝对值：年报用括号表示『减：』项，不是真为负。"""
        if x is None:
            return None
        return abs(x) if spec.get("sign") == "magnitude" else x

    usable = []
    for c in cands:
        cur = c["values"].get("2025", c["values"].get("本期"))
        if cur is None:
            continue
        if c["kinds"].get("2025", c["kinds"].get("本期")) == "percent":
            continue                       # 增减列混进来的百分比不是金额
        usable.append((_fix(_to_yuan(cur, c["scale"])), c))

    base = {
        "metric": key, "label": spec["label"], "kind": spec["kind"],
        "unit": "元", "period": str(meta.get("report_year", 2025)),
        "page": None, "source": None, "status": "not_found",
        "confidence": 0.0, "aliases_tried": spec["aliases"],
    }

    if not usable:
        if cands:
            base.update(status="not_applicable",
                        reason="matched_row_but_no_current_period_value",
                        confidence=0.5)
            return base
        # 别名一个都没命中，但表里存在同名科目行、只是数值栏是空的——这是
        # 「确定没有」（贵州茅台的商誉），不是「没抽到」。两者对使用者的含义
        # 完全不同：前者可以直接当 0 用，后者必须回去查。
        absent = [o for o in (orphan_pool or [])
                  if match_label(o["label"], spec) >= 1.0]
        if absent:
            base.update(status="not_applicable", reason="row_present_without_value",
                        page=absent[0]["printed_page"], pdf_page=absent[0]["pdf_page"],
                        alias_matched=absent[0]["label"], confidence=0.85)
            return base
        base.update(reason="alias_miss")
        return base

    if spec.get("prefer_max"):
        # 货币资金、所有者权益合计在附注/权益变动表里会出现明细或期初数，
        # 总额一定不小于明细，取绝对值最大的候选。排序优先级：
        # 1) 货币资金优先非现金流量表页（现金流量表补充资料里也会出现「货币资金」，
        #    但常是其中一项，美的的 166.6 亿就是这样来的）；
        # 2) 合并优先于母公司（茅台的母公司货币资金比合并数还大）；
        # 3) 同口径取最大值。
        def _cash_key(t):
            c = t[1]
            parent_penalty = 1 if _scope_rank(c) == 2 else 0
            return (parent_penalty, -abs(t[0]), c["priority"], c["pdf_page"])
        usable.sort(key=_cash_key)
    else:
        usable.sort(key=lambda t: (t[1]["priority"], -t[1]["score"], t[1]["pdf_page"]))
    value, best = usable[0]

    series = {}
    best_rank = _scope_rank(best)
    best_kind = str(best.get("source_kind") or "")
    for _v, c in usable:
        # 主值是合并数时，不要用母公司表的 2023 年值补序列（格力/海康常见）。
        if best_rank != 2 and _scope_rank(c) == 2:
            continue
        # 序列只从同类来源或合并主表/主要会计数据补，避免把母公司表、
        # 附注明细的 2023 年值混进合并口径的序列。
        ck = str(c.get("source_kind") or "")
        if ck != best_kind and "主要会计" not in ck and "合并" not in ck:
            continue
        for per, raw in c["values"].items():
            if per.endswith("_增减") or raw is None:
                continue
            # 主表把「本年比上年增减」列当成第三年时，值是 -9.89 这种百分比；
            # 不能写进 2023 年序列，否则三年量级检查会误报 100 倍。
            if (c.get("kinds") or {}).get(per) == "percent":
                continue
            per = {"本期": "2025", "上期": "2024"}.get(per, per)
            series.setdefault(per, _num(_fix(_to_yuan(raw, c["scale"]))))
    series.setdefault("2025", _num(value))

    cross = [{"value": _num(v), "pdf_page": c["pdf_page"], "printed_page": c["printed_page"],
              "source_kind": c["source_kind"], "label_raw": c["label_raw"]}
             for v, c in usable[1:6]]

    base.update(
        value=_num(abs(value) if spec.get("sign") == "magnitude" else value),
        unit="元",
        page=best["printed_page"],
        pdf_page=best["pdf_page"],
        source=f"{meta['name']}{meta.get('report_year', 2025)}年年度报告",
        section=best["section"],
        table=best["source_kind"],
        basis="合并",
        alias_matched=best["label_raw"],
        unit_raw=best["unit_raw"],
        raw_text=best["raw_text"],
        series=series,
        value_original=_num(best["values"].get("2025") or best["values"].get("本期")),
        status="found",
        confidence=0.95 if best["score"] >= 1.0 else 0.7,
        cross_check=cross,
    )
    return base


def _company_info(pdf_path: Path, meta: dict, texts: list[str], pagemap: dict) -> dict:
    head = "\n".join(texts[:4])
    name = meta.get("name", "")
    m = re.search(r"([一-龥]{2,20}(?:集团)?(?:股份)?有限公司)", head)
    if m:
        name = m.group(1)
    ticker = meta.get("code", "")
    m2 = re.search(r"(?:股票代码|证券代码|A股代码)\s*[:：]?\s*(\d{6})", head)
    if m2:
        ticker = m2.group(1)
    return {
        "name": name,
        "ticker": ticker,
        "industry": meta.get("industry", ""),
        "report_period": f"{meta.get('report_year', 2025)}年度",
        "report_title": f"{name}{meta.get('report_year', 2025)}年年度报告",
    }


# ------------------------------------------------------------------ 入口

def load_pagemap(pdf_path: Path) -> dict:
    p = WORK_DIR / "pagemap" / f"{pdf_path.stem}.pagemap.json"
    if not p.exists():
        raise FileNotFoundError(f"缺少页码映射 {p}，请先运行 pdf_pagemap.py")
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(description="从年报抽取 34 项财务指标")
    ap.add_argument("--pdf", help="只抽这一份")
    ap.add_argument("--codes", nargs="*", help="只抽这些股票代码")
    args = ap.parse_args()

    companies = json.loads((SRC / "companies.json").read_text(encoding="utf-8"))
    year = companies.get("report_year", 2025)
    metrics = load_aliases()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    targets = []
    for c in companies["companies"]:
        if args.codes and c["code"] not in args.codes:
            continue
        pdf = ANNUAL_DIR / f"{c['name']}_{c['code']}_{year}.pdf"
        if pdf.exists():
            targets.append((pdf, {**c, "report_year": year}))
    if args.pdf:
        p = Path(args.pdf)
        p = p if p.is_absolute() else ROOT / p
        targets = [(p, {"name": p.stem.split("_")[0], "code": p.stem.split("_")[1],
                        "industry": "", "report_year": year})]

    for pdf, meta in targets:
        print(f"抽取 {pdf.stem} ...", flush=True)
        pagemap = load_pagemap(pdf)
        result = extract_company(pdf, meta, metrics, pagemap)
        (OUT_DIR / f"{pdf.stem}.json").write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

        fin = result["financials"]
        found = [k for k, v in fin.items() if v["status"] == "found"]
        na = [k for k, v in fin.items() if v["status"] == "not_applicable"]
        miss = [k for k, v in fin.items() if v["status"] == "not_found"]
        print(f"  命中 {len(found)}/{len(fin)}  not_applicable={na}  not_found={miss}")
        if args.pdf:
            for k, v in fin.items():
                page = v.get("page")
                print(f"    {k:20s} {str(v.get('value'))[:22]:24s} "
                      f"p{page} {v.get('unit_raw') or '':5s} [{v.get('status')}] "
                      f"{v.get('alias_matched', '')[:26]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
