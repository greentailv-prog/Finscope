# -*- coding: utf-8 -*-
"""把 A 模块的两套口径整理成驾驶舱可直接渲染的统一对象。

- PDF 口径：读 data/extracted/*.json，17 个核心科目，每个数带印刷页码与原文；
- 在线口径：读 online_finance 拉到的年度三表，30 个 P0 科目，每个数带数据源字段与链接。

比率、数据质量、结论摘要都在这里算一次。页面只读结果，不重算——同一个数在卡片、
图表、表格里必须是同一个值。
"""
from __future__ import annotations

import json
import math
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import identify                     # noqa: E402
import online_finance               # noqa: E402
import webdata                      # noqa: E402

ROOT = SRC.parent
EXTRACTED = ROOT / "data" / "extracted"
ANNUAL_DIR = ROOT / "data" / "annual_reports"
ONLINE_DIR = ROOT / "data" / "online"

# 现有 17 个旧键 -> 04 规范的 canonical 键
LEGACY_TO_CANON = {
    "revenue": "revenue",
    "operating_cost": "operating_cost",
    "net_profit": "net_income",
    "net_profit_attr": "net_income_parent",
    "net_profit_deducted": "net_income_excl_nonrecurring",
    "total_assets": "total_assets",
    "total_liabilities": "total_liabilities",
    "equity_attr": "equity_parent",
    "cash": "cash_and_equivalents",
    "accounts_receivable": "accounts_receivable",
    "inventory": "inventory",
    "goodwill": "goodwill",
    "cfo": "cfo",
    "cfi": "cfi",
    "cff": "cff",
    "rd_expense": "rnd_expense",
    "capex": "capex",
}

CANON_LABEL = {
    "revenue": "营业收入", "operating_cost": "营业成本", "operating_profit": "营业利润",
    "pretax_profit": "利润总额", "income_tax_expense": "所得税费用",
    "net_income": "净利润", "net_income_parent": "归母净利润",
    "net_income_excl_nonrecurring": "扣非归母净利润",
    "selling_expense": "销售费用", "admin_expense": "管理费用",
    "finance_expense": "财务费用", "interest_expense": "利息费用",
    "depreciation_amortization": "折旧与摊销",
    "cash_and_equivalents": "货币资金", "accounts_receivable": "应收账款",
    "notes_receivable": "应收票据", "inventory": "存货",
    "contract_assets": "合同资产", "current_assets": "流动资产合计",
    "total_assets": "资产总计", "accounts_payable": "应付账款",
    "current_liabilities": "流动负债合计", "short_term_borrowings": "短期借款",
    "current_portion_lt_debt": "一年内到期的非流动负债",
    "long_term_borrowings": "长期借款", "bonds_payable": "应付债券",
    "total_liabilities": "负债合计", "equity_parent": "归母净资产",
    "total_equity": "所有者权益合计", "fixed_assets": "固定资产",
    "goodwill": "商誉", "rnd_expense": "研发费用",
    "rd_capitalized": "开发支出（余额）",
    "cfo": "经营活动现金流量净额", "cfi": "投资活动现金流量净额",
    "cff": "筹资活动现金流量净额", "capex": "资本开支",
    "cash_received_from_sales": "销售商品、提供劳务收到的现金",
    "interest_paid": "支付的利息", "dividend_paid": "分配股利、利润或偿付利息支付的现金",
    "impairment_loss": "资产及信用减值损失",
    "cash_net_increase": "现金及现金等价物净增加额",
}

P0_KEYS = online_finance.P0_KEYS


def _f(v):
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _div(a, b):
    a, b = _f(a), _f(b)
    if a is None or b in (None, 0):
        return None
    return a / b


def _avg(a, b):
    a, b = _f(a), _f(b)
    if a is None and b is None:
        return None
    if a is None:
        return b
    if b is None:
        return a
    return (a + b) / 2


def _pct(n, d):
    x = _div(n, d)
    return None if x is None else x * 100


def _growth(cur, prev):
    x = _div(cur, prev)
    return None if x is None else (x - 1) * 100


def _round(v, n=4):
    if v is None:
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return round(v, n)
    return v


def _fmt_yi(v):
    if v is None:
        return "—"
    return f"{v / 1e8:,.2f}"


def _fmt_pct(v, digits=1):
    return "—" if v is None else f"{v:.{digits}f}%"


def _fmt_pp(v, digits=1):
    return "—" if v is None else f"{v:+.{digits}f}pp"


# ---------------------------------------------------------------- PDF -> canonical

def _find_extracted(code: str, year: int) -> Path | None:
    hits = sorted(EXTRACTED.glob(f"*_{code}_{year}.json"))
    return hits[0] if hits else None


def _scope_of(rec: dict) -> str:
    basis = (rec.get("basis") or "").strip()
    if basis.startswith("合并"):
        return "合并报表"
    if basis.startswith("母公司"):
        return "母公司报表"
    return "未标注"


def from_pdf_financials(path: Path, year: int) -> tuple[dict, dict, list]:
    """把 indicators.py 的输出转成 canonical financials、company、sources。"""
    raw = json.loads(path.read_text(encoding="utf-8"))
    rows = raw.get("financials") or {}
    financials = {}
    sources = []
    seq = 0
    for legacy, rec in rows.items():
        key = LEGACY_TO_CANON.get(legacy, legacy)
        if key in financials:
            continue
        series = {str(k): _f(v) for k, v in (rec.get("series") or {}).items()}
        series = {k: v for k, v in series.items() if _f(v) is not None}
        value = _f(rec.get("value"))
        prior = series.get(str(year - 1))
        status = rec.get("status") or ("found" if value is not None else "not_found")
        if value is None and status == "found":
            status = "not_found"
        sid = None
        if status == "found":
            seq += 1
            sid = f"S{seq:02d}"
            sources.append({
                "source_id": sid, "metric": key, "source_type": "pdf",
                "source": rec.get("source") or path.stem,
                "source_url": None, "source_field": None,
                "page": rec.get("page"), "pdf_page": rec.get("pdf_page"),
                "pdf_url": f"/files/reports/{quote(path.stem + '.pdf')}",
                "upload_id": path.stem,
                "retrieved_at": None,
                "quote": (rec.get("raw_text") or "")[:500] or None,
                "purpose": "财务数据",
            })
        financials[key] = {
            "metric": key,
            "label": CANON_LABEL.get(key, rec.get("label") or key),
            "value": value,
            "value_original": rec.get("value_original"),
            "unit": "元",
            "unit_raw": rec.get("unit_raw"),
            "period": str(year),
            "prior_value": prior,
            "prior_period": str(year - 1),
            "series": series,
            "basis": rec.get("basis"),
            "scope": _scope_of(rec),
            "source_id": sid,
            "source_type": "pdf",
            "source": rec.get("source") or path.stem,
            "source_url": None,
            "source_field": None,
            "page": rec.get("page"),
            "pdf_page": rec.get("pdf_page"),
            "raw_text": rec.get("raw_text"),
            "section": rec.get("section"),
            "table": rec.get("table"),
            "confidence": rec.get("confidence"),
            "status": status,
            "status_note": rec.get("reason") or rec.get("status_note"),
        }

    # 所有者权益合计不能小于归母净资产。个别年报的权益变动表也会出现
    # 「所有者权益合计」，抽取时可能取到变动表里的期初数。用会计恒等式
    # （资产总计 - 负债合计）校正，并在 status_note 里写清是倒算值。
    te = financials.get("total_equity")
    ep = financials.get("equity_parent")
    ta = financials.get("total_assets")
    tl = financials.get("total_liabilities")
    if (te and ep and ta and tl and te.get("value") is not None
            and ep.get("value") is not None and te["value"] < ep["value"]
            and ta.get("value") is not None and tl.get("value") is not None):
        derived = ta["value"] - tl["value"]
        if derived > 0:
            note = "报告权益低于归母权益，按资产总计-负债合计倒算"
            te["value"] = derived
            te.setdefault("series", {})[str(year)] = derived
            te["page"] = ta.get("page")
            te["pdf_page"] = ta.get("pdf_page")
            te["source_id"] = ta.get("source_id")
            te["raw_text"] = (f"按资产总计 - 负债合计倒算："
                              f"{ta['value']:.2f} - {tl['value']:.2f} = {derived:.2f}")
            te["status_note"] = note
            for s in sources:
                if s.get("metric") == "total_equity":
                    s.update(page=te.get("page"), pdf_page=te.get("pdf_page"),
                             quote=te["raw_text"], source_id=te.get("source_id"))

    company = dict(raw.get("company") or {})
    raw_ticker = str(company.get("ticker") or path.stem.split("_")[1])
    if "." not in raw_ticker:
        suffix = {"sse": "SH", "szse": "SZ", "bse": "BJ"}.get(
            identify.exchange_of(path.stem.split("_")[1]), "SZ")
        raw_ticker = f"{raw_ticker}.{suffix}"
    company.update({
        "ticker": raw_ticker,
        "exchange": {"sse": "上海证券交易所", "szse": "深圳证券交易所",
                     "bse": "北京证券交易所"}.get(
                         identify.exchange_of(path.stem.split("_")[1])),
        "report_period": str(year),
        "report_type": "年度报告",
        "currency": "CNY",
        "amount_unit": "元",
        "scope": "合并报表",
        "source_url": None,
    })
    return financials, company, sources


# ---------------------------------------------------------------- 比率

def _series_get(rec: dict | None, year: int):
    if not rec:
        return None
    if str(year) == str(rec.get("period")):
        return _f(rec.get("value"))
    return _f((rec.get("series") or {}).get(str(year)))


def _ratio_specs():
    """返回 [(key, 中文名, 类别, 单位, 公式, 计算函数, 依赖科目, 越大越好, role)]。

    计算函数签名为 fn(v, year) -> (value, inputs)。v 是取值助手：
    v(key, year=None) 取科目值；缺数据返回 None，比率就标 not_evaluable。
    """
    return [
        ("revenue_growth_yoy", "营业收入同比", "growth", "%",
         "revenue_t / revenue_t-1 - 1",
         lambda v, y: (_growth(v("revenue", y), v("revenue", y - 1)),
                       {"revenue": v("revenue", y), "prior_revenue": v("revenue", y - 1)}),
         ["revenue"], True, "core"),
        ("net_income_parent_growth_yoy", "归母净利同比", "growth", "%",
         "net_income_parent_t / net_income_parent_t-1 - 1",
         lambda v, y: (_growth(v("net_income_parent", y), v("net_income_parent", y - 1)),
                       {"net_income_parent": v("net_income_parent", y),
                        "prior_net_income_parent": v("net_income_parent", y - 1)}),
         ["net_income_parent"], True, "core"),
        ("net_income_growth_yoy", "净利润同比", "growth", "%",
         "net_income_t / net_income_t-1 - 1",
         lambda v, y: (_growth(v("net_income", y), v("net_income", y - 1)),
                       {"net_income": v("net_income", y),
                        "prior_net_income": v("net_income", y - 1)}),
         ["net_income"], True, "diagnostic"),

        ("gross_margin", "毛利率", "profitability", "%",
         "(revenue - operating_cost) / revenue",
         lambda v, y: (((v("revenue", y) - v("operating_cost", y)) / v("revenue", y) * 100)
                       if v("revenue", y) not in (None, 0) and v("operating_cost", y) is not None
                       else None,
                       {"revenue": v("revenue", y), "operating_cost": v("operating_cost", y)}),
         ["revenue", "operating_cost"], True, "core"),
        ("net_margin_parent", "归母净利率", "profitability", "%",
         "net_income_parent / revenue",
         lambda v, y: (_pct(v("net_income_parent", y), v("revenue", y)),
                       {"net_income_parent": v("net_income_parent", y),
                        "revenue": v("revenue", y)}),
         ["net_income_parent", "revenue"], True, "core"),
        ("net_margin", "净利率", "profitability", "%",
         "net_income / revenue",
         lambda v, y: (_pct(v("net_income", y), v("revenue", y)),
                       {"net_income": v("net_income", y), "revenue": v("revenue", y)}),
         ["net_income", "revenue"], True, "diagnostic"),
        ("roe", "ROE（平均归母净资产）", "profitability", "%",
         "net_income_parent / avg(equity_parent_t, equity_parent_t-1)",
         lambda v, y: (_pct(v("net_income_parent", y),
                            _avg(v("equity_parent", y), v("equity_parent", y - 1))),
                       {"net_income_parent": v("net_income_parent", y),
                        "equity_parent": v("equity_parent", y),
                        "prior_equity_parent": v("equity_parent", y - 1)}),
         ["net_income_parent", "equity_parent"], True, "core"),
        ("roa", "ROA（平均总资产）", "profitability", "%",
         "net_income / avg(total_assets_t, total_assets_t-1)",
         lambda v, y: (_pct(v("net_income", y),
                            _avg(v("total_assets", y), v("total_assets", y - 1))),
                       {"net_income": v("net_income", y), "total_assets": v("total_assets", y),
                        "prior_total_assets": v("total_assets", y - 1)}),
         ["net_income", "total_assets"], True, "diagnostic"),

        ("cfo_to_revenue", "经营现金流收入比", "cashflow", "%",
         "cfo / revenue",
         lambda v, y: (_pct(v("cfo", y), v("revenue", y)),
                       {"cfo": v("cfo", y), "revenue": v("revenue", y)}),
         ["cfo", "revenue"], True, "core"),
        ("net_cash_ratio", "净现比", "cashflow", "%",
         "cfo / net_income_parent",
         lambda v, y: (_pct(v("cfo", y), v("net_income_parent", y)),
                       {"cfo": v("cfo", y), "net_income_parent": v("net_income_parent", y)}),
         ["cfo", "net_income_parent"], True, "core"),
        ("fcf_margin", "自由现金流利润率", "cashflow", "%",
         "(cfo - capex) / revenue",
         lambda v, y: (((v("cfo", y) - v("capex", y)) / v("revenue", y) * 100)
                       if v("cfo", y) is not None and v("capex", y) is not None
                       and v("revenue", y) not in (None, 0) else None,
                       {"cfo": v("cfo", y), "capex": v("capex", y), "revenue": v("revenue", y)}),
         ["cfo", "capex", "revenue"], True, "diagnostic"),
        ("cash_received_ratio", "销售收现比", "cashflow", "%",
         "cash_received_from_sales / revenue",
         lambda v, y: (_pct(v("cash_received_from_sales", y), v("revenue", y)),
                       {"cash_received_from_sales": v("cash_received_from_sales", y),
                        "revenue": v("revenue", y)}),
         ["cash_received_from_sales", "revenue"], True, "diagnostic"),

        ("debt_to_asset", "资产负债率", "solvency", "%",
         "total_liabilities / total_assets",
         lambda v, y: (_pct(v("total_liabilities", y), v("total_assets", y)),
                       {"total_liabilities": v("total_liabilities", y),
                        "total_assets": v("total_assets", y)}),
         ["total_liabilities", "total_assets"], False, "core"),
        ("current_ratio", "流动比率", "solvency", "倍",
         "current_assets / current_liabilities",
         lambda v, y: (_div(v("current_assets", y), v("current_liabilities", y)),
                       {"current_assets": v("current_assets", y),
                        "current_liabilities": v("current_liabilities", y)}),
         ["current_assets", "current_liabilities"], True, "core"),
        ("cash_ratio", "现金比率", "solvency", "倍",
         "cash_and_equivalents / current_liabilities",
         lambda v, y: (_div(v("cash_and_equivalents", y), v("current_liabilities", y)),
                       {"cash_and_equivalents": v("cash_and_equivalents", y),
                        "current_liabilities": v("current_liabilities", y)}),
         ["cash_and_equivalents", "current_liabilities"], True, "diagnostic"),
        ("net_debt_to_equity", "净负债率", "solvency", "%",
         "(有息负债 - 货币资金) / equity_parent",
         lambda v, y: _net_debt_ratio(v, y),
         ["short_term_borrowings", "current_portion_lt_debt", "long_term_borrowings",
          "bonds_payable", "cash_and_equivalents", "equity_parent"], False, "diagnostic"),
        ("interest_coverage", "利息保障倍数", "solvency", "倍",
         "operating_profit / interest_expense",
         lambda v, y: (_div(v("operating_profit", y), v("interest_expense", y)),
                       {"operating_profit": v("operating_profit", y),
                        "interest_expense": v("interest_expense", y)}),
         ["operating_profit", "interest_expense"], True, "diagnostic"),

        ("asset_turnover", "总资产周转率", "efficiency", "次",
         "revenue / avg(total_assets_t, total_assets_t-1)",
         lambda v, y: (_div(v("revenue", y),
                            _avg(v("total_assets", y), v("total_assets", y - 1))),
                       {"revenue": v("revenue", y), "total_assets": v("total_assets", y),
                        "prior_total_assets": v("total_assets", y - 1)}),
         ["revenue", "total_assets"], True, "diagnostic"),
        ("ar_turnover_days", "应收账款周转天数", "efficiency", "天",
         "365 × avg(accounts_receivable) / revenue",
         lambda v, y: (_div(365 * _avg(v("accounts_receivable", y),
                                      v("accounts_receivable", y - 1)), v("revenue", y)),
                       {"accounts_receivable": v("accounts_receivable", y),
                        "prior_accounts_receivable": v("accounts_receivable", y - 1),
                        "revenue": v("revenue", y)}),
         ["accounts_receivable", "revenue"], False, "diagnostic"),
        ("inventory_turnover_days", "存货周转天数", "efficiency", "天",
         "365 × avg(inventory) / operating_cost",
         lambda v, y: (_div(365 * _avg(v("inventory", y), v("inventory", y - 1)),
                            v("operating_cost", y)),
                       {"inventory": v("inventory", y),
                        "prior_inventory": v("inventory", y - 1),
                        "operating_cost": v("operating_cost", y)}),
         ["inventory", "operating_cost"], False, "diagnostic"),

        ("rd_to_revenue", "研发费用率", "investment", "%",
         "rnd_expense / revenue",
         lambda v, y: (_pct(v("rnd_expense", y), v("revenue", y)),
                       {"rnd_expense": v("rnd_expense", y), "revenue": v("revenue", y)}),
         ["rnd_expense", "revenue"], True, "diagnostic"),
        ("capex_to_revenue", "资本开支收入比", "investment", "%",
         "capex / revenue",
         lambda v, y: (_pct(v("capex", y), v("revenue", y)),
                       {"capex": v("capex", y), "revenue": v("revenue", y)}),
         ["capex", "revenue"], None, "diagnostic"),
        ("ebitda_margin", "EBITDA 利润率（近似）", "investment", "%",
         "(operating_profit + depreciation_amortization) / revenue",
         lambda v, y: _ebitda_margin(v, y),
         ["operating_profit", "depreciation_amortization", "revenue"], True, "diagnostic"),
    ]


def _net_debt_ratio(v, y):
    parts = [v(k, y) for k in ("short_term_borrowings", "current_portion_lt_debt",
                               "long_term_borrowings", "bonds_payable")]
    have = [p for p in parts if p is not None]
    if not have:
        return None, {"interest_bearing_debt": None, "cash_and_equivalents": v("cash_and_equivalents", y),
                      "equity_parent": v("equity_parent", y)}
    ibd = sum(have)
    cash = v("cash_and_equivalents", y) or 0.0
    equity = v("equity_parent", y)
    val = _pct(ibd - cash, equity)
    inputs = {"interest_bearing_debt": ibd, "cash_and_equivalents": v("cash_and_equivalents", y),
              "equity_parent": equity}
    if len(have) < 4:
        inputs["note"] = "部分有息负债科目未列示，按已列示项加总"
    return val, inputs


def _ebitda_margin(v, y):
    op = v("operating_profit", y)
    da = v("depreciation_amortization", y)
    rev = v("revenue", y)
    if op is None or rev in (None, 0):
        return None, {"operating_profit": op, "depreciation_amortization": da, "revenue": rev}
    ebitda = op + (da or 0.0)
    return ebitda / rev * 100, {"operating_profit": op, "depreciation_amortization": da,
                                "ebitda": ebitda, "revenue": rev}


def compute_ratios(financials: dict, year: int) -> dict:
    def v(key, y=None):
        return _series_get(financials.get(key), y or year)

    years = sorted({int(y) for rec in financials.values()
                    for y in (rec.get("series") or {}) if str(y).isdigit()})
    out = {}
    for key, name, category, unit, formula, fn, deps, higher, role in _ratio_specs():
        try:
            val, inputs = fn(v, year)
            prev, _ = fn(v, year - 1)
        except Exception:  # noqa: BLE001 - 单个比率算不出来不能拖垮整页
            val, inputs, prev = None, {}, None
        status = "ok" if val is not None else "not_evaluable"
        delta = None if (val is None or prev is None) else val - prev
        series = {}
        for y in years:
            try:
                yv, _ = fn(v, y)
            except Exception:  # noqa: BLE001
                yv = None
            if yv is not None:
                series[str(y)] = _round(yv)
        out[key] = {
            "key": key, "name": name, "category": category, "unit": unit,
            "value": _round(val), "prev": _round(prev), "delta": _round(delta),
            "formula": formula, "inputs": {k: _round(x) for k, x in inputs.items()},
            "source_fields": deps, "status": status,
            "higher_is_better": higher, "role": role, "series": series,
        }
    return out


# ---------------------------------------------------------------- 数据质量

def _check(code: str, status: str, detail: str, metric=None, rec=None) -> dict:
    return {
        "code": code, "status": status, "detail": detail, "metric": metric,
        "page": (rec or {}).get("page"), "pdf_page": (rec or {}).get("pdf_page"),
        "source_id": (rec or {}).get("source_id"),
    }


def quality_checks(financials: dict, year: int) -> dict:
    checks = []
    assets = _series_get(financials.get("total_assets"), year)
    liab = _series_get(financials.get("total_liabilities"), year)
    eq_parent = _series_get(financials.get("equity_parent"), year)
    eq_total = _series_get(financials.get("total_equity"), year)
    rec_a = financials.get("total_assets")

    if assets and liab is not None and (eq_total is not None or eq_parent is not None):
        eq = eq_total if eq_total is not None else eq_parent
        diff = abs(assets - (liab + eq))
        ratio = diff / abs(assets) * 100 if assets else 999
        if eq_total is not None:
            status = "pass" if ratio <= 0.5 else "warn"
            detail = f"资产 = 负债 + 权益，差异 {ratio:.2f}%"
        else:
            status = "pass" if ratio <= 5 else "warn"
            detail = (f"仅归母权益口径，资产与负债+归母权益差异 {ratio:.2f}%"
                      "（差额含少数股东权益）")
        checks.append(_check("BALANCE_SHEET", status, detail, "total_assets", rec_a))
    else:
        checks.append(_check("BALANCE_SHEET", "not_evaluable", "资产、负债或权益缺失", "total_assets", rec_a))

    derived = [k for k, r in financials.items()
               if "倒算" in str(r.get("status_note") or "")]
    checks.append(_check("EQUITY_SANITY", "warn" if derived else "pass",
                         ("以下科目按会计恒等式倒算：" + "、".join(derived)) if derived
                         else "权益与资产-负债关系正常",
                         derived[0] if derived else None,
                         financials.get(derived[0]) if derived else None))

    rev = _series_get(financials.get("revenue"), year)
    cost = _series_get(financials.get("operating_cost"), year)
    rec_c = financials.get("operating_cost")
    if rev and cost is not None:
        ok = cost <= rev * 2
        checks.append(_check("COST_VS_REVENUE", "pass" if ok else "blocked",
                             f"营业成本 / 营业收入 = {cost / rev:.2f}", "operating_cost", rec_c))
    else:
        checks.append(_check("COST_VS_REVENUE", "not_evaluable", "收入或成本缺失", "operating_cost", rec_c))

    gm = None
    if rev and cost is not None:
        gm = (rev - cost) / rev * 100
        checks.append(_check("GROSS_MARGIN_RANGE", "pass" if -100 <= gm <= 100 else "blocked",
                             f"毛利率 {gm:.2f}%", "gross_margin", rec_c))
    else:
        checks.append(_check("GROSS_MARGIN_RANGE", "not_evaluable", "收入或成本缺失", "gross_margin", rec_c))

    if assets and liab is not None:
        dr = liab / assets * 100
        checks.append(_check("DEBT_RATIO_RANGE", "pass" if 0 <= dr <= 100 else "blocked",
                             f"资产负债率 {dr:.2f}%", "debt_to_asset", financials.get("total_liabilities")))
    else:
        checks.append(_check("DEBT_RATIO_RANGE", "not_evaluable", "资产或负债缺失", "debt_to_asset", None))

    growth = None
    prior_rev = _series_get(financials.get("revenue"), year - 1)
    if rev and prior_rev:
        growth = (rev / prior_rev - 1) * 100
        checks.append(_check("GROWTH_RANGE", "pass" if -500 <= growth <= 500 else "blocked",
                             f"营业收入同比 {growth:.2f}%", "revenue_growth_yoy", financials.get("revenue")))
    else:
        checks.append(_check("GROWTH_RANGE", "not_evaluable", "缺上期收入", "revenue_growth_yoy",
                             financials.get("revenue")))

    # 只查主表大科目。应收票据这类小科目从几十万变到十几亿是业务事实，
    # 拿它去 block 整份数据，会把正常公司误判成单位错。
    core_scale_keys = {
        "revenue", "operating_cost", "net_income", "net_income_parent",
        "total_assets", "total_liabilities", "equity_parent", "total_equity",
        "cfo", "capex", "cash_and_equivalents",
    }
    bad_scale = []
    for key, rec in financials.items():
        if key not in core_scale_keys:
            continue
        vals = [abs(x) for x in (rec.get("series") or {}).values()
                if isinstance(x, (int, float)) and x != 0]
        if len(vals) >= 2 and max(vals) / min(vals) > 100:
            bad_scale.append(key)
    checks.append(_check("SERIES_SCALE", "pass" if not bad_scale else "blocked",
                         "三年量级正常" if not bad_scale else "量级异常：" + "、".join(bad_scale[:5]),
                         None, financials.get("revenue")))

    cfo = _series_get(financials.get("cfo"), year)
    cfi = _series_get(financials.get("cfi"), year)
    cff = _series_get(financials.get("cff"), year)
    # 必须用「现金及现金等价物净增加额」勾稽，不能用货币资金差额：货币资金含
    # 受限资金、拆出资金等，和现金流量表的口径本来就不是一回事。
    net_inc = _series_get(financials.get("cash_net_increase"), year)
    if all(x is not None for x in (cfo, cfi, cff)) and net_inc is not None:
        diff = abs((cfo + cfi + cff) - net_inc)
        limit = max(abs(net_inc) * 0.05, (assets or 0) * 0.01)
        checks.append(_check("CASH_FLOW_BRIDGE", "pass" if diff <= limit else "warn",
                             f"经营+投资+筹资与现金净增加差 {diff / 1e8:.2f} 亿元",
                             "cfo", financials.get("cfo")))
    else:
        checks.append(_check("CASH_FLOW_BRIDGE", "not_evaluable",
                             "缺现金及现金等价物净增加额，无法直接勾稽",
                             "cfo", financials.get("cfo")))

    parent_only = [k for k, r in financials.items() if r.get("scope") == "母公司报表"]
    checks.append(_check("PARENT_ONLY", "warn" if parent_only else "pass",
                         "存在母公司报表口径" if parent_only else "合并报表口径",
                         parent_only[0] if parent_only else None,
                         financials.get(parent_only[0]) if parent_only else None))

    found = [r for r in financials.values() if r.get("status") == "found"]
    missing_source = [r["metric"] for r in found
                      if not (r.get("page") or r.get("source_field"))]
    checks.append(_check("SOURCE_COMPLETE", "pass" if not missing_source else "warn",
                         "每个命中科目都有来源" if not missing_source
                         else "缺来源：" + "、".join(missing_source[:5]),
                         None, None))

    statuses = [c["status"] for c in checks]
    if "blocked" in statuses:
        overall, blocked = "blocked", True
    elif "warn" in statuses:
        overall, blocked = "warn", False
    else:
        overall, blocked = "ok", False
    return {"status": overall, "blocked": blocked, "checks": checks}


# ---------------------------------------------------------------- 结论摘要

def industry_support(industry: str | None) -> str:
    text = industry or ""
    if any(k in text for k in ("银行", "保险", "证券", "房地产", "地产")):
        return "unsupported"
    if not text or text == "未识别":
        return "limited"
    return "supported"


def build_summary(company: dict, financials: dict, ratios: dict, quality: dict, year: int) -> dict:
    rev = _series_get(financials.get("revenue"), year)
    rev_prev = _series_get(financials.get("revenue"), year - 1)
    ni = _series_get(financials.get("net_income_parent"), year)
    ni_prev = _series_get(financials.get("net_income_parent"), year - 1)
    cfo = _series_get(financials.get("cfo"), year)
    gm = ratios.get("gross_margin", {}).get("value")
    roe = ratios.get("roe", {}).get("value")
    debt = ratios.get("debt_to_asset", {}).get("value")
    cash_ratio = ratios.get("net_cash_ratio", {}).get("value")

    def g(cur, prev):
        if cur is None or prev in (None, 0):
            return None
        return (cur / prev - 1) * 100

    rev_g = g(rev, rev_prev)
    ni_g = g(ni, ni_prev)

    headline = (
        f"{year} 年营业收入 {_fmt_yi(rev)} 亿元，同比 {_fmt_pct(rev_g)}；"
        f"归母净利润 {_fmt_yi(ni)} 亿元，同比 {_fmt_pct(ni_g)}；"
        f"毛利率 {_fmt_pct(gm)}。"
    )

    points = []
    if rev_g is not None:
        tone = "good" if rev_g >= 0 else "bad"
        points.append({"label": "成长", "tone": tone,
                       "text": f"收入同比 {_fmt_pct(rev_g)}，归母净利同比 {_fmt_pct(ni_g)}。"})
    if gm is not None:
        points.append({"label": "盈利", "tone": "neutral",
                       "text": f"毛利率 {_fmt_pct(gm)}，ROE {_fmt_pct(roe)}。"})
    if cash_ratio is not None:
        tone = "good" if cash_ratio >= 100 else ("warn" if cash_ratio >= 70 else "bad")
        points.append({"label": "现金", "tone": tone,
                       "text": f"净现比 {_fmt_pct(cash_ratio)}，经营现金流 {_fmt_yi(cfo)} 亿元。"})
    if debt is not None:
        tone = "good" if debt <= 50 else ("warn" if debt <= 70 else "bad")
        points.append({"label": "杠杆", "tone": tone,
                       "text": f"资产负债率 {_fmt_pct(debt)}。"})

    focus = []
    if rev_g is not None and rev_g < 0:
        focus.append("收入转负，先看分产品/分地区拆分与价格、销量变化")
    if cash_ratio is not None and cash_ratio < 80:
        focus.append("净现比偏低，核对应收、存货与合同负债的变化")
    if debt is not None and debt > 65:
        focus.append("杠杆偏高，核对有息负债期限结构与利息保障")
    if gm is not None and gm < 20:
        focus.append("毛利率偏低，核对成本结构与同业价格")
    if not focus:
        focus.append("核心指标未见明显异常，下一步核对收入确认与现金流匹配")

    return {
        "headline": headline,
        "points": points,
        "focus": "；".join(focus) + "。",
        "quality_note": ("数据质量检查通过" if quality.get("status") == "ok"
                         else ("数据存在异常，估值类结论不可用" if quality.get("blocked")
                               else "数据有提示项，结论需结合原文复核")),
    }


# ---------------------------------------------------------------- 组装

def _attach_ratios_quality_summary(payload: dict, year: int) -> dict:
    fins = payload["financials"]
    ratios = compute_ratios(fins, year)
    quality = quality_checks(fins, year)
    summary = build_summary(payload["company"], fins, ratios, quality, year)
    payload["ratios"] = ratios
    payload["data_quality"] = quality
    payload["summary"] = summary
    payload["coverage"] = {
        "p0_total": len(P0_KEYS),
        "p0_found": sum(1 for k in P0_KEYS if fins.get(k, {}).get("status") == "found"),
        "p0_missing": [k for k in P0_KEYS if fins.get(k, {}).get("status") != "found"],
        "sources": len(payload.get("sources") or []),
    }
    payload["industry_support"] = industry_support(payload["company"].get("industry"))
    return payload


def build_online_cockpit(code: str, year: int, force: bool = False) -> dict:
    payload = online_finance.build_online_financials(code, year, force=force)
    payload["mode"] = "online"
    payload["company"]["name"] = payload["company"].get("name") or code
    try:
        report = online_finance.find_annual_report(code, year)
    except online_finance.OnlineError:
        report = None
    payload["report"] = report
    if report:
        payload["company"]["source_url"] = report.get("page_url")
        payload["company"]["report_title"] = report.get("title")
    payload["meta"]["mode_label"] = "在线快照"
    return _attach_ratios_quality_summary(payload, year)


def build_pdf_cockpit(code: str, year: int) -> dict:
    path = _find_extracted(code, year)
    if not path:
        raise FileNotFoundError(f"还没有 {code} {year} 的年报解析结果")
    fins, company, sources = from_pdf_financials(path, year)
    stem = path.stem
    pdf_path = ANNUAL_DIR / f"{stem}.pdf"
    meta = {
        "key": f"{company.get('ticker')}_{year}",
        "source_mode": "upload",
        "report_period": str(year),
        "period_type": "annual",
        "currency": "CNY",
        "amount_unit": "元",
        "consolidated": True,
        "data_source": "annual_report_pdf",
        "data_as_of": f"{year}-12-31",
        "parsed_at": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "years": [str(y) for y in sorted({int(k) for r in fins.values()
                                          for k in (r.get("series") or {})})],
        "pdf": pdf_path.name if pdf_path.exists() else None,
        "pdf_url": (f"/files/reports/{quote(pdf_path.name)}" if pdf_path.exists() else None),
        "mode_label": "年报原文",
    }
    company["source_url"] = meta["pdf_url"]
    company.setdefault("name_full", company.get("name"))
    # PDF 抽取结果里的 industry 来自 companies.json，任意公司可能没有。
    # 补一次在线公司资料，取不到就维持“未识别”，不猜。
    try:
        profile = online_finance.company_profile(code)
        if not company.get("industry") or company.get("industry") == "未识别":
            company["industry"] = profile.get("industry") or "未识别"
        company["name_short"] = profile.get("name_short") or company.get("name")
    except Exception:  # noqa: BLE001
        pass
    # 文件名里的公司简称通常比全称更适合标题：格力电器_000651_2025 -> 格力电器。
    stem_name = path.stem.split("_")[0]
    if stem_name and len(stem_name) < len(str(company.get("name_short") or "")):
        company["name_short"] = stem_name
    payload = {
        "schema_version": "2.0",
        "mode": "pdf",
        "meta": meta, "company": company,
        "financials": fins, "sources": sources,
        "report": {
            "title": f"{company.get('name', '')}{year}年年度报告",
            "page_url": meta["pdf_url"],
            "pdf_url": meta["pdf_url"],
            "source": "本地年报 PDF",
            "year": year,
        },
    }
    return _attach_ratios_quality_summary(payload, year)


def build_cockpit(code: str, year: int, mode: str = "auto") -> dict:
    code = str(code or "").strip()
    if not re.fullmatch(r"\d{6}", code):
        raise online_finance.OnlineError("E_CODE_FORMAT", "股票代码是 6 位数字，例如 600519",
                                         "请检查输入")
    if mode == "pdf":
        return build_pdf_cockpit(code, year)
    if mode == "online":
        return build_online_cockpit(code, year)
    try:
        return build_pdf_cockpit(code, year)
    except FileNotFoundError:
        return build_online_cockpit(code, year)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    code = sys.argv[1] if len(sys.argv) > 1 else "600519"
    year = int(sys.argv[2]) if len(sys.argv) > 2 else online_finance.latest_annual_year()
    mode = sys.argv[3] if len(sys.argv) > 3 else "auto"
    out = build_cockpit(code, year, mode)
    print(json.dumps({
        "mode": out["mode"], "meta": out["meta"], "summary": out["summary"],
        "coverage": out["coverage"], "quality": out["data_quality"]["status"],
        "ratios_ok": sum(1 for r in out["ratios"].values() if r["status"] == "ok"),
    }, ensure_ascii=False, indent=1, default=str))
