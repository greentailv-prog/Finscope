# -*- coding: utf-8 -*-
"""给已有的 data/extracted/*.json 补顶层 sources[]，不重跑抽取。

04 §4.5 要求 A 的输出带 sources[]。抽取本身已经记录了每个科目的 page/pdf_page/
raw_text，这里只做归集，几秒钟跑完，避免为了加一个数组再解析一遍 PDF。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from urllib.parse import quote

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
from cockpit import LEGACY_TO_CANON  # noqa: E402

ROOT = SRC.parent
EXTRACTED = ROOT / "data" / "extracted"


def main() -> int:
    n = 0
    for path in sorted(EXTRACTED.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        fins = data.get("financials") or {}
        sources = []
        seq = 0
        for key, rec in fins.items():
            if rec.get("status") != "found":
                continue
            seq += 1
            sources.append({
                "source_id": f"S{seq:02d}",
                "metric": LEGACY_TO_CANON.get(key, key),
                "source_type": "pdf",
                "source": rec.get("source") or path.stem,
                "source_url": None,
                "source_field": None,
                "page": rec.get("page"),
                "pdf_page": rec.get("pdf_page"),
                "pdf_url": f"/files/reports/{quote(path.stem + '.pdf')}",
                "upload_id": path.stem,
                "retrieved_at": None,
                "quote": (rec.get("raw_text") or "")[:500] or None,
                "purpose": "财务数据",
            })
        data["schema_version"] = "2.0"
        data["sources"] = sources
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
        n += 1
    print(f"{n} 份抽取结果已补 sources[]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
