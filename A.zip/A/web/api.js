// 与本地服务通信。探测不到后端时所有能力默认关闭，页面退回纯静态行为。
//
// 所有变更类请求都带 X-FS-Client 头：它不是简单头，会触发 CORS 预检，而服务端
// 不回任何 CORS 头，所以别的网页即使猜到端口也发不出跨站请求。

(function (global) {
  'use strict';

  var HEADER = 'X-FS-Client';

  function timeout(promise, ms) {
    return Promise.race([promise, new Promise(function (_, rej) {
      setTimeout(function () { rej(new Error('timeout')); }, ms);
    })]);
  }

  function req(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || 'GET', headers: {} };
    if (opts.json !== undefined) {
      init.method = 'POST';
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(opts.json);
    }
    if (init.method !== 'GET') init.headers[HEADER] = '1';
    if (opts.headers) Object.keys(opts.headers).forEach(function (k) {
      init.headers[k] = opts.headers[k];
    });
    if (opts.body !== undefined) init.body = opts.body;
    init.cache = 'no-store';
    return fetch(path, init).then(function (r) {
      return r.text().then(function (t) {
        var data;
        try { data = JSON.parse(t); } catch (e) { data = { error: t.slice(0, 200) }; }
        if (!r.ok) throw new Error((data && data.error) || ('HTTP ' + r.status));
        return data;
      });
    });
  }

  var api = {
    available: false,
    health: null,

    // file:// 下不可能有后端，直接判定；http 下给 1.2 秒探测窗口。
    probe: function () {
      if (location.protocol === 'file:') return Promise.resolve(false);
      return timeout(req('api/health'), 1200).then(function (h) {
        api.available = !!(h && h.ok);
        api.health = h;
        return api.available;
      }).catch(function () {
        api.available = false;
        return false;
      });
    },

    config: function () { return req('api/config'); },
    saveConfig: function (patch) { return req('api/config', { json: patch }); },
    ingest: function (code, year) {
      return req('api/ingest', { json: { code: code, year: year || 2025 } });
    },
    job: function (id) { return req('api/job?id=' + encodeURIComponent(id)); },
    jobs: function () { return req('api/jobs'); },
    cancel: function (id) { return req('api/job/cancel', { json: { id: id } }); },
    ask: function (q, codes, useSearch) {
      return req('api/ask', { json: { q: q, codes: codes || null, use_search: useSearch } });
    },
    llmTest: function () { return req('api/llm-test', { json: {} }); },

    // 上传走原始字节流（不用 multipart：Python 3.12 已移除 cgi，手写解析易错）
    upload: function (file, meta) {
      var headers = { 'Content-Type': 'application/octet-stream',
                      'X-FS-Filename': encodeURIComponent(file.name) };
      if (meta && meta.code) headers['X-FS-Code'] = meta.code;
      if (meta && meta.name) headers['X-FS-Name'] = encodeURIComponent(meta.name);
      return req('api/upload', { method: 'POST', headers: headers, body: file });
    }
  };

  global.FSApi = api;
})(window);
