// 服务模式下才出现的三块面板：添加公司、设置、AI 问答。
//
// 刻意**不改 app.js 的闭包**：这里只往 <main> 里 append 新面板，元素一律 fs- 前缀，
// 不碰原有的 16 个 id。探测不到后端（file:// 直接开、或服务没起）时整个脚本直接返回，
// 页面上什么都不出现，静态双击页的行为与加这个文件之前一字不差。
//
// 事件一律用容器委托，不用 .preset 那套批量绑定——app.js 的 bind() 在 boot 早期就
// 取完了 .preset，晚插入的按钮不会被绑上。

(function () {
  'use strict';

  var JOB_KEY = 'finscope.currentJob';
  var pollTimer = null;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function $(sel) { return document.querySelector(sel); }
  function byId(id) { return document.getElementById(id); }

  function currentCode() {
    var on = $('#companies .chip.on');
    return on ? on.dataset.code : null;
  }
  function allCodes() {
    return Array.prototype.slice.call(document.querySelectorAll('#companies .chip'))
      .map(function (c) { return c.dataset.code; });
  }

  // ---------------------------------------------------------------- 添加公司

  function addPanel() {
    var s = document.createElement('section');
    s.className = 'panel fs-panel';
    s.innerHTML =
      '<div class="panel-head">' +
      '<h1>添加公司</h1>' +
      '<p class="lead">输入 A 股股票代码或公司名，后端会去巨潮资讯网下载该公司的年度报告，' +
      '跑完整抽取管线后并入看板与检索。一份完整年报约需 5-8 分钟，可关掉页面，回来接着看。</p>' +
      '</div>' +
      '<div class="fs-row">' +
      '<input id="fs-code" type="text" autocomplete="off" placeholder="股票代码或公司名，例如 000651 或 格力电器">' +
      '<button class="fs-btn" data-act="ingest">开始分析</button>' +
      '</div>' +
      '<div class="fs-row">' +
      '<label class="fs-drop" id="fs-drop">把年报 PDF 拖到这里，或点击选择文件' +
      '<input type="file" id="fs-file" accept="application/pdf" hidden></label>' +
      '</div>' +
      '<div id="fs-job" class="fs-job"></div>';
    return s;
  }

  function renderJob(job) {
    var box = byId('fs-job');
    if (!box || !job) return;
    var steps = (FSApi.health && FSApi.health.steps) || [];
    var idx = job.step_index || 0;
    var dots = steps.map(function (s, i) {
      var cls = i < idx ? 'done' : (i === idx && job.status === 'running' ? 'now' : '');
      return '<span class="fs-dot ' + cls + '" title="' + esc(s.label) + '">' + (i + 1) + '</span>';
    }).join('');

    var head = '<div class="fs-job-head">' +
      '<b>' + esc(job.step_label || '') + '</b>' +
      '<span class="fs-pct">' + (job.percent || 0) + '%</span></div>' +
      '<div class="fs-bar"><i style="width:' + (job.percent || 0) + '%"></i></div>' +
      '<div class="fs-dots">' + dots + '</div>';

    var status = '';
    if (job.status === 'done') {
      var r = job.result || {};
      status = '<div class="fs-ok">完成：' + esc(r.name || '') + '（' + esc(r.code || '') + '），'
        + '索引 ' + (r.n_chunks || 0) + ' 个块，指标命中 ' + (r.metrics_found == null ? '—' : r.metrics_found) + '/17。'
        + '<br>页面即将刷新以载入新公司…</div>';
    } else if (job.status === 'error') {
      status = '<div class="fs-err">失败：' + esc(job.error || '未知错误') + '</div>';
    } else if (job.status === 'cancelled') {
      status = '<div class="fs-warn">已取消</div>';
    } else if (job.status === 'interrupted') {
      status = '<div class="fs-warn">服务重启过，这个任务已中断。重新提交即可（已完成的步骤不会重跑）。</div>';
    }
    var warn = (job.result && job.result.warnings && job.result.warnings.length)
      ? '<div class="fs-warn">注意：' + job.result.warnings.map(esc).join('、') + '</div>' : '';

    var log = (job.log || []).slice(-14).map(function (l) {
      return '<div>' + esc(l) + '</div>';
    }).join('');

    var cancel = (job.status === 'running' || job.status === 'queued')
      ? '<button class="fs-btn ghost" data-act="cancel" data-id="' + esc(job.id) + '">取消</button>' : '';

    box.innerHTML = head + status + warn +
      '<pre class="fs-log">' + log + '</pre>' + cancel;

    if (job.status === 'done') {
      localStorage.removeItem(JOB_KEY);
      stopPoll();
      setTimeout(function () { location.reload(); }, 2500);
    } else if (['error', 'cancelled', 'interrupted'].indexOf(job.status) >= 0) {
      localStorage.removeItem(JOB_KEY);
      stopPoll();
    }
  }

  function stopPoll() {
    if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  }

  function watch(jobId) {
    localStorage.setItem(JOB_KEY, jobId);
    stopPoll();
    var tick = function () {
      FSApi.job(jobId).then(renderJob).catch(function () { stopPoll(); });
    };
    tick();
    pollTimer = setInterval(tick, 1200);
  }

  function startIngest() {
    var code = (byId('fs-code').value || '').trim();
    if (!code) { alert('请输入股票代码或公司名'); return; }
    if (/^\d+$/.test(code) && !/^\d{6}$/.test(code)) {
      alert('股票代码应为 6 位数字；也可以直接输入公司名');
      return;
    }
    byId('fs-job').innerHTML = '<div class="fs-warn">正在提交…</div>';
    FSApi.ingest(code, 2025).then(function (job) { watch(job.id); })
      .catch(function (e) { byId('fs-job').innerHTML = '<div class="fs-err">提交失败：' + esc(e.message) + '</div>'; });
  }

  function startUpload(file) {
    if (!file) return;
    if (!/\.pdf$/i.test(file.name)) { alert('请选择 PDF 文件'); return; }
    var codeBox = byId('fs-code');
    var meta = /^\d{6}$/.test((codeBox.value || '').trim()) ? { code: codeBox.value.trim() } : {};
    byId('fs-job').innerHTML = '<div class="fs-warn">正在上传并识别…（' +
      (file.size / 1e6).toFixed(1) + ' MB）</div>';
    FSApi.upload(file, meta).then(function (res) {
      byId('fs-job').innerHTML = '<div class="fs-ok">已识别为 ' + esc(res.name) +
        '（' + esc(res.code) + '，' + esc(res.year) + ' 年）</div>';
      watch(res.job.id);
    }).catch(function (e) {
      byId('fs-job').innerHTML = '<div class="fs-err">上传失败：' + esc(e.message) + '</div>';
    });
  }

  // ---------------------------------------------------------------- 设置

  function settingsPanel() {
    var s = document.createElement('section');
    s.className = 'panel fs-panel';
    s.innerHTML =
      '<div class="panel-head"><h1>设置</h1>' +
      '<p class="lead">密钥保存在用户目录（<code>~/.finscope/config.json</code>），**不在仓库里**——' +
      '用 GitHub 网页上传文件时不读 .gitignore，密钥放仓库里早晚会被传上去。' +
      '接口只回显密钥末四位。</p></div>' +
      '<div class="fs-grid">' +
      '<h3>大模型（OpenAI 兼容接口）</h3>' +
      '<div class="fs-row" id="fs-llm-presets"></div>' +
      '<label>接口地址 base_url<input id="fs-llm-url" placeholder="https://api.deepseek.com/v1"></label>' +
      '<label>模型名<input id="fs-llm-model" placeholder="deepseek-chat"></label>' +
      '<label>密钥<input id="fs-llm-key" type="password" placeholder="留空表示不修改"></label>' +
      '<h3>联网搜索</h3>' +
      '<label>供应商<select id="fs-search-provider"></select></label>' +
      '<label>接口地址（SearXNG 用）<input id="fs-search-url" placeholder="https://your-searxng.example"></label>' +
      '<label>密钥<input id="fs-search-key" type="password" placeholder="留空表示不修改"></label>' +
      '</div>' +
      '<div class="fs-row"><button class="fs-btn" data-act="save-config">保存设置</button>' +
      '<button class="fs-btn ghost" data-act="llm-test">测试大模型连接</button>' +
      '<button class="fs-btn ghost" data-act="clear-keys">清除已保存的密钥</button>' +
      '<span id="fs-save-msg" class="fs-warn"></span></div>';
    return s;
  }

  // 常见服务商的地址与模型名。顺序即展示顺序，DeepSeek 放第一个因为最常用。
  var LLM_PRESETS = [
    { name: 'DeepSeek', url: 'https://api.deepseek.com/v1', model: 'deepseek-chat' },
    { name: 'DeepSeek 推理', url: 'https://api.deepseek.com/v1', model: 'deepseek-reasoner' },
    { name: '通义千问', url: 'https://dashscope.aliyuncs.com/compatible-mode/v1', model: 'qwen-plus' },
    { name: '智谱 GLM', url: 'https://open.bigmodel.cn/api/paas/v4', model: 'glm-4-plus' },
    { name: 'Kimi', url: 'https://api.moonshot.cn/v1', model: 'moonshot-v1-8k' }
  ];

  function fillPresets() {
    var box = byId('fs-llm-presets');
    if (!box) return;
    box.innerHTML = '<span class="fs-hint">一键填充：</span>' +
      LLM_PRESETS.map(function (p, i) {
        return '<button class="fs-btn ghost small" data-act="llm-preset" data-i="' + i + '">' +
          esc(p.name) + '</button>';
      }).join('');
  }

  function applyPreset(i) {
    var p = LLM_PRESETS[i];
    if (!p) return;
    byId('fs-llm-url').value = p.url;
    byId('fs-llm-model').value = p.model;
    byId('fs-llm-key').focus();
    byId('fs-save-msg').textContent = '已填入 ' + p.name + '，请粘贴密钥后保存';
  }

  // 密钥留空表示「不修改」，所以清除必须走一个显式哨兵值，不能靠提交空串。
  function clearKeys() {
    if (!confirm('确定清除已保存的大模型与搜索密钥吗？')) return;
    FSApi.saveConfig({ llm: { api_key: '__CLEAR__' }, search: { api_key: '__CLEAR__' } })
      .then(function (res) {
        fillSettings(res.config);
        byId('fs-save-msg').textContent = '密钥已清除';
      }).catch(function (e) {
        byId('fs-save-msg').textContent = '清除失败：' + e.message;
      });
  }

  function testLlm() {
    var msg = byId('fs-save-msg');
    msg.textContent = '正在测试…';
    FSApi.llmTest().then(function (r) {
      msg.innerHTML = r.ok
        ? '<span class="fs-ok">连接正常</span>　模型 ' + esc(r.model) +
          '　回复「' + esc(r.reply) + '」'
        : '<span class="fs-err">失败：' + esc(r.error || '未知错误') + '</span>';
    }).catch(function (e) {
      msg.innerHTML = '<span class="fs-err">失败：' + esc(e.message) + '</span>';
    });
  }

  function fillSettings(cfg) {
    byId('fs-llm-url').value = cfg.llm.base_url || '';
    byId('fs-llm-model').value = cfg.llm.model || '';
    byId('fs-llm-key').placeholder = cfg.llm.api_key.set
      ? ('已配置（' + esc(cfg.llm.api_key.tail) + '），留空表示不修改') : '尚未配置';
    var sel = byId('fs-search-provider');
    var providers = (FSApi.health && FSApi.health.search_providers) || ['off'];
    sel.innerHTML = providers.map(function (p) {
      return '<option value="' + esc(p) + '"' + (p === cfg.search.provider ? ' selected' : '') + '>' +
        esc(p === 'off' ? '不联网' : p) + '</option>';
    }).join('');
    byId('fs-search-url').value = cfg.search.base_url || '';
    byId('fs-search-key').placeholder = cfg.search.api_key.set
      ? ('已配置（' + esc(cfg.search.api_key.tail) + '），留空表示不修改') : '尚未配置';
  }

  function saveConfig() {
    var patch = {
      llm: {
        base_url: byId('fs-llm-url').value.trim(),
        model: byId('fs-llm-model').value.trim(),
        api_key: byId('fs-llm-key').value.trim()      // 空 = 不改
      },
      search: {
        provider: byId('fs-search-provider').value,
        base_url: byId('fs-search-url').value.trim(),
        api_key: byId('fs-search-key').value.trim()
      }
    };
    FSApi.saveConfig(patch).then(function (res) {
      fillSettings(res.config);
      byId('fs-llm-key').value = '';
      byId('fs-search-key').value = '';
      byId('fs-save-msg').textContent = '已保存';
      return FSApi.probe().then(function (ok) {
        if (ok) refreshStatusLine();
      });
    }).catch(function (e) {
      byId('fs-save-msg').textContent = '保存失败：' + e.message;
    });
  }

  // ---------------------------------------------------------------- AI 问答

  function askPanel() {
    var s = document.createElement('section');
    s.className = 'panel fs-panel';
    s.innerHTML =
      '<div class="panel-head"><h1>AI 问答（生成式）</h1>' +
      '<p class="lead">用大模型把检索到的年报证据整理成回答，每个结论都带角标，' +
      '角标对应下方证据的年报页码。与上方「年报问答」的区别是：那个是抽取式拼接，这个会归纳推理；' +
      '两者都只依据年报，不编数字。</p></div>' +
      '<div class="fs-row">' +
      '<input id="fs-q" type="text" autocomplete="off" placeholder="例如：美的集团2025年经营现金流与净利润的差异说明了什么？">' +
      '<button class="fs-btn" data-act="ask">提问</button>' +
      '</div>' +
      '<div class="fs-row fs-opts">' +
      '<label class="fs-check"><input type="checkbox" id="fs-use-search"> 联网补充（需在设置里配置搜索接口）</label>' +
      '<span id="fs-ask-status" class="fs-warn"></span>' +
      '</div>' +
      '<div id="fs-answer" class="fs-answer"></div>' +
      '<div id="fs-cites"></div>';
    return s;
  }

  function runAsk() {
    var q = (byId('fs-q').value || '').trim();
    if (!q) { alert('请输入问题'); return; }
    var status = byId('fs-ask-status');
    status.textContent = '检索并生成中…';
    byId('fs-answer').innerHTML = '';
    byId('fs-cites').innerHTML = '';

    var codes = currentCode() ? [currentCode()] : allCodes();
    FSApi.ask(q, codes, byId('fs-use-search').checked).then(function (d) {
      if (d.mode === 'llm_not_configured') {
        status.innerHTML = '<b>' + esc(d.message) + '</b>';
      } else {
        status.textContent = (d.model ? d.model + ' ｜ ' : '') +
          '引用证据 ' + (d.citations || []).length + ' 条' +
          (d.warnings && d.warnings.length ? ' ｜ ' + d.warnings.join('、') : '');
      }
      byId('fs-answer').innerHTML = d.answer
        ? renderAnswerText(d.answer)
        : '<p class="muted">（未生成回答）</p>';
      byId('fs-cites').innerHTML = renderCitations(d.citations || [], d.external || []);
    }).catch(function (e) {
      status.innerHTML = '<b class="fs-err">失败：' + esc(e.message) + '</b>';
    });
  }

  // 把 [1] / [E1] 变成可点的小角标；顺带保留换行。
  function renderAnswerText(text) {
    var html = esc(text)
      .replace(/\[E(\d{1,3})\]/g, '<sup class="fs-cite ext">[E$1]</sup>')
      .replace(/\[(\d{1,3})\]/g, '<sup class="fs-cite">[$1]</sup>');
    return html.split(/\n{2,}/).map(function (p) {
      return '<p>' + p.replace(/\n/g, '<br>') + '</p>';
    }).join('');
  }

  function renderCitations(cites, external) {
    if (!cites.length && !external.length) return '';
    var h = '<h3 class="fs-h3">证据与出处</h3>';
    cites.forEach(function (c) {
      var structured = /^structured_/.test(c.chunk_id || '');
      // 结构化抽取结果没有单一页码（它是十几个科目各带各的页码），别显示成「第 ? 页」
      var loc = structured
        ? '　<b>结构化抽取结果</b><span class="muted small">（各科目页码见正文）</span>'
        : '　<b>第 ' + (c.printed_page == null ? '?' : c.printed_page) + ' 页</b>';
      var meta = structured
        ? '本系统从年报逐字抽取的字段，金额已统一为元'
        : 'BM25 名次 ' + (c.bm25_rank || '—') + '　向量名次 ' + (c.vec_rank || '—') +
          '　' + esc(c.chunk_id);
      h += '<div class="ev' + (c.used ? ' used' : '') + '">' +
        '<div class="ev-head"><b>[' + c.n + ']</b> ' + esc(c.company) + '　' +
        esc(c.section || '') + loc +
        (c.is_table && !structured ? '　<span class="badge tb">表格</span>' : '') +
        (c.used ? '' : '　<span class="muted small">（未被引用）</span>') + '</div>' +
        '<div class="ev-meta mono">' + meta + '</div>' +
        '<div class="ev-text">' + esc(c.text.slice(0, 600)) + '</div></div>';
    });
    if (external.length) {
      h += '<h3 class="fs-h3">联网检索到的外部资料（非年报原文，仅作背景）</h3>';
      external.forEach(function (e) {
        h += '<div class="ev ext"><div class="ev-head"><b>[E' + e.n + ']</b> ' +
          esc(e.title) + '　<span class="muted small">' + esc(e.domain) + '</span></div>' +
          '<div class="ev-text">' + esc(e.snippet) + '</div>' +
          (e.url ? '<div class="small"><a href="' + esc(e.url) + '" target="_blank" rel="noopener">' + esc(e.url) + '</a></div>' : '') +
          '</div>';
      });
    }
    return h;
  }

  // ---------------------------------------------------------------- 组装

  function refreshStatusLine() {
    var h = FSApi.health || {};
    var bits = ['服务模式'];
    bits.push(h.llm_ready ? '大模型已配置' : '大模型未配置');
    bits.push(h.search_ready ? ('联网搜索已配置（' + (h.search_provider || '') + '）') : '联网搜索未配置');
    if (!h.model_present) bits.push('缺向量模型，AI 问答不可用');
    var badge = byId('fs-mode');
    if (badge) {
      badge.textContent = bits.join(' · ');
      badge.className = 'selfcheck ' + (h.llm_ready ? 'ok' : '');
    }
  }

  function bindDelegation(root) {
    root.addEventListener('click', function (ev) {
      var btn = ev.target.closest('[data-act]');
      if (!btn) return;
      var act = btn.dataset.act;
      if (act === 'ingest') startIngest();
      else if (act === 'cancel') FSApi.cancel(btn.dataset.id).then(function () { /* 下次轮询会反映 */ });
      else if (act === 'save-config') saveConfig();
      else if (act === 'llm-preset') applyPreset(parseInt(btn.dataset.i, 10));
      else if (act === 'llm-test') testLlm();
      else if (act === 'clear-keys') clearKeys();
      else if (act === 'ask') runAsk();
    });
    root.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Enter') return;
      if (ev.target.id === 'fs-code') { ev.preventDefault(); startIngest(); }
      if (ev.target.id === 'fs-q') { ev.preventDefault(); runAsk(); }
    });

    var drop = byId('fs-drop');
    var file = byId('fs-file');
    if (drop && file) {
      file.addEventListener('change', function () { startUpload(file.files[0]); file.value = ''; });
      ['dragenter', 'dragover'].forEach(function (t) {
        drop.addEventListener(t, function (e) { e.preventDefault(); drop.classList.add('over'); });
      });
      ['dragleave', 'drop'].forEach(function (t) {
        drop.addEventListener(t, function () { drop.classList.remove('over'); });
      });
      drop.addEventListener('drop', function (e) {
        e.preventDefault();
        startUpload(e.dataTransfer.files && e.dataTransfer.files[0]);
      });
    }
  }

  function init() {
    FSApi.probe().then(function (ok) {
      if (!ok) return;                      // 静态页：什么都不加，行为与原来一致
      var main = document.querySelector('main');
      if (!main) return;

      var add = addPanel();
      var settings = settingsPanel();
      var askp = askPanel();
      main.appendChild(add);
      main.appendChild(askp);
      main.appendChild(settings);

      var badge = document.createElement('div');
      badge.id = 'fs-mode';
      badge.className = 'selfcheck';
      var topbar = document.querySelector('.topbar');
      if (topbar) topbar.appendChild(badge);

      bindDelegation(main);
      refreshStatusLine();
      fillPresets();
      FSApi.config().then(fillSettings).catch(function () { });

      // 刷新后如果还有在跑的任务，接着显示
      var saved = localStorage.getItem(JOB_KEY);
      if (saved) {
        FSApi.job(saved).then(function (job) {
          if (job && ['running', 'queued'].indexOf(job.status) >= 0) watch(saved);
          else renderJob(job);
        }).catch(function () { localStorage.removeItem(JOB_KEY); });
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
