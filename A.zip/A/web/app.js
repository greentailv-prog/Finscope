// FinScope A 模块前端：数据看板 + 带出处的问答。
// 页面只读 D/A 定义的接口（metrics.js / shard_*.js），不重算任何财务数据。

(function () {
  'use strict';

  var MODE = (location.protocol === 'file:') ? 'static' : 'server';
  var shards = [];          // 已加载的分片对象
  var activeCompanies = {}; // code -> bool
  var currentCode = null;

  var $ = function (sel) { return document.querySelector(sel); };
  var $$ = function (sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); };

  function yi(v) {
    if (v == null) return '—';
    return (v / 1e8).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function pct(a, b) {
    if (a == null || b == null || b === 0) return null;
    return ((a - b) / Math.abs(b) * 100);
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  // ---------------------------------------------------------------- 启动自检
  function runSelfCheck() {
    var box = $('#selfcheck');
    var msgs = [];
    var g = window.TOKENIZER_GOLDEN;
    var res = FinTok.checkGolden(g);
    if (!res.ok) {
      msgs.push('分词实现与 Python 侧不一致，检索结果不可信：' +
        JSON.stringify(res.bad && res.bad[0] ? res.bad[0].input : res.reason));
    }
    var man = window.FINSCOPE_MANIFEST || {};
    if (man.index_version) {
      msgs.push('索引 ' + man.index_version + ' / 分词 ' + man.tokenizer_version +
        ' / 向量 ' + (man.embedder_version || '?'));
    }
    box.className = 'selfcheck ' + (msgs.length && !res.ok ? 'bad' : 'ok');
    box.textContent = res.ok
      ? '分词一致性自检通过（' + msgs.join('；') + '）'
      : msgs.join('；');
  }

  // ---------------------------------------------------------------- 数据装载
  function loadShards() {
    var man = window.FINSCOPE_MANIFEST;
    if (!man || !man.shards) return Promise.resolve([]);
    // 顺序注入 <script>，保证分片对象挂到 window.FINSCOPE_SHARDS 上
    return man.shards.reduce(function (p, s) {
      return p.then(function () {
        return new Promise(function (resolve) {
          var el = document.createElement('script');
          el.src = 'data/' + s.file;
          el.onload = function () { resolve(); };
          el.onerror = function () { resolve(); };   // 单个分片失败不阻塞整体
          document.head.appendChild(el);
        });
      });
    }, Promise.resolve()).then(function () {
      var store = window.FINSCOPE_SHARDS || {};
      Object.keys(store).forEach(function (code) {
        activeCompanies[code] = true;
        shards.push(FinSearch.prepare(store[code]));
      });
      return shards;
    });
  }

  // ---------------------------------------------------------------- 看板
  function renderCompanyList() {
    var man = window.FINSCOPE_MANIFEST || { shards: [] };
    var metrics = window.FINSCOPE_METRICS || {};
    var box = $('#companies');
    box.innerHTML = '';
    man.shards.forEach(function (s) {
      var m = metrics[s.code] || { company: { name: s.name } };
      var el = document.createElement('div');
      el.className = 'chip' + (activeCompanies[s.code] ? ' on' : '');
      el.dataset.code = s.code;
      el.innerHTML = '<b>' + esc(m.company.name || s.name) + '</b>' +
        '<span>' + esc(s.code) + ' · ' + s.n_chunks + ' 块 · ' + s.size_mb + 'MB</span>';
      el.onclick = function () {
        currentCode = s.code;
        renderCompanyList();
        renderDashboard(s.code);
      };
      box.appendChild(el);
    });
  }

  function statusBadge(st) {
    if (st === 'found') return '';
    if (st === 'not_applicable') return '<span class="badge na" title="命中了科目名但值确实是空">不适用</span>';
    if (st === 'not_found') return '<span class="badge nf" title="别名未命中，可能是抽取失败">未找到</span>';
    return '<span class="badge nf">' + esc(st) + '</span>';
  }

  function renderDashboard(code) {
    var metrics = window.FINSCOPE_METRICS || {};
    var m = metrics[code];
    var head = $('#dash-head'), body = $('#dash-body');
    if (!m) { head.innerHTML = ''; body.innerHTML = '<tr><td>无数据</td></tr>'; return; }

    var c = m.company, em = m.extraction_meta;
    head.innerHTML =
      '<h2>' + esc(c.name) + ' <span class="ticker">' + esc(c.ticker) + '</span></h2>' +
      '<div class="sub">' + esc(c.industry) + ' · ' + esc(c.report_period) +
      ' · 年报 ' + em.pdf_pages + ' 页 · 页码映射覆盖率 ' +
      (em.pagemap.coverage * 100).toFixed(0) + '%' +
      ' · 指标 ' + Object.keys(m.financials).length + '/17</div>';

    var rows = ['<tr><th>指标</th><th class="num">2025</th><th class="num">2024</th>' +
      '<th class="num">同比</th><th>来源页码</th><th>单位</th></tr>'];
    Object.keys(m.financials).forEach(function (key) {
      var f = m.financials[key];
      var v25 = f.value, v24 = f.series ? f.series['2024'] : null;
      var chg = pct(v25, v24);
      var page = (f.page != null)
        ? '<a href="#" class="pg" data-code="' + code + '" data-page="' + f.page + '">第 ' + f.page + ' 页</a>'
        : '<span class="muted">—</span>';
      rows.push('<tr>' +
        '<td>' + esc(f.label) + statusBadge(f.status) + '</td>' +
        '<td class="num">' + yi(v25) + '</td>' +
        '<td class="num muted">' + yi(v24) + '</td>' +
        '<td class="num ' + (chg == null ? 'muted' : (chg >= 0 ? 'up' : 'down')) + '">' +
        (chg == null ? '—' : (chg >= 0 ? '+' : '') + chg.toFixed(2) + '%') + '</td>' +
        '<td>' + page + '</td>' +
        '<td class="muted">亿元</td>' +
        '</tr>');
    });
    body.innerHTML = rows.join('');

    var ctx = $('#dash-context');
    ctx.innerHTML = '<div class="hint">数值单位已统一为亿元。点页码可看该数字在年报里的原文与所在章节；' +
      '原始计量单位与科目名见下方提示。</div>';

    $$('#dash-body a.pg').forEach(function (a) {
      a.onclick = function (ev) {
        ev.preventDefault();
        showSourceCard(code, parseInt(a.dataset.page, 10));
      };
    });
  }

  function showSourceCard(code, page) {
    var m = (window.FINSCOPE_METRICS || {})[code];
    if (!m) return;
    var hits = [];
    Object.keys(m.financials).forEach(function (k) {
      var f = m.financials[k];
      if (f.page === page) hits.push(f);
    });
    var html = hits.map(function (f) {
      return '<div class="ev">' +
        '<div class="ev-head">' + esc(f.label) + '　<span class="mono">' +
        (f.unit_raw || '') + '</span>　' + esc(f.table || '') + '　' + esc(f.section || '') + '</div>' +
        '<div class="mono">' + esc(f.raw_text || '') + '</div>' +
        '<div class="muted small">科目名匹配：' + esc(f.alias_matched || '') +
        '　口径：' + esc(f.basis || '') + '　置信度：' + f.confidence + '</div>' +
        '</div>';
    }).join('') || '<div class="muted">该页无指标命中</div>';
    $('#source-body').innerHTML =
      '<h3>' + esc(m.company.name) + ' 年报第 ' + page + ' 页的原文</h3>' + html;
    $('#source-panel').classList.add('show');
  }

  // ---------------------------------------------------------------- 问答
  function queryVector(text) {
    // 静态页装不下 95MB 的 ONNX 模型，只有预置问题带向量；
    // 本地服务模式则现算。
    var presets = window.FINSCOPE_QUERIES || [];
    for (var i = 0; i < presets.length; i++) {
      if (presets[i].q === text) return toFloatVec(presets[i].vec);
    }
    return null;
  }

  function toFloatVec(b64) {
    var i8 = FinSearch.decodeTyped(b64, Int8Array);
    var f = new Float32Array(i8.length);
    for (var i = 0; i < i8.length; i++) f[i] = i8[i];
    return f;
  }

  function embedViaServer(text) {
    if (MODE !== 'server') return Promise.resolve(null);
    return fetch('/embed?q=' + encodeURIComponent(text))
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { return j && j.vec ? toFloatVec(j.vec) : null; })
      .catch(function () { return null; });
  }

  // 抽取式回答：从命中的证据块里挑与问题词重叠最高的句子，逐句标注出处。
  // 不生成、不润色——页面上写清楚这是抽取而非生成，避免看起来像编的。
  function composeAnswer(question, results) {
    var qset = Object.create(null);
    FinTok.tokenize(question).forEach(function (t) { qset[t] = true; });
    var scored = [];
    results.forEach(function (r, ri) {
      var sents = r.text.split(/(?<=[。！？；\n])/).map(function (s) { return s.trim(); })
        .filter(function (s) { return s.length >= 8; });
      sents.forEach(function (s) {
        var toks = FinTok.tokenize(s), hit = 0;
        toks.forEach(function (t) { if (qset[t]) hit++; });
        scored.push({ sent: s, score: hit / Math.sqrt(toks.length || 1) + 0.35 / (ri + 1), ref: ri + 1 });
      });
    });
    scored.sort(function (a, b) { return b.score - a.score; });
    var picked = [], seen = Object.create(null);
    for (var i = 0; i < scored.length && picked.length < 4; i++) {
      var key = scored[i].sent.slice(0, 30);
      if (seen[key]) continue;
      seen[key] = true;
      picked.push(scored[i]);
    }
    return picked;
  }

  function runQuery(text) {
    if (!text.trim()) return;
    var useCompanies = shards.filter(function (s) { return activeCompanies[s.meta.code]; });
    if (!useCompanies.length) { alert('请先选择至少一家公司'); return; }

    $('#qa-status').textContent = '检索中…';
    var t0 = performance.now();

    embedViaServer(text).then(function (serverVec) {
      var qvec = serverVec || queryVector(text);
      var route;
      if (qvec) {
        route = (MODE === 'server' ? '本地服务：现算向量' : '预置问题的向量') + ' + BM25 混合检索';
      } else {
        route = 'BM25 单路（静态页无法对自由提问现算向量）';
      }

      var results = FinSearch.searchAll(useCompanies, text, qvec, { topN: 8, pool: 200 });
      var ms = (performance.now() - t0).toFixed(0);

      $('#qa-status').innerHTML =
        '<span class="mode ' + (MODE === 'static' ? 'static' : 'server') + '">' +
        (MODE === 'static' ? '静态页（file://）' : '本地服务（http://）') + '</span> ' +
        '检索路径：' + esc(route) + '　·　' + ms + ' ms　·　' +
        useCompanies.length + ' 家公司、' +
        useCompanies.reduce(function (a, s) { return a + s.meta.n_chunks; }, 0) + ' 个块';

      renderAnswer(text, results);
    });
  }

  function renderAnswer(question, results) {
    var picked = composeAnswer(question, results);
    var head = '<div class="ans-note">以下答案由检索到的证据块<b>抽取</b>拼接，未做生成式改写；' +
      '每条结论后的角标对应下方证据。</div>';
    var body = picked.map(function (p) {
      return '<p>' + esc(p.sent) + '<sup class="cite">[' + p.ref + ']</sup></p>';
    }).join('');
    if (!picked.length) body = '<p class="muted">没有找到足够相关的证据。</p>';

    var ev = results.map(function (r) {
      return '<div class="ev">' +
        '<div class="ev-head">' +
        '<b>[' + r.fused_rank + ']</b> ' + esc(r.company_name) + '　' +
        esc(r.section || '') + '　<b>第 ' + (r.printed_page == null ? '?' : r.printed_page) + ' 页</b>' +
        (r.is_table ? '　<span class="badge tb">表格</span>' : '') +
        '</div>' +
        '<div class="ev-meta mono">BM25 名次 ' + (r.bm25_rank || '—') +
        '　向量名次 ' + (r.vec_rank || '—') +
        '　融合分 ' + r.fused_score.toFixed(4) + '</div>' +
        '<div class="ev-text">' + esc(r.text.slice(0, 420)) + '</div>' +
        '</div>';
    }).join('');

    $('#qa-answer').innerHTML = head + body;
    $('#qa-evidence').innerHTML = '<h3>证据块（' + results.length + '）</h3>' + ev;
  }

  // ---------------------------------------------------------------- 事件
  function bind() {
    $('#qa-form').onsubmit = function (e) {
      e.preventDefault();
      runQuery($('#qa-input').value);
      return false;
    };
    $$('.preset').forEach(function (b) {
      b.onclick = function () {
        $('#qa-input').value = b.dataset.q;
        runQuery(b.dataset.q);
      };
    });
    $('#close-source').onclick = function () {
      $('#source-panel').classList.remove('show');
    };
  }

  function renderPresetButtons() {
    var box = $('#presets');
    var list = window.FINSCOPE_QUERIES || [];
    box.innerHTML = list.map(function (p) {
      return '<button class="preset" data-q="' + esc(p.q) + '">' + esc(p.q) + '</button>';
    }).join('');
  }

  function boot() {
    runSelfCheck();
    // 预置按钮要先渲染再绑事件：bind() 是批量取 .preset 挂 onclick，
    // 反过来的话按钮还没有 DOM 节点，点了没反应。
    renderPresetButtons();
    bind();
    loadShards().then(function () {
      var man = window.FINSCOPE_MANIFEST;
      if (man && man.shards && man.shards.length) currentCode = man.shards[0].code;
      renderCompanyList();
      if (currentCode) renderDashboard(currentCode);
      $('#loading').style.display = 'none';
    });
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
