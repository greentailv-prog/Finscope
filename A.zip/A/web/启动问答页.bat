@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  )
)

if not defined PY (
  echo.
  echo 没有找到 Python。可以不启动本服务，直接双击 index.html 打开静态页。
  echo 静态页里自由提问只走 BM25 检索，预置问题仍是混合检索。
  echo.
  pause
  exit /b 1
)

echo 正在启动 FinScope 问答页...
%PY% serve.py
pause
