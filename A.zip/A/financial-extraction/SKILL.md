---
name: financial-extraction
description: >
  Read a listed company's annual report PDF and turn it into a traceable financial
  dataset: 17 standard line items (revenue, operating cost, net profit, profit
  attributable to shareholders, deducted profit, total assets, total liabilities,
  parent equity, cash, accounts receivable, inventory, goodwill, operating /
  investing / financing cash flow, R&D expense, capex) plus company basics, each
  value carrying the annual report's own printed page number and the exact source
  sentence. Use this skill whenever the user uploads an annual report, 10-K, or
  interim report and asks to pull out financial figures, build a financial dataset
  from filings, cross-check a number against its source page, locate which page a
  figure appears on, or answer questions grounded in a filing with citations. Also
  use it to build the retrieval index that backs cited filing Q&A. Hand the
  resulting financial JSON to financial-diagnosis for ratio and risk work, and to
  company-valuation once peer and cash flow figures are needed.
---

# Financial Extraction

Turns one annual report PDF into a financial JSON where **every number can be walked
back to a printed page and a source sentence**. Downstream modules (diagnosis, risk,
valuation) consume that JSON rather than re-reading the PDF.

**Disclaimer**: Research and educational output. Not financial advice.

---

## Step 1: Check the runtime

```
!`python -c "exec('try:\n import pdfplumber, onnxruntime, tokenizers, numpy, requests\n print(\'DEPS_OK\')\nexcept Exception as e:\n print(\'DEPS_MISSING:\', e)')"`
```

```
!`test -f models/bge-small-zh-v1.5/onnx/model.onnx && echo "MODEL_OK" || echo "MODEL_MISSING"`
```

| Condition | Path |
|---|---|
| `DEPS_OK` and `MODEL_OK` | Full path: layout parsing, page mapping, vector index |
| `DEPS_MISSING` | Stop and report which package is missing. Only `tokenizers` and `onnxruntime` are extra; `pdfplumber`, `numpy`, `requests` are usually already present. Do not silently fall back to a weaker parser. |
| `MODEL_MISSING` | Extraction still works (pdfplumber only). Skip the embedding index and say so; retrieval degrades to BM25. |

---

## Step 2: Resolve the source document

If the user gave a PDF, use it. If they gave only a company and year, fetch the filing
from 巨潮资讯网 (cninfo). Do not substitute a summary PDF, an English translation, or a
corrected announcement for the annual report body.

| Title contains | Verdict |
|---|---|
| `年年度报告` and not another keyword below | Use it |
| `摘要` / `英文` / `更正` / `补充` / `取消` / `问询` | Reject; keep looking |
| Multiple candidates | Take the latest `announcementTime` |

---

## Step 3: Map PDF pages to printed page numbers

**Do this before anything else.** Every citation in the output depends on it.

The PDF's physical page order is not the annual report's printed page number: covers and
tables of contents sit in front, and inserted colour pages shift the offset mid-document.

Approach:

1. Collect page-number candidates from the margin bands only. Explicit page syntax
   (`第N页`, `N/总数`) is credible in header or footer; a bare number is credible **only in
   the footer** — a bare `2025` in the header is a year, not a page number.
2. Convert every candidate to an offset `printed - physical` and build a **support
   histogram across the whole document**. The true offset forms a dominant peak.
   Choosing per page by highest score instead lets header years win and corrupts the map.
3. Accept offsets with enough support, then fill pages that carry no number (inserted
   pages, full-page charts) from the surrounding offset, marking them `inferred`.
   A derived value below 1 means a cover page: leave it null, never write "page 0".
4. Validate: coverage above 0.85, printed numbers strictly increasing, one to three runs.

Run `src/pdf_pagemap.py`; it writes `work/pagemap/<stem>.pagemap.json`. Read the
`validation` block. If `coverage` is below 0.85 or `n_runs` exceeds 3, stop and tell the
user the page mapping is unreliable for this file rather than emitting citations anyway.

---

## Step 4: Parse tables by coordinates, not by text order

Annual report tables break naive text parsing in five specific ways. All five are handled
by `src/table_extract.py`:

| Trap | Why text order fails | Handling |
|---|---|---|
| Numbers right-align into columns | Space-split rows lose column identity | Cluster number right edges into columns |
| Long line items wrap, numbers sit vertically centred | Label splits into lines above and below its own numbers | Anchor rows on numbers, attach labels by vertical distance |
| Header spans two lines and contains no numbers | Header never becomes a row anchor | Detect headers over all visual lines, not just numeric rows |
| Consolidated and parent-company figures share a page | Four number columns, two of them the wrong basis | Read the scope sub-header (合并 / 公司) and keep consolidated only |
| Note reference numbers sit inside the label column | `四(48)` glues onto the item name | Strip note-reference tokens from the label region |

Also required: strip each table's own unit (`单位：千元`, or `（千元）` inside the item name)
— units differ between the summary table and the notes, so they must be judged per table,
not per document.

---

## Step 5: Extract the 17 line items

Priority order, highest first:

1. **主要会计数据和财务指标** — a standardised, audited summary table; compact and the
   least ambiguous source for revenue, attributable and deducted profit, operating cash
   flow, total assets, parent equity.
2. **Consolidated statements** — income statement, balance sheet, cash flow statement.
3. **Notes** — only to fill what the first two do not carry.

Match item names against `src/aliases.json`, which lists Chinese variants plus a
**forbidden list**. The forbidden list matters more than the alias list:

- `营业总成本` is not `营业成本` (it includes taxes and period expenses)
- `净利润` is not `归属于上市公司股东的净利润`
- `现金及现金等价物` is not `货币资金`
- `所有者权益合计` is not `归属于母公司股东权益合计`
- `应收账款坏账准备`, `实际核销的应收账款` are notes detail, not the balance sheet item

Match on **exact item name only** (after stripping enumeration prefixes, trailing unit
parentheses, and inline annotations). Do not accept substring matches: with substring
matching, the note line `可随时用于支付的其他货币资金` outranks the balance sheet's
`货币资金` and replaces an 85 bn figure with a 0.6 bn one. A missing value is a far
better outcome than a wrong one.

Sign convention: the income statement prints deductions as `减：营业成本 (335,989,528)`.
The parentheses are presentation, not a negative quantity. Cost and expense items are
reported as positive magnitudes; cash flow items keep their sign.

---

## Step 6: Represent missing values honestly

Four distinct states, never collapsed into one:

| `status` | Meaning | What to emit |
|---|---|---|
| `found` | Located with a value | value, page, source sentence |
| `not_applicable` | Item matched, but the report shows it as empty or not applicable | `value: null`, high confidence — the company genuinely has none |
| `not_found` | No alias matched any row | `value: null`, plus `aliases_tried` and a note that extraction may have failed |
| `extraction_error` | Row matched but the value could not be parsed | `value: null`, flag for review |

Never write 0 for a missing figure, and never estimate one.

---

## Step 7: Validate before returning

1. Page map thresholds from Step 3.
2. Revenue from the summary table against revenue from the income statement — flag if they
   differ by more than 0.5%.
3. `总资产 = 总负债 + 归母净资产 + 少数股东权益`.
4. Every `page` must be non-null for `found` items. A value without a page is a value the
   user cannot audit.

Keep the raw matched line in `raw_text` for each item, so the user can compare character
by character against the PDF.

---

## Step 8: Respond to the User

Lead with a one-line summary: company, reporting period, how many of the 17 items were
found, and the page-map coverage. Then give the table of items with value, unit, page.
Then state which items are `not_applicable` versus `not_found` — these mean different
things and the user needs to know which is which.

### Error handling

| Situation | Response |
|---|---|
| No text layer (scanned PDF) | Report that the file has no extractable text; do not run OCR silently and do not emit figures |
| Page-map coverage below 0.85 | Report the failure; offer the figures with PDF page indices instead, clearly labelled as not being the report's own page numbers |
| Fewer than 12 of 17 items found | Report which failed and why (alias miss versus parse failure) instead of presenting a partial table as complete |
| Two sources disagree beyond tolerance | Present both values with their pages; do not pick one silently |

### Caveats to include

- Figures are as reported; restatements in later filings are not applied.
- Only consolidated figures are taken; parent-company figures are ignored.
- Cost and expense items are shown as positive magnitudes.
- Research and educational output. Not financial advice.

---

## Reference Files

- `src/aliases.json` — the 17 items with Chinese aliases and forbidden near-misses
- `src/pdf_pagemap.py` — PDF page to printed page number mapping, with validation
- `src/table_extract.py` — coordinate-based table parser for Chinese annual reports
- `src/indicators.py` — priority-ordered extraction and missing-value semantics
- `schema/financial_schema.json` — the output contract consumed by downstream modules
- `references/method-notes.md` — worked examples of each trap and how it was resolved
