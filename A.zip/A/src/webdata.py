# -*- coding: utf-8 -*-
"""web/data 下「真相源 JSON + 派生态 JS」的读写。

页面在 `file://` 下不能 fetch，所以浏览器必须加载 `.js`（`<script src>` 能读，fetch 不行）。
但 `build_index.py` / `export_metrics.py` 要能读回上一次的结果做增量合并，而
`window.FINSCOPE_MANIFEST = {...};` 这种 JS 文件从 Python 读回来得剥前缀，很别扭。

所以约定：**`_<name>.json` 是真相源，`<name>.js` 只是由它生成的派生物。**
两个文件一起写，脚本只读 JSON。首次运行时若只有旧 JS，做一次迁移。

原子写是为了避免页面正好读到写了一半的文件。
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WEB_DATA = ROOT / "web" / "data"


def atomic_write_text(path: Path, text: str) -> None:
    """先写临时文件再 os.replace——同目录内的 replace 是原子的。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def read_json(path: Path, default=None):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default


def publish(name: str, global_name: str, payload, indent: int = 1) -> None:
    """同时写 `_<name>.json`（真相源）与 `<name>.js`（页面加载）。"""
    body = json.dumps(payload, ensure_ascii=False, indent=indent)
    atomic_write_text(WEB_DATA / f"_{name}.json", body)
    atomic_write_text(WEB_DATA / f"{name}.js", f"window.{global_name} = {body};\n")


def read_shard(code: str):
    """读回单个分片（分片没进 truth-source JSON，只有 JS）。

    服务端要用它里面已经算好的 int8 向量做检索，避免为了问答再把几千个块重新
    embedding 一遍——那些向量构建索引时就算过了。
    """
    path = WEB_DATA / f"shard_{code}.js"
    if not path.exists():
        return None
    text = path.read_text(encoding="utf-8")
    m = re.search(r"=\s*(\{.*\});\s*$", text, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return None


def load_published(name: str, global_name: str, default):
    """读真相源。只有旧 JS 时做一次性迁移，把它剥成 JSON。"""
    j = read_json(WEB_DATA / f"_{name}.json")
    if j is not None:
        return j
    js = WEB_DATA / f"{name}.js"
    if js.exists():
        text = js.read_text(encoding="utf-8")
        m = re.search(rf"window\.{re.escape(global_name)}\s*=\s*(.*?);\s*$", text, re.S)
        if m:
            try:
                return json.loads(m.group(1))
            except json.JSONDecodeError:
                pass
    return default
