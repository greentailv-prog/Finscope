# -*- coding: utf-8 -*-
"""联网搜索适配器：把不同供应商的结果统一成同一种结构。

外部资料**只作背景**送进大模型，绝不能当成年报原文引用——年报是审计过的原始披露，
新闻是二手转述，两者的可信度差着级别。所以调用方拿到的每条结果都带 `kind: "web"`，
在提示词里单独成段并明确标注。

供应商都需要各自的密钥，在设置面板里填。默认 `off`，此时不注入外部资料段。
"""
from __future__ import annotations

import sys
from pathlib import Path
from urllib.parse import urlparse

import requests

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import config as config_mod       # noqa: E402

TIMEOUT = 20


class SearchError(RuntimeError):
    pass


def _clean(items: list[dict], top_k: int) -> list[dict]:
    out = []
    for it in items[:top_k]:
        url = (it.get("url") or "").strip()
        title = (it.get("title") or "").strip()
        snippet = (it.get("snippet") or "").strip().replace("\n", " ")
        if not url and not snippet:
            continue
        out.append({
            "kind": "web",
            "title": title or url,
            "url": url,
            "domain": urlparse(url).netloc if url else "",
            "snippet": snippet[:1200],
            "published_at": it.get("published_at") or "",
        })
    return out


# ---------------------------------------------------------------- 各供应商

def _tavily(query: str, top_k: int, cfg: dict) -> list[dict]:
    r = requests.post("https://api.tavily.com/search",
                      json={"api_key": cfg["api_key"], "query": query,
                            "max_results": top_k, "search_depth": "basic",
                            "include_answer": False},
                      timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    return _clean([{"title": x.get("title"), "url": x.get("url"),
                    "snippet": x.get("content"),
                    "published_at": x.get("published_date")}
                   for x in (data.get("results") or [])], top_k)


def _bocha(query: str, top_k: int, cfg: dict) -> list[dict]:
    base = (cfg.get("base_url") or "https://api.bochaai.com/v1").rstrip("/")
    r = requests.post(f"{base}/web-search",
                      headers={"Authorization": f"Bearer {cfg['api_key']}",
                               "Content-Type": "application/json"},
                      json={"query": query, "count": top_k, "summary": True},
                      timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    pages = (((data.get("data") or {}).get("webPages") or {}).get("value")) or []
    return _clean([{"title": x.get("name"), "url": x.get("url"),
                    "snippet": x.get("summary") or x.get("snippet"),
                    "published_at": x.get("datePublished")}
                   for x in pages], top_k)


def _searxng(query: str, top_k: int, cfg: dict) -> list[dict]:
    base = (cfg.get("base_url") or "").rstrip("/")
    if not base:
        raise SearchError("SearXNG 需要填实例地址（base_url）")
    r = requests.get(f"{base}/search",
                     params={"q": query, "format": "json", "language": "zh-CN"},
                     timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    return _clean([{"title": x.get("title"), "url": x.get("url"),
                    "snippet": x.get("content"),
                    "published_at": x.get("publishedDate")}
                   for x in (data.get("results") or [])], top_k)


def _bing(query: str, top_k: int, cfg: dict) -> list[dict]:
    base = (cfg.get("base_url") or "https://api.bing.microsoft.com/v7.0").rstrip("/")
    r = requests.get(f"{base}/search",
                     headers={"Ocp-Apim-Subscription-Key": cfg["api_key"]},
                     params={"q": query, "count": top_k, "mkt": "zh-CN"},
                     timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    pages = ((data.get("webPages") or {}).get("value")) or []
    return _clean([{"title": x.get("name"), "url": x.get("url"),
                    "snippet": x.get("snippet"),
                    "published_at": x.get("dateLastCrawled")}
                   for x in pages], top_k)


_PROVIDERS = {
    "tavily": _tavily,
    "bocha": _bocha,
    "searxng": _searxng,
    "bing": _bing,
}


def available_providers() -> list[str]:
    return ["off"] + sorted(_PROVIDERS)


def search(query: str, top_k: int | None = None, cfg: dict | None = None) -> list[dict]:
    """按配置执行联网搜索。未配置（off）或失败时返回空列表，不抛异常给上层。

    失败时**静默降级为空**是有意的：联网搜索只是补充，搜不到不该让整个问答失败。
    但调用方要把 `warnings` 透到界面上，让用户知道这次没联网。
    """
    cfg = (cfg or config_mod.load()["search"])
    provider = cfg.get("provider") or "off"
    if provider == "off":
        return []
    fn = _PROVIDERS.get(provider)
    if fn is None:
        raise SearchError(f"未知的搜索供应商：{provider}")
    k = int(top_k or cfg.get("top_k") or 5)
    return fn(query, k, cfg)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    import json
    print("可选供应商:", available_providers())
    print("当前配置:", config_mod.load()["search"])
    print("已配置可用:", config_mod.search_ready())
