# -*- coding: utf-8 -*-
"""从年报 PDF 的前几页识别出 公司名 / 股票代码 / 报告年份。

上传流程要用：文件名必须符合 `<公司名>_<代码>_<年份>` 的约定，整条下游管线（页码映射、
切块、分片）都靠这个 stem 串起来，识别错了后面全错，所以识别不出时**返回 None 让调用方
去问用户**，而不是猜一个。
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pdfplumber

# 公司名：以「有限公司」结尾的中文全称。允许中间有「集团」「股份」。
_NAME_RE = re.compile(r"([一-龥]{2,20}(?:集团)?(?:股份)?有限公司)")
_CODE_RE = re.compile(r"(?:股票代码|证券代码|A股代码|股票简称\s*[:：]?\s*[^\s]*?\s*股票代码)\s*[:：]?\s*(\d{6})")
_CODE_FALLBACK_RE = re.compile(r"\b(\d{6})\b")
_YEAR_RE = re.compile(r"(20\d{2})\s*年\s*年度报告")

_NAME_OK = re.compile(r"^[一-龥A-Za-z0-9]{2,30}$")


def read_head(path: Path, pages: int = 4) -> str:
    with pdfplumber.open(path) as pdf:
        return "\n".join((p.extract_text() or "") for p in pdf.pages[:pages])


def identify_pdf(path: Path, default_year: int | None = None) -> dict:
    """返回 {"name", "code", "year", "source"}；识别不到的字段为 None。"""
    head = read_head(path)

    name = None
    m = _NAME_RE.search(head)
    if m:
        candidate = m.group(1)
        if _NAME_OK.match(candidate):
            name = candidate

    code = None
    m = _CODE_RE.search(head)
    if m:
        code = m.group(1)
    else:
        # 封面通常也印「公司代码：600519」。只有在附近出现「代码」字样时才用兜底正则，
        # 否则会把注册资本、电话之类的六位数字当成股票代码。
        for line in head.split("\n")[:12]:
            if "代码" in line:
                m = _CODE_FALLBACK_RE.search(line)
                if m:
                    code = m.group(1)
                    break

    year = None
    m = _YEAR_RE.search(head)
    if m:
        year = int(m.group(1))
    elif default_year:
        year = default_year

    return {"name": name, "code": code, "year": year, "source": str(path)}


def is_valid_code(code: str | None) -> bool:
    return bool(code and re.fullmatch(r"\d{6}", code))


def is_valid_name(name: str | None) -> bool:
    return bool(name and _NAME_OK.match(name))


def is_valid_year(year) -> bool:
    return isinstance(year, int) and 2000 <= year <= 2100


def exchange_of(code: str) -> str:
    """由股票代码前缀推交易所，与 fetch_cninfo.resolve_org_id 的兜底规则一致。"""
    if code.startswith(("6", "9")):
        return "sse"
    if code.startswith(("4", "8")):
        return "bse"
    return "szse"


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if not target:
        print("用法: python identify.py <年报.pdf>")
        raise SystemExit(2)
    info = identify_pdf(target)
    print(info)
