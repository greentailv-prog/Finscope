# -*- coding: utf-8 -*-
"""预计算预置问题的查询向量，产出 web/data/queries.js。

静态页无法在浏览器里跑 95MB 的 bge 模型，所以预置问题的向量只能构建期算好。
未预置的自由提问在静态页里退化为 BM25 单路；页面会明示当前走的是哪一路，
不会假装做了混合检索。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import embed as embed_mod            # noqa: E402

ROOT = SRC.parent
OUT = ROOT / "web" / "data" / "queries.js"


def main() -> int:
    spec = json.loads((SRC / "preset_questions.json").read_text(encoding="utf-8"))
    questions = spec["questions"]

    emb = embed_mod.Embedder()
    vecs = emb.encode(questions)
    q = embed_mod.quantize_int8(vecs)

    dim = embed_mod.DIM
    items = []
    for i, text in enumerate(questions):
        items.append({"q": text, "vec": embed_mod.b64_int8(q[i:i + 1].reshape(1, dim))})

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(
        "window.FINSCOPE_QUERIES = " +
        json.dumps(items, ensure_ascii=False, separators=(",", ":")) + ";\n",
        encoding="utf-8")
    # 逐条向量单独存成一行会太长，这里只报总览
    total_kb = OUT.stat().st_size / 1024
    print(f"预置问题 {len(items)} 条，维度 {dim}，量化 int8 -> {OUT.name} ({total_kb:.0f} KB)")
    for it in items:
        print("  -", it["q"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
