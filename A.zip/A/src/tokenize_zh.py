# -*- coding: utf-8 -*-
"""中文检索分词：CJK 走字符 unigram + 相邻 bigram，拉丁/数字走整词。

不装 jieba 的理由：字符 bigram 在中文短查询上召回不低于分词，而且**零依赖、
零歧义**——这一点对本项目很关键，因为浏览器里要用纯 JS 复刻同一套分词，
任何一个边界情况不一致，BM25 的打分就对不上。

算法（web/tokenize.js 必须逐字复刻）：
1. NFKC 归一化，转小写；
2. 按类别切段：CJK 连续段 / 拉丁数字连续段 / 其它（丢弃）；
3. CJK 段：输出每个字符，再输出每对相邻字符；
4. 拉丁数字段：整段作为 1 个 token。

用法:
    python tokenize_zh.py --self-test     # 跑 golden 用例，产出 web/data/tokens_golden.js
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
GOLDEN_PATH = ROOT / "web" / "data" / "tokens_golden.js"

_CJK = re.compile(r"[一-鿿]+")
_ALNUM = re.compile(r"[a-z0-9]+")

# 版本号在索引与页面两侧都要存，不一致就说明分词实现改了，必须重建索引
TOKENIZER_VERSION = "zh-char-bigram-v1"


def normalize(text: str) -> str:
    return unicodedata.normalize("NFKC", text or "").lower()


def tokenize(text: str) -> list[str]:
    """返回 token 列表（保留重复，BM25 需要词频）。"""
    s = normalize(text)
    out: list[str] = []
    for seg in _CJK.findall(s):
        out.extend(seg)
        out.extend(seg[i:i + 2] for i in range(len(seg) - 1))
    out.extend(_ALNUM.findall(s))
    return out


def token_freq(text: str) -> dict[str, int]:
    tf: dict[str, int] = {}
    for t in tokenize(text):
        tf[t] = tf.get(t, 0) + 1
    return tf


# golden 用例：覆盖中文、数字、中英混排、全角、大小写、标点
GOLDEN_CASES = [
    "营业收入",
    "美的集团2025年年度报告",
    "ＡＢＣ１２３全角",
    "归母净利润 43,945,411 千元",
    "应收账款（净额）",
    "ROE 与 EBITDA 口径",
    "现金流量表---经营活动",
    "   ",
    "",
    "2025",
]


def main() -> int:
    ap = argparse.ArgumentParser(description="中文检索分词与 golden 用例")
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()

    golden = [{"input": c, "tokens": tokenize(c)} for c in GOLDEN_CASES]
    if args.self_test:
        for g in golden:
            print(f"{g['input']!r} -> {g['tokens']}")

    GOLDEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    body = json.dumps({"version": TOKENIZER_VERSION, "cases": golden},
                      ensure_ascii=False, indent=1)
    GOLDEN_PATH.write_text("window.TOKENIZER_GOLDEN = " + body + ";\n", encoding="utf-8")
    print(f"golden 用例 {len(golden)} 条 -> {GOLDEN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
