# -*- coding: utf-8 -*-
"""Python 侧检索：与 web/search.js 同一套算法（同分词、同哈希、同 BM25 公式、同融合）。

核验必须走与页面完全相同的管线，否则「脚本说对、页面看到的却是另一回事」。
所以这里刻意不另写一套，而是逐条复刻 JS 的实现：
    tokenize_zh.tokenize  <-> web/tokenize.js tokenize
    build_index.fnv1a     <-> web/tokenize.js fnv1a
    BM25 k1=1.5 b=0.75    <-> web/search.js K1/B
    RRF k=60              <-> web/search.js RRF_K
"""
from __future__ import annotations

import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import build_index                    # noqa: E402
import tokenize_zh                    # noqa: E402

ROOT = SRC.parent
CHUNK_DIR = ROOT / "work" / "chunks"

K1, B, RRF_K = 1.5, 0.75, 60
# 问句里点名了公司时，给该公司的块加权。八家年报的科目名高度同质，
# 「比亚迪2025年经营活动现金流」里的「比亚迪」只有三个 bigram，光靠 BM25
# 压不住「经营活动产生的现金流量净额」在另外七家上百次的出现。
COMPANY_BOOST = 1.8


class Index:
    """一家公司的 BM25 + 向量索引，内存内构建。"""

    def __init__(self, stem: str):
        self.stem = stem
        self.chunks = [json.loads(l) for l in
                       (CHUNK_DIR / f"{stem}.chunks.jsonl").read_text(encoding="utf-8").splitlines()
                       if l.strip()]
        self.code = self.chunks[0]["company_code"]
        self.name = self.chunks[0]["company_name"]

        postings: dict[int, dict[int, int]] = defaultdict(dict)
        doc_len = np.zeros(len(self.chunks), dtype=np.int64)
        for doc_id, c in enumerate(self.chunks):
            # 与 build_index 用同一份「索引文本」，否则 Python 侧与页面侧的
            # BM25 打分对不上，核验就失去意义
            tf = tokenize_zh.token_freq(build_index.index_text(c))
            doc_len[doc_id] = sum(tf.values())
            for tok, n in tf.items():
                postings[build_index.fnv1a(tok)][doc_id] = min(n, 255)
        self.postings = postings
        self.doc_len = doc_len
        self.avgdl = float(doc_len.mean()) if len(doc_len) else 1.0
        self.n_docs = len(self.chunks)
        self._vec = None

    @classmethod
    def from_shard(cls, code: str) -> "Index | None":
        """从已发布的分片建索引。

        服务器与核验都走这条路：**不依赖 `work/chunks/`**（那是可再生的中间产物，
        不在仓库里），只要仓库里有 `web/data/` 就能问答。分片里已经存了 chunk 全文、
        BM25 倒排和 int8 向量，直接用；而且这样两侧看到的向量与打分与浏览器完全一致。
        """
        import base64
        import webdata
        d = webdata.read_shard(code)
        if not d:
            return None
        obj = cls.__new__(cls)
        obj.code = d["meta"]["code"]
        obj.name = d["meta"]["name"]
        obj.stem = d["meta"].get("stem", obj.name)
        obj.n_docs = int(d["bm25"]["n_docs"])
        obj.avgdl = float(d["bm25"]["avgdl"]) or 1.0
        obj.chunks = [dict(c, company_code=obj.code, company_name=obj.name)
                      for c in d["chunks"]]

        def arr(key, dtype):
            return np.frombuffer(base64.b64decode(d["bm25"][key]), dtype=dtype)

        th = arr("term_hashes_b64", "<i4")
        df = arr("df_b64", "<u2")
        post_doc = arr("post_doc_b64", "<u2")
        post_tf = arr("post_tf_b64", "<u1")
        obj.doc_len = arr("doc_len_b64", "<u2").astype(np.int64)

        postings: dict[int, dict[int, int]] = defaultdict(dict)
        pos = 0
        for i, h in enumerate(th):
            n = int(df[i])
            bucket = postings[int(h)]
            for k in range(pos, pos + n):
                bucket[int(post_doc[k])] = int(post_tf[k])
            pos += n
        obj.postings = postings

        raw = base64.b64decode(d["vec"]["b64"])
        dim = int(d["vec"]["dim"])
        q = np.frombuffer(raw, dtype="<i1").reshape(-1, dim)
        obj._vec = q.astype(np.float32) / 127.0     # 与浏览器同一份量化向量
        return obj

    # ---- BM25 ----
    def bm25(self, query: str) -> np.ndarray:
        scores = np.zeros(self.n_docs, dtype=np.float32)
        tf = tokenize_zh.token_freq(query)
        N, avgdl = self.n_docs, self.avgdl or 1.0
        for tok in tf:
            h = build_index.fnv1a(tok)
            plist = self.postings.get(h)
            if not plist:
                continue
            df = len(plist)
            idf = math.log(1 + (N - df + 0.5) / (df + 0.5))
            for d, f in plist.items():
                dl = self.doc_len[d] or 1
                scores[d] += idf * (f * (K1 + 1)) / (f + K1 * (1 - B + B * dl / avgdl))
        return scores

    # ---- 向量 ----
    def set_vectors(self, vecs: np.ndarray):
        """vecs: (n, dim) 已 L2 归一化的 float32。"""
        self._vec = np.ascontiguousarray(vecs, dtype=np.float32)

    def vec(self, qvec: np.ndarray | None) -> np.ndarray:
        if self._vec is None or qvec is None:
            return np.zeros(self.n_docs, dtype=np.float32)
        return self._vec @ np.asarray(qvec, dtype=np.float32)

    def top_k(self, scores: np.ndarray, k: int) -> list[int]:
        idx = np.nonzero(scores > 0)[0]
        if len(idx) == 0:
            return []
        order = idx[np.argsort(-scores[idx])]
        return order[:k].tolist()


def search(indexes: list[Index], query: str, qvec: np.ndarray | None = None,
           top_n: int = 8, pool: int = 200, mode: str = "rrf") -> list[dict]:
    """跨公司检索，与 web/search.js 的 searchAll 同一套逻辑。"""
    bm_list: list[tuple[int, int, float]] = []
    vec_list: list[tuple[int, int, float]] = []

    for si, ix in enumerate(indexes):
        bm = ix.bm25(query)
        for d in ix.top_k(bm, pool):
            bm_list.append((si, d, float(bm[d])))
        if qvec is not None:
            vs = ix.vec(qvec)
            for d in ix.top_k(vs, pool):
                vec_list.append((si, d, float(vs[d])))

    bm_list.sort(key=lambda x: -x[2])
    vec_list.sort(key=lambda x: -x[2])

    rank_bm = {(si, d): i + 1 for i, (si, d, _) in enumerate(bm_list)}
    rank_vec = {(si, d): i + 1 for i, (si, d, _) in enumerate(vec_list)}

    fused: dict[tuple[int, int], float] = {}
    for i, (si, d, _) in enumerate(bm_list):
        fused[(si, d)] = fused.get((si, d), 0.0) + 1.0 / (RRF_K + i + 1)
    for i, (si, d, _) in enumerate(vec_list):
        fused[(si, d)] = fused.get((si, d), 0.0) + 1.0 / (RRF_K + i + 1)

    named = {si for si, ix in enumerate(indexes) if ix.name and ix.name in query}
    if named:
        for key in list(fused):
            if key[0] in named:
                fused[key] *= COMPANY_BOOST

    ordered = sorted(fused.items(), key=lambda kv: -kv[1])[:top_n]
    bm_scores = {(si, d): s for si, d, s in bm_list}
    vec_scores = {(si, d): s for si, d, s in vec_list}

    out = []
    for rank, ((si, d), score) in enumerate(ordered, 1):
        c = indexes[si].chunks[d]
        out.append({
            "fused_rank": rank,
            "fused_score": score,
            "company_code": c["company_code"],
            "company_name": c["company_name"],
            "chunk_id": c["chunk_id"],
            "section": c["section"],
            "printed_page": c["printed_page"],
            "pdf_index": c["pdf_index"],
            "is_table": c["is_table"],
            "bm25_rank": rank_bm.get((si, d)),
            "vec_rank": rank_vec.get((si, d)),
            "bm25_score": bm_scores.get((si, d), 0.0),
            "vec_score": vec_scores.get((si, d)),
            "text": c["text"],
        })
    return out


def load_indexes(stems: list[str] | None = None) -> list[Index]:
    """从 `work/chunks/` 建索引（需要中间产物；重建分片时用）。"""
    if stems is None:
        stems = sorted(p.name[:-len(".chunks.jsonl")]
                       for p in CHUNK_DIR.glob("*.chunks.jsonl"))
    return [Index(s) for s in stems]


def load_from_shards(codes: list[str] | None = None) -> list[Index]:
    """从已发布的分片建索引（只需 `web/data/`，服务器与核验默认走这条）。"""
    import webdata
    man = webdata.load_published("manifest", "FINSCOPE_MANIFEST", {"shards": []})
    want = set(codes) if codes else None
    out = []
    for s in man.get("shards", []):
        if want and s["code"] not in want:
            continue
        ix = Index.from_shard(s["code"])
        if ix:
            out.append(ix)
    return out


def quantized_vectors(code: str) -> np.ndarray | None:
    """从已发布的分片里取回 int8 向量，还原成 float32。

    分片里的向量是 `round(单位向量 * 127)`，所以除以 127 就得到近似单位向量。
    这样服务端问答不必再为几千个块重新 embedding——而且拿到的正是**浏览器看到的
    同一份量化向量**，两侧打分天然一致。
    """
    import base64
    import webdata
    d = webdata.read_shard(code)
    if not d or "vec" not in d:
        return None
    try:
        raw = base64.b64decode(d["vec"]["b64"])
        dim = int(d["vec"]["dim"])
        q = np.frombuffer(raw, dtype=np.int8).reshape(-1, dim)
    except (KeyError, ValueError):
        return None
    return q.astype(np.float32) / 127.0


def attach_vectors(indexes: list[Index], embedder=None) -> None:
    """给索引挂上向量：优先用分片里已算好的，缺失时才现算。"""
    for ix in indexes:
        v = quantized_vectors(ix.code)
        if v is not None and len(v) == ix.n_docs:
            ix.set_vectors(v)
            continue
        if embedder is None:
            import embed as embed_mod
            embedder = embed_mod.Embedder()
        ix.set_vectors(embedder.encode([c["text"] for c in ix.chunks]))
    return embedder
