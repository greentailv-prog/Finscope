# -*- coding: utf-8 -*-
"""用 onnxruntime 跑 bge-small-zh-v1.5，产出 L2 归一化的 512 维中文句向量。

不装 sentence-transformers（会连带装 torch，约 2GB）。这里自己做三件事：
1. 用 tokenizers 加载 tokenizer.json（它自带 [CLS]/[SEP] 后处理）；
2. ONNX 推理，取 **CLS 池化**（last_hidden_state[:, 0, :]）——bge 系列的官方池化方式，
   不是 mean pooling，用错会明显掉点；
3. L2 归一化，使余弦相似度退化成点积，浏览器里省一次除法。

量化：向量已单位化，分量天然落在 [-1, 1]，所以 q = round(v * 127) 到 int8，
反量化时点积除以 127 即可，不需要存 scale。

用法:
    python embed.py --check          # 自检：相关句对相似度应高于无关句对
"""
from __future__ import annotations

import argparse
import base64
import sys
from pathlib import Path

import numpy as np
import onnxruntime as ort
from tokenizers import Tokenizer

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = ROOT / "models" / "bge-small-zh-v1.5"
MAX_LEN = 512
DIM = 512
EMBEDDER_VERSION = "bge-small-zh-v1.5-cls-v1"


class Embedder:
    def __init__(self, model_dir: Path = MODEL_DIR, threads: int = 0):
        self.tokenizer = Tokenizer.from_file(str(model_dir / "tokenizer.json"))
        self.tokenizer.enable_truncation(max_length=MAX_LEN)
        opts = ort.SessionOptions()
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        if threads:
            opts.intra_op_num_threads = threads
        self.session = ort.InferenceSession(
            str(model_dir / "onnx" / "model.onnx"), sess_options=opts,
            providers=["CPUExecutionProvider"])
        self.input_names = [i.name for i in self.session.get_inputs()]

    def encode(self, texts: list[str], batch_size: int = 32) -> np.ndarray:
        """返回 (n, 512) 的 float32 单位向量。"""
        out = np.zeros((len(texts), DIM), dtype=np.float32)
        for start in range(0, len(texts), batch_size):
            chunk = texts[start:start + batch_size]
            encs = [self.tokenizer.encode(t or " ") for t in chunk]
            maxlen = max(len(e.ids) for e in encs)
            ids = np.zeros((len(encs), maxlen), dtype=np.int64)
            mask = np.zeros((len(encs), maxlen), dtype=np.int64)
            for i, e in enumerate(encs):
                ids[i, :len(e.ids)] = e.ids
                mask[i, :len(e.ids)] = 1
            feed = {"input_ids": ids, "attention_mask": mask,
                    "token_type_ids": np.zeros_like(ids)}
            feed = {k: v for k, v in feed.items() if k in self.input_names}
            hidden = self.session.run(None, feed)[0]
            vec = hidden[:, 0, :]                       # CLS 池化
            norm = np.linalg.norm(vec, axis=1, keepdims=True)
            vec = vec / np.maximum(norm, 1e-9)
            out[start:start + len(chunk)] = vec
        return out


def quantize_int8(vectors: np.ndarray) -> np.ndarray:
    """单位向量 -> int8。分量在 [-1,1]，直接乘 127。"""
    return np.clip(np.rint(vectors * 127.0), -127, 127).astype(np.int8)


def b64_int8(arr: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(arr, dtype=np.int8).tobytes()).decode("ascii")


def main() -> int:
    ap = argparse.ArgumentParser(description="bge 中文向量自检")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    emb = Embedder()
    if not args.check:
        print(f"embedder 就绪，版本 {EMBEDDER_VERSION}，维度 {DIM}")
        return 0

    pairs = [
        ("2025年营业收入", "公司本期实现的营业总收入是多少", True),
        ("2025年营业收入", "研发人员中博士的人数", False),
        ("应收账款增速快于营收", "应收款项增长超过收入增长", True),
        ("存货跌价准备", "公司治理结构", False),
    ]
    texts = [p[0] for p in pairs] + [p[1] for p in pairs]
    vecs = emb.encode(texts)
    n = len(pairs)
    ok = True
    for i, (a, b, same) in enumerate(pairs):
        sim = float(vecs[i] @ vecs[n + i])
        verdict = "OK " if (sim > 0.6) == same else "FAIL"
        if verdict == "FAIL":
            ok = False
        print(f"[{verdict}] cos={sim:+.3f} 期望{'相近' if same else '不相近'}  {a} <> {b}")
    print("自检", "通过" if ok else "未通过")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
