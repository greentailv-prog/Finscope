# -*- coding: utf-8 -*-
"""从巨潮资讯网下载 A 股上市公司年度报告 PDF。

用法:
    python fetch_cninfo.py                     # 下载 companies.json 里的全部公司
    python fetch_cninfo.py 600519 000333       # 只下载指定代码
    python fetch_cninfo.py --year 2025         # 覆盖报告年度

产物:
    data/annual_reports/<公司名>_<代码>_<年度>.pdf
    data/annual_reports/_fetch_log.json        每份年报的公告元数据与下载结果
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

import requests

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
from identify import exchange_of       # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
SRC = Path(__file__).resolve().parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
LOG_PATH = ANNUAL_DIR / "_fetch_log.json"

QUERY_URL = "http://www.cninfo.com.cn/new/hisAnnouncement/query"
SEARCH_URL = "http://www.cninfo.com.cn/new/information/topSearch/query"
STATIC_BASE = "http://static.cninfo.com.cn/"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "X-Requested-With": "XMLHttpRequest",
    "Referer": "http://www.cninfo.com.cn/new/commonUrl?url=disclosure/list/notice",
}

# 标题里出现这些词的一律不是我们要的正文年报
TITLE_REJECT = ("摘要", "英文", "英文版", "更正", "补充", "取消", "问询", "意见", "公告", "提示性")
# 标题必须包含的片段（去掉空格后比较）
TITLE_REQUIRE_TPL = "{year}年年度报告"


def load_config() -> dict:
    return json.loads((SRC / "companies.json").read_text(encoding="utf-8"))


def resolve_org_id(code: str, session: requests.Session) -> str | None:
    """用巨潮的搜索接口把股票代码解析成 orgId（查询公告时必须带）。"""
    try:
        r = session.post(
            SEARCH_URL,
            headers=HEADERS,
            data={"keyWord": code, "maxNum": 10},
            timeout=20,
        )
        r.raise_for_status()
        for item in r.json() or []:
            if item.get("code") == code:
                return item.get("orgId")
    except Exception as exc:  # noqa: BLE001 - 解析失败就走兜底猜测
        print(f"  [warn] orgId 解析失败 {code}: {exc}", file=sys.stderr)
    # 兜底：沪市 gssh0+code，深市 gssz0+code
    prefix = "gssh0" if code.startswith(("6", "9")) else "gssz0"
    return prefix + code


def _norm(text: str) -> str:
    return "".join((text or "").split())


def resolve_company(query: str, session: requests.Session | None = None) -> dict | None:
    """把股票代码或公司名解析成 {code, name, exchange}。

    巨潮的 topSearch 接口同时支持代码与名称作为关键词，返回里带中文简称 `zwjc`，
    正好用作文件名里的公司名。交易所由代码前缀推——现有 `resolve_org_id` 的兜底
    用的就是这个规则，这里只是把它显式化。
    """
    sess = session or requests.Session()
    try:
        r = sess.post(SEARCH_URL, headers=HEADERS,
                      data={"keyWord": query, "maxNum": 10}, timeout=20)
        r.raise_for_status()
        items = r.json() or []
    except Exception as exc:  # noqa: BLE001
        print(f"  [warn] 公司解析失败 {query}: {exc}", file=sys.stderr)
        return None

    if not items:
        return None

    q = query.strip()
    cands = [it for it in items
             if it.get("category") == "A股" and it.get("delisted") != "true"]
    if not cands:
        cands = items

    pick = None
    if re.fullmatch(r"\d{6}", q):
        pick = next((it for it in cands if it.get("code") == q), None)
    else:
        pick = next((it for it in cands if q in (it.get("zwjc") or "")
                     or (it.get("zwjc") or "") in q), None)
    if pick is None:
        pick = cands[0]

    code = pick.get("code")
    name = pick.get("zwjc") or ""
    if not code or not name:
        return None
    return {"code": code, "name": name, "exchange": exchange_of(code),
            "orgId": pick.get("orgId"), "category": pick.get("category")}


def pick_annual_report(items: list[dict], year: int) -> dict | None:
    """从公告列表里挑出目标年度的年报正文，多条时取发布时间最新的。"""
    need = TITLE_REQUIRE_TPL.format(year=year)
    hits = []
    for it in items:
        title = _norm(it.get("announcementTitle", ""))
        if need not in title:
            continue
        if any(bad in title for bad in TITLE_REJECT):
            continue
        hits.append(it)
    if not hits:
        return None
    hits.sort(key=lambda x: x.get("announcementTime") or 0, reverse=True)
    return hits[0]


def query_announcements(
    code: str, org_id: str, column: str, year: int, session: requests.Session
) -> list[dict]:
    data = {
        "pageNum": 1,
        "pageSize": 30,
        "column": column,
        "tabName": "fulltext",
        "plate": "",
        "stock": f"{code},{org_id}",
        "searchkey": "",
        "secid": "",
        "category": "category_ndbg_szsh",
        "trade": "",
        "seDate": f"{year + 1}-01-01~{year + 1}-12-31",
        "sortName": "",
        "sortType": "",
        "isHLtitle": "true",
    }
    r = session.post(QUERY_URL, headers=HEADERS, data=data, timeout=30)
    r.raise_for_status()
    return r.json().get("announcements") or []


def download_pdf(url: str, dest: Path, session: requests.Session) -> int:
    r = session.get(url, headers={"User-Agent": HEADERS["User-Agent"]}, stream=True, timeout=180)
    r.raise_for_status()
    tmp = dest.with_suffix(".part")
    n = 0
    with open(tmp, "wb") as fh:
        for chunk in r.iter_content(1 << 16):
            fh.write(chunk)
            n += len(chunk)
    with open(tmp, "rb") as fh:
        if fh.read(5) != b"%PDF-":
            tmp.unlink(missing_ok=True)
            raise ValueError(f"下载内容不是 PDF: {url}")
    tmp.replace(dest)
    return n


def fetch_one(company: dict, year: int, session: requests.Session, force: bool = False) -> dict:
    code, name = company["code"], company["name"]
    dest = ANNUAL_DIR / f"{name}_{code}_{year}.pdf"
    record = {"code": code, "name": name, "year": year, "path": str(dest.relative_to(ROOT))}

    if dest.exists() and dest.stat().st_size > 100_000 and not force:
        record.update(status="cached", size=dest.stat().st_size)
        print(f"[{name} {code}] 已存在，跳过（{dest.stat().st_size/1e6:.1f} MB）")
        return record

    org_id = resolve_org_id(code, session)
    if not org_id:
        record.update(status="error", reason="orgId_not_found")
        return record

    items = query_announcements(code, org_id, company["exchange"], year, session)
    hit = pick_annual_report(items, year)
    if not hit:
        titles = [i.get("announcementTitle") for i in items]
        record.update(status="error", reason="annual_report_not_found", titles_seen=titles)
        print(f"[{name} {code}] 未找到 {year} 年年度报告，共 {len(items)} 条公告")
        return record

    url = STATIC_BASE + hit["adjunctUrl"]
    size = download_pdf(url, dest, session)
    record.update(
        status="downloaded",
        title=hit["announcementTitle"],
        announcement_id=hit.get("announcementId"),
        announcement_time=hit.get("announcementTime"),
        url=url,
        size=size,
    )
    print(f"[{name} {code}] 下载完成 {size/1e6:.1f} MB -> {dest.name}")
    return record


def main() -> int:
    cfg = load_config()
    parser = argparse.ArgumentParser(description="下载 A 股年度报告")
    parser.add_argument("codes", nargs="*", help="只下载这些股票代码（默认全部）")
    parser.add_argument("--year", type=int, default=cfg.get("report_year", 2025))
    parser.add_argument("--force", action="store_true", help="已存在也重新下载")
    args = parser.parse_args()

    targets = cfg["companies"]
    if args.codes:
        wanted = set(args.codes)
        targets = [c for c in targets if c["code"] in wanted]
        # 清单外的代码现场解析，这样「网页上输入任意股票代码」不必先改 companies.json。
        known = {c["code"] for c in cfg["companies"]}
        for code in [c for c in args.codes if c not in known]:
            info = resolve_company(code)
            if info:
                print(f"[解析] {code} -> {info['name']}（{info['exchange']}）")
                targets.append(info)
            else:
                print(f"[warn] 无法解析股票代码 {code}", file=sys.stderr)

    ANNUAL_DIR.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    records = []
    for company in targets:
        try:
            records.append(fetch_one(company, args.year, session, force=args.force))
        except Exception as exc:  # noqa: BLE001 - 单家失败不影响其余
            print(f"[{company['name']} {company['code']}] 失败: {exc}", file=sys.stderr)
            records.append({"code": company["code"], "name": company["name"],
                            "year": args.year, "status": "error", "reason": str(exc)})
        time.sleep(0.8)  # 对巨潮友好一点

    # 合并历史记录，避免重跑时丢掉已下载项
    history = {}
    if LOG_PATH.exists():
        for rec in json.loads(LOG_PATH.read_text(encoding="utf-8")):
            history[rec.get("code")] = rec
    for rec in records:
        history[rec["code"]] = rec
    LOG_PATH.write_text(
        json.dumps(sorted(history.values(), key=lambda r: r.get("code", "")),
                   ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    ok = sum(1 for r in records if r.get("status") in ("downloaded", "cached"))
    print(f"\n完成：{ok}/{len(records)} 家成功。日志 -> {LOG_PATH}")
    return 0 if ok == len(records) else 1


if __name__ == "__main__":
    sys.exit(main())
