# -*- coding: utf-8 -*-
"""一键跑完 A 模块全流程。

顺序有依赖，不能乱：
    fetch -> pagemap -> indicators        （抽取链：先有 PDF，才有页码，才能抽数）
    chunker -> embed -> build_index       （检索链：切块要靠页码，索引要靠切块）
    export_metrics / build_queries        （页面数据与预置问题向量）
    verify                                （核验要求抽取与索引都已就绪）

用法:
    python src/run_all.py              # 全跑
    python src/run_all.py --skip-fetch # 已有年报 PDF，跳过下载
    python src/run_all.py --only extract
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent
ROOT = SRC.parent

EXTRACT = [
    ("fetch_cninfo.py", []),        # 已下载的会自动跳过
    ("pdf_pagemap.py", []),
    ("indicators.py", []),
]
INDEX = [
    ("chunker.py", []),
    ("embed.py", ["--check"]),
    ("build_index.py", []),
]
PAGE = [
    ("tokenize_zh.py", ["--self-test"]),
    ("export_metrics.py", []),
    ("build_queries.py", []),
]
VERIFY = [("run_verify.py", [])]


PATHS = {"run_verify.py": ROOT / "verify" / "run_verify.py"}


def run(script: str, extra: list[str]) -> bool:
    path = PATHS.get(script, SRC / script)
    print(f"\n>>> {script} {' '.join(extra)}")
    t0 = time.time()
    proc = subprocess.run([sys.executable, "-I", str(path), *extra], cwd=str(ROOT))
    print(f"<<< {script} 退出码 {proc.returncode}  用时 {time.time()-t0:.1f}s")
    return proc.returncode == 0


def main() -> int:
    ap = argparse.ArgumentParser(description="A 模块全流程")
    ap.add_argument("--skip-fetch", action="store_true")
    ap.add_argument("--only", choices=["extract", "index", "page", "verify"],
                    help="只跑其中一段")
    args = ap.parse_args()

    stages = []
    if not args.only or args.only == "extract":
        stages.append(("抽取", [s for s in EXTRACT if not (args.skip_fetch and s[0] == "fetch_cninfo.py")]))
    if not args.only or args.only == "index":
        stages.append(("索引", INDEX))
    if not args.only or args.only == "page":
        stages.append(("页面数据", PAGE))
    if not args.only or args.only == "verify":
        stages.append(("核验", VERIFY))

    failed = []
    for name, steps in stages:
        print(f"\n{'='*60}\n阶段：{name}\n{'='*60}")
        for script, extra in steps:
            if not run(script, extra):
                failed.append(script)
    if failed:
        print(f"\n以下步骤失败：{failed}")
        return 1
    print("\n全部完成。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
