# -*- coding: utf-8 -*-
"""把一家公司从系统里摘掉：分片、看板条目、抽取结果、中间产物，以及（可选）年报 PDF。

加错一家或者想清理试跑的公司时用。默认**只列出要删什么、不真删**，确认无误再加 --yes。
删除是不可逆的，所以这里刻意不做「智能猜测」，名字对不上就报错而不是模糊匹配。

用法:
    python src/remove_company.py 000651              # 预览
    python src/remove_company.py 000651 --yes        # 执行
    python src/remove_company.py 000651 --yes --keep-pdf
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import webdata                       # noqa: E402

ROOT = SRC.parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
EXTRACTED = ROOT / "data" / "extracted"
WORK = ROOT / "work"


def plan(code: str, keep_pdf: bool) -> list[tuple[str, Path, str]]:
    """返回 [(类别, 路径, 说明)]。只认精确匹配，不做模糊。"""
    items: list[tuple[str, Path, str]] = []

    shard = webdata.WEB_DATA / f"shard_{code}.js"
    if shard.exists():
        items.append(("分片", shard, "检索分片，删掉后该公司不再出现在问答里"))

    for p in EXTRACTED.glob(f"*_{code}_*.json"):
        items.append(("抽取", p, "指标抽取结果"))
    for p in (WORK / "pagemap").glob(f"*_{code}_*.pagemap.json"):
        items.append(("中间", p, "页码映射（可重新生成）"))
    for p in (WORK / "chunks").glob(f"*_{code}_*.chunks.jsonl"):
        items.append(("中间", p, "切块结果（可重新生成）"))
    if not keep_pdf:
        for p in ANNUAL_DIR.glob(f"*_{code}_*.pdf"):
            items.append(("年报", p, "原始年报 PDF"))
    return items


def prune_json(name: str, global_name: str, code: str) -> bool:
    """从 truth-source JSON 里去掉该公司，并重新生成 .js。返回是否有改动。"""
    data = webdata.load_published(name, global_name, None)
    if data is None:
        return False
    changed = False
    if name == "manifest":
        before = len(data.get("shards", []))
        data["shards"] = [s for s in data.get("shards", []) if s.get("code") != code]
        changed = len(data["shards"]) != before
    else:
        if code in data:
            del data[code]
            changed = True
    if changed:
        webdata.publish(name, global_name, data)
    return changed


def main() -> int:
    ap = argparse.ArgumentParser(description="移除一家公司的全部产物")
    ap.add_argument("code", help="6 位股票代码")
    ap.add_argument("--yes", action="store_true", help="真正执行删除（不加则只预览）")
    ap.add_argument("--keep-pdf", action="store_true", help="保留年报 PDF")
    args = ap.parse_args()

    code = args.code.strip()
    if not (len(code) == 6 and code.isdigit()):
        print("请给 6 位股票代码", file=sys.stderr)
        return 2

    items = plan(code, args.keep_pdf)
    print(f"公司 {code}：")
    if not items:
        print("  没有找到任何相关产物")
    for kind, path, note in items:
        try:
            size = f"{path.stat().st_size/1e6:.2f}MB"
        except OSError:
            size = "?"
        print(f"  [{kind}] {path.relative_to(ROOT)}  {size}  —— {note}")

    man = webdata.load_published("manifest", "FINSCOPE_MANIFEST", {"shards": []})
    in_manifest = any(s.get("code") == code for s in man.get("shards", []))
    met = webdata.load_published("metrics", "FINSCOPE_METRICS", {})
    in_metrics = isinstance(met, dict) and code in met
    print(f"  清单条目：manifest {'有' if in_manifest else '无'}，"
          f"metrics {'有' if in_metrics else '无'}")

    if not args.yes:
        print("\n以上为预览。确认无误后加 --yes 执行。")
        return 0

    removed = 0
    for _kind, path, _note in items:
        try:
            path.unlink()
            removed += 1
        except OSError as exc:
            print(f"  删除失败 {path.name}: {exc}", file=sys.stderr)
    prune_json("manifest", "FINSCOPE_MANIFEST", code)
    prune_json("metrics", "FINSCOPE_METRICS", code)

    print(f"\n已删除 {removed} 个文件，并从 manifest / metrics 移除条目。")
    print("刷新页面即可看到该公司消失。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
