# -*- coding: utf-8 -*-
"""中文年报表格抽取：按坐标把页面还原成「科目名 + 多期数值」。

年报表格有五个坑，全部用坐标解决：

1. **数值成列且右对齐** —— 聚合同页数值词的右边缘得到列位置。比 extract_tables
   可靠：后者遇合并单元格、无框线表就散架。
2. **科目名折行、数值垂直居中** —— 折行科目名拆成上下两段，数值夹在中间。做法是
   先把数值词聚成「行锚」，再把科目区的词按「离最近行锚的垂直距离」分配过去，
   而不是按 top 硬切行。
3. **表头可能跨两行且本身没有数字** —— 三表页的表头是
   「2025年度 2024年度 2025年度 2024年度」+ 下一行「合并 合并 公司 公司」。
   表头行没有数值，不会被行锚捕获，所以表头识别必须独立走一遍全页视觉行。
4. **合并/公司同页并列** —— 同一科目有四个数：合并本期、合并上期、公司本期、
   公司上期。靠表头第二行的「合并 / 公司」子标签按 x 位置区分，只取合并口径。
5. **附注号混进科目名** —— 科目名右边常有「四(48)」「十八(3)」这类附注索引，
   位置落在科目区里，会污染科目名。按模式剔除。

用法（作为库）:
    from table_extract import parse_page_table
    table = parse_page_table(page)
"""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

# 数值：允许千分位、小数、负号、括号负数（中文报表里 (123) 表示 -123）
_AMOUNT_RE = re.compile(r"^([（(])?([+-]?)([\d,]+(?:\.\d+)?)([)）])?$")
_PERCENT_RE = re.compile(r"^([（(])?([+-]?)([\d.]+)\s*%([)）])?$")

# 语义空值：命中科目名但值确实是「没有」
_EMPTY_TOKENS = {"-", "—", "－", "–", "/", "不适用", "无", "N/A", "n/a", "nil"}

# 附注索引。各家写法不一，都要覆盖：四(48)、七、24、(五)19、(12)、48
_NOTE_REF_RE = re.compile(
    r"^(?:"
    r"[一二三四五六七八九十百]+[、.]?[（(]?\d*[)）]?\d*"   # 七、24 ／ 四(48) ／ 五
    r"|[（(][一二三四五六七八九十百\d]+[)）]\d*"          # (五)19 ／ (1)
    r"|\d{1,3}"                                          # 28
    r")$")

# 折行科目名的接续字：完整科目名不会以这些字收尾，也不会以它们开头，
# 出现即说明这一截还没写完
_CONT_TAIL = set("的、和与及或（(／/")
_CONT_HEAD = set("的、和与及或")

# 阈值
_ROW_TOL = 3.0
_COL_TOL = 8.0
_LABEL_RADIUS_MIN = 13.0
_LABEL_RADIUS_MAX = 17.0
_TOKEN_GAP = 6.0

_UNIT_RE = re.compile(r"[（(]\s*(?:人民币)?\s*(元/股|元／股|千元|百万元|万元|亿元|元)\s*[)）]")
_UNIT_LINE_RE = re.compile(r"(?:单位\s*[：:]|金额单位为?)\s*(?:人民币)?\s*(元/股|千元|百万元|万元|亿元|元)")
_UNIT_SCALE = {"元": Decimal(1), "千元": Decimal(1000), "万元": Decimal(10000),
               "百万元": Decimal(1000000), "亿元": Decimal(100000000),
               "元/股": Decimal(1), "元／股": Decimal(1)}

_PERIOD_HINT = re.compile(r"(20\d{2}|年末|年初|期末|期初|本期|上期|本年|上年|增减|变动|同比|幅度)")
_SCOPE_RE = re.compile(r"(合并|母公司|本集团|本公司|公司)")

# 非表格行：页眉、报表标题、单位说明、公司名。这些行里的数字不是表格数据，
# 必须整条排除，否则标题里的「2025」会参与定列。
_NON_TABLE_PATTERNS = [
    re.compile(r"年度报告|年报全文"),
    re.compile(r"^(?:\d{4}\s*年度)?\s*(?:合并及公司|合并|母公司|公司)?\s*"
               r"(?:资产负债表|利润表|现金流量表)(?:[（(]续[)）])?$"),
    re.compile(r"^[（(]?除特别注明外"),
    re.compile(r"^(?:单位|金额单位)\s*[：:]"),
    re.compile(r"^[一-龥]{2,20}(?:集团)?(?:股份)?有限公司$"),
]


def _is_non_table_line(text: str) -> bool:
    t = text.strip()
    if not t or len(t) > 40:
        return False
    return any(p.search(t) for p in _NON_TABLE_PATTERNS)


def normalize(text: str) -> str:
    """全角转半角、去掉零宽字符。"""
    if not text:
        return ""
    out = []
    for ch in text:
        code = ord(ch)
        if code == 0x3000:
            out.append(" ")
        elif 0xFF01 <= code <= 0xFF5E:
            out.append(chr(code - 0xFEE0))
        elif code in (0x200B, 0x200C, 0x200D, 0xFEFF):
            continue
        else:
            out.append(ch)
    return "".join(out)


def parse_amount(text: str) -> tuple[Decimal | None, str]:
    """解析金额，返回 (值, 类型)，类型 ∈ amount/percent/empty/text。"""
    t = normalize(text).strip().replace(" ", "")
    if not t:
        return None, "text"
    if t in _EMPTY_TOKENS:
        return None, "empty"
    m = _PERCENT_RE.match(t)
    if m:
        try:
            return Decimal(m.group(2) + m.group(3)), "percent"
        except InvalidOperation:
            return None, "text"
    m = _AMOUNT_RE.match(t)
    if m:
        raw = m.group(3).replace(",", "")
        if not raw or raw in (".", "-"):
            return None, "text"
        try:
            val = Decimal(raw)
        except InvalidOperation:
            return None, "text"
        if m.group(2) == "-" or (m.group(1) and m.group(4)):
            val = -val
        return val, "amount"
    return None, "text"


def group_lines(words: list[dict], tol: float = _ROW_TOL) -> list[list[dict]]:
    lines: list[list[dict]] = []
    for w in sorted(words, key=lambda d: (d["top"], d["x0"])):
        if lines and abs(w["top"] - lines[-1][0]["top"]) <= tol:
            lines[-1].append(w)
        else:
            lines.append([w])
    for ln in lines:
        ln.sort(key=lambda d: d["x0"])
    return lines


def _merge_line_tokens(line: list[dict], gap: float = _TOKEN_GAP) -> list[dict]:
    """把一行的词按窄间隙合并成「列头候选」，如 2025 + 年度 -> 2025年度。"""
    out: list[dict] = []
    for w in line:
        if out and w["x0"] - out[-1]["x1"] <= gap:
            out[-1]["x1"] = max(out[-1]["x1"], w["x1"])
            out[-1]["text"] += normalize(w["text"])
        else:
            out.append({"x0": w["x0"], "x1": w["x1"], "text": normalize(w["text"]),
                        "top": w["top"]})
    for t in out:
        t["xc"] = (t["x0"] + t["x1"]) / 2
    return out


def _merge_numeric_fragments(words: list[dict]) -> list[dict]:
    """pdfplumber 偶尔把 456,451,731 拆成两三个词，按窄间隙拼回去。"""
    if not words:
        return []
    merged = [dict(words[0])]
    for w in words[1:]:
        prev = merged[-1]
        gap = w["x0"] - prev["x1"]
        _, pk = parse_amount(prev["text"])
        _, ck = parse_amount(w["text"])
        frag = prev["text"].rstrip().endswith((",", ".", "-", "(")) or \
            w["text"].lstrip().startswith((".", ","))
        if gap < 2.0 and pk in ("amount", "percent") and ck in ("amount", "percent") and frag:
            prev["text"] += w["text"]
            prev["x1"] = w["x1"]
            continue
        merged.append(dict(w))
    return merged


def _cluster_values(values: list[float], tol: float) -> list[list[float]]:
    if not values:
        return []
    xs = sorted(values)
    clusters: list[list[float]] = [[xs[0]]]
    for x in xs[1:]:
        if x - clusters[-1][-1] <= tol:
            clusters[-1].append(x)
        else:
            clusters.append([x])
    return clusters


def detect_columns(numeric_words: list[dict], tol: float = _COL_TOL) -> list[dict]:
    return [{"right": sum(c) / len(c), "n": len(c)}
            for c in _cluster_values([w["x1"] for w in numeric_words], tol)]


def _group_by_right(numeric_words: list[dict]) -> dict[float, list[dict]]:
    by_right: dict[float, list[dict]] = {}
    for w in numeric_words:
        key = None
        for k in by_right:
            if abs(k - w["x1"]) <= _COL_TOL:
                key = k
                break
        if key is None:
            by_right[w["x1"]] = [w]
        else:
            by_right[key].append(w)
    return by_right


def note_ref_columns(numeric_words: list[dict]) -> list[float]:
    """找出「整列都是小整数」的列——那是资产负债表的附注索引列（1、2、3、28…），
    不是金额列。

    不排掉它会出很隐蔽的错：附注列在科目区和金额列之间，被当成金额列后，
    「2025」那一栏会取到附注号 1，于是应收账款从 118 亿变成 1 元，页面照样显示不报错。
    """
    by_right = _group_by_right(numeric_words)
    if len(by_right) <= 1:
        return []
    out = []
    for right, ws in by_right.items():
        vals = [w["value"] for w in ws]
        if len(vals) >= 3 and all(
                v == v.to_integral_value() and 1 <= v <= 199 for v in vals):
            out.append(right)
    return out


def table_left_edge(numeric_words: list[dict], min_support: int = 3) -> float:
    """科目区的右界：取「有足够支撑度的最左列」的左边缘。

    不能直接用全部数值词的最小 x0——页面标题里的「2025」、正文里的孤立数字
    都会把边界拉到页面左边，导致整个科目区被当成数值区。
    """
    if not numeric_words:
        return 0.0
    by_right = {}
    for w in numeric_words:
        key = None
        for k in by_right:
            if abs(k - w["x1"]) <= _COL_TOL:
                key = k
                break
        if key is None:
            by_right[w["x1"]] = [w]
        else:
            by_right[key].append(w)
    qualified = [grp for grp in by_right.values() if len(grp) >= min_support]
    if not qualified:
        qualified = list(by_right.values())
    leftmost = min(qualified, key=lambda g: min(w["x0"] for w in g))
    return min(w["x0"] for w in leftmost)


def _nearest_column(x1: float, columns: list[dict]) -> int | None:
    if not columns:
        return None
    idx = min(range(len(columns)), key=lambda i: abs(columns[i]["right"] - x1))
    if abs(columns[idx]["right"] - x1) > 18.0:
        return None
    return idx


def detect_unit(page) -> tuple[str, Decimal, bool]:
    """在整页文本里找「单位：X」「金额单位为人民币X」。

    第三个返回值表示「本页是否明确写了单位」。跨页续表上往往没有这行，单位写在
    首页，所以要靠调用方继承；不继承的话千元会被当成元，数字差 1000 倍。
    """
    for m in _UNIT_LINE_RE.finditer(normalize(page.extract_text() or "")):
        unit = m.group(1)
        return unit, _UNIT_SCALE.get(unit, Decimal(1)), True
    return "元", Decimal(1), False


# ------------------------------------------------------------ 表头

def period_key(text: str) -> str:
    """列头文字 -> 期间键：2025 / 2024 / 本期 / 上期 / 增减 / 其他。

    三条顺序上的讲究，任何一条错了都会静默出错值：
    1. 纯百分比不能当「增减」列头，否则数据行里的 19.70% 会被当成表头行；
    2. 上期要排在**本期之前**判断——「上年年末余额」同时含「上年」和「年末」，
       按本期那组先判就会被认成本期，两列都变成同一个键，后一列的数值直接被丢；
    3. 年份优先于上面两组，「2024年12月31日」要认成 2024 而不是「本期」。
    """
    t = normalize(text).replace(" ", "")
    m = re.search(r"(20\d{2})", t)
    if m:
        return m.group(1)
    if re.search(r"(增减|变动|同比|幅度|增长)", t):
        return "增减"
    if re.search(r"(上期|上年|上年度|期初|年初)", t):
        return "上期"
    if re.search(r"(本期|本年|本年度|期末|年末)", t):
        return "本期"
    return "其他"


def _is_delta(text: str) -> bool:
    return bool(re.search(r"(增减|变动|同比|幅度)", normalize(text)))


def scope_key(text: str) -> str | None:
    """合并 / 母公司 / None。"""
    t = normalize(text)
    if "合并" in t or "本集团" in t:
        return "合并"
    if "母公司" in t or "本公司" in t:
        return "母公司"
    if t.strip() == "公司":
        return "母公司"
    return None


def _in_value_band(t: dict, label_x_max: float, slack: float = 30.0) -> bool:
    """判断一个词是否属于数值区（含表头）。

    判据用**右缘**不用左缘：表头文字常比数值列宽、居中排布，左缘会落在科目名区
    右侧。宁德时代「期末余额」[279-315] 的左缘 279 就在科目名右界 323 的左边，
    按左缘判会把整个表头丢掉，那一页的数值就全没有年度归属了。科目名本身很长、
    右缘越界的，会被 period_key 判为「其他」而滤掉，不会混进来。
    """
    return t["x1"] >= label_x_max - slack


def detect_header(lines: list[list[dict]], label_x_max: float) -> dict:
    """独立于数值行找表头——三表页的表头本身没有数字，抓不到行锚。

    表头可能跨两行：第一行是期间（2025年度 / 2024年度…），第二行是口径
    （合并 / 公司）。返回期间列与口径列的 x 位置。
    """
    best_i, best_score = None, 0
    for i, line in enumerate(lines):
        toks = [t for t in _merge_line_tokens(line) if _in_value_band(t, label_x_max)]
        score = sum(1 for t in toks if period_key(t["text"]) != "其他")
        if score > best_score and len(toks) >= 2:
            best_i, best_score = i, score
    if best_i is None or best_score < 2:
        return {"periods": [], "scopes": [], "header_lines": []}

    periods = [dict(t, key=period_key(t["text"]), is_delta=_is_delta(t["text"]))
               for t in _merge_line_tokens(lines[best_i])
               if _in_value_band(t, label_x_max) and period_key(t["text"]) != "其他"]

    scopes: list[dict] = []
    header_lines = [best_i]
    for j in (best_i + 1, best_i + 2):
        if j >= len(lines):
            break
        toks = [t for t in _merge_line_tokens(lines[j]) if _in_value_band(t, label_x_max)]
        if not toks:
            break
        keys = [scope_key(t["text"]) for t in toks]
        if sum(1 for k in keys if k) >= max(2, len(toks) // 2):
            scopes = [{"xc": t["xc"], "scope": scope_key(t["text"])} for t in toks
                      if scope_key(t["text"])]
            header_lines.append(j)
            break
    return {"periods": periods, "scopes": scopes, "header_lines": header_lines}


# ------------------------------------------------------------ 主解析

def parse_page_table(page, y_from: float | None = None, y_to: float | None = None,
                     label_x_max: float | None = None,
                     header_override: dict | None = None) -> dict:
    """把一页（或纵向区间）解析成列定义 + 行。

    header_override 用于跨页续表：三表常跨两三页，续页上只有数值没有表头，
    自身推不出口径，必须继承上一页的列头。
    """
    y0 = y_from if y_from is not None else page.height * 0.06
    y1 = y_to if y_to is not None else page.height * 0.90

    raw_words = [w for w in page.extract_words(x_tolerance=1.5, keep_blank_chars=False)
                 if y0 <= w["top"] <= y1]
    # 先按视觉行找出「非表格行」（页眉、报表标题、单位说明），整条 y 带排除。
    # 报表标题里的「2025」若不排除，会被当成数值参与定列，把科目区挤没。
    excluded_bands = []
    for line in group_lines(raw_words, tol=4.0):
        text = normalize("".join(w["text"] for w in line))
        if _is_non_table_line(text):
            excluded_bands.append((min(w["top"] for w in line) - 2,
                                   max(w["bottom"] for w in line) + 2))

    def _excluded(w: dict) -> bool:
        c = (w["top"] + w["bottom"]) / 2
        return any(a <= c <= b for a, b in excluded_bands)

    words = _merge_numeric_fragments([w for w in raw_words if not _excluded(w)])

    # 只用严格金额/百分比定数值列；含数字的非数值词（信用代码、年份、附注号）
    # 一律不算，否则科目区右界会算到页码位置，列标签全部丢失。
    strict = [{**w, "value": v, "kind": k} for w in words
              for v, k in [parse_amount(w["text"])]
              if k in ("amount", "percent") and v is not None]
    # 先摘掉附注索引列，再定数值列与科目区边界
    ref_cols = note_ref_columns(strict)
    if ref_cols:
        strict = [w for w in strict
                  if not any(abs(w["x1"] - c) <= _COL_TOL for c in ref_cols)]
    if not strict:
        return {"columns": [], "rows": [], "unit": "元", "scale": Decimal(1),
                "unit_explicit": False,
                "label_x_max": label_x_max or page.width * 0.78, "orphan_labels": [],
                "header_periods": [], "header_scopes": []}

    columns = detect_columns(strict)
    if label_x_max is None:
        label_x_max = table_left_edge(strict) - 4

    value_words = [w for w in words if w["x0"] >= label_x_max]
    label_words = [w for w in words if w["x0"] < label_x_max]

    lines = group_lines(words)
    header = detect_header(lines, label_x_max)
    if not header["periods"] and header_override and header_override.get("periods"):
        header = {"periods": header_override["periods"],
                  "scopes": header_override.get("scopes", []),
                  "header_lines": []}

    anchors: list[float] = []
    for t in sorted(round(w["top"], 1) for w in strict):
        if not anchors or abs(t - anchors[-1]) > _ROW_TOL:
            anchors.append(t)

    gaps = [b - a for a, b in zip(anchors, anchors[1:])]
    radius = _LABEL_RADIUS_MAX
    if gaps:
        radius = min(_LABEL_RADIUS_MAX, max(_LABEL_RADIUS_MIN,
                                            sorted(gaps)[len(gaps) // 2] * 0.62))

    rows = [{"top": t, "label_parts": [], "cells": []} for t in anchors]

    # 科目名按「视觉行」而不是按「词」分配，并且带连续性：折行科目名的第二行
    # 往往离下一行的数值比离本行数值更近（茅台「扣除非…经常性损益的净利润」就是
    # 这样），逐词取最近会把半截科目名送给下一行。规则是——上一行科目名若已归
    # 到某个行锚，且本行仍在它的归属半径内，就跟着它走。
    # 科目名分两轮归属，避免「无值的行」把科目名漏给邻行：
    #   第一轮：与某个行锚同行的科目名，直接归它——这是最硬的证据；
    #   第二轮：剩下的按折行续行处理，条件是上一行的行锚**夹在两行科目名之间**
    #           （折行科目名一定是「第一段 / 数值 / 第二段」这个夹心结构）；
    #   两轮都没归上的丢弃。宁可丢一个用不到的科目名，也不能让它污染邻行——
    #   伊利资产负债表里「应收分保合同准备金」（该行为空）就曾把名字并到
    #   「其他应收款」上，导致按别名匹配全部落空。
    label_lines = group_lines([w for w in label_words
                               if not _NOTE_REF_RE.match(normalize(w["text"]).strip())])
    label_lines.sort(key=lambda ln: min(w["top"] for w in ln))

    tops = [min(w["top"] for w in ln) for ln in label_lines]
    centers = [sum((w["top"] + w["bottom"]) / 2 for w in ln) / len(ln) for ln in label_lines]
    line_anchor: dict[int, int] = {}
    claimed: set[int] = set()

    for j, ln in enumerate(label_lines):                      # 第一轮
        for i, a in enumerate(anchors):
            if abs(a - tops[j]) <= _ROW_TOL and i not in claimed:
                line_anchor[j] = i
                claimed.add(i)
                break

    # 第二轮：折行续行。判据是「上一行的数值夹在两截科目名之间」，但只在**上一行
    # 本身也是折行片段**时才启用（用中心而不是顶边来判，理由同下）。
    #
    # 为什么必须区分上一行的来路：如果是「科目名与数值同行」的正常行，它下面那一行
    # 就是新科目，不是续行。三一重工现金流量表里「投资活动现金流入小计」下面紧跟
    # 「购建固定资产、无形资产…支付的」，不区分就会把这一行的科目名并进上一行。
    pass1_lines = set(line_anchor.keys())
    prev_anchor, prev_center, prev_is_p1 = None, None, False       # 第二轮
    for j, ln in enumerate(label_lines):
        if j in line_anchor:
            prev_anchor, prev_center = line_anchor[j], centers[j]
            prev_is_p1 = j in pass1_lines
            continue
        center = centers[j]
        nearest = min(range(len(anchors)), key=lambda i: abs(anchors[i] - center))
        d_near = abs(anchors[nearest] - center)
        idx = None
        if nearest not in claimed and d_near <= radius:
            idx = nearest                       # 情形一：本行对应的行锚还没人认领
        elif nearest in claimed and d_near <= radius and center > anchors[nearest]:
            idx = nearest                       # 情形二：落在已认领行锚的下方，是它的下半截
        elif (prev_anchor is not None and not prev_is_p1 and prev_center is not None
                and prev_center < anchors[prev_anchor] < center):
            idx = prev_anchor                   # 情形三：接上一截折行科目名
        if idx is not None:
            line_anchor[j] = idx
            claimed.add(idx)
        prev_anchor, prev_center, prev_is_p1 = idx, center, False

    # 第三轮：收尾那些「半截」科目名——它们在数值行的同侧，前两轮都顾不上。
    # 两个方向都要认，因为折行断点各家不同：
    #   正向：本段以接续字结尾（「…支付的」），说明话没说完，归下面的数值行；
    #   反向：下面那行已经归到某个数值行，且它的开头是接续字（「的扣除非经常性
    #         损益」），那本段就是它的前半截（宁德时代「归属于上市公司股东」）。
    # 伊利资产负债表里那个空行科目名「应收分保合同准备金」两头都不满足，因此
    # 不会被误并到下一行。
    def _assigned_text(anchor_idx: int) -> str:
        """已经归到这个行锚的科目名文本（按阅读顺序拼）。"""
        parts = [label_lines[j] for j, a in line_anchor.items() if a == anchor_idx]
        parts.sort(key=lambda ln: min(w["top"] for w in ln))
        return "".join(w["text"] for ln in parts for w in ln).strip()

    for j, ln in enumerate(label_lines):
        if j in line_anchor:
            continue
        text = "".join(w["text"] for w in ln).strip()
        if not text:
            continue
        center = centers[j]
        below = [i for i in range(len(anchors)) if 0 < anchors[i] - center <= radius * 1.4]
        if not below:
            continue
        i = min(below, key=lambda k: anchors[k] - center)
        if text[-1] in _CONT_TAIL:
            line_anchor[j] = i
            continue
        head = _assigned_text(i)
        if head and head[0] in _CONT_HEAD:
            line_anchor[j] = i

    for j, i in line_anchor.items():
        rows[i]["label_parts"].extend(label_lines[j])

    # 没归上任何行锚的科目行单独留着，别丢。它们大多是「科目在、但本期值为空」的行
    # （贵州茅台的「商誉」就是这种：表里有这一行，数字栏是空的）。下游据此判
    # not_applicable——「确定没有」和「没抽到」是两件事，混为一谈会误导使用者。
    orphan_labels = []
    for j, ln in enumerate(label_lines):
        if j in line_anchor:
            continue
        text = normalize("".join(w["text"] for w in ln)).strip()
        if text and any("一" <= c <= "鿿" for c in text):
            orphan_labels.append({"label": text, "top": round(min(w["top"] for w in ln), 1)})

    for w in value_words:
        v, k = parse_amount(w["text"])
        center = (w["top"] + w["bottom"]) / 2
        best = min(range(len(anchors)), key=lambda i: abs(anchors[i] - center))
        if abs(anchors[best] - center) > _ROW_TOL * 2:
            continue
        rows[best]["cells"].append({
            "col": _nearest_column(w["x1"], columns), "x1": round(w["x1"], 1),
            "xc": round((w["x0"] + w["x1"]) / 2, 1),
            "text": w["text"], "value": v, "kind": k,
        })

    out_rows = []
    for r in rows:
        parts = sorted(r["label_parts"], key=lambda w: (round(w["top"], 1), w["x0"]))
        label = normalize("".join(p["text"] for p in parts)).strip()
        mu = _UNIT_RE.search(label)
        cells = sorted(r["cells"], key=lambda c: c["xc"])
        band = [w for w in words if abs((w["top"] + w["bottom"]) / 2 - r["top"]) <= radius]
        band.sort(key=lambda w: w["x0"])
        out_rows.append({
            "top": round(r["top"], 1), "label": label,
            "unit_hint": mu.group(1) if mu else None,
            "cells": cells, "words": band,
            "raw": normalize(" ".join([label] + [c["text"] for c in cells])),
        })

    _assign_periods(out_rows, header["periods"], header["scopes"],
                    skip=header["header_lines"])

    unit, scale, unit_explicit = detect_unit(page)
    return {"columns": columns, "rows": out_rows, "unit": unit, "scale": scale,
            "unit_explicit": unit_explicit,
            "label_x_max": label_x_max, "orphan_labels": orphan_labels,
            "header_periods": header["periods"], "header_scopes": header["scopes"]}


def _assign_periods(rows: list[dict], periods: list[dict], scopes: list[dict],
                    skip: list[int]) -> None:
    """按 x 中心把数值挂到列头；有合并/公司子标签时只保留合并口径。"""
    for i, r in enumerate(rows):
        values, kinds, scopes_out = {}, {}, {}
        if i not in skip and periods:
            xs = sorted(p["xc"] for p in periods)
            tol = 60.0
            if len(xs) > 1:
                tol = max(30.0, min(b - a for a, b in zip(xs, xs[1:])) * 0.75)
            for c in r["cells"]:
                if c["kind"] not in ("amount", "percent", "empty"):
                    continue
                near = min(periods, key=lambda p: abs(p["xc"] - c["xc"]))
                if abs(near["xc"] - c["xc"]) > tol:
                    continue
                if scopes:
                    ns = min(scopes, key=lambda s: abs(s["xc"] - c["xc"]))
                    if ns["scope"] == "母公司":
                        continue          # 只要合并口径
                    scopes_out[near["key"]] = ns["scope"]
                key = near["key"] + ("_增减" if near["is_delta"] else "")
                values.setdefault(key, c["value"])
                kinds.setdefault(key, c["kind"])
        r["values"], r["kinds"], r["scopes"] = values, kinds, scopes_out


def format_amount(value: Decimal | None, scale: Decimal = Decimal(1)) -> str:
    if value is None:
        return ""
    yuan = value * scale
    return f"{yuan:,.0f}" if yuan == yuan.to_integral_value() else f"{yuan:,.2f}"
