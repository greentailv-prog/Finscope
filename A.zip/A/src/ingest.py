# -*- coding: utf-8 -*-
"""把一家新公司接进系统：下载 / 定位年报 → 页码映射 → 指标抽取 → 切块 → 建索引 → 看板。

**建索引与看板放最后**（`index`、`metrics`）。前面任何一步失败，页面上就完全看不到
这家公司，不会出现「列表里有它、点开却没数据」的半截状态。前面的产物按 stem 覆盖，
天然幂等，重试就是重跑同一个任务。

另有一条 upload 流程：PDF 已由上传接口落到 `data/annual_reports/`，从页码映射开始跑。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import identify                      # noqa: E402
import jobs                          # noqa: E402

ROOT = SRC.parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
EXTRACTED = ROOT / "data" / "extracted"
WORK_DIR = ROOT / "work"

PAGEMAP_COVERAGE_MIN = 0.85
MIN_METRICS_FOUND = 12               # 17 项里少于这个数，多半是解析出了问题


def _script(name: str) -> str:
    return str(SRC / name)


def _find_pdf(code: str, year: int) -> Path | None:
    """按代码找年报 PDF。文件名约定是 <公司名>_<代码>_<年份>.pdf，公司名可能带简称差异，
    所以按「代码 + 年份」兜底匹配，而不是拼死一个名字。"""
    hits = [p for p in ANNUAL_DIR.glob(f"*_{code}_{year}.pdf") if p.stat().st_size > 100_000]
    return hits[0] if hits else None


def _read_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def run(job: dict, ctx: "jobs.JobContext") -> dict:
    params = job["params"]
    code = str(params.get("code") or "").strip()
    year = int(params.get("year") or 2025)
    warnings: list[str] = []

    if job["kind"] == "upload":
        stem = params["stem"]
        code = params.get("code") or stem.split("_")[1]
        pdf = ANNUAL_DIR / f"{stem}.pdf"
        if not pdf.exists():
            raise RuntimeError(f"上传的年报不在预期位置：{pdf.name}")
        name = stem.split("_")[0]
    else:
        if not identify.is_valid_code(code):
            raise RuntimeError(f"股票代码不合法：{code!r}")
        ctx.set_step("resolve")
        from fetch_cninfo import resolve_company
        info = resolve_company(code)
        if not info:
            raise RuntimeError(f"无法解析股票代码 {code}，请确认代码是否正确")
        name = info["name"]
        ctx.log(f"解析到：{name}（{info['code']}，{info['exchange']}）")

        ctx.set_step("download")
        rc = ctx.run([_script("fetch_cninfo.py"), code, "--year", str(year)])
        if rc != 0:
            raise RuntimeError(f"下载年报失败（退出码 {rc}）。可能是该公司尚未披露 {year} 年年报。")
        pdf = _find_pdf(code, year)
        if pdf is None:
            raise RuntimeError(f"下载后没找到年报文件（{code} {year}）")
        stem = pdf.stem
        if stem.split("_")[0] != name:
            name = stem.split("_")[0]

    ctx.log(f"年报文件：{pdf.name}（{pdf.stat().st_size/1e6:.1f} MB）")

    # ---- 页码映射 ----
    ctx.set_step("pagemap")
    rc = ctx.run([_script("pdf_pagemap.py"), "--pdf", str(pdf)])
    if rc != 0:
        raise RuntimeError("页码映射失败")
    pm = _read_json(WORK_DIR / "pagemap" / f"{stem}.pagemap.json")
    if pm:
        v = pm.get("validation", {})
        cov = v.get("coverage", 0)
        ctx.log(f"页码映射：覆盖率 {cov:.2f}，分段 {v.get('n_runs')}，"
                f"单调 {v.get('monotonic_ok')}")
        if cov < PAGEMAP_COVERAGE_MIN or not v.get("monotonic_ok"):
            warnings.append("pagemap_low_quality")
            ctx.log("[注意] 页码映射质量偏低，引用页码的可靠性下降")

    # ---- 指标抽取 ----
    ctx.set_step("indicators")
    rc = ctx.run([_script("indicators.py"), "--pdf", str(pdf)])
    if rc != 0:
        raise RuntimeError("指标抽取失败")
    ext = _read_json(EXTRACTED / f"{stem}.json")
    if ext:
        fin = ext.get("financials", {})
        found = [k for k, v in fin.items() if v.get("status") == "found"]
        absent = [k for k, v in fin.items() if v.get("status") == "not_applicable"]
        missing = [k for k, v in fin.items() if v.get("status") == "not_found"]
        ctx.log(f"指标命中 {len(found)}/17，值为空 {len(absent)}，未抽到 {len(missing)}")
        if missing:
            ctx.log("  未抽到：" + "、".join(missing))
        if len(found) < MIN_METRICS_FOUND:
            warnings.append("few_metrics")
            ctx.log("[注意] 命中数偏少，可能该公司报表版式与已支持的样本差异较大")

    # ---- 切块 ----
    ctx.set_step("chunker")
    rc = ctx.run([_script("chunker.py"), "--pdf", str(pdf)])
    if rc != 0:
        raise RuntimeError("切块失败")
    chunk_path = WORK_DIR / "chunks" / f"{stem}.chunks.jsonl"
    n_chunks = sum(1 for line in chunk_path.read_text(encoding="utf-8").splitlines() if line.strip()) \
        if chunk_path.exists() else 0
    if n_chunks == 0:
        raise RuntimeError("切块结果为空，无法建立检索")
    ctx.log(f"切出 {n_chunks} 个块")

    # ---- 建索引（只算这一家，其余分片原样保留）----
    ctx.set_step("index")
    rc = ctx.run([_script("build_index.py"), "--codes", code])
    if rc != 0:
        raise RuntimeError("建立检索索引失败")

    # ---- 看板数据 ----
    ctx.set_step("metrics")
    rc = ctx.run([_script("export_metrics.py"), "--codes", code])
    if rc != 0:
        raise RuntimeError("更新看板数据失败")

    return {
        "code": code, "name": name, "stem": stem,
        "year": year, "n_chunks": n_chunks,
        "metrics_found": len([k for k, v in (ext or {}).get("financials", {}).items()
                              if v.get("status") == "found"]) if ext else None,
        "warnings": warnings,
        "pdf": pdf.name,
    }


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    code = sys.argv[1] if len(sys.argv) > 1 else "000651"
    job = {"kind": "ingest", "params": {"code": code, "year": 2025}, "id": "manual"}
    job.setdefault("log", __import__("collections").deque(maxlen=200))
    ctx = jobs.JobContext(job)
    ctx.log = print          # 手动跑时直接打到终端
    print(run(job, ctx))
