# -*- coding: utf-8 -*-
"""建立「PDF 物理页序号 -> 年报印刷页码」的映射。

A 模块所有引用都要落到年报页码上，所以这一步是地基。做法分四步：

1. 逐页在页边带取词，用一组正则识别页码候选。显式页码语法（第N页、N/总数）
   在页眉页脚都可信；裸数字只认页脚——页眉里的 2025、2021 是年份不是页码。
2. **按偏移直方图定标**：把每个候选换算成偏移 (印刷号 - 物理页)，统计各偏移的
   支持度与得分。真实偏移会形成压倒性主峰；逐页取最大分会把年份误当页码，
   全局直方图能躲开这个坑。
3. 用被接受的偏移给每页定值，落在已覆盖区间内但该页没候选的，按邻近偏移推算，
   标记 inferred；推算值小于 1（封面）一律置空，不编造「第 0 页」。
4. 校验覆盖率、单调性、段数，并保留页脚原文作为证据。

用法:
    python pdf_pagemap.py                      # 处理 data/annual_reports 下全部 PDF
    python pdf_pagemap.py --pdf <路径>          # 只处理一份并落盘
    python pdf_pagemap.py --diagnose <路径>     # 只打印候选与定标细节，不落盘
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import pdfplumber

ROOT = Path(__file__).resolve().parent.parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
WORK_DIR = ROOT / "work" / "pagemap"

# 候选模式：(名称, 正则, 基础置信度, 是否显式页码语法)
_PATTERNS = [
    ("cn_page_of", re.compile(r"^第\s*(\d{1,4})\s*页\s*[/共]\s*(\d{1,4})\s*页$"), 0.97, True),
    ("fraction", re.compile(r"^(\d{1,4})\s*/\s*(\d{1,4})$"), 0.94, True),
    ("cn_page", re.compile(r"^第\s*(\d{1,4})\s*页$"), 0.90, True),
    ("roman", re.compile(r"^[ivxlcdm]{1,7}$"), 0.55, False),
    ("bare", re.compile(r"^(\d{1,4})$"), 0.50, False),
]

_ROMAN = {"i": 1, "v": 5, "x": 10, "l": 50, "c": 100, "d": 500, "m": 1000}

# 定标阈值
_MIN_SUPPORT_ABS = 3          # 一个偏移至少要有这么多页支持
_MIN_SUPPORT_REL = 0.15       # 或达到主峰支持度的这个比例
_TOTAL_MATCH_BONUS = 0.12     # 候选里的「总数」等于 PDF 总页数时加分


def roman_to_int(s: str) -> int | None:
    s = s.lower()
    if not s or any(c not in _ROMAN for c in s):
        return None
    total, prev = 0, 0
    for ch in reversed(s):
        v = _ROMAN[ch]
        total += -v if v < prev else v
        prev = max(prev, v)
    return total


def page_candidates(page) -> list[dict]:
    """在一页里找出所有可能的印刷页码候选。"""
    W, H = page.width, page.height
    hi, lo = H * 0.12, H * 0.86
    out: list[dict] = []
    for w in page.extract_words(use_text_flow=False, keep_blank_chars=False, x_tolerance=1.5):
        text = w["text"].strip()
        if not text:
            continue
        top = w["top"]
        if top >= lo:
            band, band_bonus = "bottom", 0.06
        elif top <= hi:
            band, band_bonus = "top", 0.0
        else:
            continue
        for pname, pat, base, explicit in _PATTERNS:
            m = pat.fullmatch(text)
            if not m:
                continue
            # 裸数字只认页脚：页眉里的 2025 是年份
            if pname == "bare" and band != "bottom":
                continue
            if pname == "roman":
                num = roman_to_int(text)
                if num is None or num > 60:
                    continue
                total = None
            else:
                num = int(m.group(1))
                total = int(m.group(2)) if (m.lastindex or 0) >= 2 else None
                if num == 0 or num > 5000:
                    continue
            cx = (w["x0"] + w["x1"]) / 2
            out.append({
                "pattern": pname, "printed": num, "total": total, "explicit": explicit,
                "band": band, "x_ratio": round(cx / W, 3), "top": round(top, 1),
                "score": round(base + band_bonus, 3), "evidence": text,
            })
    return out


def _candidate_score(c: dict, total_pages: int) -> float:
    s = c["score"]
    if c["total"] is not None and c["total"] == total_pages:
        s += _TOTAL_MATCH_BONUS
    return s


def build_page_map(pdf_path: Path, diagnose: bool = False) -> dict:
    with pdfplumber.open(pdf_path) as pdf:
        total_pages = len(pdf.pages)
        cands_per_page = [page_candidates(p) for p in pdf.pages]

    # --- 第一步：偏移直方图定标 ---
    # 同一页同一偏移可能有多个候选，取该页该偏移下的最高分，避免重复计票。
    support: dict[int, int] = defaultdict(int)
    weight: dict[int, float] = defaultdict(float)
    best_by_offset: dict[int, dict[int, dict]] = {}
    for idx, cands in enumerate(cands_per_page, 1):
        per_off: dict[int, dict] = {}
        for c in cands:
            off = c["printed"] - idx
            s = _candidate_score(c, total_pages)
            if off not in per_off or s > _candidate_score(per_off[off], total_pages):
                per_off[off] = c
        best_by_offset[idx] = per_off
        for off, c in per_off.items():
            support[off] += 1
            weight[off] += _candidate_score(c, total_pages)

    if not support:
        result = {
            "pdf": pdf_path.name, "total_pdf_pages": total_pages,
            "pages": [{"pdf_index": i, "printed_page": None, "method": "no_text_layer",
                       "confidence": 0.0, "evidence": ""} for i in range(1, total_pages + 1)],
            "runs": [],
            "validation": {"coverage": 0.0, "n_detected": 0, "n_inferred": 0,
                           "n_missing": total_pages, "n_runs": 0, "monotonic_ok": False,
                           "offset_summary": []},
        }
        return result

    max_sup = max(support.values())
    accepted = {off for off, n in support.items()
                if n >= max(_MIN_SUPPORT_ABS, _MIN_SUPPORT_REL * max_sup)}

    # --- 第二步：逐页定值 ---
    # evidence 只记「真正决定该页取值」的那个候选，便于审计复核。
    pages = []
    for idx in range(1, total_pages + 1):
        per_off = best_by_offset.get(idx, {})
        picked, method, conf, evi = None, "missing", 0.0, ""
        acc = [(off, c) for off, c in per_off.items() if off in accepted]
        if acc:
            _, c = max(acc, key=lambda t: _candidate_score(t[1], total_pages))
            picked, method, evi = c["printed"], "detected", c["evidence"]
            conf = round(min(_candidate_score(c, total_pages), 1.0), 2)
        pages.append({"pdf_index": idx, "printed_page": picked, "method": method,
                      "confidence": conf, "evidence": evi})

    # --- 第三步：区间回填 ---
    # 对每个被接受的偏移，看它在哪些页被确认；在首末确认页之间、且该页还没有值的，
    # 用这个偏移推算（插页/整页图页没有页码，但位置是确定的）。
    runs = []
    for off in sorted(accepted):
        members = [p["pdf_index"] for p in pages
                   if p["printed_page"] is not None and p["printed_page"] - p["pdf_index"] == off]
        if len(members) < _MIN_SUPPORT_ABS:
            continue
        lo, hi = min(members), max(members)
        runs.append({"start": lo, "end": hi, "offset": off, "n_members": len(members)})

    runs.sort(key=lambda r: (r["start"], r["end"]))
    for r in runs:
        for p in pages:
            if p["printed_page"] is not None:
                continue
            if r["start"] < p["pdf_index"] < r["end"]:
                cand = p["pdf_index"] + r["offset"]
                if cand >= 1:
                    p.update(printed_page=cand, method="inferred", confidence=0.6)

    # 推算值小于 1 的（封面等）一律置空，不编造「第 0 页」
    for p in pages:
        if p["printed_page"] is not None and p["printed_page"] < 1:
            p.update(printed_page=None, method="missing", confidence=0.0)

    # --- 第四步：校验 ---
    numbered = [p["printed_page"] for p in pages if p["printed_page"] is not None]
    violations = [(a, b) for a, b in zip(numbered, numbered[1:]) if b <= a]
    detected = sum(1 for p in pages if p["method"] == "detected")
    result = {
        "pdf": pdf_path.name,
        "total_pdf_pages": total_pages,
        "pages": pages,
        "runs": runs,
        "validation": {
            "coverage": round(detected / total_pages, 3),
            "n_detected": detected,
            "n_inferred": sum(1 for p in pages if p["method"] == "inferred"),
            "n_missing": sum(1 for p in pages if p["printed_page"] is None),
            "n_runs": len(runs),
            "monotonic_ok": not violations,
            "n_violations": len(violations),
            "accepted_offsets": sorted(accepted),
        },
    }

    if diagnose:
        print(f"\n=== {pdf_path.name}  pages={total_pages} ===")
        print("偏移支持度（前 8）:",
              sorted(support.items(), key=lambda kv: -kv[1])[:8])
        print("接受的偏移:", sorted(accepted))
        for r in runs:
            print(f"  run ph {r['start']}..{r['end']}  offset={r['offset']:>4}  members={r['n_members']}")
        print("校验:", json.dumps(result["validation"], ensure_ascii=False))
        if violations:
            print("单调性违例前 10:", violations[:10])
        print("前 6 页:", [(p["pdf_index"], p["printed_page"], p["method"]) for p in pages[:6]])
    return result


def resolve(p: Path) -> Path:
    return p if p.is_absolute() else (ROOT / p)


def main() -> int:
    ap = argparse.ArgumentParser(description="PDF 物理页 -> 年报印刷页码映射")
    ap.add_argument("--pdf", help="只处理这一份 PDF")
    ap.add_argument("--diagnose", help="只诊断这一份，不落盘")
    args = ap.parse_args()

    if args.diagnose:
        build_page_map(resolve(Path(args.diagnose)), diagnose=True)
        return 0

    targets = [resolve(Path(args.pdf))] if args.pdf else sorted(ANNUAL_DIR.glob("*.pdf"))
    WORK_DIR.mkdir(parents=True, exist_ok=True)
    bad = []
    for path in targets:
        res = build_page_map(path)
        (WORK_DIR / f"{path.stem}.pagemap.json").write_text(
            json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
        v = res["validation"]
        ok = v["coverage"] > 0.85 and v["monotonic_ok"] and v["n_runs"] <= 3
        print(f"[{'OK ' if ok else 'CHK'}] {path.stem:26s} pages={res['total_pdf_pages']:4d} "
              f"coverage={v['coverage']:.2f} runs={v['n_runs']} "
              f"offsets={v['accepted_offsets']} mono={v['monotonic_ok']} "
              f"missing={v['n_missing']}")
        if not ok:
            bad.append(path.stem)
    if bad:
        print("\n需要人工核查:", bad)
    return 0


if __name__ == "__main__":
    sys.exit(main())
