# -*- coding: utf-8 -*-
"""下载 bge-small-zh-v1.5 的 ONNX 模型与分词器（约 95MB，只需一次）。

从 hf-mirror.com 拉取（HuggingFace 的国内镜像）。选 Xenova 那个仓库是因为它提供
现成的 ONNX 导出——官方 BAAI 仓库只有 PyTorch 权重，转换需要装 torch。

只下推理必需的文件：onnx/model.onnx、tokenizer.json、vocab.txt、config.json。
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT / "models" / "bge-small-zh-v1.5"
BASE = "https://hf-mirror.com/Xenova/bge-small-zh-v1.5/resolve/main/"
FILES = ["onnx/model.onnx", "tokenizer.json", "vocab.txt", "config.json",
         "tokenizer_config.json", "special_tokens_map.json"]


def main() -> int:
    DEST.mkdir(parents=True, exist_ok=True)
    ok = True
    for rel in FILES:
        out = DEST / rel
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists() and out.stat().st_size > 0:
            print(f"已存在，跳过  {rel}  ({out.stat().st_size/1e6:.1f} MB)")
            continue
        try:
            r = requests.get(BASE + rel, headers={"User-Agent": "Mozilla/5.0"},
                             stream=True, timeout=180)
            r.raise_for_status()
            tmp = out.with_suffix(out.suffix + ".part")
            n = 0
            with open(tmp, "wb") as fh:
                for chunk in r.iter_content(1 << 16):
                    fh.write(chunk)
                    n += len(chunk)
            tmp.replace(out)
            print(f"下载完成      {rel}  ({n/1e6:.1f} MB)")
        except Exception as exc:  # noqa: BLE001
            ok = False
            print(f"下载失败      {rel}  {exc}", file=sys.stderr)

    model = DEST / "onnx" / "model.onnx"
    if model.exists():
        digest = hashlib.sha256(model.read_bytes()).hexdigest()
        print(f"\nmodel.onnx sha256 = {digest}")
        print(f"（本项目构建时用的版本是 69a0b846f4f116b5...，用于核对模型未被换过）")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
