# -*- coding: utf-8 -*-
"""把 data/extracted/*.json 汇总成看板用的 web/data/metrics.js。

页面不重算任何数据，只读这份文件渲染——与 E 的分工原则一致（前端只读接口）。
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import webdata                      # noqa: E402

ROOT = SRC.parent
EXTRACTED = ROOT / "data" / "extracted"

# 看板展示顺序
ORDER = [
    "revenue", "operating_cost", "net_profit", "net_profit_attr", "net_profit_deducted",
    "total_assets", "total_liabilities", "equity_attr", "cash", "accounts_receivable",
    "inventory", "goodwill", "cfo", "cfi", "cff", "rd_expense", "capex",
]


def build_entry(path: Path) -> tuple[str, dict]:
    """把一份抽取结果压成看板需要的最小字段。"""
    d = json.loads(path.read_text(encoding="utf-8"))
    code = d["company"]["ticker"] or path.stem.split("_")[1]
    fin = {}
    for key in ORDER:
        v = d["financials"].get(key)
        if not v:
            continue
        fin[key] = {
            "label": v["label"], "value": v.get("value"), "unit": v.get("unit", "元"),
            "page": v.get("page"), "pdf_page": v.get("pdf_page"),
            "section": v.get("section"), "table": v.get("table"),
            "status": v.get("status"), "reason": v.get("reason"),
            "alias_matched": v.get("alias_matched"), "unit_raw": v.get("unit_raw"),
            "raw_text": v.get("raw_text"), "series": v.get("series", {}),
            "confidence": v.get("confidence"), "basis": v.get("basis"),
        }
    return code, {
        "company": d["company"],
        "financials": fin,
        "extraction_meta": {
            "pdf": d["extraction_meta"]["pdf"],
            "pdf_pages": d["extraction_meta"]["pdf_pages"],
            "pagemap": d["extraction_meta"]["pagemap_validation"],
        },
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="汇总看板数据")
    ap.add_argument("--codes", nargs="*",
                    help="只重算这些股票代码（增量，其余公司沿用上一次的结果）")
    args = ap.parse_args()

    paths = sorted(EXTRACTED.glob("*.json"))
    if args.codes:
        want = set(args.codes)
        paths = [p for p in paths
                 if p.name[:-len(".json")].split("_")[1] in want]
    if not paths:
        print("没有匹配的抽取结果，先跑 indicators.py", file=sys.stderr)
        return 1

    incremental = bool(args.codes)
    payload = webdata.load_published("metrics", "FINSCOPE_METRICS", {}) if incremental else {}
    if not isinstance(payload, dict):
        payload = {}

    for path in paths:
        code, entry = build_entry(path)
        payload[code] = entry

    webdata.publish("metrics", "FINSCOPE_METRICS", payload, indent=1)
    size_kb = (webdata.WEB_DATA / "metrics.js").stat().st_size / 1024
    print(f"{len(payload)} 家 -> web/data/metrics.js  ({size_kb:.0f} KB)")
    for code in sorted(payload):
        p = payload[code]
        miss = [k for k, v in p["financials"].items() if v["status"] != "found"]
        print(f"  {code} {p['company']['name'][:8]:9s} 指标 {len(p['financials'])}/17 "
              f"异常={miss if miss else '无'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
