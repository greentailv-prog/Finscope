# -*- coding: utf-8 -*-
"""把年报切成带「公司 + 章节 + 页码」的 chunk。

三条硬规则：

1. **chunk 不跨页**。页码引用要唯一，跨页 chunk 会让「这条证据出自第几页」没法回答。
   所以先按页切，再在页内切。
2. **页眉页脚要洗掉**。每页重复的「XX公司2025年年度报告」和页脚页码，属于每页都有的
   噪声，留着会让所有 chunk 都命中同一个无关查询。
3. **表格块单独标出来**。表格里的数字与正文语义不同，标 is_table 便于下游按需加权。

页脚页码在 pdfplumber 里是独立词，位置固定在页边带，按「与页脚带重合且内容像页码」剔除。

用法:
    python chunker.py                 # 处理全部年报
    python chunker.py --pdf <路径>     # 只处理一份
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import pdfplumber

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import table_extract as te            # noqa: E402
import indicators as ind              # noqa: E402

ROOT = SRC.parent
ANNUAL_DIR = ROOT / "data" / "annual_reports"
WORK_DIR = ROOT / "work"
CHUNK_DIR = WORK_DIR / "chunks"

TARGET_CHARS = 450
MAX_CHARS = 700
OVERLAP_CHARS = 50
MIN_CHARS = 40

_SENT_SPLIT = re.compile(r"(?<=[。！？；])")
_PAGE_NUM_LINE = re.compile(r"^(?:第\s*\d{1,4}\s*页|\d{1,4}\s*/\s*\d{1,4}|\d{1,4})$")
_NAV_LINE = re.compile(r"^[□√×✓\s适用不]{%6,}$")
# 页眉：公司名 + 年度（+「年度报告」/「年度报告全文」）。它可能独占一行，也可能
# 被 pdfplumber 和紧跟的正文并到同一行，所以两头都要处理。
_RUNNING = re.compile(r"[一-龥]{2,20}(?:集团)?(?:股份)?有限公司\s*\d{4}\s*年(?:年度报告|年报)(?:全文)?")


def clean_page_text(page) -> str:
    """去掉页眉页脚，返回该页可切块的正文。"""
    out_lines = []
    for raw in (page.extract_text() or "").split("\n"):
        s = " ".join(raw.split())
        if not s:
            continue
        s = _RUNNING.sub("", s).strip()          # 剥掉行内/行首的页眉
        if not s:
            continue
        if len(s) <= 8 and _PAGE_NUM_LINE.match(s):
            continue                             # 页脚页码（独立成行）
        out_lines.append(s)
    return "\n".join(out_lines)


def split_sentences(text: str) -> list[str]:
    parts: list[str] = []
    for block in text.split("\n"):
        block = block.strip()
        if not block:
            continue
        if len(block) <= MAX_CHARS:
            parts.append(block)
            continue
        for s in _SENT_SPLIT.split(block):
            s = s.strip()
            if s:
                parts.append(s)
    return parts


def looks_like_table(text: str) -> bool:
    lines = [x for x in text.split("\n") if x.strip()]
    if not lines:
        return False
    numeric_lines = sum(
        1 for ln in lines
        if len(re.findall(r"\d[\d,]*(?:\.\d+)?", ln)) >= 2
    )
    digits = sum(ch.isdigit() for ch in text)
    return numeric_lines >= 3 or (digits / max(len(text), 1) > 0.25 and numeric_lines >= 2)


def chunk_page(text: str, company: dict, section: str, pdf_index: int,
               printed_page: int | None, seq_start: int = 0) -> list[dict]:
    """在一页内切块；返回该页的 chunk 列表。"""
    units = split_sentences(text)
    chunks: list[dict] = []
    buf = ""

    def flush() -> None:
        nonlocal buf
        body = buf.strip()
        buf = ""
        if len(body) < MIN_CHARS or _NAV_LINE.match(body.replace(" ", "")):
            return
        chunks.append({
            "chunk_id": f"{company['code']}_{pdf_index}_{seq_start + len(chunks)}",
            "company_code": company["code"],
            "company_name": company["name"],
            "section": section,
            "pdf_index": pdf_index,
            "printed_page": printed_page,
            "is_table": looks_like_table(body),
            "n_chars": len(body),
            "text": body,
        })

    # 拼接必须带换行：丢掉换行会把表格行压成一长串，既读不出行列结构，
    # looks_like_table 也认不出来。
    def push(piece: str) -> None:
        nonlocal buf
        buf = f"{buf}\n{piece}" if buf else piece

    for u in units:
        if len(u) > MAX_CHARS:                       # 超长行硬切，绝不跨页
            for i in range(0, len(u), MAX_CHARS):
                push(u[i:i + MAX_CHARS])
                if len(buf) >= TARGET_CHARS:
                    flush()
            continue
        push(u)
        if len(buf) >= TARGET_CHARS:
            tail = buf[-OVERLAP_CHARS:]
            flush()
            buf = tail
    flush()

    # 没有可切内容时，退化成整页一块（例如整页是图表的页）
    if not chunks and len(text.strip()) >= MIN_CHARS:
        chunks.append({
            "chunk_id": f"{company['code']}_{pdf_index}_{seq_start}",
            "company_code": company["code"], "company_name": company["name"],
            "section": section, "pdf_index": pdf_index, "printed_page": printed_page,
            "is_table": looks_like_table(text), "n_chars": len(text.strip()),
            "text": text.strip(),
        })
    return chunks


def build_chunks(pdf_path: Path, meta: dict, pagemap: dict) -> list[dict]:
    pm = {p["pdf_index"]: p["printed_page"] for p in pagemap["pages"]}
    total = pagemap["total_pdf_pages"]
    chunks: list[dict] = []
    with pdfplumber.open(pdf_path) as pdf:
        texts = [te.normalize(p.extract_text() or "") for p in pdf.pages]
        sections = ind.build_page_sections(texts)
        for i, page in enumerate(pdf.pages):
            body = clean_page_text(page)
            if not body.strip():
                continue
            chunks.extend(chunk_page(body, meta, sections[i], i + 1, pm.get(i + 1)))
    return chunks


def main() -> int:
    ap = argparse.ArgumentParser(description="年报切块")
    ap.add_argument("--pdf", help="只处理这一份")
    args = ap.parse_args()

    companies = json.loads((SRC / "companies.json").read_text(encoding="utf-8"))
    year = companies.get("report_year", 2025)
    CHUNK_DIR.mkdir(parents=True, exist_ok=True)

    targets = []
    for c in companies["companies"]:
        p = ANNUAL_DIR / f"{c['name']}_{c['code']}_{year}.pdf"
        if p.exists():
            targets.append((p, {**c, "report_year": year}))
    if args.pdf:
        p = Path(args.pdf)
        p = p if p.is_absolute() else ROOT / p
        targets = [(p, {"name": p.stem.split("_")[0], "code": p.stem.split("_")[1],
                        "report_year": year})]

    for pdf, meta in targets:
        pagemap = json.loads(
            (WORK_DIR / "pagemap" / f"{pdf.stem}.pagemap.json").read_text(encoding="utf-8"))
        chunks = build_chunks(pdf, meta, pagemap)
        out = CHUNK_DIR / f"{pdf.stem}.chunks.jsonl"
        with open(out, "w", encoding="utf-8") as fh:
            for c in chunks:
                fh.write(json.dumps(c, ensure_ascii=False) + "\n")
        tables = sum(1 for c in chunks if c["is_table"])
        avg = sum(c["n_chars"] for c in chunks) / max(len(chunks), 1)
        print(f"{pdf.stem:26s} chunks={len(chunks):5d} 表格块={tables:5d} 平均{avg:.0f}字 -> {out.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
