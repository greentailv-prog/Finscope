# -*- coding: utf-8 -*-
"""把 chunk 建成浏览器可以直接用的检索索引（BM25 倒排 + int8 向量）。

为什么要自造哈希而不是存词表：
- 存词表（60k 个中文词）光 JSON 就有几 MB，而且浏览器要重建映射；
- 查询侧只需要「给定 token 找到它的倒排表」，用 **FNV-1a 32 位哈希**对 token 取桶就行，
  两边算法一致即可。60k 个词落在 2^32 空间里，碰撞概率可忽略。

编码（全部 base64 的定型数组，浏览器用 atob 还原）：
- term_hashes : Int32Array  升序排列的 token 哈希
- df          : Uint16Array 每个 token 的文档频次
- post_doc    : Uint16Array 倒排文档号，按 token 分组、组内升序
- post_tf     : Uint8Array  对应词频
- doc_len     : Uint16Array 每篇 chunk 的 token 数
偏移由 df 前缀和推出，不必单独存。

用法:
    python build_index.py                # 全部公司
    python build_index.py --codes 000333
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import embed as embed_mod            # noqa: E402
import tokenize_zh                   # noqa: E402
import webdata                       # noqa: E402

ROOT = SRC.parent
CHUNK_DIR = ROOT / "work" / "chunks"
WEB_DATA = ROOT / "web" / "data"
INDEX_VERSION = "bm25-int8-v1"

FNV_OFFSET = 2166136261
FNV_PRIME = 16777619
UINT32 = 0xFFFFFFFF


def fnv1a(token: str) -> int:
    """FNV-1a 32 位，按 **UTF-16 码元** 迭代。

    不用 ord(ch)：Python 的 ord 对增补平面字符返回 >0xFFFF 的单值，而 JS 的
    charCodeAt 返回代理对的两个值，两边会算不到一块去。统一按 UTF-16 码元，
    与 web/tokenize.js 的 charCodeAt 逐字一致。
    """
    raw = token.encode("utf-16-le")
    h = FNV_OFFSET
    for i in range(0, len(raw), 2):
        h ^= raw[i] | (raw[i + 1] << 8)
        h = (h * FNV_PRIME) & UINT32
    return h


def b64(array, dtype) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype=dtype).tobytes()).decode("ascii")


def index_text(chunk: dict) -> str:
    """索引用的文本 = 公司名 + 章节 + 正文。

    切块时已经把页眉洗掉了，正文里不再出现公司名。不补回去的话，「美的集团2025年
    营业收入」这类指名道姓的问题就分不出是哪一家——BM25 只看文本，看不到元数据，
    八家公司的「营业收入」在它眼里完全一样。章节同理，能帮上「管理层讨论」这类问法。
    展示给用户的仍是原始正文，这里只是喂给索引的副本。
    """
    return f'{chunk["company_name"]} {chunk["section"]} {chunk["text"]}'


def build_company(stem: str, emb: embed_mod.Embedder) -> dict:
    chunks = [json.loads(l) for l in
              (CHUNK_DIR / f"{stem}.chunks.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    texts = [c["text"] for c in chunks]

    # ---- BM25 倒排 ----
    postings: dict[int, list[tuple[int, int]]] = defaultdict(list)
    doc_len = np.zeros(len(chunks), dtype=np.int64)
    for doc_id, text in enumerate(texts):
        tf = tokenize_zh.token_freq(index_text(chunks[doc_id]))
        doc_len[doc_id] = sum(tf.values())
        for tok, n in tf.items():
            postings[fnv1a(tok)].append((doc_id, min(n, 255)))

    # 哈希是 [0, 2^32) 的无符号值，但要转成 int32 存。转换后 ≥2^31 的会变负数，
    # 若按无符号序排好再转，数组在 int32 空间里就不是升序了，浏览器的二分查找会失效。
    # 所以直接按 int32 的解释值排序。
    def as_i32(h: int) -> int:
        return h if h < 2 ** 31 else h - 2 ** 32

    term_hashes = sorted(postings.keys(), key=as_i32)
    df = np.zeros(len(term_hashes), dtype=np.int64)
    post_doc: list[int] = []
    post_tf: list[int] = []
    for i, h in enumerate(term_hashes):
        entries = sorted(postings[h])
        df[i] = len(entries)
        for d, n in entries:
            post_doc.append(d)
            post_tf.append(n)

    th_i32 = np.array([as_i32(h) for h in term_hashes], dtype=np.int32)

    # ---- 向量 ----
    vectors = emb.encode(texts)
    q = embed_mod.quantize_int8(vectors)

    meta = {
        "code": chunks[0]["company_code"],
        "name": chunks[0]["company_name"],
        "n_chunks": len(chunks),
        "n_tables": int(sum(1 for c in chunks if c["is_table"])),
        "stem": stem,
    }
    return {
        "meta": meta,
        "chunks": [{k: c[k] for k in
                    ("chunk_id", "section", "pdf_index", "printed_page", "is_table", "n_chars", "text")}
                   for c in chunks],
        "bm25": {
            "n_docs": len(chunks),
            "avgdl": float(doc_len.mean()) if len(chunks) else 0.0,
            "term_hashes_b64": b64(th_i32, np.int32),
            "df_b64": b64(np.minimum(df, 65535), np.uint16),
            "post_doc_b64": b64(np.array(post_doc, dtype=np.uint16), np.uint16),
            "post_tf_b64": b64(np.minimum(np.array(post_tf, dtype=np.uint8), 255), np.uint8),
            "doc_len_b64": b64(np.minimum(doc_len, 65535), np.uint16),
        },
        "vec": {"dim": embed_mod.DIM, "b64": embed_mod.b64_int8(q)},
    }


def all_stems() -> list[str]:
    # 取去掉后缀的完整文件名，不能用 Path.stem——"x.chunks.jsonl" 的 stem 是 "x.chunks"。
    return sorted(p.name[:-len(".chunks.jsonl")]
                  for p in CHUNK_DIR.glob("*.chunks.jsonl"))


def targets(args) -> list[str]:
    stems = all_stems()
    if args.stems:
        want = set(args.stems)
        return [s for s in stems if s in want]
    if args.codes:
        want = set(args.codes)
        # 精确比对代码段。原来写成 `any(c in s ...)` 是子串匹配，`--codes 6005`
        # 会同时命中 600519/600031/600309/600887 好几家，增量就变成误伤。
        return [s for s in stems if s.split("_")[1] in want]
    return stems


def current_versions() -> dict:
    return {"index_version": INDEX_VERSION,
            "tokenizer_version": tokenize_zh.TOKENIZER_VERSION,
            "embedder_version": embed_mod.EMBEDDER_VERSION}


def assert_incremental_compatible(man: dict) -> None:
    """增量合并前先确认版本一致。

    分词实现或向量模型一改，新旧分片的打分就不可比；混在一个库里检索会静默给出
    错的排序，比直接报错难查得多。所以这里宁可拒绝，让调用方去跑一次全量重建。
    """
    if not man.get("shards"):
        return
    cur = current_versions()
    diff = {k: (man.get(k), v) for k, v in cur.items() if man.get(k) != v}
    if diff:
        detail = "；".join(f"{k}: 索引里是 {a}，当前是 {b}" for k, (a, b) in diff.items())
        raise SystemExit(f"索引版本不一致，增量会污染全库，请先跑一次全量重建：\n  {detail}")


def main() -> int:
    ap = argparse.ArgumentParser(description="构建检索索引")
    ap.add_argument("--codes", nargs="*", help="只重建这些股票代码（增量，其余分片原样保留）")
    ap.add_argument("--stems", nargs="*", help="按 stem 精确指定要重建的公司")
    args = ap.parse_args()

    WEB_DATA.mkdir(parents=True, exist_ok=True)
    stems = targets(args)
    if not stems:
        print("没有匹配的 chunk 文件，先跑 chunker.py", file=sys.stderr)
        return 1

    incremental = bool(args.codes or args.stems)
    empty = {"shards": [], **current_versions()}
    man = webdata.load_published("manifest", "FINSCOPE_MANIFEST", empty) if incremental else empty
    if incremental:
        assert_incremental_compatible(man)
    by_code = {s["code"]: s for s in man.get("shards", [])}
    before = set(by_code)

    emb = None
    for stem in stems:
        if emb is None:
            emb = embed_mod.Embedder()      # 真有活干时才加载这 95MB 的模型
        data = build_company(stem, emb)
        code = data["meta"]["code"]
        body = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        out = WEB_DATA / f"shard_{code}.js"
        webdata.atomic_write_text(out, f'window.FINSCOPE_SHARDS["{code}"] = {body};\n')
        size_mb = out.stat().st_size / 1e6
        by_code[code] = {**data["meta"], "file": out.name, "size_mb": round(size_mb, 2)}
        tag = "更新" if code in before else "新增"
        print(f"[{tag}] {stem:26s} chunks={data['meta']['n_chunks']:5d} "
              f"表格块={data['meta']['n_tables']:5d} 分片={size_mb:5.2f}MB -> {out.name}")

    payload = {"shards": sorted(by_code.values(), key=lambda s: s["code"]),
               **current_versions()}
    webdata.publish("manifest", "FINSCOPE_MANIFEST", payload)
    kept = len(payload["shards"]) - len(stems)
    if incremental:
        print(f"增量完成：重建 {len(stems)} 家，沿用 {kept} 家的既有分片，"
              f"共 {len(payload['shards'])} 家")
    else:
        print(f"全量完成：共 {len(payload['shards'])} 个分片 -> manifest.js")
    return 0


if __name__ == "__main__":
    sys.exit(main())
