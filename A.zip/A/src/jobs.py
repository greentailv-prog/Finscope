# -*- coding: utf-8 -*-
"""后台任务：单工作线程 + 队列 + 进度上报 + 落盘续看。

为什么单线程串行：pdfplumber 解析与 ONNX 推理都吃满 CPU，并发只会互相拖慢；
`Embedder` 会话加上每份年报的解析状态常驻数百 MB，并发就是 N 倍内存；
而且 manifest 的读改写不是并发安全的。一次一家，反而最快。

进度怎么来：子进程按 `#FS# {...}` 打印机器可读的进度行，这里逐行读 stdout 解析。
必须给子进程加 `-u`，否则 Windows 上管道会攒到最后一次性吐出来，进度条形同虚设。
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid
from collections import deque
from datetime import datetime
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import webdata                       # noqa: E402

ROOT = SRC.parent
JOBS_DIR = ROOT / "work" / "jobs"

LOG_KEEP = 300          # 每个任务保留的日志行数
PERSIST_INTERVAL = 2.0  # 落盘节流，秒

# 步骤与权重。权重按实测各段耗时占比给：指标抽取最久，页码映射次之，
# 向量索引第三（要过一遍 ONNX）。
STEPS = [
    {"name": "resolve",    "weight": 0.03, "label": "解析公司与交易所"},
    {"name": "download",   "weight": 0.06, "label": "下载年报 PDF"},
    {"name": "pagemap",    "weight": 0.18, "label": "建立页码映射"},
    {"name": "indicators", "weight": 0.28, "label": "抽取财务指标"},
    {"name": "chunker",    "weight": 0.13, "label": "切块"},
    {"name": "index",      "weight": 0.27, "label": "向量化并建索引"},
    {"name": "metrics",    "weight": 0.05, "label": "更新看板数据"},
]
STEP_INDEX = {s["name"]: i for i, s in enumerate(STEPS)}

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.RLock()
QUEUE: "queue.Queue[str]" = queue.Queue()
_worker_started = False


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def snapshot(job: dict) -> dict:
    """对外只给快照，内部字段（子进程句柄等）不出去。"""
    with JOBS_LOCK:
        out = {k: v for k, v in job.items() if not k.startswith("_")}
        out["log"] = list(job.get("log") or [])
    return out


def percent_of(job: dict) -> int:
    i = int(job.get("step_index", 0))
    i = max(0, min(i, len(STEPS) - 1))
    done = sum(s["weight"] for s in STEPS[:i])
    p = job.get("progress") or {}
    frac = (p.get("done", 0) / p["total"]) if p.get("total") else 0.0
    return int(round(100 * (done + STEPS[i]["weight"] * min(max(frac, 0.0), 1.0))))


class JobContext:
    """给 ingest 用的操作句柄：记日志、报步骤、跑子进程。"""

    def __init__(self, job: dict):
        self.job = job

    def log(self, line: str) -> None:
        with JOBS_LOCK:
            self.job["log"].append(line.rstrip("\n"))
            self.job["updated_at"] = _now()
        _maybe_persist(self.job)

    def set_step(self, name: str) -> None:
        with JOBS_LOCK:
            self.job["step_index"] = STEP_INDEX.get(name, self.job.get("step_index", 0))
            self.job["step"] = name
            self.job["step_label"] = STEPS[self.job["step_index"]]["label"]
            self.job["progress"] = {}
            self.job["percent"] = percent_of(self.job)
            self.job["updated_at"] = _now()
        _persist(self.job)

    def check_cancel(self) -> None:
        if self.job.get("_cancel"):
            raise JobCancelled()

    def run(self, cmd: list[str], env_extra: dict | None = None) -> int:
        """跑一个子进程，边跑边解析 `#FS#` 进度行。返回退出码。"""
        self.check_cancel()
        env = dict(os.environ, PYTHONIOENCODING="utf-8", FS_PROGRESS="1")
        if env_extra:
            env.update(env_extra)
        # -u 必须加：不加的话 Windows 管道会缓冲，进度会被攒到进程结束时才出来
        proc = subprocess.Popen([sys.executable, "-u", *cmd], cwd=str(ROOT), env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace")
        with JOBS_LOCK:
            self.job["_proc"] = proc
        for line in proc.stdout:
            line = line.rstrip("\n")
            if line.startswith("#FS# "):
                try:
                    ev = json.loads(line[5:])
                except json.JSONDecodeError:
                    continue
                with JOBS_LOCK:
                    self.job["progress"] = {"done": ev.get("done"), "total": ev.get("total")}
                    self.job["percent"] = percent_of(self.job)
                _maybe_persist(self.job)
            elif line.strip():
                self.log(line)
            if self.job.get("_cancel"):
                proc.kill()
                raise JobCancelled()
        code = proc.wait()
        with JOBS_LOCK:
            self.job["_proc"] = None
        return code


class JobCancelled(Exception):
    pass


# ---------------------------------------------------------------- 落盘

_last_persist: dict[str, float] = {}


def _persist(job: dict) -> None:
    try:
        JOBS_DIR.mkdir(parents=True, exist_ok=True)
        webdata.atomic_write_text(JOBS_DIR / f"{job['id']}.json",
                                  json.dumps(snapshot(job), ensure_ascii=False, indent=1))
        _last_persist[job["id"]] = time.time()
    except OSError:
        pass


def _maybe_persist(job: dict) -> None:
    if time.time() - _last_persist.get(job["id"], 0) >= PERSIST_INTERVAL:
        _persist(job)


# ---------------------------------------------------------------- 队列

def submit(kind: str, params: dict) -> dict:
    """入队一个任务。同一家公司已有排队/运行中的任务时，直接返回既有的那个。"""
    key = params.get("code") or params.get("stem") or ""
    with JOBS_LOCK:
        for j in JOBS.values():
            if j["kind"] == kind and j["status"] in ("queued", "running") \
                    and (j["params"].get("code") or j["params"].get("stem")) == key:
                return snapshot(j)
        job = {
            "id": uuid.uuid4().hex[:12],
            "kind": kind,
            "params": params,
            "status": "queued",
            "step_index": 0,
            "step": STEPS[0]["name"],
            "step_label": STEPS[0]["label"],
            "percent": 0,
            "progress": {},
            "log": deque(maxlen=LOG_KEEP),
            "result": None,
            "error": None,
            "created_at": _now(),
            "updated_at": _now(),
            "_proc": None,
            "_cancel": False,
        }
        JOBS[job["id"]] = job
    _persist(job)
    _ensure_worker()
    QUEUE.put(job["id"])
    return snapshot(job)


def get(job_id: str) -> dict | None:
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    return snapshot(job) if job else None


def recent(limit: int = 20) -> list[dict]:
    with JOBS_LOCK:
        jobs = sorted(JOBS.values(), key=lambda j: j["created_at"], reverse=True)
    return [snapshot(j) for j in jobs[:limit]]


def cancel(job_id: str) -> bool:
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job or job["status"] not in ("queued", "running"):
            return False
        job["_cancel"] = True
        proc = job.get("_proc")
    if proc and proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    return True


def _finish(job: dict, status: str, result=None, error: str | None = None) -> None:
    with JOBS_LOCK:
        job["status"] = status
        job["result"] = result
        job["error"] = error
        job["updated_at"] = _now()
        if status == "done":
            job["percent"] = 100
        job["_proc"] = None
    _persist(job)


def _ensure_worker() -> None:
    global _worker_started
    with JOBS_LOCK:
        if _worker_started:
            return
        _worker_started = True
    threading.Thread(target=_worker, name="finscope-jobs", daemon=True).start()


def _worker() -> None:
    while True:
        job_id = QUEUE.get()
        with JOBS_LOCK:
            job = JOBS.get(job_id)
        if not job or job["status"] != "queued":
            continue
        with JOBS_LOCK:
            job["status"] = "running"
            job["updated_at"] = _now()
        _persist(job)
        ctx = JobContext(job)
        try:
            import ingest
            result = ingest.run(job, ctx)
            _finish(job, "done", result=result)
        except JobCancelled:
            ctx.log("任务已取消")
            _finish(job, "cancelled")
        except Exception as exc:  # noqa: BLE001
            ctx.log(f"[错误] {exc}")
            _finish(job, "error", error=str(exc))


def mark_interrupted_on_startup() -> None:
    """服务器重启后，之前 running/queued 的任务其子进程已随旧进程死掉，标为中断。"""
    if not JOBS_DIR.exists():
        return
    for path in JOBS_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("status") in ("running", "queued"):
            data["status"] = "interrupted"
            data["error"] = "服务重启，任务已中断"
            webdata.atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=1))


def load_history(limit: int = 50) -> None:
    """把上次运行留下的任务读回内存，让用户还能看到当时发生了什么。"""
    if not JOBS_DIR.exists():
        return
    files = sorted(JOBS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    with JOBS_LOCK:
        for path in files[:limit]:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            data["log"] = deque(data.get("log") or [], maxlen=LOG_KEEP)
            data["_proc"] = None
            data["_cancel"] = False
            JOBS.setdefault(data["id"], data)
