# -*- coding: utf-8 -*-
"""运行期配置的读写：大模型接口、联网搜索接口、检索参数。

**密钥刻意存在仓库之外**（`%USERPROFILE%\\.finscope\\config.json`）。理由：用 GitHub
网页上传文件时**不读 .gitignore**，密钥一旦落进仓库目录，早晚会被传上去。放用户目录下
也天然按用户隔离（Windows 下 profile 默认仅本人可读）。

可用环境变量覆盖，便于测试：
    FINSCOPE_HOME   改基准目录
    FINSCOPE_CONFIG 直接指定配置文件路径
"""
from __future__ import annotations

import copy
import json
import os
import sys
from pathlib import Path

_BASE = Path(os.environ.get("FINSCOPE_HOME")
             or (Path(os.environ.get("USERPROFILE") or Path.home()) / ".finscope"))
CONFIG_PATH = Path(os.environ.get("FINSCOPE_CONFIG") or (_BASE / "config.json"))

SECRET_KEYS = ("api_key",)
# 密钥留空表示「不改」（前端只拿到脱敏视图，原样提交空白会抹掉已配置的密钥），
# 所以清除要一个显式哨兵值，不能靠空字符串。
CLEAR_SENTINEL = "__CLEAR__"

DEFAULTS: dict = {
    "llm": {
        # 只做 OpenAI 兼容的 /chat/completions。DeepSeek、通义千问、智谱 GLM、Kimi、
        # 本地 vLLM 都兼容，填 base_url + model + api_key 即可，不引入额外的 SDK 依赖。
        "provider": "openai_compatible",
        "base_url": "",
        "model": "",
        "api_key": "",
        "timeout_s": 120,
        "max_tokens": 2048,
        "temperature": 0.2,
    },
    "search": {
        # off / tavily / bocha / searxng / bing。off 时不注入外部资料段。
        "provider": "off",
        "api_key": "",
        "base_url": "",
        "top_k": 5,
    },
    "rag": {
        "top_n": 8,
        "per_evidence_chars": 1500,
        "max_evidence_chars": 9000,
    },
}


def _deep_merge(base: dict, patch: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load() -> dict:
    """读配置；文件不存在或损坏时返回默认值，不抛异常。"""
    if not CONFIG_PATH.exists():
        return copy.deepcopy(DEFAULTS)
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return copy.deepcopy(DEFAULTS)
    return _deep_merge(DEFAULTS, raw if isinstance(raw, dict) else {})


def save(patch: dict) -> dict:
    """深合并写入，返回合并后的完整配置。

    密钥（api_key）留空表示「不改」——前端拿到的是脱敏视图，看不到真值，若把空白原样
    提交上来就会把已配置的密钥抹掉。其余字段留空表示「清空」，是有效操作（比如清空
    base_url 就等于停用大模型）。
    """
    merged = _deep_merge(load(), _drop_blank_secrets(patch or {}))
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_name(CONFIG_PATH.name + ".tmp")
    tmp.write_text(json.dumps(merged, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, CONFIG_PATH)
    try:
        os.chmod(CONFIG_PATH, 0o600)     # Windows 上是空操作，POSIX 上收紧权限
    except OSError:
        pass
    return merged


def _drop_blank_secrets(patch: dict) -> dict:
    out = {}
    for k, v in patch.items():
        if isinstance(v, dict):
            sub = _drop_blank_secrets(v)
            if sub:
                out[k] = sub
        elif k in SECRET_KEYS and v == "":
            continue                      # 留空 = 不改，见 save() 的说明
        elif k in SECRET_KEYS and v == CLEAR_SENTINEL:
            out[k] = ""                   # 显式清除
        else:
            out[k] = v
    return out


def get(dotted: str, default=None):
    node = load()
    for part in dotted.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


def _mask(value: str) -> dict:
    if not value:
        return {"set": False}
    tail = value[-4:] if len(value) > 4 else value
    return {"set": True, "tail": "…" + tail}


def public_view() -> dict:
    """给前端读的脱敏视图——**永远不含明文密钥**。"""
    cfg = load()
    return {
        "llm": {
            "provider": cfg["llm"]["provider"],
            "base_url": cfg["llm"]["base_url"],
            "model": cfg["llm"]["model"],
            "api_key": _mask(cfg["llm"]["api_key"]),
            "timeout_s": cfg["llm"]["timeout_s"],
            "max_tokens": cfg["llm"]["max_tokens"],
            "temperature": cfg["llm"]["temperature"],
        },
        "search": {
            "provider": cfg["search"]["provider"],
            "base_url": cfg["search"]["base_url"],
            "api_key": _mask(cfg["search"]["api_key"]),
            "top_k": cfg["search"]["top_k"],
        },
        "rag": cfg["rag"],
        "config_path": str(CONFIG_PATH),
    }


def llm_ready() -> bool:
    c = load()["llm"]
    return bool(c.get("base_url") and c.get("model") and c.get("api_key"))


def search_ready() -> bool:
    c = load()["search"]
    if c.get("provider", "off") == "off":
        return False
    if c["provider"] == "searxng":          # 自建实例不需要密钥，但要有地址
        return bool(c.get("base_url"))
    return bool(c.get("api_key"))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    print("配置文件:", CONFIG_PATH)
    print("存在:", CONFIG_PATH.exists())
    print("大模型已配置:", llm_ready())
    print("联网搜索已配置:", search_ready())
    print(json.dumps(public_view(), ensure_ascii=False, indent=1))
