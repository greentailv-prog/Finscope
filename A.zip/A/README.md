# A 模块 · 财报读取理解与数据追踪

FinScope 的第一棒。输入上市公司年报 PDF，输出一份**每个数字都能回到年报页码**的财务数据，
外加一个能带出处回答年报问题的问答页。

## 这个模块交付什么

| 交付物 | 位置 | 说明 |
|---|---|---|
| 抽取技能 | [`financial-extraction/SKILL.md`](financial-extraction/SKILL.md) | 给 Agent 看的抽取流程与判断准则 |
| 方法札记 | [`financial-extraction/references/method-notes.md`](financial-extraction/references/method-notes.md) | 七个真实踩过的坑与修法，含真实坐标 |
| 数据接口 | [`schema/financial_schema.json`](schema/financial_schema.json) | A 填写的 `financials` 段规范，对齐 D 的统一 Schema |
| 最小案例 | [`demo/`](demo/) | 美的集团 2025 年报 PDF + 抽取结果 JSON |
| 问答页 | [`web/index.html`](web/index.html) | 数据看板 + 带出处的问答，双击即开 |
| 核验报告 | [`verify/`](verify/) | 10 道题（含 3 道推理题）逐题记录对错与召回证据 |

抽取对象为 8 家 A 股公司 2025 年年度报告：贵州茅台 600519、美的集团 000333、
比亚迪 002594、宁德时代 300750、海康威视 002415、伊利股份 600887、万华化学 600309、
三一重工 600031。

库里另有**第 9 家格力电器 000651**，它是用服务模式的「添加公司」功能跑进来的
（输入代码 → 联网下载 → 自动抽取入库，约 3 分钟），用来验证该功能端到端可用。

## 怎么用

### 只用结果

`data/extracted/*.json` 已经是抽好的 8 家公司数据，可直接读。字段含义见
`schema/financial_schema.json`。给 B 和 C 的接入点：

- **B 算指标**：读 `financials.<指标>.value`（单位恒为元）与 `.series`（多期，用于增速）。
- **B 判风险**：`financials.<指标>.page` 给出证据页码，可直接写进风险条目的证据链。
- **C 做估值**：`revenue` / `net_profit_attr` / `cash` / `cfi` / `capex` 等齐备。

### 跑一遍管线

```bash
cd A
python src/fetch_cninfo.py       # 1. 从巨潮资讯网下载年报 PDF（已有则跳过）
python src/pdf_pagemap.py        # 2. PDF 物理页 -> 年报印刷页码
python src/indicators.py         # 3. 抽取 17 项指标 -> data/extracted/
python src/chunker.py            # 4. 切块（公司 + 章节 + 页码）
python src/embed.py --check      # 5. 向量模型自检
python src/build_index.py        # 6. 建 BM25 + 向量索引 -> web/data/
python src/export_metrics.py     # 7. 汇总看板数据 -> web/data/metrics.js
python src/build_queries.py      # 8. 预置问题的查询向量
```

第 1–3 步是抽取，第 4–8 步是问答页所需。只关心数据的话跑到第 3 步就够。

### 打开问答页

**双击 `web/index.html`**。双击即用，无需启动任何服务。

**双击 `web/启动问答页.bat`** 会起一个本地服务，多出四样能力：

| 能力 | 双击 index.html | 双击 启动问答页.bat |
|---|---|---|
| 看板、抽取结果 | 有 | 有 |
| 预置问题的混合检索 | 有 | 有 |
| 自由提问的向量检索 | 只能 BM25 | 完整混合 |
| **联网抓取新公司年报** | 无 | 有 |
| **上传本地年报 PDF** | 无 | 有 |
| **大模型生成式回答** | 无 | 有（需配置密钥） |
| **联网搜索补充** | 无 | 有（需配置密钥） |

差别的原因见下面「已知限制」。页面右上角会明示当前处于哪种模式。

### 服务模式下怎么用

**添加公司**。输入 A 股代码或公司名（如 `000651` 或 `格力电器`），后端会去巨潮资讯网
下载该公司年报、跑完整管线、并入看板与检索。也可以直接把年报 PDF 拖进去。
一份年报约需 3–8 分钟，任务在后台跑，**关掉页面再回来看也行**（进度与日志会续上）。
实测：格力电器从提交到入库约 3 分钟，17 项指标全部命中。

**AI 问答**。用大模型把证据归纳成回答，每个结论带角标，角标对应证据的年报页码。
与原来的「年报问答」并存但不互相影响：那个是抽取式拼接（不改写原文），这个是生成式归纳。

送给模型的证据有两类，分开成节：

- **结构化抽取结果** —— 本模块从年报逐字抽取的 17 项指标，金额已统一为元，每条都标了
  口径（合并/母公司）、来源页码、原科目名与原单位。数值题以它为准。
- **年报原文片段** —— 向量 + BM25 检索回来的段落，用来核对口径与背景。

加结构化这一节是因为：数值题常要跨表取值（「经营现金流减资本开支」要同时命中合并
现金流量表的两个行），纯靠片段检索漏掉一处，模型就只能拒答。实测中三一重工那道题
一开始就因此拒答，补上结构化证据后给出了正确结果。

**设置**。填大模型与搜索接口，见下。

## 大模型与联网搜索

两者都需要密钥，在页面的「设置」面板里填。**密钥存在用户目录**
（`%USERPROFILE%\.finscope\config.json`），**不在仓库里**——用 GitHub 网页上传文件时
不读 `.gitignore`，密钥放仓库里早晚会被传上去。接口只回显末四位。

**大模型**只做 OpenAI 兼容的 `/chat/completions`，所以 DeepSeek、通义千问、智谱 GLM、
Kimi、本地 vLLM 都能用。设置面板里有**一键填充**按钮，点一下就把地址和模型名填好，
你只需要粘密钥：

| 服务商 | base_url | 模型名 |
|---|---|---|
| DeepSeek | `https://api.deepseek.com/v1` | `deepseek-chat` |
| DeepSeek 推理 | `https://api.deepseek.com/v1` | `deepseek-reasoner` |
| 通义千问 | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` |
| 智谱 GLM | `https://open.bigmodel.cn/api/paas/v4` | `glm-4-plus` |
| Kimi | `https://api.moonshot.cn/v1` | `moonshot-v1-8k` |

填完点「**测试大模型连接**」会发一次极小的请求，立刻告诉你通不通。密钥写错、地址写错、
模型名不存在，这三种错在真正提问时都表现成「问答失败」，很难分辨，所以单独给一个验证入口。
填错了可以点「清除已保存的密钥」重来。

**联网搜索**在设置里选供应商。**目前没有配置任何供应商，所以这项默认关闭**，
页面会显示「联网搜索未配置」，不会假装能搜。可选：Tavily（有免费额度）、博查、
Bing、SearXNG（自建实例，不需要密钥）。填好后勾选「联网补充」即可。
外部资料在回答里单独标注为「非年报原文，仅作背景」，不会被当成年报数据引用。

## 环境与依赖

Python 3.12。已有依赖：`pdfplumber`、`numpy`、`requests`、`onnxruntime`。

**本项目只新增一个依赖：`tokenizers`**（约 2MB）。

```bash
pip install tokenizers
```

用途：`onnxruntime` 只负责跑推理，不含分词。`tokenizers` 加载 bge 模型的 `tokenizer.json`。

**刻意不装的**：`sentence-transformers`（会连带 PyTorch，约 2GB）、`jieba`、`rank_bm25`、
`sklearn`、`PyMuPDF`。中文分词用字符 unigram + bigram 自实现（`src/tokenize_zh.py`），
BM25 与 int8 量化自实现，都不需要额外依赖。

向量模型需单独下载（约 95MB，只下一次）：

```bash
python src/download_model.py     # 从 hf-mirror 拉 Xenova/bge-small-zh-v1.5 的 ONNX
```

**模型没有放进仓库**（91MB，超过 GitHub 网页上传的单文件上限）。说明一下谁需要它：

| 用途 | 是否需要模型 |
|---|---|
| 读 `data/extracted/*.json` | 不需要 |
| 双击 `web/index.html` 用问答页 | **不需要**（向量已预计算进 `web/data/` 的分片） |
| 重跑抽取（`indicators.py` 及之前） | 不需要 |
| 重建索引（`build_index.py`） | 需要 |
| 本地服务模式（`启动问答页.bat`） | 需要 |
| 重跑核验（`verify/run_verify.py`） | 需要 |

同理，`work/`（页码映射与切块的中间结果）也没有放进仓库，它可由 `pdf_pagemap.py`
和 `chunker.py` 从年报 PDF 重新生成。网页不读它。

## 抽取规则要点

**提取哪些指标**：17 项，见 `src/aliases.json`。每项配中文别名清单与**禁用别名清单**。

**抽取优先级**：主要会计数据和财务指标表 > 合并三表 > 财务报表附注。

**单位与口径**：数值统一换算为元存入 `value`，同时保留 `value_original`（年报原值）与
`unit_raw`（年报原单位）。单位**逐表判定**——同一份年报的资产负债表用「元」、附注用
「千元」很常见，套用页面级单位会让数字差 1000 倍。报表口径只取**合并**，不取母公司。

**来源与页码追踪**：每项带 `page`（年报印刷页码）、`pdf_page`（PDF 物理页序）、`section`
（章节）、`table`（来源表）、`raw_text`（命中行原文），可逐字回核。

**缺失值分四态**，绝不填 0 不猜：

| status | 含义 |
|---|---|
| `found` | 抽到值 |
| `not_applicable` | 命中了科目但值确实是空（如公司无商誉）——**确定没有** |
| `not_found` | 别名一个都没命中——**可能抽取失败**，附 `aliases_tried` |
| `extraction_error` | 命中但值解析失败，需人工复核 |

## 跑出来的结果

**抽取**：9 家 × 17 项 = 153 格，命中 151 格；另有 1 格是「科目在、值为空」，
1 格未抽到。

| 公司 | 命中 | 说明 |
|---|---|---|
| 万华化学 600309 | 17/17 | |
| 三一重工 600031 | 17/17 | |
| 伊利股份 600887 | 17/17 | |
| 宁德时代 300750 | 17/17 | |
| 海康威视 002415 | 17/17 | |
| 美的集团 000333 | 17/17 | |
| 格力电器 000651 | 17/17 | 由「添加公司」功能联网抓取后自动抽取 |
| 比亚迪 002594 | 16/17 | 扣非归母净利润未抽到 |
| 贵州茅台 600519 | 16/17 | 商誉记为 `not_applicable`（年报里这一行是空的，确实没有） |

比亚迪那一格是主表跨页断裂、且续页首列数字被并进了科目名，属该页独有的错版。
它记为 `not_found`（可能抽取失败），不是 `not_applicable`——两者含义不同，不混用。

**核验**：10 道题（事实 6、推理 3、召回 1）

- 数值正确 **10/10**
- 检索命中期望页 **9/9**（1 道开放题不判页码）
- 逐题对错、召回证据块与出处见 [`verify/report.md`](verify/report.md)

两处交叉校验也通过：美的营业收入在主数据表与利润表两处列示差 0.03%；
`总资产 = 总负债 + 归母净资产 + 少数股东权益` 在 8 家上均成立。

## 已知限制

**联网、上传、生成式回答只在服务模式下可用。** 浏览器跨域拿不到巨潮资讯网的数据，
也跑不了 pdfplumber 与 95MB 的 ONNX 模型。这是物理限制，不是实现取舍。

**静态双击页对自由提问只走 BM25 单路。** 原因是浏览器装不下那个模型，无法对任意输入
现算查询向量。页面会明确标注当前检索路径：

- 双击 `index.html`：自由提问走 BM25 单路；预置问题（含 10 道核验题）走 BM25 + 向量混合。
- 双击 `启动问答页.bat`：任意提问都走完整混合检索。

**AI 问答需要向量模型。** 文档向量已随分片预计算好（所以检索很快），但查询向量依赖
用户输入，必须现算，因此服务模式下的语义检索与 AI 问答都需要 `models/` 里那个 95MB 的模型
（`python src/download_model.py` 拉取）。缺模型时页面会提示，其余功能不受影响。

**问答页是抽取式而非生成式。** 答案由检索到的证据块抽取拼接并逐句标注出处，不做改写。
这样做是为了让「页面展示」与「核验脚本结果」永远一致——若用生成式，页面答案与
`verify/results.json` 会各说各话。

**不处理扫描件。** 无文本层的 PDF 会报错退出，不做 OCR。

**不处理金融业口径。** 银行、保险的科目体系与一般工商业不同，本项目选样已排除金融业。

**主表跨页断裂的行可能取不到。** 当一个科目行的科目名在上一页、数字在下一页时，
管线会尝试把上一页的遗留科目行接回来（仅在这条拼接能对上别名时才采用），
但续页排版错乱时（比亚迪的扣非行）仍然取不到，会记为 `not_found`。

**检索对同质科目名有天然弱点。** 八家年报里「经营活动产生的现金流量净额」出现上百次，
问句点名公司时靠 `COMPANY_BOOST`（1.8 倍）加权区分。若问句不含公司名，跨公司
检索会把这些同质块混在一起——这是 BM25 与向量都解决不了的问题，需要按公司过滤。

## 目录结构

```
A/
├── financial-extraction/        SKILL.md + references/method-notes.md
├── schema/                      financial_schema.json
├── demo/                        美的集团 2025：input PDF + output JSON
├── data/annual_reports/         年报原件（未进仓库，本地跑管线需要）
├── data/extracted/              抽取结果 JSON（交付物）
├── models/                      bge-small-zh-v1.5 ONNX + tokenizer（未进仓库）
├── src/                         可运行管线
│   ├── fetch_cninfo.py          下载年报；resolve_company 支持任意代码/公司名
│   ├── pdf_pagemap.py           页码映射
│   ├── table_extract.py         坐标表格解析
│   ├── indicators.py            17 项指标抽取
│   ├── chunker.py               切块
│   ├── build_index.py           BM25 + int8 向量（支持增量）
│   ├── export_metrics.py        看板数据（支持增量）
│   ├── identify.py              从 PDF 识别公司名/代码/年份
│   ├── config.py                运行期配置（密钥存仓库外）
│   ├── jobs.py                  后台任务队列 + 进度
│   ├── ingest.py                新增公司的完整编排
│   ├── ask.py                   大模型问答（提示词 + 引用解析）
│   ├── websearch.py             联网搜索适配器
│   └── remove_company.py        移除一家公司的全部产物
├── web/                         问答页 + 看板 + 后端
│   ├── index.html  app.js  search.js  tokenize.js  style.css
│   ├── api.js  extras.js        服务模式下才生效的前端（静态页不加载新面板）
│   ├── serve.py                 本地服务：静态文件 + /api/*
│   ├── 启动问答页.bat
│   └── data/                    页面数据
│       ├── _manifest.json _metrics.json   真相源
│       ├── manifest.js metrics.js queries.js tokens_golden.js   由真相源生成
│       └── shard_<代码>.js      各公司的检索分片
└── verify/                      10 题核验：questions.json + results.json + report.md
```

## 维护

```bash
# 增量重建某一家（不会动其他公司的分片）
python src/build_index.py --codes 000333

# 全量重建（改了分词或换了向量模型后必须跑）
python src/build_index.py

# 移除一家公司（默认只预览，加 --yes 才真删）
python src/remove_company.py 000651
```

**改了分词或换了向量模型，必须全量重建。** 增量前会比对分片里的版本号，不一致直接拒绝——
新旧打分不可比，混在一个库里检索会静默给出错的排序，比报错难查得多。
