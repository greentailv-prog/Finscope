# -*- coding: utf-8 -*-
"""核验：10 道题（含 3 道推理）走与网页完全相同的管线，逐题记录对错与证据。

单一真相源是 verify/questions.json：题目、人工读 PDF 填的期望值、期望页码、判分方式。
本脚本只负责跑、判、记，不产生真值。

判分分两层，分开记：
- **检索命中**：top-N 证据块是否覆盖期望页码（expected_pages 为空的开放题不判此项）
- **数值正确**：data/extracted 里的抽取结果是否等于期望值（fact / reasoning 题）

两层分开记是因为它们的失败含义不同：检索没召回是索引问题，数值不对是抽取问题，
混在一个「对/错」里就定位不到根因。

用法:
    python verify/run_verify.py
    python verify/run_verify.py --topn 8
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
import embed as embed_mod     # noqa: E402
import search_py              # noqa: E402

ROOT = SRC.parent
HERE = Path(__file__).resolve().parent
EXTRACTED = ROOT / "data" / "extracted"

FAILURE_KINDS = [
    "retrieval_miss", "extraction_wrong", "alias_miss", "unit_error", "scope_error",
    "column_error", "not_found", "numeric_parse_error", "reasoning_error", "page_citation_wrong",
]


def load_extracted() -> dict:
    out = {}
    for p in EXTRACTED.glob("*.json"):
        d = json.loads(p.read_text(encoding="utf-8"))
        out[d["company"]["ticker"]] = d
    return out


def metric_value(extracted: dict, code: str, key: str):
    """返回 (值, 状态, 页码)。值单位：元。"""
    d = extracted.get(code)
    if not d:
        return None, "no_extraction", None
    m = d["financials"].get(key)
    if not m:
        return None, "no_metric", None
    return m.get("value"), m.get("status"), m.get("page")


def judge_number(got, expected, tol):
    if got is None:
        return False, None
    got_yi = got / 1e8
    if expected == 0:
        return abs(got_yi) < 1e-6, got_yi
    ok = abs(got_yi - expected) / abs(expected) <= tol
    return ok, got_yi


def main() -> int:
    ap = argparse.ArgumentParser(description="运行 A 模块核验")
    ap.add_argument("--topn", type=int, default=8)
    args = ap.parse_args()

    spec = json.loads((HERE / "questions.json").read_text(encoding="utf-8"))
    questions = spec["questions"]
    extracted = load_extracted()

    print("加载索引与向量模型 ...", flush=True)
    # 直接从已发布的分片建索引：文档向量用的是分片里那份量化向量，与浏览器看到的
    # 完全一致；也不需要 work/ 里的中间产物，所以核验只靠仓库里的文件就能复现。
    indexes = search_py.load_from_shards()
    if not indexes:
        print("找不到任何分片，请先运行 src/build_index.py", file=sys.stderr)
        return 1
    emb = embed_mod.Embedder()          # 只用来现算查询向量
    print(f"索引就绪：{len(indexes)} 家公司，"
          f"{sum(ix.n_docs for ix in indexes)} 个块\n")

    results = []
    for q in questions:
        t0 = time.perf_counter()
        qvec = emb.encode([q["question"]])[0]
        hits = search_py.search(indexes, q["question"], qvec, top_n=args.topn)
        ms = (time.perf_counter() - t0) * 1000

        # ---- 检索判分 ----
        pages = [h["printed_page"] for h in hits if h["printed_page"] is not None]
        exp_pages = q.get("expected_pages") or []
        page_hit = (set(pages) & set(exp_pages)) != set() if exp_pages else None

        # ---- 数值判分 ----
        check = q["check"]
        kind = check["kind"]
        expected = q.get("expected", {})
        value_ok, got_yi, detail = None, None, ""

        if kind == "metric":
            got, status, page = metric_value(extracted, q["company"], check["metric"])
            value_ok, got_yi = judge_number(got, expected["value"], expected.get("tolerance", 0.01))
            detail = f"metric={check['metric']} status={status} page={page}"
        elif kind == "growth":
            d = extracted.get(q["company"], {}).get("financials", {}).get(check["metric"], {})
            s = d.get("series", {})
            a, b = s.get("2025"), s.get("2024")
            if a is not None and b not in (None, 0):
                got_yi = (a - b) / abs(b) * 100
                value_ok = abs(got_yi - expected["value"]) / abs(expected["value"]) <= expected.get("tolerance", 0.03)
            else:
                value_ok = False
            detail = f"growth({check['metric']}) 2025={a} 2024={b}"
        elif kind == "formula":
            keys = check["expr"]
            a, st_a, _ = metric_value(extracted, q["company"], keys[0])
            b, st_b, _ = metric_value(extracted, q["company"], keys[-1])
            if a is not None and b is not None:
                got_yi = (a - b) / 1e8
                value_ok = abs(got_yi - expected["value"]) / abs(expected["value"]) <= expected.get("tolerance", 0.03)
            else:
                value_ok = False
            detail = f"formula({keys[0]} - {keys[-1]}) {keys[0]}={a} status={st_a}；{keys[-1]}={b} status={st_b}"
        elif kind == "keywords":
            blob = "\n".join(h["text"] for h in hits)
            kws = expected["keywords"]
            hit_kws = [k for k in kws if k in blob]
            value_ok = len(hit_kws) >= expected["min_hits"]
            detail = f"风险关键词命中 {len(hit_kws)}/{expected['min_hits']}：{hit_kws}"
            got_yi = len(hit_kws)

        # ---- 失败分类 ----
        failure = None
        if value_ok is False:
            m = extracted.get(q["company"], {}).get("financials", {}).get(check.get("metric", ""), {})
            st = m.get("status")
            if st == "not_found":
                failure = "alias_miss" if m.get("reason") == "alias_miss" else "not_found"
            elif st == "not_applicable":
                failure = "not_found"
            elif kind in ("growth", "formula"):
                failure = "reasoning_error"
            else:
                failure = "extraction_wrong"
        if page_hit is False and failure is None:
            failure = "retrieval_miss"

        results.append({
            "qid": q["qid"], "type": q["type"], "question": q["question"],
            "company": q["company"], "company_name": q["company_name"],
            "expected": expected,
            "system_value_yi": None if got_yi is None else round(float(got_yi), 4),
            "detail": detail,
            "value_correct": value_ok,
            "retrieval_page_hit": page_hit,
            "expected_pages": exp_pages,
            "retrieved_pages": pages,
            "evidence": [{
                "fused_rank": h["fused_rank"], "chunk_id": h["chunk_id"],
                "company": h["company_name"], "section": h["section"],
                "printed_page": h["printed_page"], "is_table": h["is_table"],
                "bm25_rank": h["bm25_rank"], "vec_rank": h["vec_rank"],
                "text_snippet": h["text"][:220].replace("\n", " "),
            } for h in hits],
            "failure_reason": failure,
            "latency_ms": round(ms, 1),
        })

    n_val = sum(1 for r in results if r["value_correct"])
    n_ret = sum(1 for r in results if r["retrieval_page_hit"])
    n_ret_judged = sum(1 for r in results if r["retrieval_page_hit"] is not None)

    summary = {
        "n_questions": len(results),
        "value_correct": n_val,
        "retrieval_hit": n_ret,
        "retrieval_judged": n_ret_judged,
        "by_type": {},
        "failure_kinds": {k: 0 for k in FAILURE_KINDS},
        "versions": {
            "embedder": embed_mod.EMBEDDER_VERSION,
            "tokenizer": __import__("tokenize_zh").TOKENIZER_VERSION,
        },
    }
    for r in results:
        t = r["type"]
        summary["by_type"].setdefault(t, {"n": 0, "value_correct": 0, "retrieval_hit": 0})
        summary["by_type"][t]["n"] += 1
        summary["by_type"][t]["value_correct"] += int(bool(r["value_correct"]))
        summary["by_type"][t]["retrieval_hit"] += int(bool(r["retrieval_page_hit"]))
        if r["failure_reason"]:
            summary["failure_kinds"][r["failure_reason"]] += 1

    (HERE / "results.json").write_text(
        json.dumps({"summary": summary, "results": results}, ensure_ascii=False, indent=2),
        encoding="utf-8")

    _write_report(HERE / "report.md", summary, results)

    print(f"数值正确 {n_val}/{len(results)}　检索命中 {n_ret}/{n_ret_judged}"
          f"（开放题 {len(results)-n_ret_judged} 道不判页码）")
    for r in results:
        mark = "OK " if r["value_correct"] else "FAIL"
        page = "页命中" if r["retrieval_page_hit"] else ("页未中" if r["retrieval_page_hit"] is False else "开放题")
        print(f"  [{mark}] {r['qid']:>3s} {r['type']:9s} {page:6s} "
              f"系统={r['system_value_yi']} 期望={r['expected'].get('value')} "
              f"{'失败=' + r['failure_reason'] if r['failure_reason'] else ''}")
    print(f"\n结果 -> {HERE / 'results.json'}\n报告 -> {HERE / 'report.md'}")
    return 0


def _write_report(path: Path, summary: dict, results: list[dict]) -> None:
    L = []
    L.append("# A 模块核验报告\n")
    L.append("检索与数值都走与网页相同的管线（同一分词、同一 BM25 公式、同一 bge 向量、"
             "同一 RRF 融合），所以页面上看到的结果与下面这张表一致。\n")
    L.append(f"- 题目 {summary['n_questions']} 道（事实 6、推理 3、召回 1）")
    L.append(f"- **数值正确 {summary['value_correct']}/{summary['n_questions']}**")
    L.append(f"- **检索命中期望页 {summary['retrieval_hit']}/{summary['retrieval_judged']}**"
             f"（开放题 {summary['n_questions']-summary['retrieval_judged']} 道不判页码）")
    L.append(f"- 版本：向量 `{summary['versions']['embedder']}` / 分词 `{summary['versions']['tokenizer']}`\n")

    fails = {k: v for k, v in summary["failure_kinds"].items() if v}
    L.append("失败类型分布：" + (", ".join(f"{k} {v}" for k, v in fails.items()) if fails else "无") + "\n")

    L.append("## 逐题\n")
    for r in results:
        ok = "对" if r["value_correct"] else "错"
        L.append(f"### {r['qid']}　{r['company_name']}　[{r['type']}]　**{ok}**\n")
        L.append(f"**题目**：{r['question']}\n")
        exp = r["expected"]
        L.append(f"**期望**：{exp.get('value', '')}{exp.get('unit', '')}"
                 + (f"（容差 {exp.get('tolerance')}）" if exp.get("tolerance") else "")
                 + (f"　关键词命中不少于 {exp.get('min_hits')} 个" if exp.get("min_hits") else ""))
        L.append(f"**系统**：{r['system_value_yi']}{exp.get('unit', '')}\n")
        L.append(f"**判据**：{r['detail']}")
        L.append(f"**页码**：期望 {r['expected_pages'] or '—'}，召回 {r['retrieved_pages']}"
                 f"　→ {'命中' if r['retrieval_page_hit'] else ('未命中' if r['retrieval_page_hit'] is False else '不判')}")
        if r["failure_reason"]:
            L.append(f"**失败类型**：`{r['failure_reason']}`")
        L.append(f"**耗时**：{r['latency_ms']} ms\n")
        L.append("**召回的证据块**：\n")
        L.append("| 融合名次 | chunk_id | 公司 | 章节 | 年报页 | 表格 | BM25名次 | 向量名次 |")
        L.append("|---|---|---|---|---|---|---|---|")
        for e in r["evidence"][:5]:
            L.append(f"| {e['fused_rank']} | `{e['chunk_id']}` | {e['company']} | "
                     f"{(e['section'] or '')[:18]} | {e['printed_page']} | "
                     f"{'是' if e['is_table'] else ''} | {e['bm25_rank'] or '—'} | {e['vec_rank'] or '—'} |")
        L.append("")
        for e in r["evidence"][:2]:
            L.append(f"> **[第 {e['printed_page']} 页]** {e['text_snippet']}…\n")
    path.write_text("\n".join(L), encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
