# 给 E 的 D 前端对接包

这个包只放 E 做前端需要的东西，不需要读 A/B/C 的代码。

## 包里有什么

```text
README_给E.md                 本文件
docs/给E的前端对接说明.md     页面结构、字段、状态、验收清单
docs/接口说明.md              完整 API 契约
web/index.html                D 侧现有工作台，可参考或直接改样式
samples/unified/*.json        14 家公司的真实统一对象，可直接当 mock 数据
samples/reports/<key>/        对应的报告 HTML / Markdown / JSON / CSV
samples/README.md             样例公司说明
```

## 最快上手

1. 先看 `docs/给E的前端对接说明.md` 第 3 节“页面信息架构”。
2. 打开 `samples/reports/600519.SH_2025/memo.html`，看最终报告长什么样。
3. 打开 `samples/unified/600519.SH_2025.json`，按文档第 5 节字段表渲染。
4. 用 `samples/unified/600900.SH_2025.json` 做估值页，它有 DCF 敏感性网格。
5. 用 `samples/unified/600660.SH_2024.json` 做阻断状态，`data_quality.blocked=true`。

## 如果要连真实后端

D 的完整后端不在本包内，在 `Finscope-D-final`（或向 D 要 `Finscope-D-final-release.zip`），需要 Python 3.11：

```bash
python -X utf8 server/app.py
```

默认 `http://127.0.0.1:8790`。E 只需要调 `/api/*`，不要在前端重算指标、估值或风险。

## 三个必须遵守的展示规则

- 缺失值显示 `-`，不写“数据缺失”“待核验”。
- 同比写“同比增长 xx%”或“同比下降 xx%”。
- 页面不出现 A/B/C/D、`net_income_parent` 这类字段名、`risk_id`。

## 重点样例

- `600519.SH_2025`：正常分析、估值、4 家同业。
- `600900.SH_2025`：DCF 有敏感性网格，估值页滑块可用；加权 ROE 显示“未取到”。
- `600660.SH_2024`：`blocked`，顶部要显示阻断原因，不显示估值结论。
- `600660.SH_2025`：借款科目异常被剔除，指标显示“未取到”。
