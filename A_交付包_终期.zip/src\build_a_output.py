# -*- coding: utf-8 -*-
"""把 data/extracted/*.json 转成 04 规范里的 A 段输出。

04 要求的 A 段是 company + financials + sources，financials 用 canonical 键，
每条记录带 source_id。驾驶舱内部已经做了这套映射，这里只负责落盘，方便 D 直接读。

产物：data/unified/<ticker>_<year>.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import cockpit                       # noqa: E402
import webdata                       # noqa: E402

ROOT = SRC.parent
EXTRACTED = ROOT / "data" / "extracted"
OUT = ROOT / "data" / "unified"


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for path in sorted(EXTRACTED.glob("*.json")):
        parts = path.stem.split("_")
        if len(parts) < 3:
            continue
        code, year = parts[-2], parts[-1]
        if not (len(code) == 6 and code.isdigit() and year.isdigit()):
            continue
        try:
            data = cockpit.build_pdf_cockpit(code, int(year))
        except Exception as exc:  # noqa: BLE001 - 单家失败不影响其余
            print(f"[skip] {path.name}: {exc}", file=sys.stderr)
            continue
        payload = {
            "schema_version": "2.0",
            "meta": data["meta"],
            "company": data["company"],
            "financials": data["financials"],
            "sources": data["sources"],
            "data_quality": data["data_quality"],
            "coverage": data["coverage"],
        }
        key = data["meta"]["key"]
        webdata.atomic_write_text(OUT / f"{key}.json",
                                  json.dumps(payload, ensure_ascii=False, indent=1))
        rows.append((key, data["coverage"]["p0_found"], data["coverage"]["p0_total"],
                     len(data["sources"]), data["data_quality"]["status"]))
    for key, found, total, nsrc, q in rows:
        print(f"  {key:16s} P0 {found:2d}/{total}  sources {nsrc:3d}  quality {q}")
    print(f"{len(rows)} 家 -> {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
