# -*- coding: utf-8 -*-
"""生成 11 家 × 30 个 P0 × 三年覆盖表。

读 data/unified/*.json，不联网。输出 Markdown 到 docs/coverage_11x30.md。
单元格是该科目在 2023–2025 里有数值的年数（0–3）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
ROOT = SRC.parent
UNIFIED = ROOT / "data" / "unified"
OUT = ROOT / "docs" / "coverage_11x30.md"

P0 = [
    "revenue", "operating_cost", "operating_profit", "pretax_profit",
    "income_tax_expense", "net_income", "net_income_parent",
    "net_income_excl_nonrecurring", "selling_expense", "admin_expense",
    "finance_expense", "interest_expense", "depreciation_amortization",
    "cash_and_equivalents", "accounts_receivable", "inventory", "current_assets",
    "total_assets", "accounts_payable", "current_liabilities",
    "short_term_borrowings", "current_portion_lt_debt", "long_term_borrowings",
    "bonds_payable", "total_liabilities", "equity_parent", "total_equity",
    "cfo", "capex", "cash_received_from_sales",
]
LABEL = {
    "revenue": "营业收入", "operating_cost": "营业成本", "operating_profit": "营业利润",
    "pretax_profit": "利润总额", "income_tax_expense": "所得税费用",
    "net_income": "净利润", "net_income_parent": "归母净利",
    "net_income_excl_nonrecurring": "扣非归母", "selling_expense": "销售费用",
    "admin_expense": "管理费用", "finance_expense": "财务费用",
    "interest_expense": "利息费用", "depreciation_amortization": "折旧摊销",
    "cash_and_equivalents": "货币资金", "accounts_receivable": "应收账款",
    "inventory": "存货", "current_assets": "流动资产",
    "total_assets": "总资产", "accounts_payable": "应付账款",
    "current_liabilities": "流动负债", "short_term_borrowings": "短期借款",
    "current_portion_lt_debt": "一年内到期", "long_term_borrowings": "长期借款",
    "bonds_payable": "应付债券", "total_liabilities": "总负债",
    "equity_parent": "归母净资产", "total_equity": "所有者权益",
    "cfo": "经营现金流", "capex": "资本开支", "cash_received_from_sales": "销售收现",
}
YEARS = ("2023", "2024", "2025")


def main() -> int:
    data = []
    for path in sorted(UNIFIED.glob("*.json")):
        d = json.loads(path.read_text(encoding="utf-8"))
        fins = d.get("financials", {})
        yearly = {}
        for key in P0:
            series = (fins.get(key) or {}).get("series") or {}
            yearly[key] = {y for y in YEARS
                           if isinstance(series.get(y), (int, float))
                           and series.get(y) is not None}
        counts = {k: len(v) for k, v in yearly.items()}
        found = sum(1 for key in P0
                    if (fins.get(key) or {}).get("status") == "found")
        data.append({
            "key": d.get("meta", {}).get("key", path.stem),
            "company": d.get("company", {}),
            "counts": counts,
            "yearly": yearly,
            "three": sum(1 for k in P0 if counts[k] == 3),
            "found": found,
            "missing": [k for k in P0 if counts[k] == 0],
        })

    lines = [
        "# 11 家 × 30 个 P0 × 三年覆盖",
        "",
        "> 由 `src/coverage_report.py` 从 `data/unified/*.json` 生成，不联网。",
        "> 单元格为 2023 / 2024 / 2025 中有值的年数（0–3）；0 表示三年都没有数值。",
        "",
        "## 汇总",
        "",
        "| 公司 | 三年齐 P0 | P0 found | 2023 有值 | 2024 有值 | 2025 有值 | 缺失 P0 |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for x in data:
        c = x["counts"]
        name = x["company"].get("name_short") or x["company"].get("name") or x["key"]
        n23 = sum(1 for k in P0 if c[k] >= 1 and _has_year(x, k, "2023"))
        n24 = sum(1 for k in P0 if c[k] >= 1 and _has_year(x, k, "2024"))
        n25 = sum(1 for k in P0 if c[k] >= 1 and _has_year(x, k, "2025"))
        lines.append(f"| {name} {x['key']} | {x['three']} | {x['found']} | "
                     f"{n23} | {n24} | {n25} | "
                     f"{'、'.join(LABEL.get(k, k) for k in x['missing'][:8]) if x['missing'] else '无'} |")

    lines += ["", "## 逐科目矩阵（0–3 年）", "",
              "| 科目 | " + " | ".join(x["key"].split(".")[0] for x in data) + " |",
              "|---|" + "---:|" * len(data)]
    for key in P0:
        cells = " | ".join(str(x["counts"][key]) for x in data)
        lines.append(f"| {LABEL.get(key, key)} | {cells} |")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(data)} 家 -> {OUT}")
    return 0


def _has_year(x: dict, key: str, year: str) -> bool:
    # counts 只存年数；为了按年统计，重新从 unified 读一次代价太高，
    # 这里用 series 的年数无法区分具体年份，因此把 yearly 存在 data 里。
    return year in x.get("yearly", {}).get(key, ())


if __name__ == "__main__":
    sys.exit(main())
