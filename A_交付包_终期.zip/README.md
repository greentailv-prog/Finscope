# A 模块 · 财报读取、联网取数与研究驾驶舱

FinScope 的第一棒。用户输入 A 股代码或公司名，系统在巨潮资讯网打开该公司年报页面，
同时下载年报 PDF、建立页码级证据；在线三表先把驾驶舱填满，PDF 解析完成后再切换到
“年报原文”口径。每个数字都能回到数据源字段或年报印刷页码。

## 这一版改了什么

- 产品入口从“9 家公司看板”改成“搜索任意 A 股公司”。原来的 9 家加上 000858、
  002709 只保留作回归测试集，首页不再预置它们的卡片。
- 新增联网取数：公司检索、年报定位、东方财富年度三表、30 个 P0 科目的 canonical 映射。
- 新增研究驾驶舱：结论、KPI、成长/盈利/现金流/偿债/效率五组图、数据表、来源台账、
  证据抽屉。在线与原文两种口径分开渲染，不混数。
- PDF 抽取修了两个会直接说错话的 bug：把母公司表当合并表、把占比列当金额列。
  新增合并三表文本兜底，避免表头落在上一页时整段数值丢失。
- 输出对齐 04 规范：canonical 键、`sources[]`、`data_quality`、P0 覆盖率、
  双口径交叉校验。

### 按 `调整意见/05_A必须修改项.md` 的终期修改（2026-11-08）

- A1 万华 `current_portion_lt_debt`：修了 `table_extract.unit_from_text` 的
  单位识别，正文里的「（单位：亿元）」不再覆盖表头「单位：元」；值回到 168.16 亿元。
- A2 五粮液 2025：封面与第 7 页核验为年度报告，营收下滑是原文列示；货币资金
  2025/2024 原文两列相同，`SERIES_IDENTICAL` 标出，说明见
  [`docs/000858_source_check.md`](docs/000858_source_check.md)。
- A3 三一：`total_liabilities`、D&A 改为合并口径并取合理候选；所有者权益回到
  89.43 亿元、负债 83.87 亿元，D&A 4.09 亿而不是 1,178 万；cfo 2023/2024 在原文里
  都是 14,814,278 千元，`SERIES_IDENTICAL` 标出。
- A4 天赐：印刷页码映射覆盖率只有 5%，`page` 用 PDF 物理页兜底，并在
  `status_note` 写明。
- A5 三年覆盖：主表按列序补 2023；`docs/coverage_11x30.md` 给出 11×30×3 表。
- A6 Schema：新增 [`schema/canonical_schema.json`](schema/canonical_schema.json)，
  `financial_schema.json` 明确为 PDF 原始抽取层。
- A7 `scope`：`not_applicable` 记录写 `null`，有值记录只允许合并/母公司。
- A8 自检：P0 全量量级、单位换算、金额量级、两年相同、报告期/标题、三年覆盖
  都进了 `data_quality.checks`。
- A9 联网样例：`data/online_samples/` 提供 000858、000333、600309 三家
  `source_mode="online"` 样例。
- A10 交付包：`A_交付包/` 第一层只有 A 的内容，不混 B 的文件。

## 怎么打开

双击 [`web/启动问答页.bat`](web/启动问答页.bat)，浏览器会打开
`http://127.0.0.1:8765/index.html`。搜索、下载、解析、问答都需要这个本地服务。

直接双击 `web/index.html` 只能看到搜索框，联网取数与下载不可用；页面会明确提示。
旧版看板、抽取式问答和上传 PDF 保留在 `web/legacy.html`，新入口搜索框下方有
“已有年报 PDF？去上传页”的链接，不再把上传放在主路径上。

## 搜索后发生什么

1. 输入 6 位代码或公司简称，选择报告年度（默认最近一期年报）。
2. 后端用巨潮 `topSearch` 解析公司，用公告接口定位该年度年报正文。
3. 浏览器在新标签页打开巨潮的年报页面。弹窗被拦截时，页面顶部保留“打开年报页面”按钮。
4. 后台任务开始：下载 PDF → 页码映射 → 指标抽取 → 切块 → 向量索引 → 更新看板。
5. 同时请求东方财富年度三表，先渲染“在线快照”。
6. 抽取结果落盘后，前端自动切到“年报原文”，页码、原文片段、PDF 预览可用。

一份新年报通常 2–5 分钟；已下载过的公司会跳过下载，但仍会重新解析，以保证数据是最新的。

## 两种口径

| | 在线快照 | 年报原文 |
|---|---|---|
| 来源 | 东方财富 F10 年度三表 | 巨潮下载的年报 PDF |
| 速度 | 秒级 | 分钟级 |
| 科目 | 30 个 P0（多数公司可全取） | 34 个指标，覆盖 27–30 个 P0（视公司版式） |
| 出处 | 数据源 + 字段 + 链接 | 印刷页码 + PDF 页 + 原文片段 |
| 页码 | 没有，页面明确写“在线模式无页码” | 有，可点回 PDF 对应页 |
| 适合 | 先看数和趋势 | 复核、写报告、答辩 |

`meta.source_mode` 区分入口：`online` / `upload`。`financials.*.source_type`
区分单条数据：`online` / `pdf`。上传模式固定 `pdf`，不会写成 `upload`。

**不混数。** 同一屏只渲染一种口径。切换口径会重新渲染全部卡片、图表、表格与来源。
两边都加载后，页面会跑一次双口径交叉校验，对收入、归母净利、总资产、总负债、
货币资金、经营现金流六项做 1% 阈值比对；差异会列在状态条和抽屉里，不会静默覆盖。

## 数据接口

新增接口都在 `web/serve.py`：

| 接口 | 用途 |
|---|---|
| `GET /api/search?q=&year=` | 公司检索，返回候选与最佳匹配的年报公告 |
| `GET /api/report?code=&year=` | 单家公司的年报公告页、PDF 链接、公司资料 |
| `GET /api/online?code=&year=` | 在线驾驶舱对象（30 个 P0、比率、质量、摘要） |
| `GET /api/cockpit?code=&year=&mode=auto\|online\|pdf` | 驾驶舱对象；`auto` 优先原文 |
| `GET /api/history` | 真实跑过的任务列表，不含预置样例 |
| `POST /api/analyze` | 启动下载 + 解析任务，等价于旧的 `/api/ingest` |
| `GET /files/reports/<文件名>.pdf` | 本地年报 PDF，支持 Range，证据抽屉直接打开到指定页 |

旧接口 `/api/upload`、`/api/ask`、`/api/job`、`/api/jobs`、`/api/config` 保留。

驾驶舱对象的结构：

```
{
  schema_version, mode, meta, company,
  financials: { canonical_key: MetricRecord },
  ratios: { key: {name, value, prev, delta, unit, formula, inputs, series, ...} },
  summary: { headline, points[], focus, quality_note },
  coverage: { p0_total, p0_found, p0_missing[], sources },
  sources: [ ... ],
  data_quality: { status, blocked, checks[] },
  report: { page_url, pdf_url, title, ... }
}
```

`financials` 的 canonical 键对齐 04：`net_income_parent`、`net_income_excl_nonrecurring`、
`equity_parent`、`cash_and_equivalents` 等。旧的 17 个键在 `src/cockpit.py` 的
`LEGACY_TO_CANON` 里做映射，老数据不用重抽。

## 30 个 P0 科目

在线模式按以下清单映射东方财富字段，缺项写 `not_found`，不填 0：

- 利润表：revenue、operating_cost、operating_profit、pretax_profit、income_tax_expense、
  net_income、net_income_parent、net_income_excl_nonrecurring、selling_expense、
  admin_expense、finance_expense、interest_expense、depreciation_amortization
- 资产负债表：cash_and_equivalents、accounts_receivable、inventory、current_assets、
  total_assets、accounts_payable、current_liabilities、short_term_borrowings、
  current_portion_lt_debt、long_term_borrowings、bonds_payable、total_liabilities、
  equity_parent、total_equity
- 现金流量表：cfo、capex、cash_received_from_sales

PDF 模式抽 34 个指标，覆盖 30 个 P0 中的 27–30 个，视公司版式而定。缺的项不会
悄悄补 0：状态条标覆盖率，证据抽屉标 `not_found` / `not_applicable`。常见的
`not_applicable` 是公司确实没有短期借款、长期借款或应付债券；常见的 `not_found`
是报表把科目名和金额拆成两行、或改用「财务收入」这类非标准列示。

## 数据质量

页面上的检查与 04 第 11 节一致：资产负债平衡、成本与收入、毛利率区间、资产负债率区间、
增速区间、三年量级、现金流勾稽、母公司口径、来源完整性。每条检查带 `metric`、
`page`、`pdf_page`、`source_id`，证据抽屉里能直接看到。

`status=blocked` 时，页面对估值类结论保持克制；摘要只描述数据异常，不输出“低估/高估”。
`warn` 会列在状态条，不阻断阅读。

## 抽取管线

```bash
cd A_交付包
python src/fetch_cninfo.py       # 1. 从巨潮下载年报 PDF（已有则跳过）
python src/pdf_pagemap.py        # 2. PDF 物理页 -> 印刷页码
python src/indicators.py         # 3. 抽取 34 项指标 -> data/extracted/
python src/chunker.py            # 4. 切块（公司 + 章节 + 页码）
python src/embed.py --check      # 5. 向量模型自检
python src/build_index.py        # 6. 建 BM25 + 向量索引 -> web/data/
python src/export_metrics.py     # 7. 旧版看板数据（legacy.html 用）
python src/build_queries.py      # 8. 预置问题的查询向量
```

第 1–3 步是抽取，第 4–8 步是问答与旧看板所需。驾驶舱只依赖第 1–3 步的结果；
在线快照完全不依赖 PDF。

联网取数的三个模块：

- `src/online_finance.py`：公司检索、年报定位、三表拉取、canonical 映射。
- `src/cockpit.py`：把在线或 PDF 数据整理成驾驶舱对象，算比率、质量、摘要。
- `src/line_fallback.py`：合并三表文本兜底，修表头跨页与多表同页的漏值。

## 单位与口径

- 所有金额内部统一为元，页面金额折算为亿元展示，表格保留两位小数。
- 报表口径只取合并；只有母公司数据时 `scope="母公司报表"`，并在质量检查里记
  `PARENT_ONLY`。
- 利润表/现金流量表取全年累计，资产负债表取年末。
- 资本开支传正数（现金流出额），在 `status_note` 说明“流出”。
- 负值直接写负，不取绝对值；成本类科目按年报列示符号取绝对值。

## 已知限制

- 在线接口是公开页面背后的 JSON，字段随上游变。上游改版会报错，不静默返回空。
- 在线模式没有页码，这是产品取舍；要页码就用原文模式。
- PDF 模式抽 34 个指标，P0 覆盖 27–30 个；个别科目会因拆分排版或非标准列示
  （如「财务收入」）记为 `not_found`，页面会标注，不用 0 填。
- 少数公司（美的、格力、海康）的“主要会计数据”表把“本年比上年增减”列排在
  2023 年列前面。解析器会跳过百分比列，`series` 只保留 2025/2024，不会把
  -9.89 这类同比数写成 2023 年金额；在线模式仍有完整三年。
- 扫描件、图片型 PDF 不处理，直接报错。
- 银行、保险、证券、地产的科目体系与一般工商业不同；驾驶舱会标
  `industry_support=unsupported/limited`，不套标准估值口径。
- 问答需要向量模型（约 95MB）。模型缺失时检索退化为 BM25，页面会提示。
- 双口径交叉校验只覆盖 6 个主科目，不能替代逐项复核。

## 目录

```
A_交付包/
├── src/
│   ├── online_finance.py      联网取数：检索、年报、三表、canonical 映射
│   ├── cockpit.py             驾驶舱对象：比率、质量、摘要、双口径
│   ├── line_fallback.py       合并三表文本兜底
│   ├── build_a_output.py      04 A 段落盘 -> data/unified/
│   ├── add_sources.py         给抽取结果补顶层 sources[]
│   ├── fetch_cninfo.py        巨潮下载
│   ├── indicators.py          34 项指标抽取
│   ├── pdf_pagemap.py         页码映射
│   ├── chunker.py / embed.py / build_index.py   检索索引
│   └── ask.py                 带出处的问答
├── web/
│   ├── index.html             驾驶舱（产品入口）
│   ├── cockpit.css / cockpit.js
│   ├── legacy.html            旧版看板与抽取式问答
│   ├── serve.py               本地服务与 /api
│   └── 启动问答页.bat
├── data/
│   ├── annual_reports/        年报 PDF
│   ├── extracted/             PDF 抽取结果
│   └── online/                在线数据缓存（12 小时）
├── docs/field_mapping.md      04 canonical ← 东方财富字段对照
├── schema/financial_schema.json
├── financial-extraction/SKILL.md
└── verify/                    10 题核验
```

## 维护

```bash
# 增量重建某一家（不会动其他公司的分片）
python src/build_index.py --codes 000333

# 移除一家公司（默认只预览，加 --yes 才真删）
python src/remove_company.py 000651

# 清掉在线缓存，强制重新取数
# 删除 data/online/ 下对应文件即可，页面下次请求会重新拉
```

改了分词或换了向量模型，必须全量重建索引；新旧打分不可比，混在一个库里检索会静默给出
错误排序。

## 核验

`verify/` 保留 10 道题（事实 6、推理 3、召回 1）。这一版的回归重点是：

- 600519：PDF 与在线口径的收入、归母净利、总资产、总负债、货币资金、经营现金流
  六项交叉校验一致；
- 000858：任意公司联网取数可跑通，在线 30 个 P0、PDF 核心科目均有来源；
- 000333：上传 PDF 模式页码可点；
- 002594：单位错必须被质量检查拦住；
- 600036：银行行业标 `unsupported`；
- 999999：错误代码不白屏。

研究性输出，不构成投资建议。
