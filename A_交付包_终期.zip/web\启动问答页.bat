@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  )
)

if not defined PY (
  echo.
  echo 没有找到 Python。联网搜索、下载年报与解析都需要本服务，请先安装 Python 3.12。
  echo 直接双击 index.html 只能看到搜索框，不能联网取数。
  echo.
  pause
  exit /b 1
)

echo 正在启动 FinScope 财报研究驾驶舱...
%PY% serve.py
pause
