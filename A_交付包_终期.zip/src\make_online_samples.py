# -*- coding: utf-8 -*-
"""生成 3 家 source_mode="online" 的样例，供 D/调整意见 A9 验收。

产物：data/online_samples/<ticker>_<year>.json
不写 data/online/ 缓存目录，避免和 12 小时缓存混在一起。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import cockpit                       # noqa: E402
import webdata                       # noqa: E402

ROOT = SRC.parent
OUT = ROOT / "data" / "online_samples"
CODES = ("000858", "000333", "600309")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    for code in CODES:
        data = cockpit.build_online_cockpit(code, 2025, force=True)
        payload = {
            "schema_version": "2.0",
            "meta": data["meta"],
            "company": data["company"],
            "financials": data["financials"],
            "sources": data["sources"],
            "data_quality": data["data_quality"],
            "coverage": data["coverage"],
        }
        key = data["meta"]["key"]
        webdata.atomic_write_text(OUT / f"{key}.json",
                                  json.dumps(payload, ensure_ascii=False, indent=1))
        print(f"  {key}  P0 {data['coverage']['p0_found']}/30  "
              f"source_mode={data['meta']['source_mode']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
