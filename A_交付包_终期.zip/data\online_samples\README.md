# 联网模式样例（source_mode="online"）

由 `python src/make_online_samples.py` 生成，对应调整意见 A9。

| 文件 | 公司 | 说明 |
|---|---|---|
| `000858.SZ_2025.json` | 五粮液 | 在线三表，2023–2025 三年 |
| `000333.SZ_2025.json` | 美的集团 | 在线三表，2023–2025 三年 |
| `600309.SH_2025.json` | 万华化学 | 在线三表，2023–2025 三年 |

每条 `financials` 记录：

- `source_type="online"`、`page=null`、`pdf_page=null`
- `source_field` 是东方财富字段名（如 `OPERATE_INCOME`）
- `source_url` 是 F10 数据页
- `series` 含 2023/2024/2025

这些文件不含页码，和 `data/unified` 的 PDF 口径分开。页面切到“在线快照”时读这一套。
