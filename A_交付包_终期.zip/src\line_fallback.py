# -*- coding: utf-8 -*-
"""三表行的文本兜底解析。

坐标表格解析在两种版式上会漏值：
1. 报表标题和表头落在上一页页尾（茅台 2025 年报第 56 页：审计报告结尾接着合并
   资产负债表的表头），续页又没有表头，整段数值没有列归属；
2. 同一页有多个表（第 14 页「资产构成」：货币资金 51,690,610,946.50 17.01
   59,295,822,956.89 19.84 -12.83），占比列被当成了金额列。

这里用纯文本行兜底：只在「合并」三表页上，按「科目名 + 一至两个金额」取数，
不处理合并/母公司并排的版式（那种交给 table_extract 的列头识别）。
兜底结果只在坐标解析没有拿到三表级候选时启用，不覆盖已经解析正确的值。
"""
from __future__ import annotations

import re
from decimal import Decimal

import table_extract as te

_NUM = re.compile(r"\(?-?\d[\d,]*(?:\.\d+)?\)?%?")
_STMT = re.compile(r"(合并及公司|合并|母公司)\s*(资产负债表|利润表|现金流量表)")
_SECTION = re.compile(r"第[一二三四五六七八九十]+节\s*[^\s，。；、：（(]{2,14}")
_NOTE_REF = re.compile(r"\s+\d{1,3}\s*$")
_UNIT = re.compile(r"单位\s*(?:均为|为)?\s*[：:]?\s*(?:人民币)?\s*"
                   r"(千元|万元|百万元|亿元|元)")
_UNIT_SCALE = {"元": Decimal(1), "千元": Decimal(1000), "万元": Decimal(10000),
               "百万元": Decimal(1000000), "亿元": Decimal(100000000)}


def _page_units(texts: list[str], marks: list[tuple[str | None, str | None]]) -> list[str]:
    """逐页维护报表金额单位。

    只认三表页上的单位，且取**第一个**匹配：报表首页的表头写「单位：千元」，
    同一页后半段的附注可能写「单位：万元」，取最后一个会把整张表放大 10 倍。
    续页没有单位时沿用上一页；非三表页（附注、管理层讨论）的单位不参与继承。
    """
    out = []
    cur = "元"
    for i, text in enumerate(texts):
        scope, kind = marks[i]
        if (scope and kind) or _is_main_page(text):
            unit, _, explicit = te.unit_from_text(text)
            if explicit:
                cur = unit
        out.append(cur)
    return out


def _page_statements(texts: list[str]) -> list[tuple[str | None, str | None]]:
    """逐页标出 (口径, 报表类型)；续页继承上一页。"""
    out: list[tuple[str | None, str | None]] = []
    scope = kind = None
    for text in texts:
        # 扫描整页，不只看页首：茅台的「合并资产负债表」标题落在第 56 页页尾，
        # 只看前 12 行会把后续两页的续页都判成「没有口径」。
        matches = list(_STMT.finditer(text))
        if matches:
            m = matches[-1]
            scope = m.group(1)
            kind = m.group(2)
        out.append((scope, kind))
    return out


def _values(line: str) -> tuple[str, list[Decimal]]:
    """拆出科目名与金额。附注号（1-3 位整数）和百分比不算金额。"""
    kept = []
    first = None
    for m in _NUM.finditer(line):
        raw = m.group(0)
        if raw.endswith("%"):
            continue
        clean = raw.replace(",", "").replace("(", "-").replace(")", "")
        try:
            val = Decimal(clean)
        except Exception:  # noqa: BLE001
            continue
        # 纯整数且小于 1000 的，是附注索引，不是金额
        if "," not in raw and "." not in raw and abs(val) < 1000:
            continue
        if first is None:
            first = m.start()
        kept.append(val)
    if first is None or not kept:
        return "", []
    label = line[:first].strip()
    label = _NOTE_REF.sub("", label).strip()
    return label, kept[:4]


_SCOPE_WORDS = ("合并", "公司", "母公司", "本集团")
_MAIN_HEADS = ("主要会计数据和财务指标", "主要会计数据")
# 先按关键词筛行，避免对每一行都跑 34 个指标 × 4 个标签变体。
# 一份 200 页年报有几万行，不做这层过滤会把单次抽取拖到几分钟。
_KEYWORDS = (
    "收入", "成本", "利润", "费用", "资产", "负债", "权益", "股东", "存货",
    "应收", "应付", "现金", "货币", "借款", "债券", "折旧", "摊销", "所得税",
    "资本", "销售商品", "研发", "商誉", "所有者", "少数股东", "支出", "开发",
    "损益", "扣非",
)


def _is_main_page(text: str) -> bool:
    # 主要会计数据表不一定在页首：三一第 6 页前 20 行是公司地址和股票信息，
    # 表格标题在页面中后段。整页找标题，避免漏掉三年主表。
    return any(h in text for h in _MAIN_HEADS)


def _label_variants(label: str, lines: list[str], j: int) -> list[str]:
    """科目名被拆成上下几行时，拼回可能的完整名字。

    例：五粮液的「归属于上市公司股东的 / 扣除非经常性损益的净 8,815,… / 利润（元）」，
    中间一行带数字，前后各是半个科目名。
    """
    def fragment(s: str) -> bool:
        return bool(s) and len(s) <= 14 and re.fullmatch(r"[一-龥、（）()]+", s) is not None

    out = [label]
    prev = lines[j - 1] if j > 0 else ""
    nxt = lines[j + 1] if j + 1 < len(lines) else ""
    if fragment(prev):
        out.append(prev + label)
    if fragment(nxt):
        out.append(label + nxt)
    if fragment(prev) and fragment(nxt):
        out.append(prev + label + nxt)
    return out


def _scope_order(text: str) -> list[str]:
    """「合并及公司」四栏表的列口径顺序，例如 ['合并','合并','公司','公司']。"""
    for line in text.split("\n"):
        toks = [t for t in re.split(r"\s+", te.normalize(line).strip()) if t]
        scopes = [t for t in toks if t in _SCOPE_WORDS]
        if len(scopes) >= 2:
            return scopes
    return []


def candidates(texts: list[str], sections: list[str], pm_pages: dict,
               metrics: dict, year: int, src_statement: int) -> dict[str, list[dict]]:
    marks = _page_statements(texts)
    units = _page_units(texts, marks)
    out: dict[str, list[dict]] = {k: [] for k in metrics}
    for i, text in enumerate(texts):
        scope, kind = marks[i]
        is_main = _is_main_page(text)
        if not is_main and (scope not in ("合并", "合并及公司")
                            or kind not in ("资产负债表", "利润表", "现金流量表")):
            continue
        if is_main:
            scope = "合并"
        lines = [te.normalize(x).strip() for x in text.split("\n")]
        for j, line in enumerate(lines):
            if not line or len(line) > 120:
                continue
            if not any(k in line for k in _KEYWORDS):
                continue
            label, vals = _values(line)
            # 科目名和数字被排到两行：年报里「销售商品、提供劳务收到的现金」
            # 单独一行，金额在下一行。把下一行的纯数字接过来。
            if (not label or not vals) and j + 1 < len(lines):
                nxt = lines[j + 1]
                if nxt and not re.search(r"[一-龥]", nxt):
                    _, nvals = _values(nxt)
                    if nvals:
                        label = _NOTE_REF.sub("", line).strip()
                        # 科目名最后一个字可能被挤到数字行之后：
                        # 「…收到的现」/ 183,990,… / 「金」。把尾部短片段接回来。
                        k = j + 2
                        while k < len(lines) and 0 < len(lines[k]) <= 4 \
                                and re.fullmatch(r"[一-龥、（）()]+", lines[k]):
                            label += lines[k]
                            k += 1
                        vals = nvals
            if not label or not vals:
                continue
            third_year = None
            if scope == "合并及公司":
                order = _scope_order(text)
                idx = [k for k, s in enumerate(order) if s in ("合并", "本集团")]
                if not idx:
                    continue
                vals = [vals[k] for k in idx if k < len(vals)]
            elif is_main:
                # 主要会计数据表常见列序：2025 / 2024 / 2023 / 本年比上年增减。
                # 增减列有时带 %（会被 _values 跳过），有时是 34.84 这种小数。
                # 值个数为 4 时，若第 4 个像百分比（<1000 且有小数），
                # 第 3 个是 2023；否则第 4 个是 2023。
                if len(vals) >= 4:
                    fourth = vals[3]
                    if abs(fourth) < 1000 and fourth != int(fourth):
                        third_year = vals[2]
                    else:
                        third_year = fourth
                elif len(vals) == 3 and str(year - 2) in text:
                    third_year = vals[2]
                vals = vals[:2]
            else:
                vals = vals[:2]
            if not vals:
                continue
            variants = _label_variants(label, lines, j)
            for key, spec in metrics.items():
                score, matched = 0.0, label
                for v in variants:
                    sc = _match(v, spec)
                    if sc > score:
                        score, matched = sc, v
                if score <= 0:
                    continue
                values = {str(year): vals[0]}
                kinds = {str(year): "amount"}
                if len(vals) > 1:
                    values[str(year - 1)] = vals[1]
                    kinds[str(year - 1)] = "amount"
                if third_year is not None:
                    values[str(year - 2)] = third_year
                    kinds[str(year - 2)] = "amount"
                printed = (pm_pages.get(i + 1) or {}).get("printed_page")
                out[key].append({
                    "pdf_page": i + 1, "printed_page": printed,
                    "section": sections[i],
                    "source_kind": "主要会计数据" if is_main else f"合并{kind}",
                    "priority": src_statement, "score": score,
                    "label_raw": matched, "core": matched, "unit_raw": units[i],
                    "scale": _UNIT_SCALE.get(units[i], Decimal(1)),
                    "values": values, "kinds": kinds,
                    "scopes": {str(year): "合并"},
                    "top": 0.0, "raw_text": line,
                })
    return out


def _match(label: str, spec: dict) -> float:
    """与 indicators.match_label 同一套规则，但在这里避免循环导入。"""
    import indicators
    return indicators.match_label(label, spec)
