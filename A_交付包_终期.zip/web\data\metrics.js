window.FINSCOPE_METRICS = {
 "600309": {
  "company": {
   "name": "万华化学集团股份有限公司",
   "ticker": "600309",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "万华化学集团股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 203234573814.42,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入",
    "unit_raw": "元",
    "raw_text": "营业收入 203,234,573,814.42 182,069,119,160.94 11.62 175,360,935,668.36",
    "series": {
     "2025": 203234573814.42,
     "2024": 182069119160.94,
     "2023": 175360935668.36
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 175569584829.32,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "营业成本",
    "unit_raw": "元",
    "raw_text": "营业成本 175,569,584,829.32 152,642,583,643.90 15.02",
    "series": {
     "2025": 175569584829.32,
     "2024": 152642583643.9
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 14039935975.43,
    "unit": "元",
    "page": 84,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "五、净利润(净亏损以“-”号",
    "series": {
     "2025": 14039935975.43,
     "2024": 14791313747.02
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 12527201094.15,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净利润 12,527,201,094.15 13,033,066,612.84 -3.88 16,815,755,534.31",
    "series": {
     "2025": 12527201094.15,
     "2024": 13033066612.84,
     "2023": 16815755534.31
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 3204044734.83,
    "unit": "元",
    "page": 8,
    "pdf_page": 8,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益后的净利润",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益后的净利润 3,040,424,946.53 3,204,044,734.83 2,856,277,954.14 3,042,928,129.50",
    "series": {
     "2025": 3204044734.83,
     "2024": 2856277954.14,
     "2023": 3042928129.5
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 323009018441.98,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "总资产",
    "unit_raw": "元",
    "raw_text": "总资产 323,009,018,441.98 293,333,349,744.25 10.12 253,040,390,845.31",
    "series": {
     "2025": 323009018441.98,
     "2024": 293333349744.25,
     "2023": 253040390845.31
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 202880274334.07,
    "unit": "元",
    "page": 80,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 202,880,274,334.07 189,833,199,877.59",
    "series": {
     "2025": 202880274334.07,
     "2024": 189833199877.59
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 108305459478.31,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产 108,305,459,478.31 94,625,896,066.69 14.46 88,656,204,854.29",
    "series": {
     "2025": 108305459478.31,
     "2024": 94625896066.69,
     "2023": 88656204854.29
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 27662042570.54,
    "unit": "元",
    "page": 79,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 27,662,042,570.54 24,533,221,345.80",
    "series": {
     "2025": 27662042570.54,
     "2024": 24533221345.8
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 15872973091.27,
    "unit": "元",
    "page": 79,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 15,872,973,091.27 12,318,995,367.05",
    "series": {
     "2025": 15872973091.27,
     "2024": 12318995367.05
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 26014205386.5,
    "unit": "元",
    "page": 79,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 26,014,205,386.50 24,107,312,714.47",
    "series": {
     "2025": 26014205386.5,
     "2024": 24107312714.47
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 2293156182.4,
    "unit": "元",
    "page": 80,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 2,293,156,182.40 2,196,124,305.24",
    "series": {
     "2025": 2293156182.4,
     "2024": 2196124305.24
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 33105189455.82,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金",
    "series": {
     "2025": 33105189455.82,
     "2024": 30053435178.33,
     "2023": 16083614784.13
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -32782705274.57,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -32,782,705,274.57 -37,077,680,248.74 11.58",
    "series": {
     "2025": -32782705274.57,
     "2024": -37077680248.74
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": 2143880788.98,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 2,143,880,788.98 6,186,159,622.30 -65.34",
    "series": {
     "2025": 2143880788.98,
     "2024": 6186159622.3
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 4865228956.11,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 4,865,228,956.11 4,550,357,851.17 6.92",
    "series": {
     "2025": 4865228956.11,
     "2024": 4550357851.17
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 30711201211.89,
    "unit": "元",
    "page": 88,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 30,711,201,211.89 35,830,124,773.82",
    "series": {
     "2025": 30711201211.89,
     "2024": 35830124773.82
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 16666043830.84,
    "unit": "元",
    "page": 84,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号",
    "series": {
     "2025": 16666043830.84,
     "2024": 17965674752
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 16268157181.59,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 16,268,157,181.59 16,924,136,091.56 -3.88 20,009,871,906.36",
    "series": {
     "2025": 16268157181.59,
     "2024": 16924136091.56,
     "2023": 20009871906.36
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 2228221206.16,
    "unit": "元",
    "page": 175,
    "pdf_page": 175,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "元",
    "raw_text": "所得税费用 2,228,221,206.16",
    "series": {
     "2025": 2228221206.16,
     "2024": 2132822344.54
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 1630471458.75,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 1,630,471,458.75 1,618,933,244.35 0.71",
    "series": {
     "2025": 1630471458.75,
     "2024": 1618933244.35
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 2801987383.62,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 2,801,987,383.62 3,022,773,237.84 -7.30",
    "series": {
     "2025": 2801987383.62,
     "2024": 3022773237.84
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 3024453322.24,
    "unit": "元",
    "page": 177,
    "pdf_page": 177,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用(收益以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "财务费用(收益以“-”号填列) 3,024,453,322.24 2,883,633,636.74",
    "series": {
     "2025": 3024453322.24,
     "2024": 2883633636.74
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 2935698983.54,
    "unit": "元",
    "page": 83,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 2,935,698,983.54 2,817,045,032.13",
    "series": {
     "2025": 2935698983.54,
     "2024": 2817045032.13
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 14579833984.34,
    "unit": "元",
    "page": 177,
    "pdf_page": 177,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧",
    "unit_raw": "元",
    "raw_text": "固定资产折旧 14,579,833,984.34 11,284,807,204.15",
    "series": {
     "2025": 14579833984.34,
     "2024": 11284807204.15
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 81636785654.2,
    "unit": "元",
    "page": 79,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 81,636,785,654.20 69,990,431,437.26",
    "series": {
     "2025": 81636785654.2,
     "2024": 69990431437.26
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 24547758029.7,
    "unit": "元",
    "page": 200,
    "pdf_page": 200,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 24,547,758,029.70 24,547,758,029.70",
    "series": {
     "2025": 24547758029.7,
     "2024": 24547758029.7
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 132518810250.62,
    "unit": "元",
    "page": 80,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 132,518,810,250.62 126,082,780,126.36",
    "series": {
     "2025": 132518810250.62,
     "2024": 126082780126.36
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 35557147552.13,
    "unit": "元",
    "page": 176,
    "pdf_page": 176,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "元",
    "raw_text": "短期借款 35,557,147,552.13 66,435,009,136.28 1,102,197,781.44 75,305,651,548.86 27,788,702,920.99",
    "series": {
     "2025": 35557147552.13,
     "2024": 66435009136.28
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 1681627650156000000,
    "unit": "元",
    "page": 24,
    "pdf_page": 24,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "亿元",
    "raw_text": "一年内到期的非流动负债 16,816,276,501.56 5.21 11,181,705,458.41 3.81 50.39 主要为部分长期借款转入一年",
    "series": {
     "2025": 1681627650156000000,
     "2024": 381000000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 16013476130.2,
    "unit": "元",
    "page": 200,
    "pdf_page": 200,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "元",
    "raw_text": "长期借款 16,013,476,130.20 13,980,549,843.74 11,239,127,257.91 21,968,074,065.46 63,201,227,297.31",
    "series": {
     "2025": 16013476130.2,
     "2024": 13980549843.74
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": 7575215534.24,
    "unit": "元",
    "page": 161,
    "pdf_page": 161,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付债券",
    "unit_raw": "元",
    "raw_text": "应付债券 7,575,215,534.24 3,429,024,657.53",
    "series": {
     "2025": 7575215534.24,
     "2024": 3429024657.53
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 120128744107.90997,
    "unit": "元",
    "page": 83,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益(或股东权益)合计",
    "unit_raw": "元",
    "raw_text": "按资产总计 - 负债合计倒算：323009018441.98 - 202880274334.07 = 120128744107.91",
    "series": {
     "2025": 120128744107.90997,
     "2024": 66592261094.13
    },
    "confidence": 0.7,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 208681033248.19,
    "unit": "元",
    "page": 87,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 208,681,033,248.19 213,272,888,219.39",
    "series": {
     "2025": 208681033248.19,
     "2024": 213272888219.39
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "万华化学_600309_2025.pdf",
   "pdf_pages": 229,
   "pagemap": {
    "coverage": 1.0,
    "n_detected": 229,
    "n_inferred": 0,
    "n_missing": 0,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "600031": {
  "company": {
   "name": "三一重工股份有限公司",
   "ticker": "600031",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "三一重工股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 89699505000,
    "unit": "元",
    "page": 89,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一、营业总收入",
    "unit_raw": "千元",
    "raw_text": "一、营业总收入 89,699,505 78,383,379",
    "series": {
     "2025": 89699505000,
     "2024": 78383379000,
     "2023": 77773391000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 64660293000,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "营业成本",
    "unit_raw": "千元",
    "raw_text": "营业成本 64,660,293 57,216,959 13.01",
    "series": {
     "2025": 64660293000,
     "2024": 57216959000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 8487650000,
    "unit": "元",
    "page": 90,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "千元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 8,487,650 6,092,538",
    "series": {
     "2025": 8487650000,
     "2024": 6092538000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 8408057000,
    "unit": "元",
    "page": 90,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "1.归属于母公司股东的净利润(净亏损以“-”号填列)",
    "unit_raw": "千元",
    "raw_text": "1.归属于母公司股东的净利润(净亏损以“-”号填列) 8,408,057 5,955,567",
    "series": {
     "2025": 8408057000,
     "2024": 5955567000,
     "2023": 5975451000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 8221213000,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润 8,221,213 5,333,989 5,333,989 54.13 4,388,393",
    "series": {
     "2025": 8221213000,
     "2023": 5333989000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 173299138000,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "千元",
    "raw_text": "资产总计 173,299,138 152,145,077",
    "series": {
     "2025": 173299138000,
     "2024": 152145077000,
     "2023": 152145076000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 22876303000,
    "unit": "元",
    "page": 89,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "千元",
    "raw_text": "负债合计 22,876,303 24,654,527",
    "series": {
     "2025": 22876303000,
     "2024": 24654527000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 88331244000,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的净资产 88,331,244 71,923,866 71,953,244 22.81 68,029,017",
    "series": {
     "2025": 88331244000,
     "2023": 71953244000,
     "2024": 71923866000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 38451241000,
    "unit": "元",
    "page": 85,
    "pdf_page": 85,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "千元",
    "raw_text": "货币资金 38,451,241 20,383,176",
    "series": {
     "2025": 38451241000,
     "2024": 20383176000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 25540365000,
    "unit": "元",
    "page": 85,
    "pdf_page": 85,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "千元",
    "raw_text": "应收账款 25,540,365 25,516,530",
    "series": {
     "2025": 25540365000,
     "2024": 25516530000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 22526664000,
    "unit": "元",
    "page": 85,
    "pdf_page": 85,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "千元",
    "raw_text": "存货 22,526,664 19,947,981",
    "series": {
     "2025": 22526664000,
     "2024": 19947981000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 40771000,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "千元",
    "raw_text": "商誉 40,771 48,010",
    "series": {
     "2025": 40771000,
     "2024": 48010000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 19975261000,
    "unit": "元",
    "page": 92,
    "pdf_page": 92,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "经营活动产生的现金流量净额 19,975,261 14,814,278",
    "series": {
     "2025": 19975261000,
     "2024": 14814278000,
     "2023": 14814278000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -17909299000,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "投资活动产生的现金流量净额 -17,909,299 -1,157,848 -1,446.77",
    "series": {
     "2025": -17909299000,
     "2024": -1157848000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": 1575997000,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "筹资活动产生的现金流量净额 1,575,997 -10,279,150 115.33",
    "series": {
     "2025": 1575997000,
     "2024": -10279150000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 209076000,
    "unit": "元",
    "page": 91,
    "pdf_page": 91,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "千元",
    "raw_text": "研发费用 209,076 256,434",
    "series": {
     "2025": 209076000,
     "2024": 256434000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 2771319000,
    "unit": "元",
    "page": 93,
    "pdf_page": 93,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "千元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 2,771,319 2,938,287",
    "series": {
     "2025": 2771319000,
     "2024": 2938287000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 9935668000,
    "unit": "元",
    "page": 90,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "千元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 9,935,668 6,994,764",
    "series": {
     "2025": 9935668000,
     "2024": 6994764000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 9907171000,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "千元",
    "raw_text": "利润总额 9,907,171 6,907,770 6,907,770 43.42 5,316,554",
    "series": {
     "2025": 9907171000,
     "2023": 6907770000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 1419521000,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "千元",
    "raw_text": "所得税费用 1,419,521 815,232 74.12",
    "series": {
     "2025": 1419521000,
     "2024": 815232000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 126928000,
    "unit": "元",
    "page": 91,
    "pdf_page": 91,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "千元",
    "raw_text": "销售费用 126,928 80,273",
    "series": {
     "2025": 126928000,
     "2024": 80273000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 468224000,
    "unit": "元",
    "page": 91,
    "pdf_page": 91,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "千元",
    "raw_text": "管理费用 468,224 521,937",
    "series": {
     "2025": 468224000,
     "2024": 521937000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 312183000,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "千元",
    "raw_text": "财务费用 -312,183 201,776 -254.72",
    "series": {
     "2025": 312183000,
     "2024": 201776000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 568877000,
    "unit": "元",
    "page": 90,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "千元",
    "raw_text": "其中:利息费用 568,877 845,080",
    "series": {
     "2025": 568877000,
     "2024": 845080000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 11789000,
    "unit": "元",
    "page": 155,
    "pdf_page": 155,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧",
    "unit_raw": "千元",
    "raw_text": "固定资产折旧 11,789 2,963 31,828 8,232",
    "series": {
     "2025": 11789000,
     "2024": 2783826000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 124297751000,
    "unit": "元",
    "page": 85,
    "pdf_page": 85,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "千元",
    "raw_text": "流动资产合计 124,297,751 101,505,320",
    "series": {
     "2025": 124297751000,
     "2024": 101505320000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 27247771000,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "千元",
    "raw_text": "应付账款 27,247,771 21,264,967",
    "series": {
     "2025": 27247771000,
     "2024": 21264967000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 71856386000,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "千元",
    "raw_text": "流动负债合计 71,856,386 63,669,229",
    "series": {
     "2025": 71856386000,
     "2024": 63669229000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 5270,
    "unit": "元",
    "page": 21,
    "pdf_page": 21,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "千元",
    "raw_text": "短期借款 9,128,447 5.27 5,953,356 3.91 53.33 主要系本期新增借款影响。",
    "series": {
     "2025": 5270,
     "2024": 5953356000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 3323028000,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "千元",
    "raw_text": "一年内到期的非流动负债 3,323,028 3,956,407",
    "series": {
     "2025": 3323028000,
     "2024": 3956407000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 4530,
    "unit": "元",
    "page": 21,
    "pdf_page": 21,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "千元",
    "raw_text": "长期借款 7,853,367 4.53 11,556,182 7.60 -32.04 主要系本期偿还借款影响。",
    "series": {
     "2025": 4530,
     "2024": 11556182000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": 86,
    "pdf_page": 86,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "应付债券",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 150422835000,
    "unit": "元",
    "page": 89,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益(或股东权益)合计",
    "unit_raw": "千元",
    "raw_text": "按资产总计 - 负债合计倒算：173299138000.00 - 22876303000.00 = 150422835000.00",
    "series": {
     "2025": 150422835000,
     "2024": 22708356000
    },
    "confidence": 0.7,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 94730210000,
    "unit": "元",
    "page": 92,
    "pdf_page": 92,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "千元",
    "raw_text": "销售商品、提供劳务收到的现金 94,730,210 82,694,250",
    "series": {
     "2025": 94730210000,
     "2024": 82694250000
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "三一重工_600031_2025.pdf",
   "pdf_pages": 250,
   "pagemap": {
    "coverage": 1.0,
    "n_detected": 250,
    "n_inferred": 0,
    "n_missing": 0,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "000858": {
  "company": {
   "name": "宜宾五粮液股份有限公司",
   "ticker": "000858",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "宜宾五粮液股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 40528509770.23,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入(元)",
    "unit_raw": "元",
    "raw_text": "营业收入(元) 40,528,509,770.23 89,175,178,322.70 -54.55% 83,272,067,317.19",
    "series": {
     "2025": 40528509770.23,
     "2024": 89175178322.7,
     "2023": 83272067317.19
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 9101956953.59,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "元",
    "raw_text": "其中:营业成本 9,101,956,953.59 20,461,423,083.74",
    "series": {
     "2025": 9101956953.59,
     "2024": 20461423083.74
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 9317113184.68,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "净利润",
    "unit_raw": "元",
    "raw_text": "净利润 9,317,113,184.68 33,193,460,484.32",
    "series": {
     "2025": 9317113184.68,
     "2024": 33193460484.32
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 8954257202.51,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净利润(元) 8,954,257,202.51 31,853,172,533.98 -71.89% 30,210,585,269.30",
    "series": {
     "2025": 8954257202.51,
     "2024": 31853172533.98,
     "2023": 30210585269.3
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 8815635943.27,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据",
    "status": "found",
    "reason": null,
    "alias_matched": "扣除非经常性损益的净利润(元)",
    "unit_raw": "元",
    "raw_text": "扣除非经常性损益的净 8,815,635,943.27 31,741,959,276.27 -72.23% 30,116,468,910.79",
    "series": {
     "2025": 8815635943.27,
     "2024": 31741959276.27
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 189984270815.47,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "总资产(元)",
    "unit_raw": "元",
    "raw_text": "总资产(元) 189,984,270,815.47 188,252,218,704.17 0.92% 165,432,981,684.75",
    "series": {
     "2025": 189984270815.47,
     "2024": 188252218704.17,
     "2023": 165432981684.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 58680033891.13,
    "unit": "元",
    "page": 122,
    "pdf_page": 122,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 58,680,033,891.13 56,997,555,119.78",
    "series": {
     "2025": 58680033891.13,
     "2024": 56997555119.78
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 119932271234.99,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产(元) 119,932,271,234.99 133,285,282,015.97 -10.02% 129,558,241,040.51",
    "series": {
     "2025": 119932271234.99,
     "2024": 133285282015.97,
     "2023": 129558241040.51
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 127398915484.11,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 127,398,915,484.11 127,398,915,484.11",
    "series": {
     "2025": 127398915484.11,
     "2024": 127398915484.11
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 37745419.51,
    "unit": "元",
    "page": 51,
    "pdf_page": 51,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 37,745,419.51 37,346,561.95",
    "series": {
     "2025": 37745419.51,
     "2024": 37346561.95
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 20065336751.2,
    "unit": "元",
    "page": 51,
    "pdf_page": 51,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 20,065,336,751.20 18,233,702,166.62",
    "series": {
     "2025": 20065336751.2,
     "2024": 18233702166.62
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 1621619.53,
    "unit": "元",
    "page": 52,
    "pdf_page": 52,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 1,621,619.53 1,621,619.53",
    "series": {
     "2025": 1621619.53,
     "2024": 1621619.53
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 29706259919.13,
    "unit": "元",
    "page": 7,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额(元)",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额(元) 29,706,259,919.13 33,939,755,192.78 -12.47% 41,742,479,908.23",
    "series": {
     "2025": 29706259919.13,
     "2024": 33939755192.78,
     "2023": 41742479908.23
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -1970567930.01,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -1,970,567,930.01 -2,642,221,739.05 不适用",
    "series": {
     "2025": -1970567930.01,
     "2024": -2642221739.05
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -28391572146.41,
    "unit": "元",
    "page": 17,
    "pdf_page": 17,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 -28,391,572,146.41 -19,622,477,387.77 不适用",
    "series": {
     "2025": -28391572146.41,
     "2024": -19622477387.77
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 449183817.5,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 449,183,817.50 405,053,632.27",
    "series": {
     "2025": 449183817.5,
     "2024": 405053632.27
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 1967407316.36,
    "unit": "元",
    "page": 60,
    "pdf_page": 60,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 1,967,407,316.36 2,666,310,780.23",
    "series": {
     "2025": 1967407316.36,
     "2024": 2666310780.23
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 12251151014.43,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 12,251,151,014.43 44,200,075,710.37",
    "series": {
     "2025": 12251151014.43,
     "2024": 44200075710.37
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 12198853038.23,
    "unit": "元",
    "page": 115,
    "pdf_page": 115,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 12,198,853,038.23",
    "series": {
     "2025": 12198853038.23
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 2881739853.55,
    "unit": "元",
    "page": 115,
    "pdf_page": 115,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "元",
    "raw_text": "所得税费用 2,881,739,853.55",
    "series": {
     "2025": 2881739853.55,
     "2024": 356556555.61
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 7628615140.51,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 7,628,615,140.51 10,692,376,117.41",
    "series": {
     "2025": 7628615140.51,
     "2024": 10692376117.41
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 3096502911.23,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 3,096,502,911.23 3,555,238,122.50",
    "series": {
     "2025": 3096502911.23,
     "2024": 3555238122.5
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 2661630589.09,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 -2,661,630,589.09 -2,833,530,840.46",
    "series": {
     "2025": 2661630589.09,
     "2024": 2833530840.46
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 28573949.37,
    "unit": "元",
    "page": 56,
    "pdf_page": 56,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 28,573,949.37 40,436,892.68",
    "series": {
     "2025": 28573949.37,
     "2024": 40436892.68
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 592664029.5,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    "unit_raw": "元",
    "raw_text": "固定资产折旧、油气资产折耗、生产性生物资产",
    "series": {
     "2025": 592664029.5,
     "2024": 563298283.79
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 164751563109.67,
    "unit": "元",
    "page": 51,
    "pdf_page": 51,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 164,751,563,109.67 165,783,297,845.86",
    "series": {
     "2025": 164751563109.67,
     "2024": 165783297845.86
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 8534820869.28,
    "unit": "元",
    "page": 52,
    "pdf_page": 52,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 8,534,820,869.28 9,076,595,227.75",
    "series": {
     "2025": 8534820869.28,
     "2024": 9076595227.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 67351815353.24,
    "unit": "元",
    "page": 52,
    "pdf_page": 52,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 67,351,815,353.24 51,026,506,357.06",
    "series": {
     "2025": 67351815353.24,
     "2024": 51026506357.06
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": null,
    "unit": "元",
    "page": 52,
    "pdf_page": 52,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "短期借款",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 364149470.84,
    "unit": "元",
    "page": 52,
    "pdf_page": 52,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 364,149,470.84 408,675,726.69",
    "series": {
     "2025": 364149470.84,
     "2024": 408675726.69
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": null,
    "unit": "元",
    "page": 53,
    "pdf_page": 53,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "长期借款",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": 53,
    "pdf_page": 53,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "应付债券",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 131304236924.34,
    "unit": "元",
    "page": 55,
    "pdf_page": 55,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益合计",
    "unit_raw": "元",
    "raw_text": "按资产总计 - 负债合计倒算：189984270815.47 - 58680033891.13 = 131304236924.34",
    "series": {
     "2025": 131304236924.34,
     "2024": 75195213748.56
    },
    "confidence": 0.7,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 91400295974.06,
    "unit": "元",
    "page": 59,
    "pdf_page": 59,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 91,400,295,974.06 101,868,590,728.87",
    "series": {
     "2025": 91400295974.06,
     "2024": 101868590728.87
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "五粮液_000858_2025.pdf",
   "pdf_pages": 141,
   "pagemap": {
    "coverage": 0.986,
    "n_detected": 139,
    "n_inferred": 1,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "600887": {
  "company": {
   "name": "内蒙古伊利实业集团股份有限公司",
   "ticker": "600887",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "内蒙古伊利实业集团股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 115931105774.99,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一、营业总收入",
    "unit_raw": "元",
    "raw_text": "一、营业总收入 115,931,105,774.99 115,779,554,649.30",
    "series": {
     "2025": 115931105774.99,
     "2024": 115779554649.3,
     "2023": 25295683131.86
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 75653843800.99,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "元",
    "raw_text": "其中:营业成本 75,653,843,800.99 76,298,833,033.93",
    "series": {
     "2025": 75653843800.99,
     "2024": 76298833033.93
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 11513910754,
    "unit": "元",
    "page": 83,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 11,513,910,754.00 8,463,710,355.65",
    "series": {
     "2025": 11513910754,
     "2024": 8463710355.65
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 11565166497.81,
    "unit": "元",
    "page": 83,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "1.归属于母公司股东的净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "1.归属于母公司股东的净利润(净亏损以“-”号填列) 11,565,166,497.81 8,452,859,993.18",
    "series": {
     "2025": 11565166497.81,
     "2024": 8452859993.18,
     "2023": 1139063880.77
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 4629303049.44,
    "unit": "元",
    "page": 4,
    "pdf_page": 8,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益后的净利润",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益后的净利润 4,629,303,049.44 2,387,046,453.43 3,086,431,987.78 965,540,204.47",
    "series": {
     "2025": 4629303049.44,
     "2024": 3086431987.78,
     "2023": 965540204.47
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 152098516632.34,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "元",
    "raw_text": "资产总计 152,098,516,632.34 153,718,003,927.97",
    "series": {
     "2025": 152098516632.34,
     "2024": 153718003927.97
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 93554239954.18,
    "unit": "元",
    "page": 79,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 93,554,239,954.18 96,710,353,251.06",
    "series": {
     "2025": 93554239954.18,
     "2024": 96710353251.06
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 54655690475.89,
    "unit": "元",
    "page": 79,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于母公司所有者权益(或股东权益)合计",
    "unit_raw": "元",
    "raw_text": "归属于母公司所有者权益(或股东权益)合计 54,655,690,475.89 53,179,935,140.80",
    "series": {
     "2025": 54655690475.89,
     "2024": 53179935140.8
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 19494920358,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 19,494,920,358.00 25,404,255,558.60",
    "series": {
     "2025": 19494920358,
     "2024": 25404255558.6
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 2987426531.59,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 2,987,426,531.59 2,878,402,047.44",
    "series": {
     "2025": 2987426531.59,
     "2024": 2878402047.44
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 10823125184.53,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 10,823,125,184.53 10,744,674,420.37",
    "series": {
     "2025": 10823125184.53,
     "2024": 10744674420.37
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 2181530707.86,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 2,181,530,707.86 2,336,555,144.44",
    "series": {
     "2025": 2181530707.86,
     "2024": 2336555144.44
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 14343920490.32,
    "unit": "元",
    "page": 85,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额 14,343,920,490.32 21,739,740,393.38",
    "series": {
     "2025": 14343920490.32,
     "2024": 21739740393.38,
     "2023": 4944057147.7
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -7796324355.55,
    "unit": "元",
    "page": 86,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -7,796,324,355.55 -32,709,427,280.73",
    "series": {
     "2025": -7796324355.55,
     "2024": -32709427280.73
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -13472893729.48,
    "unit": "元",
    "page": 86,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 -13,472,893,729.48 -7,277,915,908.33",
    "series": {
     "2025": -13472893729.48,
     "2024": -7277915908.33
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 915007208.81,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 915,007,208.81 869,976,531.80",
    "series": {
     "2025": 915007208.81,
     "2024": 869976531.8
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 3036644156.68,
    "unit": "元",
    "page": 86,
    "pdf_page": 90,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 3,036,644,156.68 3,978,318,320.96",
    "series": {
     "2025": 3036644156.68,
     "2024": 3978318320.96
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 13527806620.67,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 13,527,806,620.67 10,181,768,860.25",
    "series": {
     "2025": 13527806620.67,
     "2024": 10181768860.25
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 12993830374.42,
    "unit": "元",
    "page": 202,
    "pdf_page": 206,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 12,993,830,374.42",
    "series": {
     "2025": 12993830374.42
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 1479919620.42,
    "unit": "元",
    "page": 202,
    "pdf_page": 206,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "元",
    "raw_text": "所得税费用 1,479,919,620.42",
    "series": {
     "2025": 1479919620.42,
     "2024": 1663018637.87
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 21544580668.38,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 21,544,580,668.38 21,982,305,923.27",
    "series": {
     "2025": 21544580668.38,
     "2024": 21982305923.27
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 4695602170.41,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 4,695,602,170.41 4,465,110,012.57",
    "series": {
     "2025": 4695602170.41,
     "2024": 4465110012.57
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 690854042.99,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 -690,854,042.99 -591,649,416.42",
    "series": {
     "2025": 690854042.99,
     "2024": 591649416.42
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 1366436483.7,
    "unit": "元",
    "page": 82,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 1,366,436,483.70 1,819,520,437.71",
    "series": {
     "2025": 1366436483.7,
     "2024": 1819520437.71
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 4069342677.34,
    "unit": "元",
    "page": 206,
    "pdf_page": 210,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    "unit_raw": "元",
    "raw_text": "固定资产折旧、油气资产折耗、生产性生物资产折旧 4,069,342,677.34 4,055,643,135.37",
    "series": {
     "2025": 4069342677.34,
     "2024": 4055643135.37
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 66369720588.56,
    "unit": "元",
    "page": 78,
    "pdf_page": 82,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 66,369,720,588.56 66,619,381,426.38",
    "series": {
     "2025": 66369720588.56,
     "2024": 66619381426.38
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 11479437770.67,
    "unit": "元",
    "page": 225,
    "pdf_page": 229,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 11,479,437,770.67 11,479,437,770.67",
    "series": {
     "2025": 11479437770.67,
     "2024": 11479437770.67
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 91053004170.21,
    "unit": "元",
    "page": 79,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 91,053,004,170.21 89,924,532,161.51",
    "series": {
     "2025": 91053004170.21,
     "2024": 89924532161.51
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 36354630548.02,
    "unit": "元",
    "page": 206,
    "pdf_page": 210,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "元",
    "raw_text": "短期借款 36,354,630,548.02 111,233,343,047.73 855,639,588.55 102,812,987,156.47 45,630,626,027.83",
    "series": {
     "2025": 36354630548.02,
     "2024": 111233343047.73
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 4441660422.46,
    "unit": "元",
    "page": 225,
    "pdf_page": 229,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 4,441,660,422.46 4,441,660,422.46",
    "series": {
     "2025": 4441660422.46,
     "2024": 4441660422.46
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 524639332.68,
    "unit": "元",
    "page": 226,
    "pdf_page": 230,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "元",
    "raw_text": "长期借款 524,639,332.68 487,763,157.12 36,876,175.56",
    "series": {
     "2025": 524639332.68,
     "2024": 487763157.12
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": 79,
    "pdf_page": 83,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "应付债券",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 58544276678.16,
    "unit": "元",
    "page": 79,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益(或股东权益)合计",
    "unit_raw": "元",
    "raw_text": "所有者权益(或股东权益)合计 58,544,276,678.16 57,007,650,676.91",
    "series": {
     "2025": 58544276678.16,
     "2024": 57007650676.91
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 125775963273.89,
    "unit": "元",
    "page": 85,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 125,775,963,273.89 130,651,821,490.28",
    "series": {
     "2025": 125775963273.89,
     "2024": 130651821490.28
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "伊利股份_600887_2025.pdf",
   "pdf_pages": 259,
   "pagemap": {
    "coverage": 0.985,
    "n_detected": 255,
    "n_inferred": 0,
    "n_missing": 4,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     -4
    ]
   }
  }
 },
 "300750": {
  "company": {
   "name": "宁德时代新能源科技股份有限公司",
   "ticker": "300750",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "宁德时代新能源科技股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 423701834000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入",
    "unit_raw": "千元",
    "raw_text": "营业收入 423,701,834 362,012,554 17.04% 400,917,045",
    "series": {
     "2025": 423701834000,
     "2024": 362012554000,
     "2023": 400917045000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 312383297000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "千元",
    "raw_text": "其中:营业成本 312,383,297 273,518,959",
    "series": {
     "2025": 312383297000,
     "2024": 273518959000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 76786309000,
    "unit": "元",
    "page": 117,
    "pdf_page": 117,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "千元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 76,786,309 54,006,794",
    "series": {
     "2025": 76786309000,
     "2024": 54006794000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 72201282000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的净利润 72,201,282 50,744,682 42.28% 44,121,248",
    "series": {
     "2025": 72201282000,
     "2024": 50744682000,
     "2023": 44121248000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 64507864000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润 64,507,864 44,992,919 43.37% 40,091,674",
    "series": {
     "2025": 64507864000,
     "2024": 44992919000,
     "2023": 40091674000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 974827544000,
    "unit": "元",
    "page": 112,
    "pdf_page": 112,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "千元",
    "raw_text": "资产总计 974,827,544 786,658,123",
    "series": {
     "2025": 974827544000,
     "2024": 786658123000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 603801220000,
    "unit": "元",
    "page": 113,
    "pdf_page": 113,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "千元",
    "raw_text": "负债合计 603,801,220 513,201,949",
    "series": {
     "2025": 603801220000,
     "2024": 513201949000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 337107747000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的净资产 337,107,747 246,930,033 36.52% 197,708,052",
    "series": {
     "2025": 337107747000,
     "2024": 246930033000,
     "2023": 197708052000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 333512927000,
    "unit": "元",
    "page": 111,
    "pdf_page": 111,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "千元",
    "raw_text": "货币资金 333,512,927 303,511,993",
    "series": {
     "2025": 333512927000,
     "2024": 303511993000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 76403264000,
    "unit": "元",
    "page": 111,
    "pdf_page": 111,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "千元",
    "raw_text": "应收账款 76,403,264 64,135,510",
    "series": {
     "2025": 76403264000,
     "2024": 64135510000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 94526239000,
    "unit": "元",
    "page": 111,
    "pdf_page": 111,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "千元",
    "raw_text": "存货 94,526,239 59,835,533",
    "series": {
     "2025": 94526239000,
     "2024": 59835533000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 837328000,
    "unit": "元",
    "page": 112,
    "pdf_page": 112,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "千元",
    "raw_text": "商誉 837,328 894,757",
    "series": {
     "2025": 837328000,
     "2024": 894757000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 133219982000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "经营活动产生的现金流量净额 133,219,982 96,990,345 37.35% 92,826,124",
    "series": {
     "2025": 133219982000,
     "2024": 96990345000,
     "2023": 92826124000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -94475790000,
    "unit": "元",
    "page": 120,
    "pdf_page": 120,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "投资活动产生的现金流量净额 -94,475,790 -48,875,311",
    "series": {
     "2025": -94475790000,
     "2024": -48875311000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -6309543000,
    "unit": "元",
    "page": 121,
    "pdf_page": 121,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "筹资活动产生的现金流量净额 -6,309,543 -14,524,236",
    "series": {
     "2025": -6309543000,
     "2024": -14524236000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 22146581000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "千元",
    "raw_text": "研发费用 22,146,581 18,606,756",
    "series": {
     "2025": 22146581000,
     "2024": 18606756000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 42344558000,
    "unit": "元",
    "page": 120,
    "pdf_page": 120,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "千元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 42,344,558 31,179,943",
    "series": {
     "2025": 42344558000,
     "2024": 31179943000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 89518636000,
    "unit": "元",
    "page": 117,
    "pdf_page": 117,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "千元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 89,518,636 64,051,799",
    "series": {
     "2025": 89518636000,
     "2024": 64051799000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 89526545000,
    "unit": "元",
    "page": 198,
    "pdf_page": 198,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "千元",
    "raw_text": "利润总额 89,526,545",
    "series": {
     "2025": 89526545000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 12740236000,
    "unit": "元",
    "page": 117,
    "pdf_page": 117,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:所得税费用",
    "unit_raw": "千元",
    "raw_text": "减:所得税费用 12,740,236 9,175,245",
    "series": {
     "2025": 12740236000,
     "2024": 9175245000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 3735118000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "千元",
    "raw_text": "销售费用 3,735,118 3,562,797",
    "series": {
     "2025": 3735118000,
     "2024": 3562797000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 11666741000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "千元",
    "raw_text": "管理费用 11,666,741 9,689,839",
    "series": {
     "2025": 11666741000,
     "2024": 9689839000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 7939863000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "千元",
    "raw_text": "财务费用 -7,939,863 -4,131,918",
    "series": {
     "2025": 7939863000,
     "2024": 4131918000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 2734017000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "千元",
    "raw_text": "其中:利息费用 2,734,017 3,879,076",
    "series": {
     "2025": 2734017000,
     "2024": 3879076000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 24322780000,
    "unit": "元",
    "page": 201,
    "pdf_page": 201,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    "unit_raw": "千元",
    "raw_text": "固定资产折旧、油气资产折耗、生产性生物资产折旧 24,322,780 22,437,872",
    "series": {
     "2025": 24322780000,
     "2024": 22437872000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 638481543000,
    "unit": "元",
    "page": 111,
    "pdf_page": 111,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "千元",
    "raw_text": "流动资产合计 638,481,543 510,142,089",
    "series": {
     "2025": 638481543000,
     "2024": 510142089000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 160328962000,
    "unit": "元",
    "page": 112,
    "pdf_page": 112,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "千元",
    "raw_text": "应付账款 160,328,962 130,977,408",
    "series": {
     "2025": 160328962000,
     "2024": 130977408000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 399625988000,
    "unit": "元",
    "page": 113,
    "pdf_page": 113,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "千元",
    "raw_text": "流动负债合计 399,625,988 317,171,534",
    "series": {
     "2025": 399625988000,
     "2024": 317171534000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 12935498000,
    "unit": "元",
    "page": 112,
    "pdf_page": 112,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "千元",
    "raw_text": "短期借款 12,935,498 19,696,282",
    "series": {
     "2025": 12935498000,
     "2024": 19696282000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 22237540000,
    "unit": "元",
    "page": 112,
    "pdf_page": 112,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "千元",
    "raw_text": "一年内到期的非流动负债 22,237,540 22,881,417",
    "series": {
     "2025": 22237540000,
     "2024": 22881417000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 15076474000,
    "unit": "元",
    "page": 210,
    "pdf_page": 210,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "千元",
    "raw_text": "长期借款 15,076,474 46,515,161 16,643,300 78,234,935",
    "series": {
     "2025": 15076474000,
     "2024": 46515161000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": 19434396000,
    "unit": "元",
    "page": 200,
    "pdf_page": 200,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付债券",
    "unit_raw": "千元",
    "raw_text": "应付债券 19,434,396 -12,521,710 151,229 7,063,915",
    "series": {
     "2025": 19434396000,
     "2024": -12521710000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 371026324000,
    "unit": "元",
    "page": 116,
    "pdf_page": 116,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益合计",
    "unit_raw": "千元",
    "raw_text": "按资产总计 - 负债合计倒算：974827544000.00 - 603801220000.00 = 371026324000.00",
    "series": {
     "2025": 371026324000,
     "2024": 194546100000
    },
    "confidence": 0.7,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 477796524000,
    "unit": "元",
    "page": 119,
    "pdf_page": 119,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "千元",
    "raw_text": "销售商品、提供劳务收到的现金 477,796,524 417,525,378",
    "series": {
     "2025": 477796524000,
     "2024": 417525378000
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "宁德时代_300750_2025.pdf",
   "pdf_pages": 232,
   "pagemap": {
    "coverage": 0.931,
    "n_detected": 216,
    "n_inferred": 15,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "000651": {
  "company": {
   "name": "珠海格力电器股份有限公司",
   "ticker": "000651",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "珠海格力电器股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 170447058533.57,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业收入",
    "unit_raw": "元",
    "raw_text": "其中:营业收入 170,447,058,533.57 189,163,654,064.64",
    "series": {
     "2025": 170447058533.57,
     "2024": 189163654064.64
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 119641353216.21,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "元",
    "raw_text": "其中:营业成本 119,641,353,216.21 133,496,119,623.36",
    "series": {
     "2025": 119641353216.21,
     "2024": 133496119623.36
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 28862746016.16,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 28,862,746,016.16 32,371,069,287.35",
    "series": {
     "2025": 28862746016.16,
     "2024": 32371069287.35
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 29003103411.66,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "1、归属于母公司股东的净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "1、归属于母公司股东的净利润(净亏损以“-”号填列) 29,003,103,411.66 32,184,570,372.28",
    "series": {
     "2025": 29003103411.66,
     "2024": 32184570372.28
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 27706292436.94,
    "unit": "元",
    "page": 6,
    "pdf_page": 7,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润(元) 27,706,292,436.94 30,099,760,382.99 -7.95% 27,565,461,117.79",
    "series": {
     "2025": 27706292436.94,
     "2024": 30099760382.99,
     "2023": 7121443552.47
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 391371999819.49,
    "unit": "元",
    "page": 85,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "元",
    "raw_text": "资产总计 391,371,999,819.49 368,031,704,522.86",
    "series": {
     "2025": 391371999819.49,
     "2024": 368031704522.86
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 241580719144.79,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 241,580,719,144.79 226,518,009,574.89",
    "series": {
     "2025": 241580719144.79
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 145929297804.02,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于母公司股东权益合计",
    "unit_raw": "元",
    "raw_text": "归属于母公司股东权益合计 145,929,297,804.02 137,416,898,946.39",
    "series": {
     "2025": 145929297804.02
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 113900461797.94,
    "unit": "元",
    "page": 192,
    "pdf_page": 193,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 113,900,461,797.94 113,900,461,797.94",
    "series": {
     "2025": 113900461797.94,
     "2024": 113900461797.94
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 15987180598.76,
    "unit": "元",
    "page": 85,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 15,987,180,598.76 16,831,887,388.06",
    "series": {
     "2025": 15987180598.76
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 28183464259.53,
    "unit": "元",
    "page": 85,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 28,183,464,259.53 27,910,910,515.55",
    "series": {
     "2025": 28183464259.53
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 1324117904.09,
    "unit": "元",
    "page": 85,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 1,324,117,904.09 1,367,729,072.13",
    "series": {
     "2025": 1324117904.09
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 46383114754.02,
    "unit": "元",
    "page": 88,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额 46,383,114,754.02 29,369,250,570.66",
    "series": {
     "2025": 46383114754.02,
     "2024": 29369250570.66
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -48599499604.72,
    "unit": "元",
    "page": 88,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -48,599,499,604.72 -15,557,909,615.57",
    "series": {
     "2025": -48599499604.72,
     "2024": -15557909615.57
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": 8605586089.84,
    "unit": "元",
    "page": 88,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 8,605,586,089.84 -23,703,212,908.16",
    "series": {
     "2025": 8605586089.84,
     "2024": -23703212908.16
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 6463100763.66,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 6,463,100,763.66 6,904,084,981.92",
    "series": {
     "2025": 6463100763.66,
     "2024": 6904084981.92
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 1717311068.1,
    "unit": "元",
    "page": 88,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 1,717,311,068.10 3,299,787,341.22",
    "series": {
     "2025": 1717311068.1,
     "2024": 3299787341.22
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 34681293552.28,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 34,681,293,552.28 36,988,437,925.60",
    "series": {
     "2025": 34681293552.28,
     "2024": 36988437925.6
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 34644658951.12,
    "unit": "元",
    "page": 176,
    "pdf_page": 177,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 34,644,658,951.12",
    "series": {
     "2025": 34644658951.12
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 5781912934.96,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:所得税费用",
    "unit_raw": "元",
    "raw_text": "减:所得税费用 5,781,912,934.96 4,524,926,560.95",
    "series": {
     "2025": 5781912934.96,
     "2024": 4524926560.95
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 8410739569.54,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 8,410,739,569.54 9,753,022,469.17",
    "series": {
     "2025": 8410739569.54,
     "2024": 9753022469.17
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 5180260235.38,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 5,180,260,235.38 6,057,608,713.94",
    "series": {
     "2025": 5180260235.38,
     "2024": 6057608713.94
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 4086088396.47,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 -4,086,088,396.47 -3,300,417,558.96",
    "series": {
     "2025": 4086088396.47,
     "2024": 3300417558.96
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 1964864912.15,
    "unit": "元",
    "page": 87,
    "pdf_page": 88,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 1,964,864,912.15 2,378,372,721.06",
    "series": {
     "2025": 1964864912.15,
     "2024": 2378372721.06
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": null,
    "unit": "元",
    "page": 113,
    "pdf_page": 114,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "(4)固定资产折旧",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 250943551897.43,
    "unit": "元",
    "page": 85,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 250,943,551,897.43 224,802,908,651.88",
    "series": {
     "2025": 250943551897.43
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 42103940920.24,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 42,103,940,920.24 47,091,320,744.05",
    "series": {
     "2025": 42103940920.24
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 231569831196.26,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 231,569,831,196.26 201,125,441,381.86",
    "series": {
     "2025": 231569831196.26
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 45014817947.51,
    "unit": "元",
    "page": 92,
    "pdf_page": 93,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "元",
    "raw_text": "短期借款 45,014,817,947.51 30,059,062,411.86",
    "series": {
     "2025": 45014817947.51,
     "2024": 30059062411.86
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 13668113331.54,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 13,668,113,331.54 15,577,179,285.89",
    "series": {
     "2025": 13668113331.54
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 3134980571.73,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "元",
    "raw_text": "长期借款 3,134,980,571.73 18,229,817,922.13",
    "series": {
     "2025": 3134980571.73
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "应付债券",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 149791280674.7,
    "unit": "元",
    "page": 86,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "股东权益合计",
    "unit_raw": "元",
    "raw_text": "股东权益合计 149,791,280,674.70 141,513,694,947.97",
    "series": {
     "2025": 149791280674.7
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 180152594833.8,
    "unit": "元",
    "page": 88,
    "pdf_page": 89,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 180,152,594,833.80 171,937,113,993.38",
    "series": {
     "2025": 180152594833.8,
     "2024": 171937113993.38
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "格力电器_000651_2025.pdf",
   "pdf_pages": 219,
   "pagemap": {
    "coverage": 0.995,
    "n_detected": 218,
    "n_inferred": 0,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     -1
    ]
   }
  }
 },
 "002594": {
  "company": {
   "name": "比亚迪股份有限公司",
   "ticker": "002594",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "比亚迪股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 803964958000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入(元)",
    "unit_raw": "元",
    "raw_text": "营业收入(元) 803,964,958,000.00 777,102,455,000.00 3.46% 602,315,354,000.00",
    "series": {
     "2025": 803964958000,
     "2024": 777102455000,
     "2023": 602315354000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 661305161000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:营业成本",
    "unit_raw": "千元",
    "raw_text": "减:营业成本 661,305,161 626,046,616",
    "series": {
     "2025": 661305161000,
     "2024": 626046616000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 33760758000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "净利润",
    "unit_raw": "千元",
    "raw_text": "净利润 33,760,758 41,587,940",
    "series": {
     "2025": 33760758000,
     "2024": 41587940000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 32619022000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净利润(元) 32,619,022,000.00 40,254,346,000.00 -18.97% 30,040,811,000.00",
    "series": {
     "2025": 32619022000,
     "2024": 40254346000,
     "2023": 30040811000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": null,
    "unit": "元",
    "page": null,
    "pdf_page": null,
    "section": null,
    "table": null,
    "status": "not_found",
    "reason": "alias_miss",
    "alias_matched": null,
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.0,
    "basis": null
   },
   "total_assets": {
    "label": "总资产",
    "value": 883729883000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "总资产(元)",
    "unit_raw": "元",
    "raw_text": "总资产(元) 883,729,883,000.00 783,355,855,000.00 12.81% 679,547,670,000.00",
    "series": {
     "2025": 883729883000,
     "2024": 783355855000,
     "2023": 679547670000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 625190698000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "千元",
    "raw_text": "负债合计 625,190,698 584,667,646",
    "series": {
     "2025": 625190698000,
     "2024": 584667646000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 246274606000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产(元) 246,274,606,000.00 185,251,104,000.00 32.94% 138,810,065,000.00",
    "series": {
     "2025": 246274606000,
     "2024": 185251104000,
     "2023": 138810065000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 75424747000,
    "unit": "元",
    "page": 123,
    "pdf_page": 123,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "千元",
    "raw_text": "货币资金 1 75,424,747 102,738,734",
    "series": {
     "2025": 75424747000,
     "2024": 102738734000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 37004685000,
    "unit": "元",
    "page": 123,
    "pdf_page": 123,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "千元",
    "raw_text": "应收账款 3 37,004,685 62,298,988",
    "series": {
     "2025": 37004685000,
     "2024": 62298988000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 138420580000,
    "unit": "元",
    "page": 123,
    "pdf_page": 123,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "千元",
    "raw_text": "存货 7 138,420,580 116,036,237",
    "series": {
     "2025": 138420580000,
     "2024": 116036237000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 4427571000,
    "unit": "元",
    "page": 123,
    "pdf_page": 123,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "千元",
    "raw_text": "商誉 19 4,427,571 4,427,571",
    "series": {
     "2025": 4427571000,
     "2024": 4427571000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 59135544000,
    "unit": "元",
    "page": 11,
    "pdf_page": 11,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额(元)",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额(元) 59,135,544,000.00 133,453,873,000.00 -55.69% 169,725,025,000.00",
    "series": {
     "2025": 59135544000,
     "2024": 133453873000,
     "2023": 169725025000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -197463109000,
    "unit": "元",
    "page": 40,
    "pdf_page": 40,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -197,463,109,000.00 -129,082,282,000.00 52.97%",
    "series": {
     "2025": -197463109000,
     "2024": -129082282000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": 104613870000,
    "unit": "元",
    "page": 131,
    "pdf_page": 131,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生/(使用)的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "筹资活动产生/(使用)的现金流量净额 104,613,870 (10,267,547 )",
    "series": {
     "2025": 104613870000,
     "2024": -10267547000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 57978105000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "千元",
    "raw_text": "研发费用 57,978,105 53,194,745",
    "series": {
     "2025": 57978105000,
     "2024": 53194745000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 156807853,
    "unit": "元",
    "page": 130,
    "pdf_page": 130,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 156,807,853 97,359,768",
    "series": {
     "2025": 156807853,
     "2024": 97359768
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 40184709000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "营业利润",
    "unit_raw": "千元",
    "raw_text": "营业利润 40,184,709 50,486,047",
    "series": {
     "2025": 40184709000,
     "2024": 50486047000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 39753049000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "千元",
    "raw_text": "利润总额 39,753,049 49,680,677",
    "series": {
     "2025": 39753049000,
     "2024": 49680677000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 5992291000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:所得税费用",
    "unit_raw": "千元",
    "raw_text": "减:所得税费用 5,992,291 8,092,737",
    "series": {
     "2025": 5992291000,
     "2024": 8092737000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 26184568000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "千元",
    "raw_text": "销售费用 26,184,568 24,085,317",
    "series": {
     "2025": 26184568000,
     "2024": 24085317000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 20199944000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "千元",
    "raw_text": "管理费用 20,199,944 18,644,661",
    "series": {
     "2025": 20199944000,
     "2024": 18644661000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 649350000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "千元",
    "raw_text": "财务费用 (649,350 ) 1,216,206",
    "series": {
     "2025": 649350000,
     "2024": 1216206000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 2551657000,
    "unit": "元",
    "page": 126,
    "pdf_page": 126,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "千元",
    "raw_text": "其中:利息费用 2,551,657 2,093,781",
    "series": {
     "2025": 2551657000,
     "2024": 2093781000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 35964164000,
    "unit": "元",
    "page": 194,
    "pdf_page": 194,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、无形资产摊销",
    "unit_raw": "千元",
    "raw_text": "固定资产折旧、无形资产摊销 35,964,164 6,084,108 23,748,690 3,964,930",
    "series": {
     "2025": 35964164000,
     "2024": 6084108000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 371467558000,
    "unit": "元",
    "page": 123,
    "pdf_page": 123,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "千元",
    "raw_text": "流动资产合计 371,467,558 370,572,244",
    "series": {
     "2025": 371467558000,
     "2024": 370572244000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 186742375000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "千元",
    "raw_text": "应付账款 26 186,742,375 241,643,424",
    "series": {
     "2025": 186742375000,
     "2024": 241643424000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 468451357000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "千元",
    "raw_text": "流动负债合计 468,451,357 495,985,176",
    "series": {
     "2025": 468451357000,
     "2024": 495985176000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 38484710000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "千元",
    "raw_text": "短期借款 24 38,484,710 12,103,272",
    "series": {
     "2025": 38484710000,
     "2024": 12103272000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 6311964000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "千元",
    "raw_text": "一年内到期的非流动负债 32 6,311,964 10,222,575",
    "series": {
     "2025": 6311964000,
     "2024": 10222575000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 60705569000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "千元",
    "raw_text": "长期借款 34 60,705,569 8,257,786",
    "series": {
     "2025": 60705569000,
     "2024": 8257786000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": 4997910000,
    "unit": "元",
    "page": 124,
    "pdf_page": 124,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付债券",
    "unit_raw": "千元",
    "raw_text": "应付债券 35 4,997,910 -",
    "series": {
     "2025": 4997910000,
     "2024": 1191601000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 258539185000,
    "unit": "元",
    "page": 125,
    "pdf_page": 125,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "股东权益合计",
    "unit_raw": "千元",
    "raw_text": "股东权益合计 258,539,185 198,688,209",
    "series": {
     "2025": 258539185000,
     "2024": 198688209000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 821214650000,
    "unit": "元",
    "page": 130,
    "pdf_page": 130,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "千元",
    "raw_text": "销售商品、提供劳务收到的现金 821,214,650 774,347,395",
    "series": {
     "2025": 821214650000,
     "2024": 774347395000
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "比亚迪_002594_2025.pdf",
   "pdf_pages": 268,
   "pagemap": {
    "coverage": 0.993,
    "n_detected": 266,
    "n_inferred": 1,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "002415": {
  "company": {
   "name": "杭州海康威视数字技术股份有限公司",
   "ticker": "002415",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "杭州海康威视数字技术股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 92507796069.94,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入(元)",
    "unit_raw": "元",
    "raw_text": "营业收入(元) 92,507,796,069.94 92,495,525,118.30 0.01% 89,341,177,610.40",
    "series": {
     "2025": 92507796069.94,
     "2024": 92495525118.3
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 50067436550.36,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "减:营业成本",
    "unit_raw": "元",
    "raw_text": "减:营业成本 50,067,436,550.36 51,953,857,912.21",
    "series": {
     "2025": 50067436550.36,
     "2024": 51953857912.21
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 15433655239.83,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "四、净利润",
    "unit_raw": "元",
    "raw_text": "四、净利润 15,433,655,239.83 13,141,022,060.51",
    "series": {
     "2025": 15433655239.83,
     "2024": 13141022060.51
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 14195371894.42,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净利润(元) 14,195,371,894.42 11,977,327,023.54 18.52% 14,107,726,276.26",
    "series": {
     "2025": 14195371894.42,
     "2024": 11977327023.54
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 13703158053.2,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润(元) 13,703,158,053.20 11,814,861,641.16 15.98% 13,665,962,325.65",
    "series": {
     "2025": 13703158053.2,
     "2024": 11814861641.16
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 138049655334.62,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "总资产(元)",
    "unit_raw": "元",
    "raw_text": "总资产(元) 138,049,655,334.62 132,016,200,156.14 4.57% 138,858,122,879.55",
    "series": {
     "2025": 138049655334.62,
     "2024": 132016200156.14
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 46832791980.03,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 46,832,791,980.03 44,515,905,407.99",
    "series": {
     "2025": 46832791980.03,
     "2024": 44515905407.99
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 83348185885.62,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产(元) 83,348,185,885.62 80,668,661,062.88 3.32% 76,354,265,540.14",
    "series": {
     "2025": 83348185885.62,
     "2024": 80668661062.88
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 46508328658.44,
    "unit": "元",
    "page": 233,
    "pdf_page": 234,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 46,508,328,658.44 36,271,488,337.03",
    "series": {
     "2025": 46508328658.44,
     "2024": 36271488337.03
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 29812378945.77,
    "unit": "元",
    "page": 146,
    "pdf_page": 147,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 29,812,378,945.77 37,910,128,735.42",
    "series": {
     "2025": 29812378945.77,
     "2024": 37910128735.42
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 20472193858.8,
    "unit": "元",
    "page": 146,
    "pdf_page": 147,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 20,472,193,858.80 19,110,711,958.11",
    "series": {
     "2025": 20472193858.8,
     "2024": 19110711958.11
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 311187727.01,
    "unit": "元",
    "page": 146,
    "pdf_page": 147,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 311,187,727.01 312,165,129.29",
    "series": {
     "2025": 311187727.01,
     "2024": 312165129.29
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 25339411083.1,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额(元)",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额(元) 25,339,411,083.10 13,264,092,022.73 91.04% 16,622,209,721.05",
    "series": {
     "2025": 25339411083.1,
     "2024": 13264092022.73
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -3417315813.86,
    "unit": "元",
    "page": 152,
    "pdf_page": 153,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 (3,417,315,813.86) (4,547,540,997.10)",
    "series": {
     "2025": -3417315813.86,
     "2024": -4547540997.1
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -11762551780.92,
    "unit": "元",
    "page": 152,
    "pdf_page": 153,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 (11,762,551,780.92) (22,078,988,785.63)",
    "series": {
     "2025": -11762551780.92,
     "2024": -22078988785.63
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 11752624736.8,
    "unit": "元",
    "page": 91,
    "pdf_page": 92,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 11,752,624,736.80 11,864,013,392.27 -0.94% 无重大变动",
    "series": {
     "2025": 11752624736.8,
     "2024": 11864013392.27
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 1036454720.57,
    "unit": "元",
    "page": 153,
    "pdf_page": 154,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 1,036,454,720.57 521,185,569.34",
    "series": {
     "2025": 1036454720.57,
     "2024": 521185569.34
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 16963083174.72,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "二、营业利润",
    "unit_raw": "元",
    "raw_text": "二、营业利润 16,963,083,174.72 14,312,246,696.51",
    "series": {
     "2025": 16963083174.72,
     "2024": 14312246696.51
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 17013438438.62,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、利润总额",
    "unit_raw": "元",
    "raw_text": "三、利润总额 17,013,438,438.62 14,343,493,640.00",
    "series": {
     "2025": 17013438438.62,
     "2024": 14343493640
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 1579783198.79,
    "unit": "元",
    "page": 225,
    "pdf_page": 226,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "元",
    "raw_text": "所得税费用 1,579,783,198.79 1,202,471,579.49",
    "series": {
     "2025": 1579783198.79,
     "2024": 1202471579.49
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 12347888877.7,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 12,347,888,877.70 12,051,218,102.62",
    "series": {
     "2025": 12347888877.7,
     "2024": 12051218102.62
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 2994512052.02,
    "unit": "元",
    "page": 91,
    "pdf_page": 92,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 2,994,512,052.02 3,095,939,643.92 -3.28% 无重大变动",
    "series": {
     "2025": 2994512052.02,
     "2024": 3095939643.92
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 71877702.83,
    "unit": "元",
    "page": 228,
    "pdf_page": 229,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 71,877,702.83 256,441,388.18",
    "series": {
     "2025": 71877702.83,
     "2024": 256441388.18
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 200704102.53,
    "unit": "元",
    "page": 150,
    "pdf_page": 151,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 200,704,102.53 391,404,187.13",
    "series": {
     "2025": 200704102.53,
     "2024": 391404187.13
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 274890844.72,
    "unit": "元",
    "page": 222,
    "pdf_page": 223,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "折旧与摊销",
    "unit_raw": "元",
    "raw_text": "折旧与摊销 274,890,844.72 323,848,822.04",
    "series": {
     "2025": 274890844.72,
     "2024": 323848822.04
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 106408460502.92,
    "unit": "元",
    "page": 146,
    "pdf_page": 147,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 106,408,460,502.92 102,480,513,627.12",
    "series": {
     "2025": 106408460502.92,
     "2024": 102480513627.12
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 19843949575.87,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 19,843,949,575.87 20,185,303,107.69",
    "series": {
     "2025": 19843949575.87,
     "2024": 20185303107.69
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 43995715374.44,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 43,995,715,374.44 37,645,004,001.91",
    "series": {
     "2025": 43995715374.44,
     "2024": 37645004001.91
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 2685866236.94,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "元",
    "raw_text": "短期借款 2,685,866,236.94 1,031,895,812.62",
    "series": {
     "2025": 2685866236.94,
     "2024": 1031895812.62
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 3939271129.61,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 3,939,271,129.61 767,030,688.91",
    "series": {
     "2025": 3939271129.61,
     "2024": 767030688.91
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 1210564814.39,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "元",
    "raw_text": "长期借款 1,210,564,814.39 5,119,185,000.00",
    "series": {
     "2025": 1210564814.39,
     "2024": 5119185000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": null,
    "pdf_page": null,
    "section": null,
    "table": null,
    "status": "not_found",
    "reason": "alias_miss",
    "alias_matched": null,
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.0,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 91216863354.59,
    "unit": "元",
    "page": 147,
    "pdf_page": 148,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益合计",
    "unit_raw": "元",
    "raw_text": "所有者权益合计 91,216,863,354.59 87,500,294,748.15",
    "series": {
     "2025": 91216863354.59,
     "2024": 87500294748.15
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 110851861667.39,
    "unit": "元",
    "page": 152,
    "pdf_page": 153,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 110,851,861,667.39 98,512,386,004.95",
    "series": {
     "2025": 110851861667.39,
     "2024": 98512386004.95
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "海康威视_002415_2025.pdf",
   "pdf_pages": 263,
   "pagemap": {
    "coverage": 0.996,
    "n_detected": 262,
    "n_inferred": 0,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     -1
    ]
   }
  }
 },
 "000333": {
  "company": {
   "name": "美的集团股份有限公司",
   "ticker": "000333",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "美的集团股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 458502407000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一、营业总收入",
    "unit_raw": "千元",
    "raw_text": "一、营业总收入 458,502,407 409,084,266 936,519 946,607",
    "series": {
     "2025": 458502407000,
     "2024": 409084266000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 335989528000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:营业成本",
    "unit_raw": "千元",
    "raw_text": "减:营业成本 (335,989,528) (299,584,935) (63,771) (40,440)",
    "series": {
     "2025": 335989528000,
     "2024": 299584935000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 44520196000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "四、净利润",
    "unit_raw": "千元",
    "raw_text": "四、净利润 44,520,196 38,757,214 29,415,131 28,517,064",
    "series": {
     "2025": 44520196000,
     "2024": 38757214000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 43945411000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于母公司股东的净利润",
    "unit_raw": "千元",
    "raw_text": "归属于母公司股东的净利润 43,945,411 38,537,237 29,415,131 28,517,064",
    "series": {
     "2025": 43945411000,
     "2024": 38537237000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 41267233000,
    "unit": "元",
    "page": 8,
    "pdf_page": 9,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润(千元)",
    "unit_raw": "千元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润(千元) 41,267,233 35,741,418 15.46% 32,974,908",
    "series": {
     "2025": 41267233000,
     "2024": 35741418000,
     "2023": 32974908000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 608791766000,
    "unit": "元",
    "page": 131,
    "pdf_page": 132,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "千元",
    "raw_text": "资产总计 608,791,766 604,351,853 295,444,621 300,151,455",
    "series": {
     "2025": 608791766000,
     "2024": 604351853000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 372367543000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "千元",
    "raw_text": "负债合计 372,367,543 376,684,462 197,391,951 193,646,429",
    "series": {
     "2025": 372367543000,
     "2024": 376684462000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 223221305000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于母公司股东权益合计",
    "unit_raw": "千元",
    "raw_text": "归属于母公司股东权益合计 223,221,305 216,750,057 98,052,670 106,505,026",
    "series": {
     "2025": 223221305000,
     "2024": 216750057000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 85247150000,
    "unit": "元",
    "page": 53,
    "pdf_page": 54,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "千元",
    "raw_text": "货币资金 85,247,150 14.00% 140,410,308 23.23% -9.23% 货币资金中的定期存款减少",
    "series": {
     "2025": 85247150000,
     "2024": 84222595000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 40450097000,
    "unit": "元",
    "page": 131,
    "pdf_page": 132,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "千元",
    "raw_text": "应收账款 40,450,097 35,798,974 - -",
    "series": {
     "2025": 40450097000,
     "2024": 35798974000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 64628834000,
    "unit": "元",
    "page": 131,
    "pdf_page": 132,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "千元",
    "raw_text": "存货 64,628,834 63,339,188 - -",
    "series": {
     "2025": 64628834000,
     "2024": 63339188000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 34256859000,
    "unit": "元",
    "page": 131,
    "pdf_page": 132,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "千元",
    "raw_text": "商誉 34,256,859 29,581,014 - -",
    "series": {
     "2025": 34256859000,
     "2024": 29581014000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 53345930000,
    "unit": "元",
    "page": 233,
    "pdf_page": 234,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "经营活动产生的现金流量净额 53,345,930 60,511,572",
    "series": {
     "2025": 53345930000,
     "2024": 60511572000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": 25340273000,
    "unit": "元",
    "page": 136,
    "pdf_page": 137,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生/(使用)的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "投资活动产生/(使用)的现金流量净额 25,340,273 (87,901,802) 61,045,937 (32,782,384)",
    "series": {
     "2025": 25340273000,
     "2024": -87901802000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -64957779000,
    "unit": "元",
    "page": 136,
    "pdf_page": 137,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动(使用)/产生的现金流量净额",
    "unit_raw": "千元",
    "raw_text": "筹资活动(使用)/产生的现金流量净额 (64,957,779) 22,697,954 (37,445,961) 5,736,041",
    "series": {
     "2025": -64957779000,
     "2024": 22697954000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 17787624000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "千元",
    "raw_text": "研发费用 (17,787,624) (16,232,771) - -",
    "series": {
     "2025": 17787624000,
     "2024": 16232771000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 11141889000,
    "unit": "元",
    "page": 136,
    "pdf_page": 137,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "千元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 (11,141,889) (7,839,636) (386,032) (570,950)",
    "series": {
     "2025": 11141889000,
     "2024": 7839636000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 52978773000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "二、营业利润",
    "unit_raw": "千元",
    "raw_text": "二、营业利润 52,978,773 46,393,752 29,166,472 28,720,667",
    "series": {
     "2025": 52978773000,
     "2024": 46393752000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 53085343000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、利润总额",
    "unit_raw": "千元",
    "raw_text": "三、利润总额 53,085,343 46,689,746 29,210,298 28,788,211",
    "series": {
     "2025": 53085343000,
     "2024": 46689746000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 8565147000,
    "unit": "元",
    "page": 229,
    "pdf_page": 230,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "所得税费用",
    "unit_raw": "千元",
    "raw_text": "所得税费用 8,565,147 7,932,532",
    "series": {
     "2025": 8565147000,
     "2024": 7932532000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 42891490000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "千元",
    "raw_text": "销售费用 (42,891,490) (38,753,649) - -",
    "series": {
     "2025": 42891490000,
     "2024": 38753649000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 16092311000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "千元",
    "raw_text": "管理费用 (16,092,311) (14,505,864) (1,542,725) (1,516,146)",
    "series": {
     "2025": 16092311000,
     "2024": 14505864000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": null,
    "unit": "元",
    "page": null,
    "pdf_page": null,
    "section": null,
    "table": null,
    "status": "not_found",
    "reason": "alias_miss",
    "alias_matched": null,
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.0,
    "basis": null
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 2211331000,
    "unit": "元",
    "page": 134,
    "pdf_page": 135,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "千元",
    "raw_text": "其中:利息费用 2,211,331 2,453,361 2,930,251 2,957,065",
    "series": {
     "2025": 2211331000,
     "2024": 2453361000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": null,
    "unit": "元",
    "page": null,
    "pdf_page": null,
    "section": null,
    "table": null,
    "status": "not_found",
    "reason": "alias_miss",
    "alias_matched": null,
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.0,
    "basis": null
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 416662341000,
    "unit": "元",
    "page": 131,
    "pdf_page": 132,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "千元",
    "raw_text": "流动资产合计 416,662,341 389,063,786 127,272,108 99,393,257",
    "series": {
     "2025": 416662341000,
     "2024": 389063786000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 103680491000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "千元",
    "raw_text": "应付账款 103,680,491 92,800,426 - -",
    "series": {
     "2025": 103680491000,
     "2024": 92800426000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 343383700000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "千元",
    "raw_text": "流动负债合计 343,383,700 351,819,806 187,528,689 185,840,717",
    "series": {
     "2025": 343383700000,
     "2024": 351819806000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 44158776000,
    "unit": "元",
    "page": 262,
    "pdf_page": 263,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款(包括利息)",
    "unit_raw": "千元",
    "raw_text": "短期借款(包括利息) 44,158,776 - - - 44,158,776",
    "series": {
     "2025": 44158776000,
     "2024": 44158776000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 5821777000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "千元",
    "raw_text": "一年内到期的非流动负债 5,821,777 39,662,733 3,998,242 9,001,153",
    "series": {
     "2025": 5821777000,
     "2024": 39662733000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 12658843000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "千元",
    "raw_text": "长期借款 12,658,843 10,491,757 9,592,200 7,599,900",
    "series": {
     "2025": 12658843000,
     "2024": 10491757000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": 3194774000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付债券",
    "unit_raw": "千元",
    "raw_text": "应付债券 3,194,774 3,266,775 - -",
    "series": {
     "2025": 3194774000,
     "2024": 3266775000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 236424223000,
    "unit": "元",
    "page": 132,
    "pdf_page": 133,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "股东权益合计",
    "unit_raw": "千元",
    "raw_text": "股东权益合计 236,424,223 227,667,391 98,052,670 106,505,026",
    "series": {
     "2025": 236424223000,
     "2024": 227667391000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 426210800000,
    "unit": "元",
    "page": 136,
    "pdf_page": 137,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "千元",
    "raw_text": "销售商品、提供劳务收到的现金 426,210,800 388,661,338 - -",
    "series": {
     "2025": 426210800000,
     "2024": 388661338000
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "美的集团_000333_2025.pdf",
   "pdf_pages": 276,
   "pagemap": {
    "coverage": 0.996,
    "n_detected": 275,
    "n_inferred": 0,
    "n_missing": 1,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     -1
    ]
   }
  }
 },
 "600519": {
  "company": {
   "name": "贵州茅台酒股份有限公司",
   "ticker": "600519",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "贵州茅台酒股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 168838102514.79,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "营业收入",
    "unit_raw": "元",
    "raw_text": "营业收入 168,838,102,514.79 170,899,152,276.34 -1.21 147,693,604,994.14",
    "series": {
     "2025": 168838102514.79,
     "2024": 170899152276.34,
     "2023": 147693604994.14
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 14892277570.91,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "元",
    "raw_text": "其中:营业成本 44 14,892,277,570.91 13,789,482,367.98",
    "series": {
     "2025": 14892277570.91,
     "2024": 13789482367.98
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 85310324833.67,
    "unit": "元",
    "page": 62,
    "pdf_page": 62,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 85,310,324,833.67 89,334,728,025.90",
    "series": {
     "2025": 85310324833.67,
     "2024": 89334728025.9
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 82320067101.68,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净利润",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净利润 82,320,067,101.68 86,228,146,421.62 -4.53 74,734,071,550.75",
    "series": {
     "2025": 82320067101.68,
     "2024": 86228146421.62,
     "2023": 74734071550.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 82293107655.25,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润 82,293,107,655.25 86,240,905,977.42 -4.58 74,752,564,425.52",
    "series": {
     "2025": 82293107655.25,
     "2024": 86240905977.42,
     "2023": 74752564425.52
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 303834844021.44,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "总资产",
    "unit_raw": "元",
    "raw_text": "总资产 303,834,844,021.44 298,944,579,918.70 1.64 272,699,660,092.25",
    "series": {
     "2025": 303834844021.44,
     "2024": 298944579918.7,
     "2023": 272699660092.25
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 49875590112.37,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 49,875,590,112.37 56,933,264,798.10",
    "series": {
     "2025": 49875590112.37,
     "2024": 56933264798.1
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 244637811032.18,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产 244,637,811,032.18 233,105,984,399.47 4.95 215,668,571,607.43",
    "series": {
     "2025": 244637811032.18,
     "2024": 233105984399.47,
     "2023": 215668571607.43
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 85687080245.45,
    "unit": "元",
    "page": 59,
    "pdf_page": 59,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "货币资金",
    "unit_raw": "元",
    "raw_text": "货币资金 85,687,080,245.45 77,252,079,198.82",
    "series": {
     "2025": 85687080245.45,
     "2024": 77252079198.82
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 2609048.49,
    "unit": "元",
    "page": 57,
    "pdf_page": 57,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 5 2,609,048.49 18,974,192.75",
    "series": {
     "2025": 2609048.49,
     "2024": 18974192.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 61427421796.18,
    "unit": "元",
    "page": 57,
    "pdf_page": 57,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 10 61,427,421,796.18 54,343,285,157.47",
    "series": {
     "2025": 61427421796.18,
     "2024": 54343285157.47
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": null,
    "unit": "元",
    "page": 57,
    "pdf_page": 57,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "商誉",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 61522204989.35,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额 61,522,204,989.35 92,463,692,168.43 -33.46 66,593,247,721.09",
    "series": {
     "2025": 61522204989.35,
     "2024": 92463692168.43,
     "2023": 66593247721.09
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -31641898948.89,
    "unit": "元",
    "page": 65,
    "pdf_page": 65,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流",
    "series": {
     "2025": -31641898948.89,
     "2024": -1785202630.71
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -73427081208.87,
    "unit": "元",
    "page": 9,
    "pdf_page": 9,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 -73,427,081,208.87 -71,067,506,484.81 不适用",
    "series": {
     "2025": -73427081208.87,
     "2024": -71067506484.81
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 190112246.58,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 49 190,112,246.58 218,375,472.87",
    "series": {
     "2025": 190112246.58,
     "2024": 218375472.87
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 3127594916.41,
    "unit": "元",
    "page": 13,
    "pdf_page": 13,
    "section": "第三节 管理层讨论与分析",
    "table": "第三节 管理层讨论与分析",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 3,127,594,916.41 4,678,712,053.56 -33.15",
    "series": {
     "2025": 3127594916.41,
     "2024": 4678712053.56
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 114808950164.24,
    "unit": "元",
    "page": 62,
    "pdf_page": 62,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 114,808,950,164.24 119,688,579,453.23",
    "series": {
     "2025": 114808950164.24,
     "2024": 119688579453.23
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 114755261605.08,
    "unit": "元",
    "page": 6,
    "pdf_page": 6,
    "section": "第二节 公司简介和主要财务指标",
    "table": "主要会计数据和财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 114,755,261,605.08 119,638,578,194.46 -4.08 103,662,553,689.81",
    "series": {
     "2025": 114755261605.08,
     "2024": 119638578194.46,
     "2023": 103662553689.81
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 29444936771.41,
    "unit": "元",
    "page": 62,
    "pdf_page": 62,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:所得税费用",
    "unit_raw": "元",
    "raw_text": "减:所得税费用 58 29,444,936,771.41 30,303,850,168.56",
    "series": {
     "2025": 29444936771.41,
     "2024": 30303850168.56
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 7253499600.68,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 47 7,253,499,600.68 5,639,300,059.49",
    "series": {
     "2025": 7253499600.68,
     "2024": 5639300059.49
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 8320061659.66,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 48 8,320,061,659.66 9,315,650,060.38",
    "series": {
     "2025": 8320061659.66,
     "2024": 9315650060.38
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 815240284.72,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 50 -815,240,284.72 -1,470,219,863.34",
    "series": {
     "2025": 815240284.72,
     "2024": 1470219863.34
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 28734948.29,
    "unit": "元",
    "page": 61,
    "pdf_page": 61,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 28,734,948.29 14,474,584.09",
    "series": {
     "2025": 28734948.29,
     "2024": 14474584.09
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 1893338311.91,
    "unit": "元",
    "page": 115,
    "pdf_page": 115,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    "unit_raw": "元",
    "raw_text": "固定资产折旧、油气资产折耗、生产性生物资产折旧 1,893,338,311.91 1,721,165,327.14",
    "series": {
     "2025": 1893338311.91,
     "2024": 1721165327.14
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 252518662398.57,
    "unit": "元",
    "page": 57,
    "pdf_page": 57,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 252,518,662,398.57 251,726,674,636.66",
    "series": {
     "2025": 252518662398.57,
     "2024": 251726674636.66
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 4007309049.87,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 28 4,007,309,049.87 3,514,969,230.31",
    "series": {
     "2025": 4007309049.87,
     "2024": 3514969230.31
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 49610476817.81,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 49,610,476,817.81 56,515,990,618.96",
    "series": {
     "2025": 49610476817.81,
     "2024": 56515990618.96
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": null,
    "unit": "元",
    "page": 57,
    "pdf_page": 57,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "短期借款",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 44206237.05,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 34 44,206,237.05 111,951,112.20",
    "series": {
     "2025": 44206237.05,
     "2024": 111951112.2
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": null,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "长期借款",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": null,
    "unit": "元",
    "page": 58,
    "pdf_page": 58,
    "section": null,
    "table": null,
    "status": "not_applicable",
    "reason": "row_present_without_value",
    "alias_matched": "应付债券",
    "unit_raw": null,
    "raw_text": null,
    "series": {},
    "confidence": 0.85,
    "basis": null
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 253959253909.07,
    "unit": "元",
    "page": 59,
    "pdf_page": 59,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益(或股东权益)合计",
    "unit_raw": "元",
    "raw_text": "所有者权益(或股东权益)合计 253,959,253,909.07 242,011,315,120.60",
    "series": {
     "2025": 253959253909.07,
     "2024": 242011315120.6
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 183990403487.8,
    "unit": "元",
    "page": 64,
    "pdf_page": 64,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现",
    "series": {
     "2025": 183990403487.8,
     "2024": 182645203339.89
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "贵州茅台_600519_2025.pdf",
   "pdf_pages": 143,
   "pagemap": {
    "coverage": 1.0,
    "n_detected": 143,
    "n_inferred": 0,
    "n_missing": 0,
    "n_runs": 1,
    "monotonic_ok": true,
    "n_violations": 0,
    "accepted_offsets": [
     0
    ]
   }
  }
 },
 "002709": {
  "company": {
   "name": "广州天赐高新材料股份有限公司",
   "ticker": "002709",
   "industry": "",
   "report_period": "2025年度",
   "report_title": "广州天赐高新材料股份有限公司2025年年度报告"
  },
  "financials": {
   "revenue": {
    "label": "营业收入",
    "value": 16649892556.28,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一、营业总收入",
    "unit_raw": "元",
    "raw_text": "一、营业总收入 16,649,892,556.28 12,518,297,342.63",
    "series": {
     "2025": 16649892556.28,
     "2024": 12518297342.63
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_cost": {
    "label": "营业成本",
    "value": 12946736447.91,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:营业成本",
    "unit_raw": "元",
    "raw_text": "其中:营业成本 12,946,736,447.91 10,154,135,596.71",
    "series": {
     "2025": 12946736447.91,
     "2024": 10154135596.71
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit": {
    "label": "净利润",
    "value": 1344179277.07,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "五、净利润(净亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "五、净利润(净亏损以“-”号填列) 1,344,179,277.07 478,433,104.75",
    "series": {
     "2025": 1344179277.07,
     "2024": 478433104.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_attr": {
    "label": "归母净利润",
    "value": 1361917896.52,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "1.归属于母公司股东的净利润",
    "unit_raw": "元",
    "raw_text": "1.归属于母公司股东的净利润 1,361,917,896.52 483,929,654.43",
    "series": {
     "2025": 1361917896.52,
     "2024": 483929654.43
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "net_profit_deducted": {
    "label": "扣非归母净利润",
    "value": 1359717877.14,
    "unit": "元",
    "page": null,
    "pdf_page": 8,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的扣除非经常性损益的净利润(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的扣除非经常性损益的净利润(元) 1,359,717,877.14 381,602,705.47 256.32% 1,823,789,997.59",
    "series": {
     "2025": 1359717877.14,
     "2024": 381602705.47,
     "2023": 1823789997.59
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_assets": {
    "label": "总资产",
    "value": 26926733976.62,
    "unit": "元",
    "page": null,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "资产总计",
    "unit_raw": "元",
    "raw_text": "资产总计 26,926,733,976.62 23,953,389,261.08",
    "series": {
     "2025": 26926733976.62,
     "2024": 23953389261.08
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_liabilities": {
    "label": "总负债",
    "value": 3155737254.99,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "负债合计",
    "unit_raw": "元",
    "raw_text": "负债合计 3,155,737,254.99 6,044,606,430.35",
    "series": {
     "2025": 3155737254.99,
     "2024": 6044606430.35
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "equity_attr": {
    "label": "归母净资产",
    "value": 17851651235.87,
    "unit": "元",
    "page": null,
    "pdf_page": 8,
    "section": "第二节 公司简介和主要财务指标",
    "table": "第二节 公司简介和主要财务指标",
    "status": "found",
    "reason": null,
    "alias_matched": "归属于上市公司股东的净资产(元)",
    "unit_raw": "元",
    "raw_text": "归属于上市公司股东的净资产(元) 17,851,651,235.87 13,103,593,054.20 36.23% 13,354,543,856.49",
    "series": {
     "2025": 17851651235.87,
     "2024": 13103593054.2,
     "2023": 13354543856.49
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash": {
    "label": "货币资金",
    "value": 1914714600,
    "unit": "元",
    "page": null,
    "pdf_page": 179,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:货币资金",
    "unit_raw": "万元",
    "raw_text": "其中:货币资金 191,471.46 162,022.94",
    "series": {
     "2025": 1914714600,
     "2024": 1620229400
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_receivable": {
    "label": "应收账款",
    "value": 6880220490.64,
    "unit": "元",
    "page": null,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应收账款",
    "unit_raw": "元",
    "raw_text": "应收账款 6,880,220,490.64 4,869,856,324.64",
    "series": {
     "2025": 6880220490.64,
     "2024": 4869856324.64
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "inventory": {
    "label": "存货",
    "value": 1619109691.52,
    "unit": "元",
    "page": null,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "存货",
    "unit_raw": "元",
    "raw_text": "存货 1,619,109,691.52 1,363,690,318.78",
    "series": {
     "2025": 1619109691.52,
     "2024": 1363690318.78
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "goodwill": {
    "label": "商誉",
    "value": 200401565,
    "unit": "元",
    "page": null,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "商誉",
    "unit_raw": "元",
    "raw_text": "商誉 200,401,565.00 200,401,565.00",
    "series": {
     "2025": 200401565,
     "2024": 200401565
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfo": {
    "label": "经营活动现金流净额",
    "value": 1182243395.29,
    "unit": "元",
    "page": null,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "经营活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "经营活动产生的现金流量净额 1,182,243,395.29 881,535,736.54",
    "series": {
     "2025": 1182243395.29,
     "2024": 881535736.54
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cfi": {
    "label": "投资活动现金流净额",
    "value": -331538134.12,
    "unit": "元",
    "page": null,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "投资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "投资活动产生的现金流量净额 -331,538,134.12 -1,010,751,383.29",
    "series": {
     "2025": -331538134.12,
     "2024": -1010751383.29
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cff": {
    "label": "筹资活动现金流净额",
    "value": -556655125.72,
    "unit": "元",
    "page": null,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "筹资活动产生的现金流量净额",
    "unit_raw": "元",
    "raw_text": "筹资活动产生的现金流量净额 -556,655,125.72 -530,273,641.38",
    "series": {
     "2025": -556655125.72,
     "2024": -530273641.38
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "rd_expense": {
    "label": "研发费用",
    "value": 846948352.88,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "研发费用",
    "unit_raw": "元",
    "raw_text": "研发费用 846,948,352.88 668,213,487.72",
    "series": {
     "2025": 846948352.88,
     "2024": 668213487.72
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "capex": {
    "label": "资本开支",
    "value": 659139342.83,
    "unit": "元",
    "page": null,
    "pdf_page": 87,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "购建固定资产、无形资产和其他长期资产支付的现金",
    "unit_raw": "元",
    "raw_text": "购建固定资产、无形资产和其他长期资产支付的现金 659,139,342.83 771,505,576.74",
    "series": {
     "2025": 659139342.83,
     "2024": 771505576.74
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "operating_profit": {
    "label": "营业利润",
    "value": 1600095667.89,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "三、营业利润(亏损以“-”号填列)",
    "unit_raw": "元",
    "raw_text": "三、营业利润(亏损以“-”号填列) 1,600,095,667.89 664,782,163.76",
    "series": {
     "2025": 1600095667.89,
     "2024": 664782163.76
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "pretax_profit": {
    "label": "利润总额",
    "value": 1538573198.75,
    "unit": "元",
    "page": null,
    "pdf_page": 161,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "利润总额",
    "unit_raw": "元",
    "raw_text": "利润总额 1,538,573,198.75",
    "series": {
     "2025": 1538573198.75
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "income_tax_expense": {
    "label": "所得税费用",
    "value": 194393921.68,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "减:所得税费用",
    "unit_raw": "元",
    "raw_text": "减:所得税费用 194,393,921.68 171,475,261.55",
    "series": {
     "2025": 194393921.68,
     "2024": 171475261.55
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "selling_expense": {
    "label": "销售费用",
    "value": 71839118.52,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售费用",
    "unit_raw": "元",
    "raw_text": "销售费用 71,839,118.52 75,132,898.00",
    "series": {
     "2025": 71839118.52,
     "2024": 75132898
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "admin_expense": {
    "label": "管理费用",
    "value": 859374390.51,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "管理费用",
    "unit_raw": "元",
    "raw_text": "管理费用 859,374,390.51 642,429,028.27",
    "series": {
     "2025": 859374390.51,
     "2024": 642429028.27
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "finance_expense": {
    "label": "财务费用",
    "value": 181610429.03,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "财务费用",
    "unit_raw": "元",
    "raw_text": "财务费用 181,610,429.03 184,179,534.85",
    "series": {
     "2025": 181610429.03,
     "2024": 184179534.85
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "interest_expense": {
    "label": "利息费用",
    "value": 183498168.64,
    "unit": "元",
    "page": null,
    "pdf_page": 84,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "其中:利息费用",
    "unit_raw": "元",
    "raw_text": "其中:利息费用 183,498,168.64 215,562,659.99",
    "series": {
     "2025": 183498168.64,
     "2024": 215562659.99
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "depreciation_amortization": {
    "label": "折旧与摊销",
    "value": 995942018.33,
    "unit": "元",
    "page": null,
    "pdf_page": 164,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "固定资产折旧、油气资产折耗、生产性生物资产折旧",
    "unit_raw": "元",
    "raw_text": "固定资产折旧、油气资产折耗、生产性生物资产折旧 995,942,018.33 902,758,205.05",
    "series": {
     "2025": 995942018.33,
     "2024": 902758205.05
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_assets": {
    "label": "流动资产合计",
    "value": 13057034200.55,
    "unit": "元",
    "page": null,
    "pdf_page": 79,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动资产合计",
    "unit_raw": "元",
    "raw_text": "流动资产合计 13,057,034,200.55 10,801,397,528.81",
    "series": {
     "2025": 13057034200.55,
     "2024": 10801397528.81
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "accounts_payable": {
    "label": "应付账款",
    "value": 4335582423.31,
    "unit": "元",
    "page": null,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付账款",
    "unit_raw": "元",
    "raw_text": "应付账款 4,335,582,423.31 3,144,365,350.87",
    "series": {
     "2025": 4335582423.31,
     "2024": 3144365350.87
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_liabilities": {
    "label": "流动负债合计",
    "value": 2511263847.04,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "流动负债合计",
    "unit_raw": "元",
    "raw_text": "流动负债合计 2,511,263,847.04 2,056,966,379.60",
    "series": {
     "2025": 2511263847.04,
     "2024": 2056966379.6
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "short_term_borrowings": {
    "label": "短期借款",
    "value": 1079045710.89,
    "unit": "元",
    "page": null,
    "pdf_page": 80,
    "section": "第八节 财务报告",
    "table": "合并资产负债表",
    "status": "found",
    "reason": null,
    "alias_matched": "短期借款",
    "unit_raw": "元",
    "raw_text": "短期借款 1,079,045,710.89 1,520,426,322.69",
    "series": {
     "2025": 1079045710.89,
     "2024": 1520426322.69
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "current_portion_lt_debt": {
    "label": "一年内到期的非流动负债",
    "value": 579047676.83,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "一年内到期的非流动负债",
    "unit_raw": "元",
    "raw_text": "一年内到期的非流动负债 579,047,676.83 215,320,733.13",
    "series": {
     "2025": 579047676.83,
     "2024": 215320733.13
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "long_term_borrowings": {
    "label": "长期借款",
    "value": 608935000,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "长期借款",
    "unit_raw": "元",
    "raw_text": "长期借款 608,935,000.00 546,590,000.00",
    "series": {
     "2025": 608935000,
     "2024": 546590000
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "bonds_payable": {
    "label": "应付债券",
    "value": 0,
    "unit": "元",
    "page": null,
    "pdf_page": 83,
    "section": "第八节 财务报告",
    "table": "合并利润表",
    "status": "found",
    "reason": null,
    "alias_matched": "应付债券",
    "unit_raw": "元",
    "raw_text": "应付债券 0.00 3,412,855,688.26",
    "series": {
     "2025": 0,
     "2024": 3412855688.26
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "total_equity": {
    "label": "所有者权益合计",
    "value": 18036176625.46,
    "unit": "元",
    "page": null,
    "pdf_page": 81,
    "section": "第八节 财务报告",
    "table": "第八节 财务报告",
    "status": "found",
    "reason": null,
    "alias_matched": "所有者权益合计",
    "unit_raw": "元",
    "raw_text": "所有者权益合计 18,036,176,625.46 13,324,570,623.28",
    "series": {
     "2025": 18036176625.46,
     "2024": 13324570623.28
    },
    "confidence": 0.95,
    "basis": "合并"
   },
   "cash_received_from_sales": {
    "label": "销售商品、提供劳务收到的现金",
    "value": 5804852527.65,
    "unit": "元",
    "page": null,
    "pdf_page": 86,
    "section": "第八节 财务报告",
    "table": "合并现金流量表",
    "status": "found",
    "reason": null,
    "alias_matched": "销售商品、提供劳务收到的现金",
    "unit_raw": "元",
    "raw_text": "销售商品、提供劳务收到的现金 5,804,852,527.65 4,951,520,829.27",
    "series": {
     "2025": 5804852527.65,
     "2024": 4951520829.27
    },
    "confidence": 0.95,
    "basis": "合并"
   }
  },
  "extraction_meta": {
   "pdf": "天赐材料_002709_2025.pdf",
   "pdf_pages": 199,
   "pagemap": {
    "coverage": 0.05,
    "n_detected": 10,
    "n_inferred": 11,
    "n_missing": 178,
    "n_runs": 2,
    "monotonic_ok": false,
    "n_violations": 3,
    "accepted_offsets": [
     -57,
     -39,
     -38,
     -34,
     -33,
     -27
    ]
   }
  }
 }
};
