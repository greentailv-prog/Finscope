/* FinScope 财报研究驾驶舱
 *
 * 两条数据口径严格分开：
 *   online = 东方财富年度三表，快，没有页码；
 *   pdf    = 本地年报解析，慢，每个数带印刷页码。
 * 同一屏只渲染一种口径，不混数。页面上的比率与摘要全部来自后端 cockpit.py，
 * 前端只做格式化和画图，不重算财务指标。
 */
(function () {
  'use strict';

  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  var S = {
    health: null, latestYear: 2025, year: 2025, mode: 'online',
    company: null, report: null,
    data: { online: null, pdf: null },
    job: null, jobTimer: null, pollTimer: null,
    busy: false, userPickedMode: false, lastQuery: '',
    history: []
  };

  // ---------------------------------------------------------------- 基础

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function num(v, d) {
    if (v == null || isNaN(v)) return '—';
    return Number(v).toLocaleString('zh-CN', {
      minimumFractionDigits: d == null ? 2 : d,
      maximumFractionDigits: d == null ? 2 : d
    });
  }

  function moneyParts(v) {
    if (v == null || isNaN(v)) return { main: '—', unit: '' };
    var a = Math.abs(v);
    if (a >= 1e8) return { main: num(v / 1e8, 2), unit: '亿元' };
    if (a >= 1e4) return { main: num(v / 1e4, 1), unit: '万元' };
    return { main: num(v, 0), unit: '元' };
  }

  function money(v) {
    var p = moneyParts(v);
    return p.main + (p.unit ? ' ' + p.unit : '');
  }

  function yi(v, d) {
    if (v == null || isNaN(v)) return '—';
    return num(v / 1e8, d == null ? 2 : d);
  }

  function pct(v, d) {
    if (v == null || isNaN(v)) return '—';
    return num(v, d == null ? 1 : d) + '%';
  }

  function deltaText(v, unit) {
    if (v == null || isNaN(v)) return '';
    var sign = v >= 0 ? '+' : '';
    if (unit === '%') return sign + num(v, 1) + 'pp';
    if (unit === '天') return sign + num(v, 1) + '天';
    return sign + num(v, 2);
  }

  function ratioText(r) {
    if (!r || r.value == null) return '—';
    if (r.unit === '%') return pct(r.value);
    if (r.unit === '天') return num(r.value, 1) + '天';
    if (r.unit === '倍' || r.unit === '次') return num(r.value, 2) + r.unit;
    return num(r.value, 2);
  }

  function yearsOf(d) {
    if (!d) return [];
    var ys = (d.meta && d.meta.years) || [];
    if (!ys.length) {
      var set = {};
      Object.keys(d.financials || {}).forEach(function (k) {
        Object.keys(d.financials[k].series || {}).forEach(function (y) { set[y] = 1; });
      });
      ys = Object.keys(set);
    }
    return ys.map(Number).filter(function (y) { return y > 1990; }).sort(function (a, b) { return a - b; });
  }

  function fin(d, key) { return d && d.financials ? d.financials[key] : null; }
  function rat(d, key) { return d && d.ratios ? d.ratios[key] : null; }

  function seriesOf(d, key, type) {
    var rec = type === 'ratio' ? rat(d, key) : fin(d, key);
    if (!rec) return {};
    return rec.series || {};
  }

  function valueIn(rec, y) {
    if (!rec) return null;
    var s = rec.series || {};
    if (s[String(y)] != null) return Number(s[String(y)]);
    if (String(y) === String(rec.period) && rec.value != null) return Number(rec.value);
    return null;
  }

  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('on');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('on'); }, 3200);
  }

  function setHint(msg, cls) {
    var h = $('#searchHint');
    h.textContent = msg || '';
    h.className = 'search-hint' + (cls ? ' ' + cls : '');
  }

  // ---------------------------------------------------------------- API

  function api(path, opts) {
    opts = opts || {};
    var init = { method: opts.method || 'GET', headers: {} };
    if (opts.json !== undefined) {
      init.method = 'POST';
      init.headers['Content-Type'] = 'application/json';
      init.headers['X-FS-Client'] = '1';
      init.body = JSON.stringify(opts.json);
    }
    return fetch(path, init).then(function (r) {
      return r.text().then(function (t) {
        var d;
        try { d = JSON.parse(t); } catch (e) { d = { error: t.slice(0, 300) }; }
        if (!r.ok) {
          var err = new Error(d.message || d.error || ('HTTP ' + r.status));
          err.code = d.code;
          err.hint = d.hint;
          throw err;
        }
        return d;
      });
    });
  }

  function withTimeout(p, ms) {
    return Promise.race([p, new Promise(function (_, rej) {
      setTimeout(function () { rej(new Error('timeout')); }, ms);
    })]);
  }

  // ---------------------------------------------------------------- 启动

  function boot() {
    bindEvents();
    withTimeout(api('/api/health'), 1800).then(function (h) {
      S.health = h;
      S.latestYear = h.latest_year || (new Date().getFullYear() - 1);
      buildYears();
      setHint('支持 A 股 6 位代码或公司简称。回车搜索。');
    }).catch(function () {
      S.latestYear = new Date().getFullYear() - 1;
      buildYears();
      setHint('没有连上本地服务。联网搜索、下载与解析需要双击「启动问答页.bat」。', 'error');
      $('#searchForm button').disabled = true;
    });
    loadHistory();
    var qs = new URLSearchParams(location.search);
    var code = qs.get('code');
    if (code) {
      $('#searchInput').value = code;
      setTimeout(function () { handleSearch(code, { popup: false }); }, 400);
    }
  }

  function buildYears() {
    var sel = $('#yearSelect');
    sel.innerHTML = '';
    for (var y = S.latestYear; y >= S.latestYear - 4; y--) {
      var o = document.createElement('option');
      o.value = y; o.textContent = y + ' 年报';
      sel.appendChild(o);
    }
    S.year = S.latestYear;
  }

  // ---------------------------------------------------------------- 事件

  function bindEvents() {
    $('#searchForm').addEventListener('submit', function (e) {
      e.preventDefault();
      handleSearch($('#searchInput').value.trim(), { popup: true });
    });
    $('#miniForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var q = $('#miniInput').value.trim();
      if (!q) return;
      $('#searchInput').value = q;
      handleSearch(q, { popup: true });
    });
    $('#newBtn').addEventListener('click', resetView);
    $('#modeSwitch').addEventListener('click', function (e) {
      var b = e.target.closest('[data-mode]');
      if (!b || b.disabled) return;
      S.userPickedMode = true;
      setMode(b.dataset.mode);
    });
    $('#refreshBtn').addEventListener('click', refreshOnline);
    $('#reanalyzeBtn').addEventListener('click', function () {
      if (!S.company) return;
      startJob(S.company.code, S.year);
      toast('已重新提交下载与解析');
    });
    $('#jobToggle').addEventListener('click', function () {
      var log = $('#jobLog');
      log.hidden = !log.hidden;
      this.textContent = log.hidden ? '日志' : '收起日志';
    });
    $('#jobClose').addEventListener('click', function () { $('#jobbar').hidden = true; });
    $('#drawerClose').addEventListener('click', closeDrawer);
    $('#scrim').addEventListener('click', function () { closeDrawer(); closeAssistant(); });
    $('#assistantFab').addEventListener('click', openAssistant);
    $('#assistantClose').addEventListener('click', closeAssistant);
    $('#assistantForm').addEventListener('submit', askAssistant);
    $('#assistantInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        if (e.target.form) e.target.form.requestSubmit();
      }
    });
    $('#railNav').addEventListener('click', function (e) {
      var b = e.target.closest('[data-jump]');
      if (!b) return;
      $$('#railNav button').forEach(function (x) { x.classList.toggle('on', x === b); });
      var el = document.getElementById(b.dataset.jump);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    document.addEventListener('click', function (e) {
      var f = e.target.closest('[data-fin]');
      if (f) { openEvidence('fin', f.dataset.fin); return; }
      var r = e.target.closest('[data-ratio]');
      if (r) { openEvidence('ratio', r.dataset.ratio); return; }
      var h = e.target.closest('[data-hist]');
      if (h) { loadHistoryItem(JSON.parse(decodeURIComponent(h.dataset.hist))); return; }
      var m = e.target.closest('[data-match]');
      if (m) { chooseMatch(JSON.parse(decodeURIComponent(m.dataset.match))); return; }
      if (e.target.closest('[data-cross]')) openCrossCheck();
    });
  }

  // ---------------------------------------------------------------- 搜索

  function handleSearch(query, opts) {
    opts = opts || {};
    if (S.busy) return;
    if (!query) { setHint('先输入股票代码或公司名。'); return; }
    S.busy = true;
    S.lastQuery = query;
    var year = parseInt($('#yearSelect').value, 10) || S.latestYear;
    var tab = null;
    if (opts.popup !== false) {
      tab = window.open('', '_blank');   // 必须同步打开，异步会被浏览器拦截
    }
    $('#searchForm button').disabled = true;
    setHint('正在联网检索公司…');
    $('#searchResults').innerHTML = '';

    api('/api/search?q=' + encodeURIComponent(query) + '&year=' + year)
      .then(function (res) {
        var best = res.best;
        if (!best) throw new Error('没有匹配的公司');
        if (!best.report) {
          if (tab) { try { tab.close(); } catch (e) {} }
          var msg = (best.report_error && best.report_error.message) ||
                    (year + ' 年年报未找到，换一个年度或改用上传 PDF');
          setHint(msg, 'error');
          return;
        }
        if (tab) {
          try { tab.location.href = best.report.page_url; } catch (e) { tab = null; }
        }
        renderSearchResults(res, year);
        selectCompany({
          code: best.code, name: best.name, name_full: best.name_full,
          ticker: best.ticker, exchange: best.exchange_name,
          industry: best.industry, market_cap: best.market_cap
        }, year, best.report);
        setHint('已打开年报页面，后台开始下载与解析。');
      })
      .catch(function (err) {
        if (tab) { try { tab.close(); } catch (e) {} }
        setHint(err.message + (err.hint ? '　' + err.hint : ''), 'error');
        toast(err.message);
      })
      .finally(function () {
        S.busy = false;
        $('#searchForm button').disabled = false;
      });
  }

  function renderSearchResults(res, year) {
    var box = $('#searchResults');
    var bar = $('#matchBar');
    if (!res.matches || res.matches.length <= 1) {
      box.innerHTML = ''; bar.hidden = true; bar.innerHTML = ''; return;
    }
    var others = res.matches.filter(function (m) { return m.code !== res.best.code; });
    if (!others.length) {
      box.innerHTML = ''; bar.hidden = true; bar.innerHTML = ''; return;
    }
    var buttons = others.slice(0, 5).map(function (m) {
      return '<button data-match="' +
        encodeURIComponent(JSON.stringify({ code: m.code, name: m.name, ticker: m.ticker })) +
        '">' + esc(m.name) + ' ' + esc(m.ticker) + '</button>';
    }).join('');
    box.innerHTML = '<div class="result-card"><div class="result-main"><b>其他匹配</b>' +
      '<p>当前已选 ' + esc(res.best.name) + ' ' + esc(res.best.ticker) +
      '。如果这不是你要的公司，点下面切换。</p></div><div class="result-actions">' +
      buttons.replace(/<button /g, '<button class="btn" ') + '</div></div>';
    bar.innerHTML = '<b>其他匹配</b><span>当前 ' + esc(res.best.name) + ' ' +
      esc(res.best.ticker) + '，可切换：</span>' + buttons;
    bar.hidden = false;
  }

  function chooseMatch(m) {
    var year = parseInt($('#yearSelect').value, 10) || S.latestYear;
    $('#matchBar').hidden = true;
    var tab = window.open('', '_blank');
    api('/api/report?code=' + m.code + '&year=' + year).then(function (res) {
      if (tab) tab.location.href = res.report.page_url;
      selectCompany({
        code: m.code, name: m.name, ticker: res.ticker,
        name_full: res.company && res.company.name_full,
        industry: (res.company && res.company.industry) || '未识别',
        exchange: res.company && res.company.exchange,
        market_cap: res.company && res.company.market_cap
      }, year, res.report);
    }).catch(function (err) {
      if (tab) { try { tab.close(); } catch (e) {} }
      toast(err.message);
    });
  }

  // ---------------------------------------------------------------- 选中公司

  function selectCompany(company, year, report) {
    S.company = company;
    S.year = year;
    S.report = report || null;
    S.data = { online: null, pdf: null };
    S.job = null;
    S.mode = 'online';
    S.userPickedMode = false;
    $('#searchView').hidden = true;
    $('#cockpit').hidden = false;
    $('#modeSwitch').hidden = false;
    $('#crumbName').textContent = company.name || company.code;
    updateHeaderSkeleton();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    saveLocalHistory(company, year);

    // 已经解析过的公司先把原文口径顶上来，同时照样重新跑一遍任务。
    tryLoadPdf(company.code, year).then(function (ok) {
      if (ok && !S.data.online) setMode('pdf');
    });
    loadOnline(company.code, year);
    startJob(company.code, year);
  }

  function updateHeaderSkeleton() {
    var c = S.company || {};
    $('#companyKicker').textContent = (c.ticker || '') + ' · ' + (c.industry || '行业未识别');
    $('#companyName').textContent = c.name || c.code || '—';
    $('#companyMeta').innerHTML = '<span>' + esc(S.year) + ' 年报</span>' +
      '<span>加载中…</span>';
    $('#statusStrip').innerHTML = '<span class="pill">正在取数</span>';
    $('#conclusion').innerHTML = '<div class="skeleton" style="height:90px"></div>';
    $('#basis').innerHTML = '';
    $('#kpiGrid').innerHTML = '';
    ['chartGrowth', 'chartProfit', 'chartCash', 'chartSolvency', 'chartEfficiency'].forEach(function (id) {
      document.getElementById(id).innerHTML = '<div class="chart-empty">正在取数…</div>';
    });
    ['growthSide', 'profitSide', 'cashSide', 'solvencySide', 'efficiencySide'].forEach(function (id) {
      document.getElementById(id).innerHTML = '';
    });
    $('#finTable').innerHTML = '';
    $('#ledger').innerHTML = '';
  }

  function loadOnline(code, year, force) {
    return api('/api/online?code=' + code + '&year=' + year + (force ? '&force=1' : ''))
      .then(function (data) {
        if (!S.company || S.company.code !== code) return;
        S.data.online = data;
        if (S.mode !== 'pdf' || !S.data.pdf) {
          S.mode = S.data.pdf && S.mode === 'pdf' ? 'pdf' : 'online';
        }
        renderAll();
        updateModeChips();
      })
      .catch(function (err) {
        if (!S.data.pdf) {
          $('#statusStrip').innerHTML = '<span class="pill bad">在线数据取不到</span>';
          toast('在线数据：' + err.message + (err.hint ? ' ' + err.hint : ''));
        }
      });
  }

  function tryLoadPdf(code, year) {
    return api('/api/cockpit?code=' + code + '&year=' + year + '&mode=pdf')
      .then(function (data) {
        if (!S.company || S.company.code !== code) return false;
        S.data.pdf = data;
        updateModeChips();
        if (!S.data.online || S.mode === 'pdf') {
          S.mode = 'pdf';
          renderAll();
        }
        return true;
      })
      .catch(function () { return false; });
  }

  function setMode(mode) {
    if (mode === 'pdf' && !S.data.pdf) return;
    S.mode = mode;
    updateModeChips();
    renderAll();
  }

  function updateModeChips() {
    $$('#modeSwitch .mode-chip').forEach(function (b) {
      b.classList.toggle('on', b.dataset.mode === S.mode);
      if (b.dataset.mode === 'pdf') {
        b.disabled = !S.data.pdf;
        b.textContent = S.data.pdf ? '年报原文' : '年报原文（解析中）';
      }
    });
  }

  function refreshOnline() {
    if (!S.company) return;
    toast('正在刷新在线数据…');
    loadOnline(S.company.code, S.year, true).then(function () {
      if (S.mode === 'online') toast('在线数据已更新');
    });
  }

  function resetView() {
    S.company = null; S.report = null; S.data = { online: null, pdf: null };
    S.job = null; S.mode = 'online';
    clearTimeout(S.pollTimer);
    $('#jobbar').hidden = true;
    $('#cockpit').hidden = true;
    $('#searchView').hidden = false;
    $('#modeSwitch').hidden = true;
    $('#crumbName').textContent = '新建研究';
    $('#searchResults').innerHTML = '';
    $('#matchBar').hidden = true;
    $('#matchBar').innerHTML = '';
    $('#searchInput').value = '';
    setHint('支持 A 股 6 位代码或公司简称。回车搜索。');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // ---------------------------------------------------------------- 任务

  function startJob(code, year) {
    api('/api/analyze', { json: { code: code, year: year } }).then(function (job) {
      if (!S.company || S.company.code !== code) return;
      S.job = job;
      showJob(job);
      pollJob();
    }).catch(function (err) {
      toast('后台任务没有启动：' + err.message);
    });
  }

  function showJob(job) {
    $('#jobbar').hidden = false;
    updateJob(job);
  }

  function updateJob(job) {
    if (!job) return;
    var label = job.step_label || job.step || '准备中';
    $('#jobStep').textContent = label;
    var p = Math.max(0, Math.min(100, job.percent || 0));
    $('#jobBar').style.width = p + '%';
    $('#jobPct').textContent = p + '%';
    var log = $('#jobLog');
    if (!log.hidden && job.log) {
      log.textContent = job.log.slice(-80).join('\n');
      log.scrollTop = log.scrollHeight;
    }
  }

  function pollJob() {
    clearTimeout(S.pollTimer);
    if (!S.job) return;
    var id = S.job.id;
    S.pollTimer = setTimeout(function () {
      api('/api/job?id=' + encodeURIComponent(id)).then(function (job) {
        if (!S.job || S.job.id !== id) return;
        S.job = job;
        updateJob(job);
        if (job.status === 'done') {
          onJobDone(job);
          return;
        }
        if (job.status === 'failed' || job.status === 'cancelled') {
          toast('解析失败：' + (job.error || '未知原因'));
          setTimeout(function () { $('#jobbar').hidden = true; }, 2500);
          return;
        }
        if (!S.data.pdf && job.step_index >= 4) tryLoadPdf(S.company.code, S.year);
        pollJob();
      }).catch(function () { pollJob(); });
    }, 1500);
  }

  function onJobDone(job) {
    $('#jobBar').style.width = '100%';
    $('#jobPct').textContent = '100%';
    $('#jobStep').textContent = '分析完成';
    tryLoadPdf(S.company.code, S.year).then(function (ok) {
      if (ok) {
        toast('年报原文解析完成，已切换到页码口径');
        if (!S.userPickedMode) setMode('pdf');
      } else {
        toast('分析完成，但原文抽取没有产出，先看在线口径');
      }
      setTimeout(function () { $('#jobbar').hidden = true; }, 1800);
    });
  }

  // ---------------------------------------------------------------- 渲染

  function currentData() {
    return S.mode === 'pdf' ? S.data.pdf : S.data.online;
  }

  function renderAll() {
    var d = currentData();
    if (!d) {
      if (!S.data.online && !S.data.pdf) {
        $('#statusStrip').innerHTML = '<span class="pill warn">正在等在线快照或原文解析</span>';
      }
      return;
    }
    renderHeader(d);
    renderStatus(d);
    renderConclusion(d);
    renderBasis(d);
    renderKpis(d);
    renderGrowth(d);
    renderProfit(d);
    renderCash(d);
    renderSolvency(d);
    renderEfficiency(d);
    renderTable(d);
    renderLedger(d);
    updateModeChips();
  }

  function renderHeader(d) {
    var c = d.company || {};
    var m = d.meta || {};
    var name = c.name_short || c.name || (S.company && S.company.name) || c.ticker || '—';
    $('#companyName').textContent = name;
    $('#companyKicker').textContent = [c.ticker, c.industry, m.report_period + ' 年报']
      .filter(Boolean).join(' · ');
    var meta = [
      c.exchange, c.report_type || '年度报告', c.scope,
      m.mode_label, m.data_as_of ? '数据日期 ' + m.data_as_of : null
    ].filter(Boolean);
    $('#companyMeta').innerHTML = meta.map(function (x) {
      return '<span>' + esc(x) + '</span>';
    }).join('');
    var page = (S.report && S.report.page_url) || c.source_url;
    var link = $('#reportLink');
    if (page) { link.href = page; link.hidden = false; } else { link.hidden = true; }
    var pdf = m.pdf_url || (d.report && d.report.pdf_url);
    var pl = $('#pdfLink');
    if (pdf) { pl.href = pdf; pl.hidden = false; } else { pl.hidden = true; }
    $('#crumbName').textContent = name;
  }

  function renderStatus(d) {
    var m = d.meta || {}, cov = d.coverage || {}, q = d.data_quality || {};
    var pills = [];
    pills.push('<span class="pill ' + (d.mode === 'pdf' ? 'good' : '') + '">' +
      (m.mode_label || (d.mode === 'pdf' ? '年报原文' : '在线快照')) + '</span>');
    var p0 = cov.p0_found != null ? cov.p0_found : 0;
    var p0t = cov.p0_total || 30;
    var cls = p0 / p0t >= 0.9 ? 'good' : (p0 / p0t >= 0.6 ? 'warn' : 'bad');
    var miss = (cov.p0_missing || []).map(function (k) {
      var f = fin(d, k); return f ? (f.label || k) : k;
    });
    pills.push('<span class="pill ' + cls + '" title="' +
      esc(miss.length ? '未取到：' + miss.join('、') + '（部分科目可能公司确实没有）' : '30 个 P0 全部取到') +
      '">P0 科目 ' + p0 + '/' + p0t + '</span>');
    var qcls = q.status === 'ok' ? 'good' : (q.status === 'blocked' ? 'bad' : 'warn');
    var qtxt = q.status === 'ok' ? '数据质量通过' : (q.status === 'blocked' ? '数据质量阻断' : '数据质量有提示');
    pills.push('<span class="pill ' + qcls + '">' + qtxt + '</span>');
    if (d.industry_support === 'unsupported') {
      pills.push('<span class="pill warn">该行业不支持标准估值</span>');
    } else if (d.industry_support === 'limited') {
      pills.push('<span class="pill warn">行业未识别，按通用口径</span>');
    }
    if (d.mode === 'pdf') pills.push('<span class="pill">页码可回原文</span>');
    else pills.push('<span class="pill">在线模式无页码</span>');
    if (S.job && S.job.status !== 'done') {
      pills.push('<span class="pill warn">原文解析 ' + (S.job.percent || 0) + '%</span>');
    }
    var diffs = crossDiffs();
    if (diffs) {
      if (!diffs.length) {
        pills.push('<span class="pill good">双口径交叉校验通过</span>');
      } else {
        pills.push('<span class="pill bad" data-cross="1" style="cursor:pointer">双口径差异 ' +
          diffs.length + ' 项</span>');
      }
    }
    $('#statusStrip').innerHTML = pills.join('');
  }

  var CROSS_KEYS = ['revenue', 'net_income_parent', 'total_assets', 'total_liabilities',
    'total_equity', 'cash_and_equivalents', 'cfo'];

  function crossDiffs() {
    if (!S.data.online || !S.data.pdf) return null;
    var out = [];
    CROSS_KEYS.forEach(function (k) {
      var a = fin(S.data.online, k), b = fin(S.data.pdf, k);
      if (!a || !b || a.value == null || b.value == null) return;
      var base = Math.max(Math.abs(a.value), Math.abs(b.value), 1);
      var rel = Math.abs(a.value - b.value) / base;
      if (rel > 0.01) {
        out.push({ key: k, label: b.label || a.label || k, online: a.value, pdf: b.value, rel: rel });
      }
    });
    return out;
  }

  function openCrossCheck() {
    var diffs = crossDiffs();
    if (!diffs || !diffs.length) return;
    var rows = diffs.map(function (x) {
      return '<div class="metric-row"><span class="nm">' + esc(x.label) + '</span>' +
        '<span class="vl" style="font-size:10.5px">在线 ' + esc(money(x.online)) +
        ' / 原文 ' + esc(money(x.pdf)) + '<span class="ex">' + (x.rel * 100).toFixed(1) + '%</span></span></div>';
    }).join('');
    $('#drawerKicker').textContent = 'CROSS CHECK / TWO SOURCES';
    $('#drawerTitle').textContent = '双口径交叉校验';
    $('#drawerBody').innerHTML =
      '<div class="ev-sub">同一科目在“在线三表”和“年报 PDF 抽取”之间的差异。超过 1% 会列在这里。</div>' +
      '<div class="ev-block"><h4>差异科目</h4>' + rows + '</div>' +
      '<div class="ev-block"><h4>怎么读</h4><div class="side-note">' +
      '常见原因：合并/母公司口径混用、上年数重述、附注与主表口径不同、字段映射错。' +
      '如果负债合计与权益合计同时偏移、差额相等且方向相反，多半是其他权益工具（永续债）' +
      '在负债与权益之间的分类差异。出现差异时，先以年报原文页为准；在线数值只作快照。</div></div>';
    $('#drawer').classList.add('open');
    $('#drawer').setAttribute('aria-hidden', 'false');
    $('#scrim').hidden = false;
  }

  function renderConclusion(d) {
    var s = d.summary || {};
    var points = (s.points || []).map(function (p) {
      return '<span class="point-chip ' + esc(p.tone || '') + '"><b>' + esc(p.label) +
        '</b>' + esc(p.text) + '</span>';
    }).join('');
    $('#conclusion').innerHTML =
      '<div class="ck">RESEARCH NOTE · ' + esc((d.company && d.company.ticker) || '') + '</div>' +
      '<h2>' + esc(s.headline || '暂无可生成的结论') + '</h2>' +
      '<div class="points">' + points + '</div>' +
      '<div class="focus"><b>研究重点</b>　' + esc(s.focus || '') +
      '　·　' + esc(s.quality_note || '') + '</div>';
  }

  function renderBasis(d) {
    var m = d.meta || {}, c = d.company || {};
    var items = [
      ['币种', c.currency || m.currency || 'CNY'],
      ['单位', '元（页面金额折算为亿元）'],
      ['口径', c.scope || '合并报表'],
      ['期间', (m.report_period || S.year) + ' 年度'],
      ['来源', d.mode === 'pdf' ? '公司年报 PDF' : '东方财富年度报表'],
      ['数据日期', m.data_as_of || '—'],
      ['模式', m.mode_label || d.mode]
    ];
    $('#basis').innerHTML = items.map(function (x) {
      return '<div><b>' + esc(x[0]) + '</b>' + esc(x[1]) + '</div>';
    }).join('');
  }

  function kpiCard(o) {
    var main, unit, sub, delta = '', spark = '', click = '', missing = '';
    if (o.type === 'ratio') {
      var r = rat(o.d, o.key);
      if (!r || r.value == null) {
        main = '—'; unit = ''; sub = '该口径未覆盖';
        missing = 'missing';
      } else {
        main = ratioText(r).replace(/(%|天|倍|次)$/, '');
        unit = (ratioText(r).match(/(%|天|倍|次)$/) || [''])[0];
        sub = r.delta != null ? ('较上期 ' + deltaText(r.delta, r.unit)) : (r.name || '');
        click = 'data-ratio="' + esc(o.key) + '"';
        var rvals = yearsOf(o.d).map(function (y) { return (r.series || {})[String(y)]; });
        spark = '<div class="spark">' + sparkline(rvals, o.color || '#3e5f86') + '</div>';
      }
    } else {
      var f = fin(o.d, o.key);
      if (!f || f.value == null) {
        main = '—'; unit = ''; sub = '该口径未覆盖'; missing = 'missing';
      } else {
        var p = moneyParts(f.value);
        main = p.main; unit = p.unit;
        var g = o.subRatio ? rat(o.d, o.subRatio) : null;
        sub = o.subLabel || (f.label || '');
        if (g && g.value != null) sub = o.subLabel + ' ' + ratioText(g);
        click = 'data-fin="' + esc(o.key) + '"';
        var vals = yearsOf(o.d).map(function (y) { return valueIn(f, y); });
        spark = '<div class="spark">' + sparkline(vals, o.color || '#3e5f86') + '</div>';
      }
    }
    return '<button class="kpi" ' + click + ' type="button">' +
      '<span class="num">' + esc(o.no) + '</span>' +
      '<span class="label">' + esc(o.label) + delta + '</span>' +
      '<span class="value">' + esc(main) + (unit ? '<small>' + esc(unit) + '</small>' : '') + '</span>' +
      '<span class="sub">' + esc(sub) + '</span>' + spark + '</button>';
  }

  function renderKpis(d) {
    var cards = [
      { no: '01', label: '营业收入', key: 'revenue', type: 'fin', subRatio: 'revenue_growth_yoy', subLabel: '同比', color: '#3e5f86' },
      { no: '02', label: '归母净利润', key: 'net_income_parent', type: 'fin', subRatio: 'net_income_parent_growth_yoy', subLabel: '同比', color: '#2f6f5f' },
      { no: '03', label: '毛利率', key: 'gross_margin', type: 'ratio', color: '#3e5f86' },
      { no: '04', label: 'ROE', key: 'roe', type: 'ratio', color: '#2f6f5f' },
      { no: '05', label: '经营现金流', key: 'cfo', type: 'fin', subRatio: 'net_cash_ratio', subLabel: '净现比', color: '#d97706' },
      { no: '06', label: '资产负债率', key: 'debt_to_asset', type: 'ratio', color: '#a8432f' },
      { no: '07', label: '净现比', key: 'net_cash_ratio', type: 'ratio', color: '#d97706' },
      { no: '08', label: '流动比率', key: 'current_ratio', type: 'ratio', color: '#3e5f86' }
    ];
    // 没有流动比率时换成总资产周转率，避免卡位空着
    if (!rat(d, 'current_ratio') || rat(d, 'current_ratio').value == null) {
      cards[7] = { no: '08', label: '总资产周转率', key: 'asset_turnover', type: 'ratio' };
    }
    $('#kpiGrid').innerHTML = cards.map(function (o) {
      o.d = d; return kpiCard(o);
    }).join('');
  }

  function sideRow(label, value, attr, extra, cls) {
    var click = attr ? ' ' + attr + ' data-click="1"' : '';
    return '<div class="metric-row"><span class="nm">' + esc(label) + '</span>' +
      '<span class="vl' + (attr ? ' clickable' : '') + '"' + click + '>' + esc(value) +
      (extra ? '<span class="ex">' + esc(extra) + '</span>' : '') + '</span></div>';
  }

  function ratioRow(d, key, label, extra) {
    var r = rat(d, key);
    if (!r) return sideRow(label, '—', null, '未覆盖');
    var v = ratioText(r);
    var ex = r.delta != null ? deltaText(r.delta, r.unit) : (extra || '');
    return sideRow(label, v, 'data-ratio="' + esc(key) + '"', ex);
  }

  function finRow(d, key, label) {
    var f = fin(d, key);
    if (!f || f.value == null) return sideRow(label, '—', null, '未覆盖');
    return sideRow(label, money(f.value), 'data-fin="' + esc(key) + '"', f.label);
  }

  function renderGrowth(d) {
    var ys = yearsOf(d);
    var rev = fin(d, 'revenue'), ni = fin(d, 'net_income_parent');
    var series = [];
    if (rev) series.push({ name: '营业收入', color: '#3e5f86', unit: 'money', values: ys.map(function (y) { return valueIn(rev, y); }) });
    if (ni) series.push({ name: '归母净利润', color: '#d97706', unit: 'money', values: ys.map(function (y) { return valueIn(ni, y); }) });
    lineChart($('#chartGrowth'), ys, series, { unit: 'money', zero: true });
    $('#growthNote').textContent = ys.length + ' 个年度 · 单位亿元';
    var rows = [
      ratioRow(d, 'revenue_growth_yoy', '营业收入同比'),
      ratioRow(d, 'net_income_parent_growth_yoy', '归母净利同比'),
      ratioRow(d, 'net_income_growth_yoy', '净利润同比'),
      ratioRow(d, 'asset_turnover', '总资产周转率')
    ];
    $('#growthSide').innerHTML = '<h4>增长与规模</h4>' + rows.join('') +
      '<div class="side-note">同比按合并口径、本期/上期计算。出现负增长时先看价格、销量与产品结构，不要直接用“行业下行”解释。</div>';
  }

  function renderProfit(d) {
    var ys = yearsOf(d);
    var specs = [
      ['gross_margin', '毛利率', '#3e5f86'],
      ['net_margin_parent', '归母净利率', '#d97706'],
      ['roe', 'ROE', '#2f6f5f']
    ];
    var series = specs.map(function (s) {
      var r = rat(d, s[0]);
      return r ? { name: s[1], color: s[2], unit: 'pct', values: ys.map(function (y) { return (r.series || {})[String(y)]; }) } : null;
    }).filter(Boolean);
    lineChart($('#chartProfit'), ys, series, { unit: 'pct' });
    $('#profitNote').textContent = 'ROE 用平均归母净资产';
    var rows = specs.map(function (s) { return ratioRow(d, s[0], s[1]); });
    rows.push(ratioRow(d, 'roa', 'ROA'));
    rows.push(ratioRow(d, 'ebitda_margin', 'EBITDA 利润率'));
    $('#profitSide').innerHTML = '<h4>回报与利润率</h4>' + rows.join('') +
      '<div class="side-note">毛利率看产品与成本，净利率看费用与税负，ROE 还要看杠杆。三个一起看，避免把加杠杆带来的高 ROE 当成经营改善。</div>';
  }

  function renderCash(d) {
    var ys = yearsOf(d);
    var cfo = fin(d, 'cfo'), ni = fin(d, 'net_income_parent');
    var series = [];
    if (cfo) series.push({ name: '经营现金流', color: '#2f6f5f', unit: 'money', values: ys.map(function (y) { return valueIn(cfo, y); }) });
    if (ni) series.push({ name: '归母净利润', color: '#d97706', unit: 'money', values: ys.map(function (y) { return valueIn(ni, y); }) });
    barChart($('#chartCash'), ys, series, { unit: 'money' });
    $('#cashNote').textContent = '经营现金流 vs 归母净利';
    var rows = [
      ratioRow(d, 'net_cash_ratio', '净现比'),
      ratioRow(d, 'cfo_to_revenue', '经营现金流/收入'),
      ratioRow(d, 'fcf_margin', '自由现金流利润率'),
      ratioRow(d, 'cash_received_ratio', '销售收现比')
    ];
    $('#cashSide').innerHTML = '<h4>利润的含金量</h4>' + rows.join('') +
      '<div class="side-note">净现比长期低于 80%，通常意味着利润更多停在应收、存货或合同资产里。先核对资产负债表，再解释行业账期。</div>';
  }

  function renderSolvency(d) {
    var ys = yearsOf(d);
    var liab = fin(d, 'total_liabilities'), eq = fin(d, 'total_equity') || fin(d, 'equity_parent');
    var series = [];
    if (liab) series.push({ name: '负债', color: '#a8432f', values: ys.map(function (y) { return valueIn(liab, y); }) });
    if (eq) series.push({ name: '权益', color: '#3e5f86', values: ys.map(function (y) { return valueIn(eq, y); }) });
    stackedBar($('#chartSolvency'), ys, series, { unit: 'money' });
    var missLiab = liab ? ys.filter(function (y) { return valueIn(liab, y) == null; }) : [];
    $('#solvencyNote').textContent = missLiab.length
      ? ('负债 / 权益 · 缺 ' + missLiab.join('、') + ' 年负债')
      : '负债 / 权益 · 单位亿元';
    var rows = [
      ratioRow(d, 'debt_to_asset', '资产负债率'),
      ratioRow(d, 'current_ratio', '流动比率'),
      ratioRow(d, 'cash_ratio', '现金比率'),
      ratioRow(d, 'net_debt_to_equity', '净负债率'),
      ratioRow(d, 'interest_coverage', '利息保障倍数')
    ];
    $('#solvencySide').innerHTML = '<h4>杠杆与流动性</h4>' + rows.join('') +
      '<div class="side-note">负债率要结合行业与负债结构看。有息负债、一年内到期债务和货币资金三项，比单看负债率更能说明短期压力。</div>';
  }

  function renderEfficiency(d) {
    var ys = yearsOf(d);
    var ar = rat(d, 'ar_turnover_days'), inv = rat(d, 'inventory_turnover_days');
    // 应收几天、存货上千天，量级差三个数量级，放一根轴上会把应收压成一条直线。
    // 拆成两张小图，各自一个纵轴。
    var host = $('#chartEfficiency');
    host.innerHTML = '<div class="chart-split">' +
      '<div><div class="mini-title">应收账款周转天数</div><div id="effAr"></div></div>' +
      '<div><div class="mini-title">存货周转天数</div><div id="effInv"></div></div>' +
      '</div>';
    lineChart($('#effAr'), ys, ar ? [{
      name: '应收天数', color: '#3e5f86', unit: 'days',
      values: ys.map(function (y) { return (ar.series || {})[String(y)]; })
    }] : [], { unit: 'days' });
    lineChart($('#effInv'), ys, inv ? [{
      name: '存货天数', color: '#d97706', unit: 'days',
      values: ys.map(function (y) { return (inv.series || {})[String(y)]; })
    }] : [], { unit: 'days' });
    $('#efficiencyNote').textContent = '两张图各自纵轴';
    var rows = [
      ratioRow(d, 'ar_turnover_days', '应收账款周转天数'),
      ratioRow(d, 'inventory_turnover_days', '存货周转天数'),
      ratioRow(d, 'asset_turnover', '总资产周转率'),
      ratioRow(d, 'rd_to_revenue', '研发费用率'),
      ratioRow(d, 'capex_to_revenue', '资本开支/收入')
    ];
    $('#efficiencySide').innerHTML = '<h4>周转与投入</h4>' + rows.join('') +
      '<div class="side-note">周转天数用期末与期初平均值。白酒、地产等行业的存货周期天然很长，存货天数高不等于管理差，要和同业比。</div>';
  }

  // ---------------------------------------------------------------- 表格与台账

  var TABLE_GROUPS = [
    ['利润表', ['revenue', 'operating_cost', 'operating_profit', 'pretax_profit', 'income_tax_expense',
      'net_income', 'net_income_parent', 'net_income_excl_nonrecurring', 'selling_expense',
      'admin_expense', 'finance_expense', 'interest_expense', 'depreciation_amortization',
      'rnd_expense', 'impairment_loss']],
    ['资产负债表', ['cash_and_equivalents', 'accounts_receivable', 'notes_receivable', 'inventory',
      'contract_assets', 'current_assets', 'total_assets', 'accounts_payable', 'current_liabilities',
      'short_term_borrowings', 'current_portion_lt_debt', 'long_term_borrowings', 'bonds_payable',
      'total_liabilities', 'equity_parent', 'total_equity', 'fixed_assets', 'goodwill', 'rd_capitalized']],
    ['现金流量表', ['cfo', 'cfi', 'cff', 'capex', 'cash_received_from_sales', 'interest_paid',
      'dividend_paid', 'cash_net_increase']]
  ];

  function renderTable(d) {
    var ys = yearsOf(d).slice(-3);
    var head = '<thead><tr><th>科目</th>' + ys.map(function (y) { return '<th>' + y + '</th>'; }).join('') +
      '<th>最新同比</th></tr></thead>';
    var body = '';
    var count = 0;
    TABLE_GROUPS.forEach(function (g) {
      var rows = '';
      g[1].forEach(function (key) {
        var f = fin(d, key);
        if (!f) return;
        rows += '<tr><td>' + esc(f.label || key) + '</td>' + ys.map(function (y) {
          var v = valueIn(f, y);
          return v == null
            ? '<td class="muted">—</td>'
            : '<td class="clickable" data-fin="' + esc(key) + '" title="' + esc(num(v, 2)) + ' 元">' + esc(yi(v, 2)) + '</td>';
        }).join('');
        var latest = valueIn(f, ys[ys.length - 1]);
        var prev = valueIn(f, ys[ys.length - 2]);
        var yoy = (latest != null && prev != null && prev !== 0) ? (latest / prev - 1) * 100 : null;
        rows += '<td class="' + (yoy != null && yoy < 0 ? 'bad' : '') + '">' +
          (yoy == null ? '—' : (yoy >= 0 ? '+' : '') + num(yoy, 1) + '%') + '</td></tr>';
        count++;
      });
      if (rows) body += '<tr class="sec"><td colspan="' + (ys.length + 2) + '">' + g[0] + '</td></tr>' + rows;
    });
    $('#finTable').innerHTML = head + '<tbody>' + (body || '<tr><td colspan="' + (ys.length + 2) +
      '" class="muted">该口径没有可展示的科目</td></tr>') + '</tbody>';
    $('#tableNote').textContent = '单位亿元 · ' + count + ' 个科目';
  }

  function renderLedger(d) {
    var rows = (d.sources || []).map(function (s) {
      var f = fin(d, s.metric);
      var label = f ? (f.label || s.metric) : s.metric;
      var where = s.source_type === 'pdf'
        ? ('印刷 P.' + (s.page == null ? '—' : s.page) + ' · PDF ' + (s.pdf_page == null ? '—' : s.pdf_page))
        : ('字段 ' + (s.source_field || '—'));
      var href = s.source_type === 'pdf'
        ? (s.pdf_url ? s.pdf_url + '#page=' + (s.pdf_page || 1) : null)
        : s.source_url;
      return '<div class="ledger-row">' +
        '<span class="sid">' + esc(s.source_id || '—') + '</span>' +
        '<span><button class="link-btn" data-fin="' + esc(s.metric) + '">' + esc(label) + '</button></span>' +
        '<span class="src">' + esc(s.source || '') + '</span>' +
        '<span style="text-align:right;color:var(--muted);font-size:9.5px">' + esc(where) + '</span>' +
        '</div>';
    }).join('');
    $('#ledger').innerHTML = '<div class="ledger-row head"><span>编号</span><span>科目</span><span>来源</span><span style="text-align:right">位置</span></div>' +
      (rows || '<div class="ledger-row"><span></span><span class="muted">暂无来源</span><span></span><span></span></div>');
    $('#evidenceNote').textContent = (d.sources || []).length + ' 条来源';
  }

  // ---------------------------------------------------------------- 证据抽屉

  function openEvidence(type, key) {
    var d = currentData();
    if (!d) return;
    var body = '';
    var title = key;
    if (type === 'ratio') {
      var r = rat(d, key);
      if (!r) return;
      title = r.name;
      body += '<div class="ev-value">' + esc(ratioText(r)) + '</div>';
      body += '<div class="ev-sub">' + esc(r.name) + ' · ' + esc(r.unit) +
        (r.delta != null ? ' · 较上期 ' + esc(deltaText(r.delta, r.unit)) : '') + '</div>';
      body += '<div class="ev-block"><h4>计算口径</h4><div class="ev-formula">' + esc(r.formula) + '</div>';
      body += '<div class="ev-inputs">';
      Object.keys(r.inputs || {}).forEach(function (k) {
        var v = r.inputs[k];
        if (k === 'note') {
          body += '<div class="ev-input"><span>' + esc(v) + '</span><b></b></div>';
          return;
        }
        var base = k.replace(/^prior_/, '');
        var f = fin(d, base);
        var label = f ? f.label : base;
        var val = v == null ? '—'
          : (typeof v === 'number' ? (Math.abs(v) >= 1e6 ? money(v) : num(v, 2)) : String(v));
        body += '<div class="ev-input" ' + (f ? 'data-fin="' + esc(base) + '"' : '') + '>' +
          '<span>' + esc(label) + '</span><b>' + esc(val) + '</b></div>';
      });
      body += '</div></div>';
      body += '<div class="ev-block"><h4>依赖科目</h4><div class="ev-kv"><dt>字段</dt><dd>' +
        esc((r.source_fields || []).join('、')) + '</dd></div></div>';
    } else {
      var f = fin(d, key);
      if (!f) return;
      title = f.label || key;
      body += '<div class="ev-value">' + esc(money(f.value)) + '</div>';
      body += '<div class="ev-sub">' + esc(f.label) + ' · ' + esc(f.period) + ' 年 · ' + esc(f.scope || '合并报表') + '</div>';
      body += '<div class="ev-block"><h4>年度序列</h4><div class="ev-kv">';
      var ys = yearsOf(d);
      ys.forEach(function (y) {
        var v = valueIn(f, y);
        body += '<dt>' + y + '</dt><dd>' + (v == null ? '—' : money(v) + '（' + num(v, 2) + ' 元）') + '</dd>';
      });
      body += '</div></div>';
      body += '<div class="ev-block"><h4>来源</h4><div class="ev-kv">' +
        '<dt>类型</dt><dd>' + (f.source_type === 'pdf' ? '年报 PDF' : '在线数据源') + '</dd>' +
        '<dt>来源</dt><dd>' + esc(f.source || '—') + '</dd>' +
        '<dt>口径</dt><dd>' + esc(f.scope || '—') + '</dd>' +
        '<dt>状态</dt><dd>' + esc(f.status || '—') + '</dd>' +
        (f.status_note ? '<dt>备注</dt><dd>' + esc(f.status_note) + '</dd>' : '');
      if (f.source_type === 'pdf') {
        body += '<dt>印刷页码</dt><dd>' + (f.page == null ? '—' : 'P.' + f.page) + '</dd>' +
          '<dt>PDF 页</dt><dd>' + (f.pdf_page == null ? '—' : f.pdf_page) + '</dd>' +
          '<dt>表/章节</dt><dd>' + esc(f.table || f.section || '—') + '</dd>';
      } else {
        body += '<dt>数据字段</dt><dd>' + esc(f.source_field || '—') + '</dd>';
      }
      body += '</div></div>';
      if (f.raw_text) {
        body += '<div class="ev-block"><h4>原文片段</h4><div class="quote">' + esc(f.raw_text) + '</div></div>';
      }
      var src = (d.sources || []).filter(function (s) { return s.metric === key; })[0];
      var href = src ? (src.source_type === 'pdf'
        ? (src.pdf_url ? src.pdf_url + '#page=' + (src.pdf_page || 1) : null)
        : src.source_url) : null;
      body += '<div class="ev-actions">';
      if (href) body += '<a class="btn primary" href="' + esc(href) + '" target="_blank" rel="noopener">' +
        (f.source_type === 'pdf' ? '打开 PDF 第 ' + (f.pdf_page || 1) + ' 页' : '打开数据源') + '</a>';
      if (S.report && S.report.page_url) body += '<a class="btn" href="' + esc(S.report.page_url) + '" target="_blank" rel="noopener">年报公告页</a>';
      body += '</div>';
    }
    var checks = ((d.data_quality || {}).checks || []).filter(function (c) {
      return c.metric === key || (c.detail || '').indexOf(title) >= 0;
    });
    if (checks.length) {
      body += '<div class="ev-block"><h4>相关数据检查</h4><div class="quality-list">' + checks.map(function (c) {
        return '<div class="quality-item ' + esc(c.status) + '"><span class="dot"></span><div>' +
          '<b>' + esc(c.code) + ' · ' + esc(c.status) + '</b>' + esc(c.detail) + '</div></div>';
      }).join('') + '</div></div>';
    }
    $('#drawerKicker').textContent = type === 'ratio' ? 'RATIO / CALCULATION' : 'FINANCIAL / EVIDENCE';
    $('#drawerTitle').textContent = title;
    $('#drawerBody').innerHTML = body;
    $('#drawer').classList.add('open');
    $('#drawer').setAttribute('aria-hidden', 'false');
    $('#scrim').hidden = false;
  }

  function closeDrawer() {
    $('#drawer').classList.remove('open');
    $('#drawer').setAttribute('aria-hidden', 'true');
    if (!$('#assistant').classList.contains('open')) $('#scrim').hidden = true;
  }

  // ---------------------------------------------------------------- 最近研究

  function shorten(n) {
    return String(n || '').replace(/股份有限公司$|有限公司$|集团股份有限公司$|集团$/, '') || n;
  }

  function localHistory() {
    try { return JSON.parse(localStorage.getItem('finscope.history') || '[]'); } catch (e) { return []; }
  }

  function saveLocalHistory(c, year) {
    var arr = localHistory().filter(function (x) { return !(x.code === c.code && x.year === year); });
    arr.unshift({ code: c.code, name: c.name, ticker: c.ticker, year: year, at: Date.now() });
    localStorage.setItem('finscope.history', JSON.stringify(arr.slice(0, 12)));
    loadHistory();
  }

  function loadHistory() {
    var local = localHistory();
    api('/api/history').then(function (res) {
      var seen = {};
      var items = [];
      (res.items || []).forEach(function (x) {
        var k = x.code + '_' + x.year;
        if (seen[k]) return;
        seen[k] = 1;
        items.push(x);
      });
      local.forEach(function (x) {
        if (!seen[x.code + '_' + x.year]) {
          seen[x.code + '_' + x.year] = 1;
          items.push({ code: x.code, name: x.name, ticker: x.ticker, year: x.year,
            analyzed_at: new Date(x.at).toISOString(), status: 'local', unified_exists: false,
            report_exists: false, source_mode: 'online' });
        }
      });
      items.sort(function (a, b) { return String(b.analyzed_at || '').localeCompare(String(a.analyzed_at || '')); });
      S.history = items.slice(0, 12);
      renderHistory();
    }).catch(function () {
      S.history = local.map(function (x) {
        return { code: x.code, name: x.name, ticker: x.ticker, year: x.year,
          analyzed_at: new Date(x.at).toISOString(), status: 'local' };
      });
      renderHistory();
    });
  }

  function renderHistory() {
    var items = S.history || [];
    var rail = $('#railHistory');
    var grid = $('#recentGrid');
    $('#recentCount').textContent = items.length + ' 条';
    if (!items.length) {
      rail.innerHTML = '<div class="empty">还没有分析记录。<br>搜索一家公司开始。</div>';
      grid.innerHTML = '<div class="recent-empty">还没有分析记录。输入代码或公司名，第一次研究会出现在这里。</div>';
      return;
    }
    rail.innerHTML = items.slice(0, 8).map(function (x) {
      return '<button class="hist-item" data-hist="' + encodeURIComponent(JSON.stringify(x)) + '">' +
        '<b>' + esc(shorten(x.name) || x.code) + '</b>' +
        '<span>' + esc(x.code) + ' · ' + esc(x.year) + '</span></button>';
    }).join('');
    grid.innerHTML = items.slice(0, 8).map(function (x) {
      var when = String(x.analyzed_at || '').slice(0, 16).replace('T', ' ');
      return '<button class="recent-card" data-hist="' + encodeURIComponent(JSON.stringify(x)) + '">' +
        '<b>' + esc(shorten(x.name) || x.code) + '</b>' +
        '<span class="code">' + esc(x.code) + ' · ' + esc(x.year) + ' 年报</span>' +
        '<span class="meta"><span>' + esc(x.unified_exists ? '原文已解析' : (x.status === 'running' ? '解析中' : '在线口径')) + '</span>' +
        '<span>' + esc(when) + '</span></span></button>';
    }).join('');
  }

  function loadHistoryItem(item) {
    if (!item || !item.code) return;
    var year = parseInt(item.year, 10) || S.latestYear;
    $('#yearSelect').value = year;
    S.company = { code: item.code, name: item.name || item.code, ticker: item.ticker };
    S.year = year; S.report = null; S.data = { online: null, pdf: null };
    S.mode = 'online'; S.userPickedMode = false; S.job = null;
    $('#searchView').hidden = true;
    $('#cockpit').hidden = false;
    $('#modeSwitch').hidden = false;
    $('#crumbName').textContent = item.name || item.code;
    updateHeaderSkeleton();
    tryLoadPdf(item.code, year).then(function (ok) {
      if (!ok) loadOnline(item.code, year);
      else if (!S.userPickedMode) setMode('pdf');
    });
    // 历史记录也要取在线数据：用户可能想切到在线口径看全 30 个 P0。
    loadOnline(item.code, year);
  }

  // ---------------------------------------------------------------- 助手

  function openAssistant() {
    if (!S.company) { toast('先在首页搜索并选中一家公司'); return; }
    $('#assistant').classList.add('open');
    $('#assistant').setAttribute('aria-hidden', 'false');
    $('#scrim').hidden = false;
    $('#assistantFab').hidden = true;
    setTimeout(function () { $('#assistantInput').focus(); }, 120);
  }

  function closeAssistant() {
    $('#assistant').classList.remove('open');
    $('#assistant').setAttribute('aria-hidden', 'true');
    $('#assistantFab').hidden = false;
    if (!$('#drawer').classList.contains('open')) $('#scrim').hidden = true;
  }

  function askAssistant(e) {
    e.preventDefault();
    var q = $('#assistantInput').value.trim();
    if (!q) return;
    if (!S.company) { toast('先选中一家公司'); return; }
    var box = $('#assistantScroll');
    box.insertAdjacentHTML('beforeend', '<div class="assistant-msg user">' + esc(q) + '</div>');
    $('#assistantInput').value = '';
    var pending = document.createElement('div');
    pending.className = 'assistant-msg';
    pending.textContent = '正在检索年报…';
    box.appendChild(pending);
    box.scrollTop = box.scrollHeight;

    api('/api/ask', { json: { q: q, codes: [S.company.code], use_search: false } })
      .then(function (res) {
        pending.remove();
        if (res.mode === 'llm_not_configured') {
          var ev = (res.evidence || []).slice(0, 3).map(function (x) {
            return (x.text || '').slice(0, 180) + (x.page ? '（P.' + x.page + '）' : '');
          }).join('\n\n');
          box.insertAdjacentHTML('beforeend', '<div class="assistant-msg">尚未配置大模型，先把检索到的原文放这里：' +
            '<div class="quote" style="margin-top:8px">' + esc(ev || '没有检索到相关片段') + '</div></div>');
        } else {
          var text = res.answer || '没有生成回答';
          var cites = (res.citations || res.evidence || []).filter(function (x) { return x.used; }).slice(0, 4);
          var citeHtml = cites.map(function (x) {
            var where = x.page ? 'P.' + x.page : (x.source_field || '');
            return '<span class="cite">[' + esc(x.n || '') + '] ' + esc(where) + '　' + esc((x.text || '').slice(0, 90)) + '…</span>';
          }).join('');
          box.insertAdjacentHTML('beforeend', '<div class="assistant-msg">' + esc(text).replace(/\n/g, '<br>') + citeHtml + '</div>');
        }
        box.scrollTop = box.scrollHeight;
      })
      .catch(function (err) {
        pending.textContent = '问答失败：' + err.message;
      });
  }

  // ---------------------------------------------------------------- 图表

  function fmtAxis(v, unit) {
    if (v == null || isNaN(v)) return '';
    if (unit === 'money') {
      var a = Math.abs(v);
      if (a >= 1e8) return num(v / 1e8, a >= 1e10 ? 0 : 1);
      if (a >= 1e4) return num(v / 1e4, 0) + '万';
      return num(v, 0);
    }
    if (unit === 'pct') return num(v, 1) + '%';
    if (unit === 'days') return num(v, 1);
    return num(v, 2);
  }

  function niceTicks(min, max, n) {
    if (min === max) { min -= 1; max += 1; }
    var span = max - min;
    var raw = span / n;
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var norm = raw / mag;
    var step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
    var lo = Math.floor(min / step) * step;
    var hi = Math.ceil(max / step) * step;
    var ticks = [];
    for (var v = lo; v <= hi + step * 0.01; v += step) ticks.push(v);
    return { min: lo, max: hi, ticks: ticks };
  }

  function lineChart(el, years, series, opts) {
    if (!el) return;
    opts = opts || {};
    series = (series || []).filter(function (s) {
      return (s.values || []).some(function (v) { return v != null && !isNaN(v); });
    });
    if (!series.length) {
      el.innerHTML = '<div class="chart-empty">该口径没有足够的年度数据</div>';
      return;
    }
    var W = 760, H = 300, pad = { l: 62, r: 18, t: 26, b: 38 };
    var all = [];
    series.forEach(function (s) { s.values.forEach(function (v) { if (v != null && !isNaN(v)) all.push(v); }); });
    var lo = Math.min.apply(null, all), hi = Math.max.apply(null, all);
    if (opts.zero) lo = Math.min(0, lo);
    var padV = (hi - lo) * 0.1 || Math.abs(hi || 1) * 0.1;
    var nice = niceTicks(lo - padV, hi + padV, 4);
    var y = function (v) { return pad.t + (nice.max - v) / (nice.max - nice.min) * (H - pad.t - pad.b); };
    var x = function (i) { return pad.l + (years.length === 1 ? 0 : i / (years.length - 1)) * (W - pad.l - pad.r); };
    var grid = nice.ticks.map(function (t) {
      return '<line x1="' + pad.l + '" x2="' + (W - pad.r) + '" y1="' + y(t).toFixed(1) +
        '" y2="' + y(t).toFixed(1) + '" stroke="#e9e4da" stroke-dasharray="3 4"/>' +
        '<text x="' + (pad.l - 9) + '" y="' + (y(t) + 3.5).toFixed(1) +
        '" text-anchor="end" font-size="9.5" fill="#9a9387">' + esc(fmtAxis(t, opts.unit)) + '</text>';
    }).join('');
    var xlabels = years.map(function (yr, i) {
      return '<text x="' + x(i).toFixed(1) + '" y="' + (H - 13) + '" text-anchor="middle" font-size="10" fill="#8d867a">' + yr + '</text>';
    }).join('');
    var paths = series.map(function (s) {
      var segs = [], cur = [];
      s.values.forEach(function (v, i) {
        if (v == null || isNaN(v)) { if (cur.length) segs.push(cur); cur = []; return; }
        cur.push([x(i), y(v)]);
      });
      if (cur.length) segs.push(cur);
      var d = segs.map(function (seg) {
        return seg.map(function (p, i) { return (i ? 'L' : 'M') + p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' ');
      }).join(' ');
      var dots = s.values.map(function (v, i) {
        if (v == null || isNaN(v)) return '';
        return '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(v).toFixed(1) + '" r="3.6" fill="#fff" stroke="' +
          s.color + '" stroke-width="2.2"><title>' + esc(s.name + ' ' + years[i] + '：' + fmtAxis(v, opts.unit)) + '</title></circle>' +
          '<text x="' + x(i).toFixed(1) + '" y="' + (y(v) - 9).toFixed(1) + '" text-anchor="middle" font-size="9" fill="' +
          s.color + '">' + esc(fmtAxis(v, opts.unit)) + '</text>';
      }).join('');
      return '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"/>' + dots;
    }).join('');
    var legend = '<div class="legend">' + series.map(function (s) {
      return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>';
    }).join('') + '</div>';
    el.innerHTML = legend + '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img">' +
      grid + xlabels + paths + '</svg>';
  }

  function barChart(el, years, series, opts) {
    if (!el) return;
    opts = opts || {};
    series = (series || []).filter(function (s) {
      return (s.values || []).some(function (v) { return v != null && !isNaN(v); });
    });
    if (!series.length) {
      el.innerHTML = '<div class="chart-empty">该口径没有足够的年度数据</div>';
      return;
    }
    var W = 760, H = 300, pad = { l: 62, r: 18, t: 26, b: 38 };
    var all = [];
    series.forEach(function (s) { s.values.forEach(function (v) { if (v != null && !isNaN(v)) all.push(v); }); });
    var lo = Math.min(0, Math.min.apply(null, all));
    var hi = Math.max(0, Math.max.apply(null, all));
    var nice = niceTicks(lo, hi, 4);
    var y = function (v) { return pad.t + (nice.max - v) / (nice.max - nice.min) * (H - pad.t - pad.b); };
    var band = (W - pad.l - pad.r) / years.length;
    var bw = Math.min(34, band * 0.62 / series.length);
    var grid = nice.ticks.map(function (t) {
      return '<line x1="' + pad.l + '" x2="' + (W - pad.r) + '" y1="' + y(t).toFixed(1) +
        '" y2="' + y(t).toFixed(1) + '" stroke="#e9e4da" stroke-dasharray="3 4"/>' +
        '<text x="' + (pad.l - 9) + '" y="' + (y(t) + 3.5).toFixed(1) +
        '" text-anchor="end" font-size="9.5" fill="#9a9387">' + esc(fmtAxis(t, opts.unit)) + '</text>';
    }).join('');
    var bars = '';
    years.forEach(function (yr, i) {
      var cx = pad.l + band * i + band / 2;
      var start = cx - (series.length * bw) / 2;
      series.forEach(function (s, j) {
        var v = s.values[i];
        if (v == null || isNaN(v)) return;
        var top = y(Math.max(0, v)), bot = y(Math.min(0, v));
        bars += '<rect x="' + (start + j * bw).toFixed(1) + '" y="' + top.toFixed(1) +
          '" width="' + (bw - 3).toFixed(1) + '" height="' + Math.max(1, bot - top).toFixed(1) +
          '" rx="2" fill="' + s.color + '"><title>' + esc(s.name + ' ' + yr + '：' + fmtAxis(v, opts.unit)) + '</title></rect>';
      });
      bars += '<text x="' + cx.toFixed(1) + '" y="' + (H - 13) + '" text-anchor="middle" font-size="10" fill="#8d867a">' + yr + '</text>';
    });
    var legend = '<div class="legend">' + series.map(function (s) {
      return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>';
    }).join('') + '</div>';
    el.innerHTML = legend + '<svg viewBox="0 0 ' + W + ' ' + H + '">' + grid + bars + '</svg>';
  }

  function stackedBar(el, years, series, opts) {
    if (!el) return;
    opts = opts || {};
    series = (series || []).filter(function (s) {
      return (s.values || []).some(function (v) { return v != null && !isNaN(v); });
    });
    if (!series.length) {
      el.innerHTML = '<div class="chart-empty">该口径没有足够的年度数据</div>';
      return;
    }
    var W = 760, H = 300, pad = { l: 62, r: 18, t: 26, b: 38 };
    var totals = years.map(function (_, i) {
      return series.reduce(function (a, s) { var v = s.values[i]; return a + (v != null && !isNaN(v) ? Math.max(0, v) : 0); }, 0);
    });
    var nice = niceTicks(0, Math.max.apply(null, totals) || 1, 4);
    var y = function (v) { return pad.t + (nice.max - v) / (nice.max - nice.min) * (H - pad.t - pad.b); };
    var band = (W - pad.l - pad.r) / years.length;
    var bw = Math.min(66, band * 0.5);
    var grid = nice.ticks.map(function (t) {
      return '<line x1="' + pad.l + '" x2="' + (W - pad.r) + '" y1="' + y(t).toFixed(1) +
        '" y2="' + y(t).toFixed(1) + '" stroke="#e9e4da" stroke-dasharray="3 4"/>' +
        '<text x="' + (pad.l - 9) + '" y="' + (y(t) + 3.5).toFixed(1) +
        '" text-anchor="end" font-size="9.5" fill="#9a9387">' + esc(fmtAxis(t, 'money')) + '</text>';
    }).join('');
    var bars = '';
    years.forEach(function (yr, i) {
      var x = pad.l + band * i + (band - bw) / 2;
      var acc = 0;
      series.forEach(function (s) {
        var v = s.values[i];
        if (v == null || isNaN(v) || v <= 0) return;
        var y0 = y(acc + v), h = y(acc) - y(acc + v);
        bars += '<rect x="' + x.toFixed(1) + '" y="' + y0.toFixed(1) + '" width="' + bw.toFixed(1) +
          '" height="' + h.toFixed(1) + '" fill="' + s.color + '"><title>' +
          esc(s.name + ' ' + yr + '：' + fmtAxis(v, 'money')) + '</title></rect>';
        acc += v;
      });
      bars += '<text x="' + (x + bw / 2).toFixed(1) + '" y="' + (H - 13) + '" text-anchor="middle" font-size="10" fill="#8d867a">' + yr + '</text>';
    });
    var legend = '<div class="legend">' + series.map(function (s) {
      return '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + '</span>';
    }).join('') + '</div>';
    el.innerHTML = legend + '<svg viewBox="0 0 ' + W + ' ' + H + '">' + grid + bars + '</svg>';
  }

  function sparkline(values, color) {
    var vs = (values || []).filter(function (v) { return v != null && !isNaN(v); });
    if (vs.length < 2) return '';
    var W = 96, H = 24, lo = Math.min.apply(null, vs), hi = Math.max.apply(null, vs);
    if (lo === hi) { lo -= 1; hi += 1; }
    var pts = vs.map(function (v, i) {
      return (i / (vs.length - 1) * W).toFixed(1) + ',' + (H - (v - lo) / (hi - lo) * H).toFixed(1);
    }).join(' ');
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" style="width:96px;height:24px">' +
      '<polyline points="' + pts + '" fill="none" stroke="' + color + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
