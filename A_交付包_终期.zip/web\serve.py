# -*- coding: utf-8 -*-
"""FinScope 本地服务：静态页 + 一组 /api 接口。

两种用法，功能不同，页面会明示当前处于哪一种：

- **双击 index.html（file://）**：不经过本服务。看板、预置问题检索照常可用；
  联网抓取、上传 PDF、大模型问答这三项不可用，因为浏览器跨域拿不到巨潮的数据，
  也跑不了 pdfplumber 与 91MB 的 ONNX 模型。
- **双击 启动问答页.bat（本服务）**：以上全部可用。

安全边界（本地服务也要管）：
- 只绑定 127.0.0.1
- 所有变更类接口要求自定义头 `X-FS-Client: 1`。这个头不是简单头，会触发 CORS 预检，
  而我们**不发任何 CORS 头**，所以别的网页即使知道端口也发不出跨站请求。
- 校验 Host 与 Origin，防 DNS rebinding
"""
from __future__ import annotations

import argparse
import base64
import json
import re
import shutil
import sys
import threading
import uuid
import webbrowser
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, quote

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import cockpit                       # noqa: E402
import config as config_mod          # noqa: E402
import identify                      # noqa: E402
import jobs                          # noqa: E402
import online_finance                # noqa: E402
import webdata                       # noqa: E402
import websearch                     # noqa: E402

ANNUAL_DIR = ROOT / "data" / "annual_reports"
UPLOAD_DIR = ROOT / "work" / "uploads"
MAX_UPLOAD = 200 * 1024 * 1024       # 200MB，够装最大的年报

_embedder = None
_embedder_lock = threading.Lock()


def get_embedder():
    """懒加载向量模型。只有现算查询向量时才需要它——检索用的文档向量已经在分片里了。"""
    global _embedder
    if _embedder is None:
        with _embedder_lock:
            if _embedder is None:
                import embed as embed_mod
                _embedder = embed_mod.Embedder()
    return _embedder


class Handler(SimpleHTTPRequestHandler):
    server_version = "FinScope/2.0"

    # ------------------------------------------------------------ 路由

    def do_GET(self):  # noqa: N802
        route = urlparse(self.path)
        path, qs = route.path, parse_qs(route.query)
        try:
            if path == "/api/health":
                return self._health()
            if path == "/api/config":
                return self._json(config_mod.public_view())
            if path == "/api/job":
                job = jobs.get((qs.get("id") or [""])[0])
                if not job:
                    return self._json({"error": "任务不存在"}, 404)
                return self._json(job)
            if path == "/api/jobs":
                return self._json({"jobs": jobs.recent(20)})
            if path == "/api/embed":
                return self._embed((qs.get("q") or [""])[0])
            if path == "/api/search":
                return self._search((qs.get("q") or [""])[0],
                                    int((qs.get("year") or [0])[0] or 0))
            if path == "/api/report":
                return self._report((qs.get("code") or [""])[0],
                                    int((qs.get("year") or [0])[0] or 0))
            if path == "/api/online":
                return self._cockpit_api((qs.get("code") or [""])[0],
                                         int((qs.get("year") or [0])[0] or 0), "online",
                                         bool((qs.get("force") or [""])[0]))
            if path == "/api/cockpit":
                return self._cockpit_api((qs.get("code") or [""])[0],
                                         int((qs.get("year") or [0])[0] or 0),
                                         (qs.get("mode") or ["auto"])[0],
                                         bool((qs.get("force") or [""])[0]))
            if path == "/api/history":
                return self._history()
            if path.startswith("/files/reports/"):
                return self._serve_report_pdf(path)
            if path == "/health":                    # 兼容旧接口
                return self._json({"ok": True})
            if path.startswith("/api/"):
                return self._json({"error": "未知接口"}, 404)
        except Exception as exc:                     # noqa: BLE001
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)
        return super().do_GET()

    def do_POST(self):  # noqa: N802
        path = urlparse(self.path).path
        try:
            if path == "/api/upload":                # 上传是原始字节流，自己读
                if not self._guard():
                    return
                return self._upload()
            if not self._guard():
                return
            body = self._read_json()
            if path == "/api/config":
                config_mod.save(body)
                return self._json({"ok": True, "config": config_mod.public_view()})
            if path in ("/api/ingest", "/api/analyze"):
                return self._ingest(body)
            if path == "/api/ask":
                return self._ask(body)
            if path == "/api/llm-test":
                return self._llm_test()
            if path == "/api/job/cancel":
                ok = jobs.cancel(body.get("id", ""))
                return self._json({"ok": ok})
            if path == "/api/embed":
                return self._embed(body.get("q", ""))
            return self._json({"error": "未知接口"}, 404)
        except Exception as exc:                     # noqa: BLE001
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, 500)

    # ------------------------------------------------------------ 安全护栏

    def _guard(self) -> bool:
        """变更类接口的前置校验。返回 False 时已经回过响应。"""
        if self.headers.get("X-FS-Client") != "1":
            # 浏览器里别的网页发不出这个头（会触发预检，而我们不回 CORS 头），
            # 所以缺这个头基本可以断定不是我们的页面发的。
            self._json({"error": "缺少 X-FS-Client 头，拒绝执行"}, 403)
            return False
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("127.0.0.1", "localhost", "[::1]"):
            self._json({"error": "Host 不是本机，拒绝执行"}, 403)
            return False
        origin = self.headers.get("Origin")
        if origin and not re.match(r"^https?://(127\.0\.0\.1|localhost)(:\d+)?$", origin):
            self._json({"error": "来源不是本机，拒绝执行"}, 403)
            return False
        return True

    def _read_json(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        try:
            data = json.loads(self.rfile.read(n).decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    # ------------------------------------------------------------ 各接口

    def _health(self):
        man = webdata.load_published("manifest", "FINSCOPE_MANIFEST", {"shards": []})
        return self._json({
            "ok": True,
            "llm_ready": config_mod.llm_ready(),
            "search_ready": config_mod.search_ready(),
            "search_provider": config_mod.get("search.provider", "off"),
            "search_providers": websearch.available_providers(),
            "model_present": (ROOT / "models" / "bge-small-zh-v1.5" / "onnx" / "model.onnx").exists(),
            "latest_year": online_finance.latest_annual_year(),
            "online_search": True,
            "companies": [{"code": s["code"], "name": s["name"]} for s in man.get("shards", [])],
            "steps": [{"name": s["name"], "label": s["label"]} for s in jobs.STEPS],
        })

    def _embed(self, question: str):
        import embed as embed_mod
        try:
            vec = get_embedder().encode([question or " "])[0]
            q = embed_mod.quantize_int8(vec.reshape(1, -1))[0]
            self._json({"q": question, "dim": embed_mod.DIM,
                        "vec": base64.b64encode(q.tobytes()).decode("ascii")})
        except Exception as exc:  # noqa: BLE001
            self._json({"error": str(exc)}, 500)

    def _ingest(self, body: dict):
        code = str(body.get("code") or "").strip()
        if not re.fullmatch(r"\d{6}", code):
            return self._json({"error": "股票代码必须是 6 位数字"}, 400)
        params = {"code": code,
                  "year": int(body.get("year") or online_finance.latest_annual_year()),
                  "force": bool(body.get("force"))}
        return self._json(jobs.submit("ingest", params))

    # ------------------------------------------------------------ 联网取数 / 驾驶舱

    def _search(self, query: str, year: int):
        year = year or online_finance.latest_annual_year()
        try:
            matches = online_finance.search_companies(query)
        except online_finance.OnlineError as exc:
            return self._json({"error": exc.message, **exc.as_dict()}, 404)
        best = dict(matches[0])
        profile = online_finance.company_profile(best["code"])
        best.update({
            "name_full": profile.get("name_full"),
            "industry": profile.get("industry") or "未识别",
            "exchange_name": profile.get("exchange"),
            "market_cap": profile.get("market_cap"),
        })
        report = None
        report_error = None
        try:
            report = online_finance.find_annual_report(best["code"], year)
        except online_finance.OnlineError as exc:
            report_error = exc.as_dict()
        return self._json({
            "query": query, "year": year, "matches": matches,
            "best": {**best, "report": report, "report_error": report_error},
        })

    def _report(self, code: str, year: int):
        year = year or online_finance.latest_annual_year()
        if not re.fullmatch(r"\d{6}", code):
            return self._json({"error": "股票代码必须是 6 位数字"}, 400)
        try:
            report = online_finance.find_annual_report(code, year)
        except online_finance.OnlineError as exc:
            return self._json({"error": exc.message, **exc.as_dict()}, 404)
        profile = online_finance.company_profile(code)
        return self._json({"code": code, "year": year, "ticker": online_finance.ticker_of(code),
                           "report": report, "company": profile})

    def _cockpit_api(self, code: str, year: int, mode: str, force: bool):
        year = year or online_finance.latest_annual_year()
        if mode not in ("auto", "online", "pdf"):
            return self._json({"error": "mode 只能是 auto / online / pdf"}, 400)
        try:
            if force and mode == "online":
                payload = cockpit.build_online_cockpit(code, year, force=True)
            else:
                payload = cockpit.build_cockpit(code, year, mode)
        except FileNotFoundError as exc:
            return self._json({"error": str(exc), "code": "E_EXTRACT_INCOMPLETE",
                               "hint": "年报还在解析，先看在线快照"}, 404)
        except online_finance.OnlineError as exc:
            return self._json({"error": exc.message, **exc.as_dict()}, 502)
        return self._json(payload)

    def _history(self):
        items = []
        for job in jobs.recent(30):
            if job.get("kind") != "ingest":
                continue
            code = str((job.get("params") or {}).get("code") or "")
            year = int((job.get("params") or {}).get("year") or 0)
            if not re.fullmatch(r"\d{6}", code) or not year:
                continue
            extracted = list((ROOT / "data" / "extracted").glob(f"*_{code}_{year}.json"))
            pdfs = list(ANNUAL_DIR.glob(f"*_{code}_{year}.pdf"))
            name = None
            if extracted:
                try:
                    name = json.loads(extracted[0].read_text(encoding="utf-8")) \
                        .get("company", {}).get("name")
                except (OSError, ValueError):
                    name = None
            if not name and pdfs:
                name = pdfs[0].stem.split("_")[0]
            items.append({
                "key": f"{online_finance.ticker_of(code)}_{year}",
                "code": code, "ticker": online_finance.ticker_of(code),
                "year": year, "name": name,
                "analyzed_at": job.get("updated_at") or job.get("created_at"),
                "status": job.get("status"), "percent": job.get("percent"),
                "unified_exists": bool(extracted), "report_exists": bool(pdfs),
                "source_mode": "pdf", "job_id": job.get("id"),
            })
        return self._json({"items": items})

    def _serve_report_pdf(self, path: str):
        name = unquote(path[len("/files/reports/"):])
        target = (ANNUAL_DIR / name).resolve()
        try:
            target.relative_to(ANNUAL_DIR.resolve())
        except ValueError:
            return self._json({"error": "路径不合法"}, 403)
        if not target.exists() or target.suffix.lower() != ".pdf":
            return self._json({"error": "文件不存在"}, 404)
        data = target.read_bytes()
        start, end = 0, len(data) - 1
        rng = self.headers.get("Range") or ""
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        partial = False
        if m and len(data):
            partial = True
            if m.group(1):
                start = int(m.group(1))
            if m.group(2):
                end = min(int(m.group(2)), len(data) - 1)
            if start > end or start >= len(data):
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{len(data)}")
                self.end_headers()
                return
        body = data[start:end + 1]
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", "application/pdf")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Accept-Ranges", "bytes")
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{len(data)}")
        # HTTP 头只能是 latin-1，中文文件名直接塞进去会抛 UnicodeEncodeError。
        # 用 RFC 5987 的 filename* 传 UTF-8 名字，另给一个 ASCII 兜底名。
        self.send_header("Content-Disposition",
                         "inline; filename=\"annual_report.pdf\"; "
                         f"filename*=UTF-8''{quote(target.name)}")
        self.end_headers()
        self.wfile.write(body)

    def _upload(self):
        n = int(self.headers.get("Content-Length") or 0)
        if not (0 < n <= MAX_UPLOAD):
            return self._json({"error": f"文件为空或超过 {MAX_UPLOAD // 1024 // 1024}MB"}, 413)
        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        # 一律用 uuid 命名，绝不让客户端给的文件名参与路径
        stage = UPLOAD_DIR / f"{uuid.uuid4().hex}.pdf"
        remaining = n
        with open(stage, "wb") as fh:
            while remaining > 0:
                buf = self.rfile.read(min(1 << 20, remaining))
                if not buf:
                    break
                fh.write(buf)
                remaining -= len(buf)
        if stage.stat().st_size < 1000:
            stage.unlink(missing_ok=True)
            return self._json({"error": "文件太小，不像是年报 PDF"}, 400)
        with open(stage, "rb") as fh:
            if fh.read(5) != b"%PDF-":
                stage.unlink(missing_ok=True)
                return self._json({"error": "这不是一个 PDF 文件"}, 400)

        try:
            return self._json(self._admit_upload(stage))
        except Exception as exc:  # noqa: BLE001
            stage.unlink(missing_ok=True)
            return self._json({"error": str(exc)}, 400)

    def _admit_upload(self, stage: Path) -> dict:
        """识别上传的 PDF 并归位到 <公司名>_<代码>_<年份>.pdf，然后起任务。"""
        info = identify.identify_pdf(stage, default_year=2025)
        # 请求头里的值优先——PDF 封面识别不出来时由前端补填
        code = (self.headers.get("X-FS-Code") or "").strip() or (info["code"] or "")
        name = (self.headers.get("X-FS-Name") or "").strip()
        if not name:
            name = unquote(self.headers.get("X-FS-Filename") or "").rsplit(".", 1)[0]
            name = re.sub(r"(19|20)\d{2}.*$", "", name).strip("_- 　")
        if not name:
            name = info["name"] or ""
        year = info["year"] or 2025

        if not identify.is_valid_code(code):
            raise RuntimeError("无法从 PDF 识别股票代码，请在「添加公司」里填上 6 位代码后再上传")
        if not identify.is_valid_name(name):
            raise RuntimeError("无法从 PDF 识别公司名，请在「添加公司」里填上公司名后再上传")

        stem = f"{name}_{code}_{year}"
        target = (ANNUAL_DIR / f"{stem}.pdf").resolve()
        if not target.is_relative_to(ANNUAL_DIR.resolve()):
            raise RuntimeError("文件名不合法")
        ANNUAL_DIR.mkdir(parents=True, exist_ok=True)
        shutil.move(str(stage), str(target))

        job = jobs.submit("upload", {"stem": stem, "code": code, "year": year})
        return {"ok": True, "job": job, "stem": stem, "name": name, "code": code,
                "year": year, "identified_from_pdf": info}

    def _llm_test(self):
        """用一次极小的调用验证大模型配置是否可用。

        密钥填错、base_url 写错、模型名不存在，这三种错在真正提问时都会表现成
        「问答失败」，用户很难分辨。这里单独给一个能立刻验证的入口。
        """
        import ask as ask_mod
        if not config_mod.llm_ready():
            return self._json({"ok": False, "error": "还没填全 base_url、模型名和密钥"}, 400)
        cfg = config_mod.load()["llm"]
        try:
            reply, usage = ask_mod.chat("你是一个连接测试助手，只按要求回复。", "回复两个字：可用")
            return self._json({"ok": True, "model": cfg["model"],
                               "base_url": cfg["base_url"],
                               "reply": (reply or "").strip()[:80],
                               "usage": usage})
        except ask_mod.LLMError as exc:
            return self._json({"ok": False, "error": str(exc)}, 400)
        except Exception as exc:  # noqa: BLE001
            return self._json({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, 500)

    def _ask(self, body: dict):
        q = (body.get("q") or "").strip()
        if not q:
            return self._json({"error": "问题为空"}, 400)
        import ask as ask_mod
        codes = body.get("codes") or None
        if isinstance(codes, list) and not codes:
            codes = None
        out = ask_mod.ask(q, codes=codes, use_search=body.get("use_search"), top_n=body.get("top_n"))
        out["question"] = q
        return self._json(out)

    # ------------------------------------------------------------ 响应

    def _json(self, obj, status: int = 200):
        data = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        if args and str(args[1]).startswith(("4", "5")):
            sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))


def main() -> int:
    ap = argparse.ArgumentParser(description="FinScope 本地服务")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    jobs.mark_interrupted_on_startup()
    jobs.load_history()

    handler = partial(Handler, directory=str(HERE))
    httpd = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    url = f"http://127.0.0.1:{args.port}/index.html"
    print("FinScope 已启动：", url)
    print("联网抓取年报、上传 PDF、大模型问答在本模式下可用。按 Ctrl+C 停止。")
    missing = []
    if not config_mod.llm_ready():
        missing.append("大模型（设置面板里填 base_url / 模型名 / 密钥）")
    if not config_mod.search_ready():
        missing.append("联网搜索（设置面板里选供应商并填密钥，可选）")
    if missing:
        print("尚未配置：" + "；".join(missing))
    if not args.no_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
