# 字段映射：04 canonical ← 东方财富年度三表

在线模式用东方财富 F10 的年度三表。单位统一为元，口径为合并报表。
下表是 `src/online_finance.py` 里 `FIELD_MAP` 的可读版本，给 D 接统一对象时对照。

## 利润表（RPT_F10_FINANCE_GINCOME）

| canonical 键 | 中文名 | 上游字段 | 档位 | 备注 |
|---|---|---|---|---|
| revenue | 营业收入 | OPERATE_INCOME，缺失时 TOTAL_OPERATE_INCOME | P0 | 银行/保险用 TOTAL_OPERATE_INCOME |
| operating_cost | 营业成本 | OPERATE_COST | P0 | 不含税金及期间费用 |
| operating_profit | 营业利润 | OPERATE_PROFIT | P0 | |
| pretax_profit | 利润总额 | TOTAL_PROFIT | P0 | |
| income_tax_expense | 所得税费用 | INCOME_TAX | P0 | |
| net_income | 净利润 | NETPROFIT | P0 | 含少数股东 |
| net_income_parent | 归母净利润 | PARENT_NETPROFIT | P0 | |
| net_income_excl_nonrecurring | 扣非归母净利润 | DEDUCT_PARENT_NETPROFIT | P0 | |
| selling_expense | 销售费用 | SALE_EXPENSE | P0 | |
| admin_expense | 管理费用 | MANAGE_EXPENSE | P0 | |
| finance_expense | 财务费用 | FINANCE_EXPENSE | P0 | 负数表示财务收入 |
| interest_expense | 利息费用 | FE_INTEREST_EXPENSE，其次 INTEREST_EXPENSE | P0 | |
| rnd_expense | 研发费用 | RESEARCH_EXPENSE，其次 ME_RESEARCH_EXPENSE | P1 | 费用化口径 |
| impairment_loss | 资产及信用减值损失 | ASSET_IMPAIRMENT_LOSS + CREDIT_IMPAIRMENT_LOSS | P1 | 两项相加，缺项按已列示项加总 |

## 资产负债表（RPT_F10_FINANCE_GBALANCE）

| canonical 键 | 中文名 | 上游字段 | 档位 | 备注 |
|---|---|---|---|---|
| cash_and_equivalents | 货币资金 | MONETARYFUNDS | P0 | 不等于现金及现金等价物 |
| accounts_receivable | 应收账款 | ACCOUNTS_RECE | P0 | |
| notes_receivable | 应收票据 | NOTE_RECE | P1 | |
| inventory | 存货 | INVENTORY | P0 | 净额 |
| contract_assets | 合同资产 | CONTRACT_ASSET | P1 | |
| current_assets | 流动资产合计 | TOTAL_CURRENT_ASSETS | P0 | |
| total_assets | 资产总计 | TOTAL_ASSETS | P0 | |
| accounts_payable | 应付账款 | ACCOUNTS_PAYABLE | P0 | |
| current_liabilities | 流动负债合计 | TOTAL_CURRENT_LIAB | P0 | |
| short_term_borrowings | 短期借款 | SHORT_LOAN | P0 | 没有就 not_found |
| current_portion_lt_debt | 一年内到期的非流动负债 | NONCURRENT_LIAB_1YEAR | P0 | |
| long_term_borrowings | 长期借款 | LONG_LOAN | P0 | 没有就 not_found |
| bonds_payable | 应付债券 | BOND_PAYABLE | P0 | 没有就 not_found |
| total_liabilities | 负债合计 | TOTAL_LIABILITIES | P0 | |
| equity_parent | 归母净资产 | TOTAL_PARENT_EQUITY | P0 | |
| total_equity | 所有者权益合计 | TOTAL_EQUITY | P0 | 含少数股东 |
| fixed_assets | 固定资产 | FIXED_ASSET | P1 | |
| goodwill | 商誉 | GOODWILL | P1 | 没有就 not_found |
| rd_capitalized | 开发支出（余额） | DEVELOP_EXPENSE | P1 | 余额口径，不是当期资本化金额 |

## 现金流量表（RPT_F10_FINANCE_GCASHFLOW）

| canonical 键 | 中文名 | 上游字段 | 档位 | 备注 |
|---|---|---|---|---|
| cfo | 经营活动现金流量净额 | NETCASH_OPERATE | P0 | |
| cfi | 投资活动现金流量净额 | NETCASH_INVEST | P1 | |
| cff | 筹资活动现金流量净额 | NETCASH_FINANCE | P1 | |
| capex | 资本开支 | CONSTRUCT_LONG_ASSET | P0 | 正数表示流出规模 |
| cash_received_from_sales | 销售商品、提供劳务收到的现金 | SALES_SERVICES | P0 | |
| interest_paid | 支付的利息 | PAY_INTEREST_COMMISSION | P1 | 一般工商业常常没有单列 |
| dividend_paid | 分配股利、利润或偿付利息支付的现金 | ASSIGN_DIVIDEND_PORFIT | P1 | 含利息，名称较长 |
| depreciation_amortization | 折旧与摊销 | FA_IR_DEPR + IR_DEPR + IA_AMORTIZE + LPE_AMORTIZE + USERIGHT_ASSET_AMORTIZE | P0 | 现金流量表补充资料；能取多少加多少 |
| cash_net_increase | 现金及现金等价物净增加额 | CCE_ADD | 内部 | 只用于现金流勾稽，不进 42 项 |

## P0 之外的派生规则

| 派生项 | 公式 | 出处 |
|---|---|---|
| interest_bearing_debt | short_term_borrowings + current_portion_lt_debt + long_term_borrowings + bonds_payable | 04 §5.2 |
| net_debt | interest_bearing_debt - cash_and_equivalents | 驾驶舱 |
| ebitda（近似） | operating_profit + depreciation_amortization | 驾驶舱，D&A 不完整时只作近似 |

## 口径与缺失

- 在线模式 `source_type="online"`，`page=null`，`source_field` 写上游字段，`source_url` 写 F10 页面。
- PDF 模式 `source_type="pdf"`，`page` 是印刷页码，`pdf_page` 是 PDF 物理页。
- `value=null` 时 `status` 只能是 `not_found` / `not_applicable` / `extraction_error`，不填 0。
- 同一科目三年量级差超过 100 倍，数据质量检查标 `SERIES_SCALE`。
- 东方财富没有列示的科目（如茅台没有短期借款）记 `not_found`，不推断为 0。

## PDF 旧键 → canonical

| 旧键 | canonical |
|---|---|
| net_profit_attr | net_income_parent |
| net_profit_deducted | net_income_excl_nonrecurring |
| equity_attr | equity_parent |
| cash | cash_and_equivalents |
| rd_expense | rnd_expense |
| net_profit | net_income |

其余 `revenue`、`operating_cost`、`total_assets`、`total_liabilities`、
`accounts_receivable`、`inventory`、`goodwill`、`cfo`、`cfi`、`cff`、`capex` 同名。
