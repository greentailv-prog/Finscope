# -*- coding: utf-8 -*-
"""联网取数：公司检索、年报定位、在线三表拉取。

这一层只做三件事，不碰 PDF：
1. 把用户输入的公司名/代码解析成 A 股公司；
2. 从巨潮资讯网找到目标年度年报正文，给出公告页与 PDF 链接；
3. 从东方财富 F10 拉年度三表，映射成 04 规范里的 canonical 科目。

设计取舍：
- 在线模式没有页码，出处写数据源 + 字段 + 链接。页码级证据走 PDF 管线，两套口径不混。
- 所有金额统一为元；东方财富返回的本来就是元，不做二次换算。
- 取不到就是 null + status=not_found，绝不填 0。
- 接口是公开页面背后的 JSON，字段随上游变；上游变了要报错让人看见，不要静默返回空。
"""
from __future__ import annotations

import json
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import requests

SRC = Path(__file__).resolve().parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

import fetch_cninfo                 # noqa: E402
import identify                     # noqa: E402
import webdata                      # noqa: E402

ROOT = SRC.parent
ONLINE_DIR = ROOT / "data" / "online"
CACHE_TTL_SECONDS = 12 * 3600       # 财务数据一天内不会变，12 小时足够
REPORT_TTL_SECONDS = 24 * 3600

EM_DATACENTER = "https://datacenter.eastmoney.com/securities/api/data/v1/get"
EM_QUOTE = "https://push2.eastmoney.com/api/qt/stock/get"
EM_F10_PAGE = "https://emweb.securities.eastmoney.com/PC_HSF10/NewFinanceAnalysis/Index?type=web&code={code}"


def _em_code(code: str) -> str:
    """东方财富网页用的代码是 SH600519 / SZ000333，不是 600519.SH。"""
    suffix = {"sse": "SH", "szse": "SZ", "bse": "BJ"}.get(identify.exchange_of(code), "SZ")
    return suffix + code

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Referer": "https://emweb.securities.eastmoney.com/",
    "Accept": "application/json, text/plain, */*",
}

_lock = threading.RLock()


class OnlineError(RuntimeError):
    def __init__(self, code: str, message: str, hint: str = ""):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint

    def as_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "hint": self.hint}


# ---------------------------------------------------------------- 基础工具

def ticker_of(code: str) -> str:
    suffix = {"sse": "SH", "szse": "SZ", "bse": "BJ"}.get(identify.exchange_of(code), "SZ")
    return f"{code}.{suffix}"


def _secucode(code: str) -> str:
    return ticker_of(code)


def _secid(code: str) -> str:
    ex = identify.exchange_of(code)
    market = "1" if ex == "sse" else "0"
    return f"{market}.{code}"


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update(HEADERS)
    return s


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _cache_path(name: str) -> Path:
    return ONLINE_DIR / name


def _read_cache(path: Path, ttl: int):
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if time.time() - float(payload.get("_cached_at", 0)) > ttl:
            return None
        return payload.get("data")
    except (OSError, ValueError, TypeError):
        return None


def _write_cache(path: Path, data) -> None:
    try:
        ONLINE_DIR.mkdir(parents=True, exist_ok=True)
        webdata.atomic_write_text(path, json.dumps(
            {"_cached_at": time.time(), "data": data}, ensure_ascii=False, indent=1))
    except OSError:
        pass


def _num(value):
    """上游偶尔把数字写成字符串；空串、'-'、None 一律当缺失。"""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if text in ("", "-", "--", "None", "null"):
        return None
    try:
        return float(text)
    except ValueError:
        return None


def validate_code(code: str) -> None:
    """快速确认代码是真实 A 股，避免对 999999 这种代码去拉三表、白等超时。"""
    if not re.fullmatch(r"\d{6}", str(code or "")):
        raise OnlineError("E_CODE_FORMAT", "股票代码是 6 位数字，例如 600519", "请检查输入")
    try:
        matches = search_companies(code, limit=3)
    except OnlineError:
        raise
    if not any(m.get("code") == code for m in matches):
        raise OnlineError("E_CODE_NOT_FOUND", f"没找到股票代码 {code}", "检查代码是否正确")


def latest_annual_year(today: datetime | None = None) -> int:
    """A 股年报最晚次年 4 月底披露。5 月以后默认上一年，1-4 月默认前一年。"""
    d = today or datetime.now()
    return d.year - 1 if d.month >= 5 else d.year - 2


# ---------------------------------------------------------------- 公司检索

def search_companies(query: str, limit: int = 8) -> list[dict]:
    """用巨潮的搜索接口把代码或名称解析成候选公司。"""
    q = (query or "").strip()
    if not q:
        raise OnlineError("E_CODE_FORMAT", "请输入股票代码或公司名", "例如 600519 或 贵州茅台")
    sess = _session()
    try:
        r = sess.post(fetch_cninfo.SEARCH_URL,
                      data={"keyWord": q, "maxNum": max(10, limit)},
                      headers=fetch_cninfo.HEADERS, timeout=20)
        r.raise_for_status()
        items = r.json() or []
    except Exception as exc:  # noqa: BLE001
        raise OnlineError("E_FETCH_FAILED", f"公司检索失败：{exc}",
                          "检查网络，或稍后重试") from exc

    out = []
    for it in items:
        code = str(it.get("code") or "").strip()
        name = (it.get("zwjc") or "").strip()
        if not re.fullmatch(r"\d{6}", code) or not name:
            continue
        if it.get("category") not in (None, "", "A股"):
            continue
        if str(it.get("delisted")).lower() == "true":
            continue
        out.append({
            "code": code,
            "name": name,
            "ticker": ticker_of(code),
            "exchange": identify.exchange_of(code),
            "org_id": it.get("orgId"),
        })
        if len(out) >= limit:
            break
    if not out:
        raise OnlineError("E_CODE_NOT_FOUND", f"没找到与“{q}”匹配的 A 股公司",
                          "检查代码或公司简称")
    if re.fullmatch(r"\d{6}", q):
        exact = [x for x in out if x["code"] == q]
        if exact:
            out = exact + [x for x in out if x["code"] != q]
    return out


# ---------------------------------------------------------------- 公司资料

def company_profile(code: str) -> dict:
    """公司全称、行业、交易所。失败就返回空字段，不编。"""
    cache = _cache_path(f"profile_{ticker_of(code)}.json")
    hit = _read_cache(cache, 7 * 24 * 3600)
    if hit:
        return hit
    ticker = _secucode(code)
    params = {
        "reportName": "RPT_F10_BASIC_ORGINFO", "columns": "ALL",
        "filter": f'(SECUCODE="{ticker}")', "pageNumber": 1, "pageSize": 1,
        "source": "HSF10", "client": "PC",
    }
    out = {"name_full": None, "name_short": None, "industry": None, "industry_code": None,
           "exchange": {"sse": "上海证券交易所", "szse": "深圳证券交易所",
                        "bse": "北京证券交易所"}.get(identify.exchange_of(code)),
           "market_cap": None, "price": None}
    try:
        r = _session().get(EM_DATACENTER, params=params, timeout=15)
        rows = ((r.json().get("result") or {}).get("data") or [])
        if rows:
            row = rows[0]
            out["name_full"] = row.get("ORG_NAME") or None
            out["industry"] = row.get("EM2016") or None
            out["industry_code"] = row.get("INDUSTRYCSRC1") or None
            out["exchange"] = row.get("TRADE_MARKET") or out["exchange"]
    except Exception:  # noqa: BLE001
        pass

    try:
        r = _session().get(EM_QUOTE, params={
            "secid": _secid(code),
            "fields": "f57,f58,f116,f117,f127,f162,f167",
        }, timeout=10)
        data = (r.json() or {}).get("data") or {}
        out["market_cap"] = _num(data.get("f116"))
        out["name_short"] = data.get("f58") or None
        out["industry"] = out["industry"] or data.get("f127") or None
    except Exception:  # noqa: BLE001
        pass
    if out.get("name_full") or out.get("industry"):
        _write_cache(cache, out)
    return out


# ---------------------------------------------------------------- 年报定位

def find_annual_report(code: str, year: int, force: bool = False) -> dict:
    """返回年报正文的公告页与 PDF 链接。找不到就抛 E_NO_ANNUAL_REPORT。"""
    cache = _cache_path(f"report_{ticker_of(code)}_{year}.json")
    if not force:
        hit = _read_cache(cache, REPORT_TTL_SECONDS)
        if hit:
            return hit

    sess = _session()
    org_id = fetch_cninfo.resolve_org_id(code, sess)
    if not org_id:
        raise OnlineError("E_FETCH_FAILED", "巨潮没有返回该公司的机构编号",
                          "稍后重试，或改用上传 PDF")
    try:
        items = fetch_cninfo.query_announcements(
            code, org_id, identify.exchange_of(code), year, sess)
    except Exception as exc:  # noqa: BLE001
        raise OnlineError("E_FETCH_FAILED", f"年报公告查询失败：{exc}",
                          "稍后重试，或改用上传 PDF") from exc
    hit = fetch_cninfo.pick_annual_report(items, year)
    if not hit:
        raise OnlineError("E_NO_ANNUAL_REPORT",
                          f"该公司 {year} 年年报未披露",
                          "换一个年度，或改用上传 PDF")

    aid = hit.get("announcementId")
    ts = hit.get("announcementTime") or 0
    pdf_url = fetch_cninfo.STATIC_BASE + (hit.get("adjunctUrl") or "")
    page_url = ("http://www.cninfo.com.cn/new/disclosure/detail"
                f"?stockCode={code}&announcementId={aid}&orgId={org_id}"
                f"&announcementTime={ts}")
    data = {
        "title": hit.get("announcementTitle") or f"{year}年年度报告",
        "year": year,
        "announcement_id": aid,
        "announcement_time": ts,
        "announcement_date": datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d") if ts else None,
        "page_url": page_url,
        "pdf_url": pdf_url,
        "org_id": org_id,
        "source": "巨潮资讯网",
    }
    _write_cache(cache, data)
    return data


# ---------------------------------------------------------------- 在线三表

_STATEMENTS = {
    "income": ("RPT_F10_FINANCE_GINCOME", "利润表"),
    "balance": ("RPT_F10_FINANCE_GBALANCE", "资产负债表"),
    "cashflow": ("RPT_F10_FINANCE_GCASHFLOW", "现金流量表"),
    "main": ("RPT_F10_FINANCE_MAINFINADATA", "主要指标"),
}


def _fetch_statement(name: str, code: str, rows: int = 6) -> list[dict]:
    report_name, _ = _STATEMENTS[name]
    params = {
        "reportName": report_name,
        "columns": "ALL",
        "filter": f'(SECUCODE="{_secucode(code)}")(REPORT_TYPE="年报")',
        "pageNumber": 1,
        "pageSize": rows,
        "sortTypes": "-1",
        "sortColumns": "REPORT_DATE",
        "source": "HSF10",
        "client": "PC",
    }
    try:
        r = _session().get(EM_DATACENTER, params=params, timeout=25)
        r.raise_for_status()
        body = r.json()
    except Exception as exc:  # noqa: BLE001
        raise OnlineError("E_FETCH_FAILED", f"{_STATEMENTS[name][1]}取数失败：{exc}",
                          "稍后重试，或改用上传 PDF") from exc
    data = ((body.get("result") or {}).get("data") or []) if body.get("success") else []
    if not data:
        raise OnlineError("E_FETCH_FAILED", f"东方财富没有返回{_STATEMENTS[name][1]}",
                          "该公司可能不在东方财富覆盖范围，改用上传 PDF")
    return data


def _row_year(row: dict) -> int | None:
    text = str(row.get("REPORT_DATE") or "")[:4]
    return int(text) if text.isdigit() else None


def _index_by_year(rows: list[dict]) -> dict[int, dict]:
    out = {}
    for row in rows:
        y = _row_year(row)
        if y and y not in out:
            out[y] = row
    return out


# canonical 键 -> (报表, 上游字段候选, 中文名)
FIELD_MAP: dict[str, tuple[str, tuple[str, ...], str]] = {
    # 利润表
    "revenue": ("income", ("OPERATE_INCOME", "TOTAL_OPERATE_INCOME"), "营业收入"),
    "operating_cost": ("income", ("OPERATE_COST",), "营业成本"),
    "operating_profit": ("income", ("OPERATE_PROFIT",), "营业利润"),
    "pretax_profit": ("income", ("TOTAL_PROFIT",), "利润总额"),
    "income_tax_expense": ("income", ("INCOME_TAX",), "所得税费用"),
    "net_income": ("income", ("NETPROFIT",), "净利润"),
    "net_income_parent": ("income", ("PARENT_NETPROFIT",), "归母净利润"),
    "net_income_excl_nonrecurring": ("income", ("DEDUCT_PARENT_NETPROFIT",), "扣非归母净利润"),
    "selling_expense": ("income", ("SALE_EXPENSE",), "销售费用"),
    "admin_expense": ("income", ("MANAGE_EXPENSE",), "管理费用"),
    "finance_expense": ("income", ("FINANCE_EXPENSE",), "财务费用"),
    "interest_expense": ("income", ("FE_INTEREST_EXPENSE", "INTEREST_EXPENSE"), "利息费用"),
    "rnd_expense": ("income", ("RESEARCH_EXPENSE", "ME_RESEARCH_EXPENSE"), "研发费用"),
    # 资产负债表
    "cash_and_equivalents": ("balance", ("MONETARYFUNDS",), "货币资金"),
    "accounts_receivable": ("balance", ("ACCOUNTS_RECE",), "应收账款"),
    "notes_receivable": ("balance", ("NOTE_RECE",), "应收票据"),
    "inventory": ("balance", ("INVENTORY",), "存货"),
    "contract_assets": ("balance", ("CONTRACT_ASSET",), "合同资产"),
    "current_assets": ("balance", ("TOTAL_CURRENT_ASSETS",), "流动资产合计"),
    "total_assets": ("balance", ("TOTAL_ASSETS",), "资产总计"),
    "accounts_payable": ("balance", ("ACCOUNTS_PAYABLE",), "应付账款"),
    "current_liabilities": ("balance", ("TOTAL_CURRENT_LIAB",), "流动负债合计"),
    "short_term_borrowings": ("balance", ("SHORT_LOAN",), "短期借款"),
    "current_portion_lt_debt": ("balance", ("NONCURRENT_LIAB_1YEAR",), "一年内到期的非流动负债"),
    "long_term_borrowings": ("balance", ("LONG_LOAN",), "长期借款"),
    "bonds_payable": ("balance", ("BOND_PAYABLE",), "应付债券"),
    "total_liabilities": ("balance", ("TOTAL_LIABILITIES",), "负债合计"),
    "equity_parent": ("balance", ("TOTAL_PARENT_EQUITY",), "归母净资产"),
    "total_equity": ("balance", ("TOTAL_EQUITY",), "所有者权益合计"),
    "fixed_assets": ("balance", ("FIXED_ASSET",), "固定资产"),
    "goodwill": ("balance", ("GOODWILL",), "商誉"),
    "rd_capitalized": ("balance", ("DEVELOP_EXPENSE",), "开发支出（余额）"),
    # 现金流量表
    "cfo": ("cashflow", ("NETCASH_OPERATE",), "经营活动现金流量净额"),
    "cfi": ("cashflow", ("NETCASH_INVEST",), "投资活动现金流量净额"),
    "cff": ("cashflow", ("NETCASH_FINANCE",), "筹资活动现金流量净额"),
    "capex": ("cashflow", ("CONSTRUCT_LONG_ASSET",), "资本开支"),
    "cash_received_from_sales": ("cashflow", ("SALES_SERVICES",), "销售商品、提供劳务收到的现金"),
    "interest_paid": ("cashflow", ("PAY_INTEREST_COMMISSION",), "支付的利息"),
    "dividend_paid": ("cashflow", ("ASSIGN_DIVIDEND_PORFIT",), "分配股利、利润或偿付利息支付的现金"),
    # 只用于现金流量勾稽自检，不属于 42 个 canonical 科目
    "cash_net_increase": ("cashflow", ("CCE_ADD",), "现金及现金等价物净增加额"),
}

DERIVED = {
    "depreciation_amortization": ("cashflow",
                                  ("FA_IR_DEPR", "IR_DEPR", "IA_AMORTIZE",
                                   "LPE_AMORTIZE", "USERIGHT_ASSET_AMORTIZE"),
                                  "折旧与摊销"),
    "impairment_loss": ("income", ("ASSET_IMPAIRMENT_LOSS", "CREDIT_IMPAIRMENT_LOSS"),
                        "资产及信用减值损失"),
}

P0_KEYS = [
    "revenue", "operating_cost", "operating_profit", "pretax_profit", "income_tax_expense",
    "net_income", "net_income_parent", "net_income_excl_nonrecurring",
    "selling_expense", "admin_expense", "finance_expense", "interest_expense",
    "depreciation_amortization",
    "cash_and_equivalents", "accounts_receivable", "inventory", "current_assets",
    "total_assets", "accounts_payable", "current_liabilities", "short_term_borrowings",
    "current_portion_lt_debt", "long_term_borrowings", "bonds_payable",
    "total_liabilities", "equity_parent", "total_equity",
    "cfo", "capex", "cash_received_from_sales",
]


def _ok(v) -> bool:
    return isinstance(v, (int, float)) and v == v


def build_online_financials(code: str, year: int, force: bool = False) -> dict:
    """拉 3 年年度三表，返回 canonical financials + company + meta + sources。"""
    cache = _cache_path(f"financials_{ticker_of(code)}_{year}.json")
    if not force:
        hit = _read_cache(cache, CACHE_TTL_SECONDS)
        if hit:
            return hit

    validate_code(code)
    raw = {name: _fetch_statement(name, code) for name in ("income", "balance", "cashflow", "main")}
    by_year = {name: _index_by_year(rows) for name, rows in raw.items()}
    years = sorted(y for y in set().union(*(set(v) for v in by_year.values()))
                   if y <= year)[-3:]
    if year not in years:
        raise OnlineError("E_NO_ANNUAL_REPORT", f"东方财富没有 {year} 年年报数据",
                          "换一个年度，或改用上传 PDF")

    company_profile_ = company_profile(code)
    main_row = by_year["main"].get(year, {})
    company_name = (main_row.get("SECURITY_NAME_ABBR")
                    or company_profile_.get("name_full") or code)

    sources = []
    financials = {}
    src_seq = 0

    def add_record(key: str, label: str, stmt_name: str, fields: tuple[str, ...],
                   mode: str = "first") -> None:
        nonlocal src_seq
        series = {}
        for y in years:
            row = by_year[stmt_name].get(y, {})
            vals = [_num(row.get(f)) for f in fields]
            vals = [v for v in vals if _ok(v)]
            if not vals:
                continue
            series[str(y)] = sum(vals) if mode == "sum" else vals[0]
        value = series.get(str(year))
        prior = series.get(str(year - 1))
        if value is None:
            financials[key] = {
                "metric": key, "label": label, "value": None, "unit": "元",
                "period": str(year), "prior_value": prior, "prior_period": str(year - 1),
                "series": series, "scope": "合并报表", "source_type": "online",
                "source_id": None, "source_field": None, "source_url": None,
                "page": None, "pdf_page": None, "raw_text": None,
                "status": "not_found", "status_note": "数据源未列示",
            }
            return
        src_seq += 1
        sid = f"ON{src_seq:02d}"
        src = {
            "source_id": sid, "metric": key, "source_type": "online",
            "source": f"东方财富·{_STATEMENTS[stmt_name][1]}（年度）",
            "source_url": EM_F10_PAGE.format(code=_em_code(code)),
            "source_field": " + ".join(fields) if mode == "sum" else fields[0],
            "page": None, "pdf_page": None, "pdf_url": None, "upload_id": None,
            "retrieved_at": _now(), "quote": None, "purpose": "财务数据",
        }
        sources.append(src)
        financials[key] = {
            "metric": key, "label": label, "value": value, "unit": "元",
            "period": str(year), "prior_value": prior, "prior_period": str(year - 1),
            "series": series, "basis": "合并", "scope": "合并报表",
            "source_id": sid, "source_type": "online",
            "source": src["source"], "source_url": src["source_url"],
            "source_field": src["source_field"], "page": None, "pdf_page": None,
            "raw_text": None, "confidence": 0.9, "status": "found", "status_note": None,
        }

    for key, (stmt_name, fields, label) in FIELD_MAP.items():
        add_record(key, label, stmt_name, fields)
    for key, (stmt_name, fields, label) in DERIVED.items():
        add_record(key, label, stmt_name, fields, mode="sum")

    # 折旧摊销：现金流补充资料里的几项加总；单列项可能缺失，有多少加多少
    da = financials.get("depreciation_amortization")
    if da and da.get("value") is None:
        financials.pop("depreciation_amortization", None)

    industry = company_profile_.get("industry") or "未识别"
    latest_notice = main_row.get("NOTICE_DATE") or ""
    data_as_of = str(latest_notice)[:10] or None

    company = {
        "name": company_name,
        "name_short": company_profile_.get("name_short") or company_name,
        "name_full": company_profile_.get("name_full") or company_name,
        "ticker": ticker_of(code),
        "exchange": company_profile_.get("exchange") or {
            "sse": "上海证券交易所", "szse": "深圳证券交易所",
            "bse": "北京证券交易所"}.get(identify.exchange_of(code)),
        "industry": industry,
        "industry_code": company_profile_.get("industry_code"),
        "report_period": str(year),
        "report_type": "年度报告",
        "currency": "CNY",
        "amount_unit": "元",
        "scope": "合并报表",
        "auditor": None,
        "audit_opinion": None,
        "source_url": EM_F10_PAGE.format(code=_em_code(code)),
        "market_cap": company_profile_.get("market_cap"),
    }

    meta = {
        "key": f"{ticker_of(code)}_{year}",
        "source_mode": "online",
        "report_period": str(year),
        "period_type": "annual",
        "currency": "CNY",
        "amount_unit": "元",
        "consolidated": True,
        "data_source": "eastmoney",
        "data_as_of": data_as_of,
        "generated_at": _now(),
        "retrieved_at": _now(),
        "years": [str(y) for y in years],
        "coverage": {
            "p0_total": len(P0_KEYS),
            "p0_found": sum(1 for k in P0_KEYS
                            if financials.get(k, {}).get("status") == "found"),
        },
    }

    payload = {
        "schema_version": "2.0",
        "mode": "online",
        "meta": meta, "company": company,
        "financials": financials, "sources": sources,
    }
    _write_cache(cache, payload)
    return payload


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    code = sys.argv[1] if len(sys.argv) > 1 else "600519"
    year = int(sys.argv[2]) if len(sys.argv) > 2 else latest_annual_year()
    print(json.dumps(build_online_financials(code, year, force=True)["meta"],
                     ensure_ascii=False, indent=1))
