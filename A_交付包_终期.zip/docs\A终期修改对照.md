# A 终期修改对照（2026-11-08）

对应 `调整意见/05_A必须修改项.md`。只写 A 自己改的部分，D 适配层不重复。

## A1 万华 current_portion_lt_debt 放大 1 亿倍

**原因**：`table_extract.detect_unit` 取页内第一个「单位：X」，万华第 24 页正文有一句
「其中：其他非流动资产 290.88（单位：亿元…）」，覆盖了真正的表头「单位：元」，
导致 168.16 亿元被乘了 1e8。

**修法**：新增 `unit_from_text()`，优先取以「单位」开头或含「金额单位」的短行，
正文长句里的括号单位不参与；`line_fallback` 同步使用。

**结果**：`current_portion_lt_debt = 16,816,276,501.56` 元（168.16 亿元），
`unit_raw="元"`，`value/value_original=1`；`total_debt` 与总负债同量级。

## A2 五粮液 2025 数据疑似不是年报

**核对结果**：源文件第 1 页封面是「宜宾五粮液股份有限公司 2025 年年度报告」，
第 7 页是「主要会计数据和财务指标」，2025/2024/2023 三列齐全。营收 405.29 亿、
归母净利 89.54 亿、同比 -54.55%/-71.89% 都是原文列示，不是把半年报/季报标成年报。

**已做的**：
- `indicators.py` 从封面识别 `report_title` 和 `report_type`，`PERIOD_ANNUAL` /
  `REPORT_TITLE` 两项检查通过。
- 货币资金 2025/2024 在原文中两列完全相同（合并、母公司两行都相同），
  `SERIES_IDENTICAL` 标为「两年数值完全相同，可能原文未更新或复制列」，
  记录 `status_note` 同步写明。
- `REVENUE_DROP` 对营收同比 < -50% 标 warn，提醒复核年度/重述。

详见 [`000858_source_check.md`](000858_source_check.md)。如果演示需要正常年份，
在页面把年度切到 2024，系统会下载 2024 年报重跑，不伪造 2025 数据。

## A3 三一 cfo / D&A / total_equity

**修法**：
- `total_liabilities` 加 `prefer_max`，同一页先合并后母公司时取非母公司最大候选；
  三一回到合并负债 83,867,741 千元，权益 89,431,397 千元，资产 173,299,138 千元，
  三者勾稽。
- `depreciation_amortization` 加 `prefer_max`，取合并补充资料行 4,092,056 千元，
  不再取母公司的 11,789 千元；2024 为 2,783,826 千元，量级正常。
- cfo 的 2023/2024 在原文里都是 14,814,278 千元（第 6 页主表同一行），
  不是解析器复制列；`SERIES_IDENTICAL` 会标出，`status_note` 写明。

## A4 天赐 page 全空

**原因**：天赐 PDF 的印刷页码映射覆盖率只有 0.05（178 页 missing），pagemap 没有
稳定页码。

**修法**：`cockpit.from_pdf_financials` 对 `page=null` 且 `pdf_page` 有值的 found
记录，用 PDF 物理页兜底，`status_note` 写「该 PDF 未识别到稳定印刷页码，
page 采用 PDF 物理页」。`data/unified/002709.SZ_2025.json` 的 34 条 found 记录
都有 `page`。

## A5 三年覆盖

**修法**：主表按列序补 2023；三表续页按合并/母公司上下文继承来源；
主表行的增减列按「是否像百分比」判断，避免把 -9.89 当 2023。
完整表见 [`coverage_11x30.md`](coverage_11x30.md)。

**结果**（P0 三年齐的科目数 / P0 found）：

| 公司 | 调整前 | 现在 |
|---|---:|---:|
| 000333 美的 | 1/28 | 4/28 |
| 000651 格力 | 1/28 | 5/28 |
| 000858 五粮液 | 5/27 | 6/27 |
| 002415 海康 | 0/29 | 5/29 |
| 002709 天赐 | 2/30 | 6/30 |
| 600031 三一 | 5/29 | 6/29 |
| 600519 茅台 | 7/27 | 7/27 |

资产负债表的年报原文通常只有两期，2023 只出现在主要会计数据摘要；三表明细类
科目无法凑三年，已在 `status_note` 里写「仅两期」。需要完整三年时用
`data/online_samples/` 的在线模式。

## A6 Schema 对不上

新增 [`../schema/canonical_schema.json`](../schema/canonical_schema.json)，
校验 `data/unified/*.json`；`financial_schema.json` 明确为 PDF 原始抽取层
（旧键），两份不再混用。

## A7 scope 出现「未标注」

`from_pdf_financials` 对非 found 记录写 `scope=null`；found 记录只保留
`合并报表` / `母公司报表`，无法判断的写 `null` 并在 `status_note` 说明。

## A8 自检太窄

`data_quality.checks` 现在包含：

- `PERIOD_ANNUAL` / `REPORT_TITLE`：报告期与标题必须是年度；
- `P0_THREE_YEAR`：P0 有三年数据的科目数；
- `SERIES_SCALE`：30 个 P0 全量查百倍跳变，不再只查 11 个 core；
- `SERIES_IDENTICAL`：两年完全相同标「疑似未更新」；
- `UNIT_SCALE`：`unit_raw` 与 `value/value_original` 对不上就 blocked；
- `AMOUNT_MAGNITUDE`：P0 金额比总资产大 10 倍或小于百万分之一就 blocked；
- `BALANCE_SHEET`：差异 >5% 直接 blocked，不再只 warn；
- `REVENUE_DROP`：营收同比 < -50% 标 warn。

## A9 没有联网样例

`data/online_samples/` 提供 000858、000333、600309 三家：
`meta.source_mode="online"`、`source_type="online"`、`source_field`、
`source_url` 有值，`page=null`，三年 `series` 齐全。

## A10 交付包外层混进 B 的文件

`A_交付包/` 第一层只有 A 的 README、交付说明、requirements、src、web、schema、
financial-extraction、docs、verify、demo、data，不含 B 的 `financial-diagnosis/`、
`risk-radar/`。

## 发回时附

1. `A_交付包_终期.zip`
2. `docs/coverage_11x30.md`
3. `data/online_samples/` 三份
4. 本文件
