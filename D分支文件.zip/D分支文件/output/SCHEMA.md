# FinScope 统一数据接口 Schema

本文件是 D 部分交付的统一数据接口说明。配套文件 `Schema.json` 是填好示例值的完整对象，A/B/C 按它的格式交数据，E 只读、不重算。

## 1. 这份接口是干什么的

FinScope 的链路是「上传年报 → 财报抽取 → 指标计算与风险诊断 → 估值 → 投研报告」。五个角色各自产出 JSON，最后汇成同一个数据对象，交给 E 渲染页面。

这份 Schema 定死一件事。全组只认一个顶层对象，A/B/C 各填自己的字段，E 按字段渲染。字段名一旦定下，谁都不改。

顶层结构固定为七个键。

```
company / financials / ratios / risks / rules_evaluated / valuation / sources
```

`risks` 只放触发的风险卡；未触发、不可评估的规则放 `rules_evaluated`。两条的分工见 5.5 与 5.5.1。

## 2. 谁填哪块

| 顶层字段 | 负责人 | 说明 |
|---|---|---|
| company | D 定义，A 补全 | D 定字段名，A 从年报首页与公司简介填入公司基本信息 |
| financials | A | 三表与关键科目的数值，带口径与页码 |
| ratios | B | 六类财务指标，用公式从 financials 算出 |
| risks | B | 触发的风险卡片列表，每条带证据与页码 |
| rules_evaluated | B | 已评估但未触发的规则，含 passed / not_evaluable / not_applicable |
| valuation | C | 相对估值、绝对估值、融合、三情景、分部估值五块，外加行情与免责声明 |
| sources | A 归集 | 每条引用对应的文件名、页码、获取时间 |
| 全字段 | E 只读 | 不重算，不新增派生字段 |

## 3. 全局约定

### 3.1 单位与数值

单位口径与 A/B/C 三家对齐，全组一致。

- **金额一律折算到「元」**。示例 18,650,000,000 表示 186.5 亿元。数量级固定，不随公司规模变。
- **比率一律用小数**，不用百分数数值。示例 0.2847 表示 28.47%。小数保留四位。这是最容易被写错的一条，B 和 C 必须遵守。
- **股本用「股」**。示例 2,200,000,000 表示 22 亿股。
- **每股价值用「元/股」**。它是股价口径，不是金额的口径，与金额的数量级无关。

金额以元为单位，动辄十位数，读起来吃力。所以**文档、表格和前端展示一律加千分符**，写成 `18,650,000,000`。

**但 JSON 数据里不加。** JSON 规范不允许数字带千分符，`18650000000` 才合法，写成 `18,650,000,000` 会被解析成两个字段。所以同一条金额有两种写法：

| 场合 | 写法 |
| --- | --- |
| JSON 数据、代码里的数值 | `18650000000` |
| 屏幕上给人看的（文档表格、网页） | `18,650,000,000` |

E 从数据里读到的是纯数字，显示前自己加千分符。本文档第 4 节的 JSON 示例与表格里的数字，就是为了这个差异分开写的。

`unit` 字段只管数量级，不管币种，取值只有五个。

| unit | 用于 | 示例 |
|---|---|---|
| 元 | 金额、金额类指标 | 18,650,000,000 |
| 小数 | 比率类指标 | 0.2847 |
| 倍 | 覆盖倍数、杠杆倍数、比值类倍数 | 1.82 |
| 天 | 周转天数 | 67.62 |
| 次 | 周转次数 | 5.40 |

`元/股` 是第六个取值，作为每股价值的特殊约定保留。它与金额单位的区别在于，金额是「总量以元计」，每股价值是「每一股多少元」，两者不能混用，也不参与金额的换算。

**精度规则。**

- 金额保留到分，两位小数。整数部分为整时不补小数位，示例 `18650000000.00` 写成 `18650000000`。
- 比率（unit 为小数）保留四位小数。示例 `(18650000000 - 13340000000) / 18650000000 = 0.284718...` 写成 `0.2847`。
- 倍数、天数、次数保留两位小数。
- 年份、页数、年数这类计数保持整数。

**币种单独管。** 币种由 `company.currency` 表示，取值 CNY / USD / HKD。`unit` 不写币种。E 显示时把两者拼起来，`currency=CNY` 显示「人民币元」，`currency=USD` 显示「美元」。

这么分是为了美股。币种塞进 unit 会让美元公司的金额写成「元」，数量级和币种是两件事，分开存才不会串。

- 每一条金额记录都要带 unit 字段，不允许只写数字不写单位。
- 负值直接写负数，投资活动现金流、自由现金流可能为负。示例 -1,850,000,000、-160,000,000。
- 图表与前端展示由 E 自适应。金额到亿元量级显示亿元，到元量级显示元，美元同理。图上和表头都必须标出单位并拼上币种。

### 3.2 口径字段取值

每个 financials 记录必须带口径字段，缺失即视为无效记录。

| 字段 | 取值 | 说明 |
|---|---|---|
| scope | 合并报表、母公司报表 | 同一指标优先取合并口径 |

`basis`（期间口径）不再逐条存，改按科目类型写死规则。

- **资产负债表科目一律「期末数」**。对应 total_assets、total_liabilities、equity_parent、current_assets 等。
- **利润表和现金流量表科目一律「累计数」**。对应 revenue、operating_cost、net_income_parent、cfo 等。

年报主表的口径本来就固定，不会变。以后接了半年报，或者要展示分季度数据，再把 basis 加回来。

### 3.3 空值与未产出

下游要能分清「没有」和「是零」。约定如下。

| 情况 | 写法 | 例子 |
|---|---|---|
| 该模块未产出 | 空对象 `{}` 或空数组 `[]` | C 没做 DCF，则 `"dcf": {}`；无分部数据，则 `"sotp": {"ok": false, "skipped": true}` |
| 该字段不适用 | `null` | 亏损公司算不出 PE，则相应倍数为 `null` |
| 缺失、未抽到 | 数值字段留 `null`，并在 confidence 或说明里标注 | `"value": null` |
| 指标因缺输入算不出 | value 写 `null`，status 写 `not_evaluable` | 缺行业基准，毛利率对比写 `not_evaluable` |
| 抽取到的真实零值 | 写 `0` | 某科目确实为零，写 `0` |

记住一条。`null` 是不知道，`0` 是确定为零。不要把不知道写成 0。

### 3.4 字段命名

- 一律英文小写下划线，如 `net_income_parent`。
- 全文件前后一致，同一含义不出现两个名字。归母净利润固定写 `net_income_parent`，全口径净利润固定写 `net_income`。
- 财务科目名以 `financials` 下的键为准，`ratios` 的 formula 里引用的就是这些键名，两边必须同名。
- formula 里用 `prior_<科目>` 表示该科目的上期值，即 financials 记录里的 `prior_value`。示例 `prior_revenue` 指上期营业收入。

## 4. 完整 JSON 示例

下面这份示例与 `Schema.json` 逐字节一致，可直接对照。示例公司为虚构的「恒锐精密制造股份有限公司」，报告期 2025 年。

数字经过自洽校验，三处勾稽成立。

- 资产总计 26,800,000,000 = 负债合计 11,260,000,000 + 所有者权益合计 15,540,000,000
- 货币资金 4,270,000,000 + 经营 1,520,000,000 + 投资 -1,850,000,000 + 筹资 210,000,000 = 4,150,000,000，与期末货币资金一致
- 毛利率 0.2847 由营业收入 18,650,000,000 与营业成本 13,340,000,000 算出

```json
{
  "company": {
    "name": "恒锐精密制造股份有限公司",
    "ticker": "688123.SH",
    "industry": "高端装备制造",
    "report_period": "2025",
    "exchange": "上海证券交易所科创板",
    "report_type": "年度报告",
    "auditor": "华信会计师事务所（特殊普通合伙）",
    "audit_opinion": "标准无保留意见",
    "currency": "CNY",
    "amount_unit": "元"
  },
  "financials": {
    "revenue": {
      "value": 18650000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 16800000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 82,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "operating_cost": {
      "value": 13340000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 12180000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 82,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "selling_expense": {
      "value": 1120000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1040000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 84,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "admin_expense": {
      "value": 840000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 760000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 84,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "rnd_expense": {
      "value": 980000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 820000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 85,
      "source": "2025年年度报告",
      "confidence": 0.96
    },
    "operating_profit": {
      "value": 2210000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1940000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 86,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "net_income_parent": {
      "value": 1580000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1320000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 87,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "net_income": {
      "value": 1700000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1430000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 87,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "net_income_excl_nonrecurring": {
      "value": 1360000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1100000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 88,
      "source": "2025年年度报告（主要会计数据）",
      "confidence": 0.95
    },
    "total_assets": {
      "value": 26800000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 24600000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 60,
      "source": "2025年年度报告",
      "confidence": 0.99
    },
    "current_assets": {
      "value": 16800000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 15200000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 60,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "total_liabilities": {
      "value": 11260000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 10340000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 61,
      "source": "2025年年度报告",
      "confidence": 0.99
    },
    "current_liabilities": {
      "value": 9250000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 8600000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 61,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "equity_parent": {
      "value": 15540000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 14260000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 62,
      "source": "2025年年度报告",
      "confidence": 0.99
    },
    "cash_and_equivalents": {
      "value": 4150000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 4270000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 60,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "accounts_receivable": {
      "value": 3860000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 3050000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 60,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "inventory": {
      "value": 4420000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 3800000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 60,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "accounts_payable": {
      "value": 3350000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 2900000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 61,
      "source": "2025年年度报告",
      "confidence": 0.97
    },
    "goodwill": {
      "value": 1280000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1280000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 63,
      "source": "2025年年度报告（附注）",
      "confidence": 0.95
    },
    "interest_bearing_debt": {
      "value": 6050000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 5400000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 64,
      "source": "2025年年度报告（借款附注汇总）",
      "confidence": 0.92
    },
    "capex": {
      "value": 1680000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1400000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 70,
      "source": "2025年年度报告",
      "confidence": 0.96
    },
    "depreciation_amortization": {
      "value": 1200000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1100000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 71,
      "source": "2025年年度报告（附注）",
      "confidence": 0.93
    },
    "cfo": {
      "value": 1520000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 1650000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 68,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "cfi": {
      "value": -1850000000,
      "unit": "元",
      "period": "2025",
      "prior_value": -1580000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 69,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "cff": {
      "value": 210000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 150000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 70,
      "source": "2025年年度报告",
      "confidence": 0.98
    },
    "cash_received_from_sales": {
      "value": 20500000000,
      "unit": "元",
      "period": "2025",
      "prior_value": 18200000000,
      "prior_period": "2024",
      "scope": "合并报表",
      "page": 68,
      "source": "2025年年度报告",
      "confidence": 0.97
    }
  },
  "ratios": {
    "growth": {
      "revenue_growth_yoy": {
        "value": 0.1101,
        "unit": "小数",
        "period": "2025",
        "formula": "revenue / prior_revenue - 1",
        "page": 82,
        "prev": 0.1275,
        "delta": -0.0174,
        "inputs": {
          "revenue": 18650000000,
          "prior_revenue": 16800000000
        },
        "inputs_prev": {
          "revenue": 16800000000,
          "prior_revenue": 14900000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_income_growth_yoy": {
        "value": 0.197,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_parent / prior_net_income_parent - 1",
        "page": 87,
        "prev": 0.2222,
        "delta": -0.0252,
        "inputs": {
          "net_income_parent": 1580000000,
          "prior_net_income_parent": 1320000000
        },
        "inputs_prev": {
          "net_income_parent": 1320000000,
          "prior_net_income_parent": 1080000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_income_excl_nonrecurring_growth_yoy": {
        "value": 0.2364,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_excl_nonrecurring / prior_net_income_excl_nonrecurring - 1",
        "page": 88,
        "prev": 0.2222,
        "delta": 0.0142,
        "inputs": {
          "net_income_excl_nonrecurring": 1360000000,
          "prior_net_income_excl_nonrecurring": 1100000000
        },
        "inputs_prev": {
          "net_income_excl_nonrecurring": 1100000000,
          "prior_net_income_excl_nonrecurring": 900000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "revenue_cagr_3y": {
        "value": 0.0777,
        "unit": "小数",
        "period": "2025",
        "formula": "(revenue / revenue_2023) ^ (1/3) - 1",
        "page": 32,
        "prev": null,
        "delta": null,
        "inputs": {
          "revenue": 18650000000,
          "revenue_2023": 14900000000
        },
        "inputs_prev": null,
        "status": "ok",
        "higher_is_better": true
      },
      "cost_of_revenue_growth": {
        "value": 0.0952,
        "unit": "小数",
        "period": "2025",
        "formula": "operating_cost / prior_operating_cost - 1",
        "page": 82,
        "prev": 0.1174,
        "delta": -0.0222,
        "inputs": {
          "operating_cost": 13340000000,
          "prior_operating_cost": 12180000000
        },
        "inputs_prev": {
          "operating_cost": 12180000000,
          "prior_operating_cost": 10900000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "total_assets_growth": {
        "value": 0.0894,
        "unit": "小数",
        "period": "2025",
        "formula": "total_assets / prior_total_assets - 1",
        "page": 60,
        "prev": 0.0885,
        "delta": 0.0009,
        "inputs": {
          "total_assets": 26800000000,
          "prior_total_assets": 24600000000
        },
        "inputs_prev": {
          "total_assets": 24600000000,
          "prior_total_assets": 22600000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "equity_parent_growth": {
        "value": 0.0898,
        "unit": "小数",
        "period": "2025",
        "formula": "equity_parent / prior_equity_parent - 1",
        "page": 62,
        "prev": 0.0885,
        "delta": 0.0013,
        "inputs": {
          "equity_parent": 15540000000,
          "prior_equity_parent": 14260000000
        },
        "inputs_prev": {
          "equity_parent": 14260000000,
          "prior_equity_parent": 13100000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "ocf_growth": {
        "value": -0.0788,
        "unit": "小数",
        "period": "2025",
        "formula": "cfo / prior_cfo - 1",
        "page": 68,
        "prev": 0.1786,
        "delta": -0.2574,
        "inputs": {
          "cfo": 1520000000,
          "prior_cfo": 1650000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "prior_cfo": 1400000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "profit_revenue_scissors": {
        "value": -0.0869,
        "unit": "小数",
        "period": "2025",
        "formula": "(revenue / prior_revenue - 1) - (net_income_parent / prior_net_income_parent - 1)",
        "page": 82,
        "prev": -0.0947,
        "delta": 0.0078,
        "inputs": {
          "revenue_growth": 0.1101,
          "net_income_parent_growth": 0.197
        },
        "inputs_prev": {
          "revenue_growth": 0.1275,
          "net_income_parent_growth": 0.2222
        },
        "status": "ok",
        "higher_is_better": false
      },
      "net_income_total_growth": {
        "value": 0.1888,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income / prior_net_income - 1",
        "page": 87,
        "prev": 0.2119,
        "delta": -0.0231,
        "inputs": {
          "net_income": 1700000000,
          "prior_net_income": 1430000000
        },
        "inputs_prev": {
          "net_income": 1430000000,
          "prior_net_income": 1180000000
        },
        "status": "ok",
        "higher_is_better": true
      }
    },
    "profitability": {
      "gross_margin": {
        "value": 0.2847,
        "unit": "小数",
        "period": "2025",
        "formula": "(revenue - operating_cost) / revenue",
        "page": 82,
        "prev": 0.275,
        "delta": 0.0097,
        "inputs": {
          "revenue": 18650000000,
          "operating_cost": 13340000000
        },
        "inputs_prev": {
          "revenue": 16800000000,
          "operating_cost": 12180000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_margin_total": {
        "value": 0.0912,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income / revenue",
        "page": 87,
        "prev": 0.0851,
        "delta": 0.0061,
        "inputs": {
          "net_income": 1700000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "net_income": 1430000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_margin": {
        "value": 0.0847,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_parent / revenue",
        "page": 87,
        "prev": 0.0786,
        "delta": 0.0061,
        "inputs": {
          "net_income_parent": 1580000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "net_income_parent": 1320000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_margin_deducted": {
        "value": 0.0729,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_excl_nonrecurring / revenue",
        "page": 88,
        "prev": 0.0655,
        "delta": 0.0074,
        "inputs": {
          "net_income_excl_nonrecurring": 1360000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "net_income_excl_nonrecurring": 1100000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "operating_margin": {
        "value": 0.1185,
        "unit": "小数",
        "period": "2025",
        "formula": "operating_profit / revenue",
        "page": 86,
        "prev": 0.1155,
        "delta": 0.003,
        "inputs": {
          "operating_profit": 2210000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "operating_profit": 1940000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "ebit_margin": {
        "value": 0.1299,
        "unit": "小数",
        "period": "2025",
        "formula": "(operating_profit + finance_expense) / revenue",
        "page": 86,
        "prev": 0.1262,
        "delta": 0.0037,
        "inputs": {
          "operating_profit": 2210000000,
          "finance_expense": 213000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "operating_profit": 1940000000,
          "finance_expense": 180000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "selling_expense_ratio": {
        "value": 0.0601,
        "unit": "小数",
        "period": "2025",
        "formula": "selling_expense / revenue",
        "page": 84,
        "prev": 0.0619,
        "delta": -0.0018,
        "inputs": {
          "selling_expense": 1120000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "selling_expense": 1040000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "admin_expense_ratio": {
        "value": 0.045,
        "unit": "小数",
        "period": "2025",
        "formula": "admin_expense / revenue",
        "page": 84,
        "prev": 0.0452,
        "delta": -0.0002,
        "inputs": {
          "admin_expense": 840000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "admin_expense": 760000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "rd_expense_ratio": {
        "value": 0.0525,
        "unit": "小数",
        "period": "2025",
        "formula": "rnd_expense / revenue",
        "page": 85,
        "prev": 0.0488,
        "delta": 0.0037,
        "inputs": {
          "rnd_expense": 980000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "rnd_expense": 820000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "finance_expense_ratio": {
        "value": 0.0114,
        "unit": "小数",
        "period": "2025",
        "formula": "finance_expense / revenue",
        "page": 84,
        "prev": 0.0107,
        "delta": 0.0007,
        "inputs": {
          "finance_expense": 213000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "finance_expense": 180000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "period_expense_ratio": {
        "value": 0.1691,
        "unit": "小数",
        "period": "2025",
        "formula": "(selling_expense + admin_expense + rnd_expense + finance_expense) / revenue",
        "page": 84,
        "prev": 0.1667,
        "delta": 0.0024,
        "inputs": {
          "selling_expense": 1120000000,
          "admin_expense": 840000000,
          "rnd_expense": 980000000,
          "finance_expense": 213000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "selling_expense": 1040000000,
          "admin_expense": 760000000,
          "rnd_expense": 820000000,
          "finance_expense": 180000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "roe_weighted": {
        "value": 0.106,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_parent / ((equity_parent + prior_equity_parent) / 2)",
        "page": 62,
        "prev": 0.0965,
        "delta": 0.0095,
        "inputs": {
          "net_income_parent": 1580000000,
          "equity_parent": 15540000000,
          "prior_equity_parent": 14260000000
        },
        "inputs_prev": {
          "net_income_parent": 1320000000,
          "equity_parent": 14260000000,
          "prior_equity_parent": 13100000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "roa": {
        "value": 0.0661,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income / ((total_assets + prior_total_assets) / 2)",
        "page": 60,
        "prev": 0.0606,
        "delta": 0.0055,
        "inputs": {
          "net_income": 1700000000,
          "total_assets": 26800000000,
          "prior_total_assets": 24600000000
        },
        "inputs_prev": {
          "net_income": 1430000000,
          "total_assets": 24600000000,
          "prior_total_assets": 22600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "roic": {
        "value": 0.096,
        "unit": "小数",
        "period": "2025",
        "formula": "nopat / ((interest_bearing_debt + prior_interest_bearing_debt + equity_parent + prior_equity_parent) / 2), nopat = (operating_profit + finance_expense) * (1 - effective_tax_rate)",
        "page": 64,
        "prev": 0.0928,
        "delta": 0.0032,
        "inputs": {
          "operating_profit": 2210000000,
          "finance_expense": 213000000,
          "effective_tax_rate": 0.18269230769230768,
          "interest_bearing_debt": 6050000000,
          "prior_interest_bearing_debt": 5400000000,
          "equity_parent": 15540000000,
          "prior_equity_parent": 14260000000
        },
        "inputs_prev": {
          "operating_profit": 1940000000,
          "finance_expense": 180000000,
          "effective_tax_rate": 0.1781609195402299,
          "interest_bearing_debt": 5400000000,
          "prior_interest_bearing_debt": 4800000000,
          "equity_parent": 14260000000,
          "prior_equity_parent": 13100000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "effective_tax_rate": {
        "value": 0.1827,
        "unit": "小数",
        "period": "2025",
        "formula": "income_tax_expense / pretax_profit",
        "page": 86,
        "prev": 0.1782,
        "delta": 0.0045,
        "inputs": {
          "income_tax_expense": 380000000,
          "pretax_profit": 2080000000
        },
        "inputs_prev": {
          "income_tax_expense": 310000000,
          "pretax_profit": 1740000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "deducted_to_parent": {
        "value": 0.8608,
        "unit": "小数",
        "period": "2025",
        "formula": "net_income_excl_nonrecurring / net_income_parent",
        "page": 88,
        "prev": 0.8333,
        "delta": 0.0275,
        "inputs": {
          "net_income_excl_nonrecurring": 1360000000,
          "net_income_parent": 1580000000
        },
        "inputs_prev": {
          "net_income_excl_nonrecurring": 1100000000,
          "net_income_parent": 1320000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "ebitda_margin": {
        "value": 0.1828,
        "unit": "小数",
        "period": "2025",
        "formula": "(operating_profit + depreciation_amortization) / revenue",
        "page": 71,
        "prev": 0.181,
        "delta": 0.0018,
        "inputs": {
          "operating_profit": 2210000000,
          "depreciation_amortization": 1200000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "operating_profit": 1940000000,
          "depreciation_amortization": 1100000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "roic_minus_wacc": {
        "value": 0.016,
        "unit": "小数",
        "period": "2025",
        "formula": "roic - wacc",
        "page": 64,
        "prev": 0.0128,
        "delta": 0.0032,
        "inputs": {
          "roic": 0.096,
          "wacc": 0.08
        },
        "inputs_prev": {
          "roic": 0.0928,
          "wacc": 0.08
        },
        "status": "ok",
        "higher_is_better": true
      }
    },
    "solvency": {
      "current_ratio": {
        "value": 1.82,
        "unit": "倍",
        "period": "2025",
        "formula": "current_assets / current_liabilities",
        "page": 60,
        "prev": 1.77,
        "delta": 0.05,
        "inputs": {
          "current_assets": 16800000000,
          "current_liabilities": 9250000000
        },
        "inputs_prev": {
          "current_assets": 15200000000,
          "current_liabilities": 8600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "quick_ratio": {
        "value": 1.34,
        "unit": "倍",
        "period": "2025",
        "formula": "(current_assets - inventory) / current_liabilities",
        "page": 60,
        "prev": 1.33,
        "delta": 0.01,
        "inputs": {
          "current_assets": 16800000000,
          "inventory": 4420000000,
          "current_liabilities": 9250000000
        },
        "inputs_prev": {
          "current_assets": 15200000000,
          "inventory": 3800000000,
          "current_liabilities": 8600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "cash_ratio": {
        "value": 0.45,
        "unit": "倍",
        "period": "2025",
        "formula": "cash_and_equivalents / current_liabilities",
        "page": 60,
        "prev": 0.5,
        "delta": -0.05,
        "inputs": {
          "cash_and_equivalents": 4150000000,
          "current_liabilities": 9250000000
        },
        "inputs_prev": {
          "cash_and_equivalents": 4270000000,
          "current_liabilities": 8600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "debt_to_asset_ratio": {
        "value": 0.4201,
        "unit": "小数",
        "period": "2025",
        "formula": "total_liabilities / total_assets",
        "page": 61,
        "prev": 0.4203,
        "delta": -0.0002,
        "inputs": {
          "total_liabilities": 11260000000,
          "total_assets": 26800000000
        },
        "inputs_prev": {
          "total_liabilities": 10340000000,
          "total_assets": 24600000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "equity_multiplier": {
        "value": 1.72,
        "unit": "倍",
        "period": "2025",
        "formula": "total_assets / equity_parent",
        "page": 62,
        "prev": 1.73,
        "delta": -0.01,
        "inputs": {
          "total_assets": 26800000000,
          "equity_parent": 15540000000
        },
        "inputs_prev": {
          "total_assets": 24600000000,
          "equity_parent": 14260000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "interest_bearing_debt": {
        "value": 6050000000,
        "unit": "元",
        "period": "2025",
        "formula": "interest_bearing_debt（原值）",
        "page": 64,
        "prev": 5400000000,
        "delta": 650000000,
        "inputs": {
          "interest_bearing_debt": 6050000000
        },
        "inputs_prev": {
          "interest_bearing_debt": 5400000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "interest_bearing_debt_ratio": {
        "value": 0.2257,
        "unit": "小数",
        "period": "2025",
        "formula": "interest_bearing_debt / total_assets",
        "page": 64,
        "prev": 0.2195,
        "delta": 0.0062,
        "inputs": {
          "interest_bearing_debt": 6050000000,
          "total_assets": 26800000000
        },
        "inputs_prev": {
          "interest_bearing_debt": 5400000000,
          "total_assets": 24600000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "interest_bearing_debt_growth": {
        "value": 0.1204,
        "unit": "小数",
        "period": "2025",
        "formula": "interest_bearing_debt / prior_interest_bearing_debt - 1",
        "page": 64,
        "prev": 0.125,
        "delta": -0.0046,
        "inputs": {
          "interest_bearing_debt": 6050000000,
          "prior_interest_bearing_debt": 5400000000
        },
        "inputs_prev": {
          "interest_bearing_debt": 5400000000,
          "prior_interest_bearing_debt": 4800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "net_debt": {
        "value": 1900000000,
        "unit": "元",
        "period": "2025",
        "formula": "interest_bearing_debt - cash_and_equivalents",
        "page": 64,
        "prev": 1130000000,
        "delta": 770000000,
        "inputs": {
          "interest_bearing_debt": 6050000000,
          "cash_and_equivalents": 4150000000
        },
        "inputs_prev": {
          "interest_bearing_debt": 5400000000,
          "cash_and_equivalents": 4270000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "cash_to_short_term_debt": {
        "value": 1.14,
        "unit": "倍",
        "period": "2025",
        "formula": "cash_and_equivalents / (short_term_borrowings + current_portion_lt_debt)",
        "page": 64,
        "prev": 1.31,
        "delta": -0.17,
        "inputs": {
          "cash_and_equivalents": 4150000000,
          "short_term_borrowings": 3000000000,
          "current_portion_lt_debt": 650000000
        },
        "inputs_prev": {
          "cash_and_equivalents": 4270000000,
          "short_term_borrowings": 2700000000,
          "current_portion_lt_debt": 560000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "interest_coverage": {
        "value": 11.82,
        "unit": "倍",
        "period": "2025",
        "formula": "(operating_profit + finance_expense) / interest_expense",
        "page": 64,
        "prev": 12.11,
        "delta": -0.29,
        "inputs": {
          "operating_profit": 2210000000,
          "finance_expense": 213000000,
          "interest_expense": 205000000
        },
        "inputs_prev": {
          "operating_profit": 1940000000,
          "finance_expense": 180000000,
          "interest_expense": 175000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "net_debt_to_ebitda": {
        "value": 0.56,
        "unit": "倍",
        "period": "2025",
        "formula": "(interest_bearing_debt - cash_and_equivalents) / (operating_profit + depreciation_amortization)",
        "page": 64,
        "prev": 0.37,
        "delta": 0.19,
        "inputs": {
          "interest_bearing_debt": 6050000000,
          "cash_and_equivalents": 4150000000,
          "operating_profit": 2210000000,
          "depreciation_amortization": 1200000000
        },
        "inputs_prev": {
          "interest_bearing_debt": 5400000000,
          "cash_and_equivalents": 4270000000,
          "operating_profit": 1940000000,
          "depreciation_amortization": 1100000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "restricted_cash_ratio": {
        "value": 0.1012,
        "unit": "小数",
        "period": "2025",
        "formula": "restricted_cash / cash_and_equivalents",
        "page": 64,
        "prev": 0.0937,
        "delta": 0.0075,
        "inputs": {
          "restricted_cash": 420000000,
          "cash_and_equivalents": 4150000000
        },
        "inputs_prev": {
          "restricted_cash": 400000000,
          "cash_and_equivalents": 4270000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "working_capital": {
        "value": 7550000000,
        "unit": "元",
        "period": "2025",
        "formula": "current_assets - current_liabilities",
        "page": 60,
        "prev": 6600000000,
        "delta": 950000000,
        "inputs": {
          "current_assets": 16800000000,
          "current_liabilities": 9250000000
        },
        "inputs_prev": {
          "current_assets": 15200000000,
          "current_liabilities": 8600000000
        },
        "status": "ok",
        "higher_is_better": null
      }
    },
    "efficiency": {
      "ar_turnover": {
        "value": 5.4,
        "unit": "次",
        "period": "2025",
        "formula": "revenue / ((accounts_receivable + prior_accounts_receivable) / 2)",
        "page": 60,
        "prev": 6.11,
        "delta": -0.71,
        "inputs": {
          "revenue": 18650000000,
          "accounts_receivable": 3860000000,
          "prior_accounts_receivable": 3050000000
        },
        "inputs_prev": {
          "revenue": 16800000000,
          "accounts_receivable": 3050000000,
          "prior_accounts_receivable": 2450000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "inventory_turnover": {
        "value": 3.25,
        "unit": "次",
        "period": "2025",
        "formula": "operating_cost / ((inventory + prior_inventory) / 2)",
        "page": 60,
        "prev": 3.43,
        "delta": -0.18,
        "inputs": {
          "operating_cost": 13340000000,
          "inventory": 4420000000,
          "prior_inventory": 3800000000
        },
        "inputs_prev": {
          "operating_cost": 12180000000,
          "inventory": 3800000000,
          "prior_inventory": 3300000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "ap_turnover": {
        "value": 4.27,
        "unit": "次",
        "period": "2025",
        "formula": "operating_cost / ((accounts_payable + prior_accounts_payable) / 2)",
        "page": 61,
        "prev": 4.51,
        "delta": -0.24,
        "inputs": {
          "operating_cost": 13340000000,
          "accounts_payable": 3350000000,
          "prior_accounts_payable": 2900000000
        },
        "inputs_prev": {
          "operating_cost": 12180000000,
          "accounts_payable": 2900000000,
          "prior_accounts_payable": 2500000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "ar_turnover_days": {
        "value": 67.62,
        "unit": "天",
        "period": "2025",
        "formula": "((accounts_receivable + prior_accounts_receivable) / 2) / revenue * 365",
        "page": 60,
        "prev": 59.75,
        "delta": 7.87,
        "inputs": {
          "accounts_receivable": 3860000000,
          "prior_accounts_receivable": 3050000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "accounts_receivable": 3050000000,
          "prior_accounts_receivable": 2450000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "inventory_turnover_days": {
        "value": 112.46,
        "unit": "天",
        "period": "2025",
        "formula": "((inventory + prior_inventory) / 2) / operating_cost * 365",
        "page": 60,
        "prev": 106.38,
        "delta": 6.08,
        "inputs": {
          "inventory": 4420000000,
          "prior_inventory": 3800000000,
          "operating_cost": 13340000000
        },
        "inputs_prev": {
          "inventory": 3800000000,
          "prior_inventory": 3300000000,
          "operating_cost": 12180000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "payable_turnover_days": {
        "value": 85.5,
        "unit": "天",
        "period": "2025",
        "formula": "((accounts_payable + prior_accounts_payable) / 2) / operating_cost * 365",
        "page": 61,
        "prev": 80.91,
        "delta": 4.59,
        "inputs": {
          "accounts_payable": 3350000000,
          "prior_accounts_payable": 2900000000,
          "operating_cost": 13340000000
        },
        "inputs_prev": {
          "accounts_payable": 2900000000,
          "prior_accounts_payable": 2500000000,
          "operating_cost": 12180000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "cash_conversion_cycle": {
        "value": 94.57,
        "unit": "天",
        "period": "2025",
        "formula": "ar_turnover_days + inventory_turnover_days - payable_turnover_days",
        "page": 60,
        "prev": 85.22,
        "delta": 9.35,
        "inputs": {
          "ar_turnover_days": 67.62,
          "inventory_turnover_days": 112.46,
          "payable_turnover_days": 85.5
        },
        "inputs_prev": {
          "ar_turnover_days": 59.75,
          "inventory_turnover_days": 106.38,
          "payable_turnover_days": 80.91
        },
        "status": "ok",
        "higher_is_better": false
      },
      "total_asset_turnover": {
        "value": 0.73,
        "unit": "次",
        "period": "2025",
        "formula": "revenue / ((total_assets + prior_total_assets) / 2)",
        "page": 60,
        "prev": 0.71,
        "delta": 0.02,
        "inputs": {
          "revenue": 18650000000,
          "total_assets": 26800000000,
          "prior_total_assets": 24600000000
        },
        "inputs_prev": {
          "revenue": 16800000000,
          "total_assets": 24600000000,
          "prior_total_assets": 22600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "fixed_asset_turnover": {
        "value": 3.08,
        "unit": "次",
        "period": "2025",
        "formula": "revenue / ((fixed_assets + prior_fixed_assets) / 2)",
        "page": 63,
        "prev": 2.95,
        "delta": 0.13,
        "inputs": {
          "revenue": 18650000000,
          "fixed_assets": 6300000000,
          "prior_fixed_assets": 5800000000
        },
        "inputs_prev": {
          "revenue": 16800000000,
          "fixed_assets": 5800000000,
          "prior_fixed_assets": 5600000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "accounts_receivable_growth": {
        "value": 0.2656,
        "unit": "小数",
        "period": "2025",
        "formula": "accounts_receivable / prior_accounts_receivable - 1",
        "page": 60,
        "prev": 0.2449,
        "delta": 0.0207,
        "inputs": {
          "accounts_receivable": 3860000000,
          "prior_accounts_receivable": 3050000000
        },
        "inputs_prev": {
          "accounts_receivable": 3050000000,
          "prior_accounts_receivable": 2450000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "inventory_growth": {
        "value": 0.1632,
        "unit": "小数",
        "period": "2025",
        "formula": "inventory / prior_inventory - 1",
        "page": 60,
        "prev": 0.1515,
        "delta": 0.0117,
        "inputs": {
          "inventory": 4420000000,
          "prior_inventory": 3800000000
        },
        "inputs_prev": {
          "inventory": 3800000000,
          "prior_inventory": 3300000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "ar_and_inventory_to_assets": {
        "value": 0.3265,
        "unit": "小数",
        "period": "2025",
        "formula": "(accounts_receivable + notes_receivable + contract_assets + inventory) / total_assets",
        "page": 60,
        "prev": 0.2939,
        "delta": 0.0326,
        "inputs": {
          "accounts_receivable": 3860000000,
          "notes_receivable": 350000000,
          "contract_assets": 120000000,
          "inventory": 4420000000,
          "total_assets": 26800000000
        },
        "inputs_prev": {
          "accounts_receivable": 3050000000,
          "notes_receivable": 280000000,
          "contract_assets": 100000000,
          "inventory": 3800000000,
          "total_assets": 24600000000
        },
        "status": "ok",
        "higher_is_better": false
      }
    },
    "cashflow_quality": {
      "ocf": {
        "value": 1520000000,
        "unit": "元",
        "period": "2025",
        "formula": "cfo（原值）",
        "page": 68,
        "prev": 1650000000,
        "delta": -130000000,
        "inputs": {
          "cfo": 1520000000
        },
        "inputs_prev": {
          "cfo": 1650000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "cfo_to_net_income_total": {
        "value": 0.8941,
        "unit": "小数",
        "period": "2025",
        "formula": "cfo / net_income",
        "page": 68,
        "prev": 1.1538,
        "delta": -0.2597,
        "inputs": {
          "cfo": 1520000000,
          "net_income": 1700000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "net_income": 1430000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "cfo_to_net_income": {
        "value": 0.962,
        "unit": "小数",
        "period": "2025",
        "formula": "cfo / net_income_parent",
        "page": 68,
        "prev": 1.25,
        "delta": -0.288,
        "inputs": {
          "cfo": 1520000000,
          "net_income_parent": 1580000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "net_income_parent": 1320000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "ocf_to_revenue": {
        "value": 0.0815,
        "unit": "小数",
        "period": "2025",
        "formula": "cfo / revenue",
        "page": 68,
        "prev": 0.0982,
        "delta": -0.0167,
        "inputs": {
          "cfo": 1520000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "cash_collection_ratio": {
        "value": 1.0992,
        "unit": "小数",
        "period": "2025",
        "formula": "cash_received_from_sales / revenue",
        "page": 68,
        "prev": 1.0833,
        "delta": 0.0159,
        "inputs": {
          "cash_received_from_sales": 20500000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "cash_received_from_sales": 18200000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "capex": {
        "value": 1680000000,
        "unit": "元",
        "period": "2025",
        "formula": "capex（原值）",
        "page": 70,
        "prev": 1400000000,
        "delta": 280000000,
        "inputs": {
          "capex": 1680000000
        },
        "inputs_prev": {
          "capex": 1400000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "capex_to_ocf": {
        "value": 1.11,
        "unit": "倍",
        "period": "2025",
        "formula": "capex / cfo",
        "page": 70,
        "prev": 0.85,
        "delta": 0.26,
        "inputs": {
          "capex": 1680000000,
          "cfo": 1520000000
        },
        "inputs_prev": {
          "capex": 1400000000,
          "cfo": 1650000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "free_cash_flow": {
        "value": -160000000,
        "unit": "元",
        "period": "2025",
        "formula": "cfo - capex",
        "page": 68,
        "prev": 250000000,
        "delta": -410000000,
        "inputs": {
          "cfo": 1520000000,
          "capex": 1680000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "capex": 1400000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "fcf_to_revenue": {
        "value": -0.0086,
        "unit": "小数",
        "period": "2025",
        "formula": "(cfo - capex) / revenue",
        "page": 68,
        "prev": 0.0149,
        "delta": -0.0235,
        "inputs": {
          "cfo": 1520000000,
          "capex": 1680000000,
          "revenue": 18650000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "capex": 1400000000,
          "revenue": 16800000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "ocf_to_interest_paid": {
        "value": 7.79,
        "unit": "倍",
        "period": "2025",
        "formula": "cfo / interest_paid",
        "page": 68,
        "prev": 9.71,
        "delta": -1.92,
        "inputs": {
          "cfo": 1520000000,
          "interest_paid": 195000000
        },
        "inputs_prev": {
          "cfo": 1650000000,
          "interest_paid": 170000000
        },
        "status": "ok",
        "higher_is_better": true
      },
      "payout_ratio": {
        "value": 0.3481,
        "unit": "小数",
        "period": "2025",
        "formula": "dividend_paid / net_income_parent",
        "page": 62,
        "prev": 0.1515,
        "delta": 0.1966,
        "inputs": {
          "dividend_paid": 550000000,
          "net_income_parent": 1580000000
        },
        "inputs_prev": {
          "dividend_paid": 200000000,
          "net_income_parent": 1320000000
        },
        "status": "ok",
        "higher_is_better": null
      },
      "cf_financing_dependency": {
        "value": 0.1784,
        "unit": "小数",
        "period": "2025",
        "formula": "(abs(cfi) - cfo) / abs(cfi)",
        "page": 69,
        "prev": -0.0443,
        "delta": 0.2227,
        "inputs": {
          "cfi": -1850000000,
          "cfo": 1520000000
        },
        "inputs_prev": {
          "cfi": -1580000000,
          "cfo": 1650000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "goodwill_to_equity": {
        "value": 0.0824,
        "unit": "小数",
        "period": "2025",
        "formula": "goodwill / equity_parent",
        "page": 63,
        "prev": 0.0898,
        "delta": -0.0074,
        "inputs": {
          "goodwill": 1280000000,
          "equity_parent": 15540000000
        },
        "inputs_prev": {
          "goodwill": 1280000000,
          "equity_parent": 14260000000
        },
        "status": "ok",
        "higher_is_better": false
      },
      "capex_to_da_ratio": {
        "value": 1.4,
        "unit": "倍",
        "period": "2025",
        "formula": "capex / depreciation_amortization",
        "page": 70,
        "prev": 1.27,
        "delta": 0.13,
        "inputs": {
          "capex": 1680000000,
          "depreciation_amortization": 1200000000
        },
        "inputs_prev": {
          "capex": 1400000000,
          "depreciation_amortization": 1100000000
        },
        "status": "ok",
        "higher_is_better": null
      }
    },
    "banking": {}
  },
  "risks": [
    {
      "risk_id": "R01",
      "risk_name": "应收账款增速快于营业收入增速",
      "category": "收入与资产",
      "severity": "medium",
      "severity_tag": "关注",
      "score": 60.0,
      "status": "triggered",
      "trigger": "应收账款增速 - 营业收入增速 > 5 个百分点",
      "involved_values": [
        {
          "metric": "accounts_receivable",
          "value": 3860000000,
          "unit": "元",
          "period": "2025",
          "page": 60
        },
        {
          "metric": "accounts_receivable",
          "value": 3050000000,
          "unit": "元",
          "period": "2024",
          "page": 60
        },
        {
          "metric": "accounts_receivable_growth",
          "value": 0.2656,
          "unit": "小数",
          "period": "2025",
          "page": 60
        },
        {
          "metric": "revenue_growth_yoy",
          "value": 0.1101,
          "unit": "小数",
          "period": "2025",
          "page": 82
        }
      ],
      "numeric_evidence": "应收账款由 3050000000 元增至 3860000000 元，增速 26.6%；营业收入增速 11.0%，相差 15.5 个百分点，超过 5 个百分点阈值。",
      "text_evidence": {
        "quote": "报告期内公司适度放宽了部分战略客户的信用账期。",
        "page": 45
      },
      "explanation": "应收增速显著高于收入增速，可能通过放宽信用政策换取收入增长，也可能是收入确认节奏前移，需结合账龄与坏账计提判断回款质量。",
      "suggested_action": "核对应收账款账龄结构附注与前五大欠款方，比较信用政策是否变化。",
      "evidence_chain": [
        {
          "step": "数据",
          "item": "accounts_receivable",
          "value": 3860000000,
          "unit": "元",
          "prev_value": 3050000000,
          "source": "2025年年度报告",
          "page": 60
        },
        {
          "step": "数据",
          "item": "revenue",
          "value": 18650000000,
          "unit": "元",
          "prev_value": 16800000000,
          "source": "2025年年度报告",
          "page": 82
        },
        {
          "step": "计算",
          "item": "触发表达式",
          "formula": "accounts_receivable_growth - revenue_growth > 0.05",
          "values": {
            "accounts_receivable_growth": 0.2656,
            "revenue_growth": 0.1101
          }
        },
        {
          "step": "出处",
          "item": "年报来源与页码",
          "sources": [
            "2025年年度报告"
          ],
          "pages": [
            60,
            82
          ]
        },
        {
          "step": "判断",
          "item": "应收增速 - 收入增速 > 5 个百分点",
          "result": "触发",
          "severity": "medium"
        },
        {
          "step": "建议",
          "item": "下一步动作",
          "actions": [
            "读取应收账款附注按账龄结构查看一年以上占比",
            "检查前五大客户集中度与关联方占比",
            "检查坏账计提比例是否随账龄恶化同步提高"
          ]
        }
      ]
    },
    {
      "risk_id": "R02",
      "risk_name": "存货周转天数上行且高于同业",
      "category": "收入与资产",
      "severity": "low",
      "severity_tag": "提示",
      "score": 40.0,
      "status": "triggered",
      "trigger": "存货周转天数连续两期上行，且高于同业中位数",
      "involved_values": [
        {
          "metric": "inventory_turnover_days",
          "value": 112.46,
          "unit": "天",
          "period": "2025",
          "page": 60
        },
        {
          "metric": "inventory_turnover_days",
          "value": 106.38,
          "unit": "天",
          "period": "2024",
          "page": 60
        }
      ],
      "numeric_evidence": "存货周转天数由 106.38 天升至 112.46 天，同业中位数约 95 天，偏高约 17 天。",
      "text_evidence": {
        "quote": "受下游需求波动影响，部分在产品备货周期有所拉长。",
        "page": 47
      },
      "explanation": "库存周转放缓叠加高于同业，可能指向需求走弱或产品滞销。当前幅度有限，列为观察项。",
      "suggested_action": "核对存货构成与跌价准备计提，结合在手订单判断是否存在积压。",
      "evidence_chain": [
        {
          "step": "数据",
          "item": "inventory",
          "value": 4420000000,
          "unit": "元",
          "prev_value": 3800000000,
          "source": "2025年年度报告",
          "page": 60
        },
        {
          "step": "计算",
          "item": "触发表达式",
          "formula": "inventory_turnover_days_delta > 0",
          "values": {
            "inventory_turnover_days": 112.46,
            "prev": 106.38
          }
        },
        {
          "step": "出处",
          "item": "年报来源与页码",
          "sources": [
            "2025年年度报告"
          ],
          "pages": [
            60
          ]
        },
        {
          "step": "判断",
          "item": "存货周转天数连续两期上行且高于同业中位数",
          "result": "触发",
          "severity": "low"
        },
        {
          "step": "建议",
          "item": "下一步动作",
          "actions": [
            "核对存货构成与跌价准备计提",
            "结合在手订单判断是否存在积压"
          ]
        }
      ]
    },
    {
      "risk_id": "R03",
      "risk_name": "控股股东股权质押比例偏高",
      "category": "治理与合规",
      "severity": "medium",
      "severity_tag": "关注",
      "score": 60.0,
      "status": "triggered",
      "trigger": "控股股东质押股份占其持股比例超过 50%",
      "involved_values": [
        {
          "metric": "pledge_ratio",
          "value": 0.58,
          "unit": "小数",
          "period": "2025",
          "page": 51
        }
      ],
      "numeric_evidence": "控股股东累计质押 1.05 亿股，占其所持 1.81 亿股的 58.0%，超过 50% 观察线。",
      "text_evidence": {
        "quote": "截至报告期末，控股股东已质押股份 1.05 亿股，占其所持股份的 58.0%。",
        "page": 51
      },
      "explanation": "高比例质押在股价波动时可能引发控制权稳定风险，属治理类信号，与当期财务数字无关但影响风险评级。",
      "suggested_action": "跟踪质押平仓线与控股股东资金用途披露。",
      "evidence_chain": [
        {
          "step": "数据",
          "item": "pledge_ratio",
          "value": 0.58,
          "unit": "小数",
          "source": "2025年年度报告（公司治理章节）",
          "page": 51
        },
        {
          "step": "计算",
          "item": "触发表达式",
          "formula": "pledge_ratio > 0.50",
          "values": {
            "pledge_ratio": 0.58
          }
        },
        {
          "step": "出处",
          "item": "年报来源与页码",
          "sources": [
            "2025年年度报告"
          ],
          "pages": [
            51
          ]
        },
        {
          "step": "判断",
          "item": "控股股东质押比例 > 50%",
          "result": "触发",
          "severity": "medium"
        },
        {
          "step": "建议",
          "item": "下一步动作",
          "actions": [
            "跟踪质押平仓线与控股股东资金用途披露"
          ]
        }
      ]
    }
  ],
  "rules_evaluated": [
    {
      "rule_id": "P03",
      "rule_name": "毛利率未低于行业中位数",
      "category": "盈利质量",
      "status": "not_evaluable",
      "severity": null,
      "severity_tag": null,
      "trigger": "gross_margin < industry_gross_margin_benchmark",
      "explanation": "缺少行业毛利率基准，标记为 not_evaluable，转人工核验，不做无风险假设。",
      "trigger_values": {
        "gross_margin": 0.2847,
        "industry_gross_margin_benchmark": null
      }
    },
    {
      "rule_id": "S06",
      "rule_name": "流动比率未偏低",
      "category": "偿债与流动性",
      "status": "passed",
      "severity": null,
      "severity_tag": null,
      "trigger": "current_ratio < 1.2",
      "explanation": "规则已执行，条件不成立，本项无异常。",
      "trigger_values": {
        "current_ratio": 1.82
      }
    },
    {
      "rule_id": "S07",
      "rule_name": "净负债/EBITDA 未偏高",
      "category": "偿债与流动性",
      "status": "passed",
      "severity": null,
      "severity_tag": null,
      "trigger": "net_debt_to_ebitda > 3",
      "explanation": "规则已执行，条件不成立，本项无异常。",
      "trigger_values": {
        "net_debt_to_ebitda": 0.56
      }
    },
    {
      "rule_id": "P04",
      "rule_name": "期间费用率未明显上升",
      "category": "盈利质量",
      "status": "passed",
      "severity": null,
      "severity_tag": null,
      "trigger": "period_expense_ratio_delta > 0.02",
      "explanation": "规则已执行，条件不成立，本项无异常。",
      "trigger_values": {
        "period_expense_ratio_delta": 0.0024
      }
    },
    {
      "rule_id": "G06",
      "rule_name": "营业收入未下滑",
      "category": "收入与资产",
      "status": "passed",
      "severity": null,
      "severity_tag": null,
      "trigger": "revenue_growth < 0",
      "explanation": "规则已执行，条件不成立，本项无异常。",
      "trigger_values": {
        "revenue_growth": 0.1101
      }
    }
  ],
  "valuation": {
    "comps": {
      "inputs": {
        "revenue": 18650000000,
        "net_income": 1580000000,
        "ebitda": 3410000000,
        "net_debt": 1900000000,
        "share_price": 16.5,
        "shares_outstanding": 2200000000,
        "shares_unit": "股",
        "market_cap": 36300000000,
        "currency": "CNY"
      },
      "peer_companies": [
        {
          "name": "锐科装备",
          "ticker": "002xxx.SZ",
          "pe": 20.5,
          "pb": 2.1,
          "ev_ebitda": 11.0,
          "ps": 1.9
        },
        {
          "name": "精工制造",
          "ticker": "300xxx.SZ",
          "pe": 24.0,
          "pb": 2.6,
          "ev_ebitda": 13.2,
          "ps": 2.3
        },
        {
          "name": "恒达智造",
          "ticker": "600xxx.SH",
          "pe": 18.0,
          "pb": 1.9,
          "ev_ebitda": 9.8,
          "ps": 1.6
        }
      ],
      "peer_multiples": {
        "pe": {
          "min": 18.0,
          "median": 20.5,
          "max": 24.0
        },
        "pb": {
          "min": 1.9,
          "median": 2.1,
          "max": 2.6
        },
        "ev_ebitda": {
          "min": 9.8,
          "median": 11.0,
          "max": 13.2
        },
        "ps": {
          "min": 1.6,
          "median": 1.9,
          "max": 2.3
        }
      },
      "implied_value_per_share": {
        "pe": {
          "low": 12.9,
          "mid": 14.7,
          "high": 17.2
        },
        "pb": {
          "low": 13.4,
          "mid": 14.8,
          "high": 18.4
        },
        "ev_ebitda": {
          "low": 14.3,
          "mid": 16.2,
          "high": 19.6
        },
        "ps": {
          "low": 13.6,
          "mid": 16.1,
          "high": 19.5
        }
      },
      "valuation_range": {
        "low": 12.9,
        "mid": 15.5,
        "high": 19.6,
        "currency": "元/股"
      }
    },
    "dcf": {
      "inputs": {
        "revenue_base": 18650000000,
        "ebit_margin": 0.119,
        "tax_rate": 0.19,
        "da": 1200000000,
        "capex": 1680000000,
        "nwc": 4930000000,
        "wacc": 0.08,
        "terminal_growth": 0.03,
        "forecast_years": 5
      },
      "forecast": [
        {
          "year": 2026,
          "revenue": 20140000000,
          "ebit": 2400000000,
          "fcff": 1400000000
        },
        {
          "year": 2027,
          "revenue": 21550000000,
          "ebit": 2560000000,
          "fcff": 1520000000
        },
        {
          "year": 2028,
          "revenue": 22850000000,
          "ebit": 2720000000,
          "fcff": 1640000000
        },
        {
          "year": 2029,
          "revenue": 23990000000,
          "ebit": 2850000000,
          "fcff": 1760000000
        },
        {
          "year": 2030,
          "revenue": 24950000000,
          "ebit": 2970000000,
          "fcff": 1860000000
        }
      ],
      "terminal_assumptions": {
        "terminal_growth": 0.03,
        "terminal_fcff": 1860000000,
        "terminal_value": 38320000000,
        "pv_terminal_value": 26080000000,
        "tv_pct_of_ev": 0.802,
        "wacc": 0.08
      },
      "valuation_range": {
        "low": 11.7,
        "mid": 13.9,
        "high": 17.4,
        "currency": "元/股"
      },
      "sensitivity": {
        "metric": "value_per_share",
        "unit": "元/股",
        "wacc_values": [
          0.075,
          0.08,
          0.085
        ],
        "terminal_growth_values": [
          0.025,
          0.03,
          0.035
        ],
        "matrix": [
          [
            14.2,
            15.6,
            17.4
          ],
          [
            12.8,
            13.9,
            15.3
          ],
          [
            11.7,
            12.6,
            13.7
          ]
        ]
      }
    },
    "blended": {
      "blended_per_share": 14.7,
      "current_price": 16.5,
      "upside": -0.1091,
      "verdict": "高估",
      "components": [
        {
          "key": "comps",
          "label": "相对估值（市场法）",
          "per_share": 15.5,
          "weight": 0.5,
          "equity_value": 34100000000
        },
        {
          "key": "dcf",
          "label": "DCF（收益法）",
          "per_share": 13.9,
          "weight": 0.5,
          "equity_value": 30580000000
        }
      ]
    },
    "scenarios": {
      "bull": {
        "per_share": 18.6,
        "equity_value": 40920000000,
        "growth_y1": 0.15,
        "ebit_margin": 0.139,
        "wacc": 0.07,
        "terminal_growth": 0.035
      },
      "base": {
        "per_share": 14.7,
        "equity_value": 32340000000,
        "growth_y1": 0.1101,
        "ebit_margin": 0.1299,
        "wacc": 0.08,
        "terminal_growth": 0.03
      },
      "bear": {
        "per_share": 10.9,
        "equity_value": 23980000000,
        "growth_y1": 0.07,
        "ebit_margin": 0.115,
        "wacc": 0.09,
        "terminal_growth": 0.025
      }
    },
    "sotp": {
      "ok": false,
      "skipped": true
    },
    "market_data": {
      "price": 16.5,
      "shares_outstanding": 2200000000,
      "market_cap": 36300000000,
      "price_date": "2026-10-05"
    },
    "warnings": [
      "可比公司样本仅 3 家，中位数受个别公司影响较大，建议扩充样本。",
      "DCF 与相对估值结果相差 11.6%，加权平均值参考价值有限，需先定位哪一头偏差。"
    ],
    "sources": [
      {
        "name": "公开行情页（收盘价与总股本）",
        "as_of": "2026-10-05",
        "official": false
      },
      {
        "name": "中国债券信息网·10 年期国债",
        "as_of": "2026-10-05",
        "official": true
      }
    ],
    "disclaimer": "本结果由模型按既定假设计算，仅供研究与教学用途，不构成投资建议。"
  },
  "sources": [
    {
      "company_name": "恒锐精密制造股份有限公司",
      "report_period": "2025",
      "file_name": "恒锐精密_2025年年度报告.pdf",
      "page": 60,
      "retrieved_at": "2026-10-05T14:20:00+08:00",
      "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"
    },
    {
      "company_name": "恒锐精密制造股份有限公司",
      "report_period": "2025",
      "file_name": "恒锐精密_2025年年度报告.pdf",
      "page": 82,
      "retrieved_at": "2026-10-05T14:20:00+08:00",
      "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"
    },
    {
      "company_name": "恒锐精密制造股份有限公司",
      "report_period": "2025",
      "file_name": "恒锐精密_2025年年度报告.pdf",
      "page": 68,
      "retrieved_at": "2026-10-05T14:20:00+08:00",
      "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"
    },
    {
      "company_name": "恒锐精密制造股份有限公司",
      "report_period": "2025",
      "file_name": "恒锐精密_2025年年度报告.pdf",
      "page": 45,
      "retrieved_at": "2026-10-05T14:20:00+08:00",
      "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"
    },
    {
      "company_name": "恒锐精密制造股份有限公司",
      "report_period": "2025",
      "file_name": "恒锐精密_2025年年度报告.pdf",
      "page": 51,
      "retrieved_at": "2026-10-05T14:20:00+08:00",
      "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"
    }
  ]
}
```

## 5. 逐字段说明

### 5.1 company（D 定义，A 补全）

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| name | string | A | 恒锐精密制造股份有限公司 | 公司全称 |
| ticker | string | A | 688123.SH | 证券代码加交易所后缀 |
| industry | string | A | 高端装备制造 | 行业归属，同业对比用 |
| report_period | string | A | 2025 | 报告期年份，也用于 E 的页面标题 |
| exchange | string | A | 上海证券交易所科创板 | 上市地 |
| report_type | string | A | 年度报告 | 文件类型 |
| auditor | string | A | 华信会计师事务所（特殊普通合伙） | 审计机构 |
| audit_opinion | string | A | 标准无保留意见 | 审计意见类型，非标准意见要触发风险 |
| currency | string | D | CNY | 币种，取 CNY / USD / HKD。美股公司填 USD |
| amount_unit | string | D | 元 | 金额数量级，固定「元」。USD 币种时读作美元元，E 显示时与 currency 拼接 |

### 5.2 financials 记录的字段（A 填）

`financials` 是一个对象。键是科目名，值是记录对象。A 抽到的每个科目按下面九个字段交。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| value | number \| null | A | 18,650,000,000 | 本期数值，单位见 unit。抽不到填 null |
| unit | string | A | 元 | 金额科目固定「元」，全组一致 |
| period | string | A | 2025 | 数值所属期间 |
| prior_value | number \| null | A | 16,800,000,000 | 上期数值，供 B 算同比。不需要则 null |
| prior_period | string \| null | A | 2024 | 上期期间，配合 prior_value |
| scope | string | A | 合并报表 | 合并报表或母公司报表，必填 |
| page | integer | A | 82 | 年报原始页码，可追溯的锚点 |
| source | string | A | 2025年年度报告 | 文件名或章节，写明出处 |
| confidence | number | A | 0.98 | 0 到 1 的抽取置信度，低于阈值进核验队列 |

期间口径（累计数／单季数／期末数）不逐条存，见 3.2 的规则。

### 5.3 financials 科目清单（A 的抽取范围，26 个）

| 键名 | 含义 | 示例值（元） |
|---|---|---|
| revenue | 营业收入 | 18,650,000,000 |
| operating_cost | 营业成本 | 13,340,000,000 |
| selling_expense | 销售费用 | 1,120,000,000 |
| admin_expense | 管理费用 | 840,000,000 |
| rnd_expense | 研发费用 | 980,000,000 |
| operating_profit | 营业利润 | 2,210,000,000 |
| net_income_parent | 归母净利润 | 1,580,000,000 |
| net_income | 净利润（全口径，含少数股东损益） | 1,700,000,000 |
| net_income_excl_nonrecurring | 扣非归母净利润 | 1,360,000,000 |
| total_assets | 资产总计 | 26,800,000,000 |
| current_assets | 流动资产合计 | 16,800,000,000 |
| total_liabilities | 负债合计 | 11,260,000,000 |
| current_liabilities | 流动负债合计 | 9,250,000,000 |
| equity_parent | 归母净资产 | 15,540,000,000 |
| cash_and_equivalents | 货币资金 | 4,150,000,000 |
| accounts_receivable | 应收账款 | 3,860,000,000 |
| inventory | 存货 | 4,420,000,000 |
| accounts_payable | 应付账款 | 3,350,000,000 |
| goodwill | 商誉 | 1,280,000,000 |
| interest_bearing_debt | 有息负债 | 6,050,000,000 |
| capex | 资本开支 | 1,680,000,000 |
| depreciation_amortization | 折旧与摊销 | 1,200,000,000 |
| cfo | 经营活动现金流量净额 | 1,520,000,000 |
| cfi | 投资活动现金流量净额 | -1,850,000,000 |
| cff | 筹资活动现金流量净额 | 210,000,000 |
| cash_received_from_sales | 销售商品、提供劳务收到的现金 | 20,500,000,000 |

本轮新增 `net_income`（净利润全口径，含少数股东损益）。B 的 roa、净利率、净现比和 C 的 DCF 都要用，原来只定义了归母的 `net_income_parent`。

清单之外还有约 25 个科目在 A 的补抽待办里，见 7.3。补抽前，依赖它们的指标标 `not_evaluable`。

### 5.4 ratios（B 填）

按六类组织。五类与设计文档 4.8 节的指标分组一致，第六类 `banking` 为可选的银行专属指标。每类是一个对象，键是指标名，值是记录对象。

指标记录的字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| value | number \| null | B | 0.2847 | 比率类写小数，金额类写元。分母为零或失真填 null |
| unit | string | B | 小数 | 元、小数、倍、天、次之一 |
| period | string | B | 2025 | 计算所属期间。A 或适配层补 |
| formula | string | B | (revenue - operating_cost) / revenue | 计算式，引用的名字必须与 financials 的键同名 |
| page | integer | B | 82 | 主要输入所在的年报页码。A 或适配层补 |
| prev | number \| null | B | 0.275 | 上期同口径的值，供看趋势 |
| delta | number \| null | B | 0.0097 | value 减 prev |
| inputs | object | B | 见示例 | 代入值字典，列出复算需要的原始值 |
| inputs_prev | object \| null | B | 见示例 | 上期代入值，算 prev 用 |
| status | string | B | ok | ok / not_evaluable，缺输入时写 not_evaluable |
| higher_is_better | boolean \| null | B | true | 越大越好填 true，越小越好填 false，中性填 null |

六类指标清单。共 68 个键，覆盖 B 的全部 65 个指标，外加我独有的 3 个（revenue_cagr_3y、ebitda_margin、capex_to_da_ratio）。B 的键按第 3.1 节映射表归到我的命名，撞名的三个改用全口径后缀。

**growth（成长性），10 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
| revenue_growth_yoy | 营业收入同比增长率 | 小数 | B revenue_growth，改名 |
| net_income_growth_yoy | 归母净利润同比增长率 | 小数 | B net_income_parent_growth，改名 |
| net_income_excl_nonrecurring_growth_yoy | 扣非净利润同比增长率 | 小数 | B net_income_deducted_growth，改名 |
| revenue_cagr_3y | 营业收入三年复合增速 | 小数 | B 无，我独有 |
| cost_of_revenue_growth | 营业成本增长率 | 小数 | 同名 |
| total_assets_growth | 总资产增长率 | 小数 | 同名 |
| equity_parent_growth | 归母净资产增长率 | 小数 | 同名 |
| ocf_growth | 经营活动现金流增长率 | 小数 | 同名 |
| profit_revenue_scissors | 收入利润剪刀差 | 小数 | 同名 |
| net_income_total_growth | 净利润（全口径）增长率 | 小数 | B net_income_growth，改名（全口径） |

**profitability（盈利能力），18 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
| gross_margin | 毛利率 | 小数 | 同名 |
| net_margin_total | 净利率（全口径） | 小数 | B net_margin，改名（全口径） |
| net_margin | 归母净利率 | 小数 | B net_margin_parent，改名 |
| net_margin_deducted | 扣非净利率 | 小数 | 同名 |
| operating_margin | 营业利润率 | 小数 | 同名 |
| ebit_margin | EBIT 利润率 | 小数 | 同名 |
| selling_expense_ratio | 销售费用率 | 小数 | 同名 |
| admin_expense_ratio | 管理费用率 | 小数 | 同名 |
| rd_expense_ratio | 研发费用率 | 小数 | 同名 |
| finance_expense_ratio | 财务费用率 | 小数 | 同名 |
| period_expense_ratio | 期间费用率 | 小数 | 同名 |
| roe_weighted | ROE（净资产收益率） | 小数 | B roe，改名 |
| roa | ROA（总资产收益率） | 小数 | 同名 |
| roic | ROIC（投入资本回报率） | 小数 | 同名 |
| effective_tax_rate | 有效税率 | 小数 | 同名 |
| deducted_to_parent | 扣非净利润占归母净利润比 | 小数 | 同名 |
| ebitda_margin | EBITDA 利润率 | 小数 | B 无（原在 derived），我独有 |
| roic_minus_wacc | ROIC 与 WACC 之差 | 小数 | 同名 |

**solvency（偿债能力），14 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
| current_ratio | 流动比率 | 倍 | 同名 |
| quick_ratio | 速动比率 | 倍 | 同名 |
| cash_ratio | 现金比率 | 倍 | 同名 |
| debt_to_asset_ratio | 资产负债率 | 小数 | B debt_to_assets，改名 |
| equity_multiplier | 权益乘数 | 倍 | 同名 |
| interest_bearing_debt | 有息负债 | 元 | 同名 |
| interest_bearing_debt_ratio | 有息负债率 | 小数 | 同名 |
| interest_bearing_debt_growth | 有息负债增长率 | 小数 | 同名 |
| net_debt | 净负债 | 元 | 同名 |
| cash_to_short_term_debt | 货币资金对短期有息债务覆盖倍数 | 倍 | 同名 |
| interest_coverage | 利息保障倍数 | 倍 | 同名 |
| net_debt_to_ebitda | 净负债 / EBITDA | 倍 | 同名 |
| restricted_cash_ratio | 受限资金占比 | 小数 | 同名 |
| working_capital | 营运资金 | 元 | 同名 |

**efficiency（营运能力），12 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
| ar_turnover | 应收账款周转率 | 次 | 同名 |
| inventory_turnover | 存货周转率 | 次 | 同名 |
| ap_turnover | 应付账款周转率 | 次 | 同名 |
| ar_turnover_days | 应收账款周转天数（DSO） | 天 | B dso，改名 |
| inventory_turnover_days | 存货周转天数（DIO） | 天 | B dio，改名 |
| payable_turnover_days | 应付账款周转天数（DPO） | 天 | B dpo，改名 |
| cash_conversion_cycle | 现金转换周期（CCC） | 天 | 同名 |
| total_asset_turnover | 总资产周转率 | 次 | 同名 |
| fixed_asset_turnover | 固定资产周转率 | 次 | 同名 |
| accounts_receivable_growth | 应收账款增长率 | 小数 | 同名 |
| inventory_growth | 存货增长率 | 小数 | 同名 |
| ar_and_inventory_to_assets | 应收与存货合计占总资产比 | 小数 | 同名 |

**cashflow_quality（现金流质量），14 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
| ocf | 经营活动现金流净额 | 元 | 同名 |
| cfo_to_net_income_total | 净现比（经营现金流 / 净利润全口径） | 小数 | B ocf_to_net_income，改名（全口径） |
| cfo_to_net_income | 净现比（经营现金流 / 归母净利润） | 小数 | B ocf_to_net_income_parent，改名 |
| ocf_to_revenue | 经营现金流收入比 | 小数 | 同名 |
| cash_collection_ratio | 收现比 | 小数 | B sales_cash_ratio，改名 |
| capex | 资本开支 | 元 | 同名 |
| capex_to_ocf | 资本开支 / 经营现金流 | 倍 | 同名 |
| free_cash_flow | 自由现金流 | 元 | 同名 |
| fcf_to_revenue | 自由现金流收入比 | 小数 | 同名 |
| ocf_to_interest_paid | 经营现金流利息覆盖倍数 | 倍 | 同名 |
| payout_ratio | 现金分红率 | 小数 | 同名 |
| cf_financing_dependency | 外部融资依赖度 | 小数 | 同名 |
| goodwill_to_equity | 商誉 / 归母净资产 | 小数 | 同名 |
| capex_to_da_ratio | 资本开支 / 折旧摊销 | 倍 | B 无，我独有 |

**banking · 银行专属（可选）**

银行专属指标放这里，制造业公司为空对象 `{}`。

五类的小计：growth 10、profitability 18、solvency 14、efficiency 12、cashflow_quality 14，合计 68，加 banking 可选。

`roe_weighted` 用归母净利润除以平均归母净资产。附注数据可得时改用加权口径，并在 formula 里注明用的是加权还是平均。

`free_cash_flow`、`interest_bearing_debt`、`net_debt`、`working_capital`、`ocf`、`capex` 是金额，unit 写「元」，其余是比率、倍数、天数或次数。

**关于缺输入的指标。** 下面 13 个指标的公式引用了 26 个科目之外的值（finance_expense、interest_expense、income_tax_expense、pretax_profit、short_term_borrowings、current_portion_lt_debt、restricted_cash、fixed_assets、notes_receivable、contract_assets、interest_paid、dividend_paid），这些都在 A 的补抽清单里：ebit_margin、finance_expense_ratio、period_expense_ratio、roic、roic_minus_wacc、effective_tax_rate、cash_to_short_term_debt、interest_coverage、restricted_cash_ratio、fixed_asset_turnover、ar_and_inventory_to_assets、ocf_to_interest_paid、payout_ratio。示例为展示完整格式仍给出数值，其输入在各条记录的 inputs 里列明。正式跑链路时，A 补齐这些科目之前，这 13 个指标应改标 status 为 not_evaluable、value 为 null，符合接口对齐方案第五节的「先用现有科目跑通，缺的标 not_evaluable」。

### 5.5 risks（B 填）

`risks` 是数组，只放 **status 为 triggered** 的风险卡。字段对应设计文档 4.9 节的风险卡结构。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| risk_id | string | B | R01 | 卡片编号，同一次分析内唯一 |
| risk_name | string | B | 应收账款增速快于营业收入增速 | 风险简称 |
| category | string | B | 收入与资产 | 六类中文之一，映射见下表 |
| severity | string | B | medium | 等级，取 high、medium、low 三值 |
| severity_tag | string | B | 关注 | 中文标签，取 重大、关注、提示 |
| score | number \| null | B | 60.0 | 0 到 100 的风险分 |
| status | string | B | triggered | 取 triggered、passed、not_evaluable、not_applicable |
| trigger | string | B | 应收账款增速 - 营业收入增速 > 5 个百分点 | 触发条件原文 |
| involved_values | array | B | 见示例 | 涉及数值列表，每项含 metric、value、unit、period、page |
| numeric_evidence | string | B | 应收账款由 3,050,000,000 元增至…… | 数字证据，一句话说清算式与结果 |
| text_evidence | object | B | {"quote": "...", "page": 45} | 文本证据，含原文片段与页码。未找到管理层解释时 quote 写 null |
| explanation | string | B | 应收增速显著高于收入增速…… | 解释说明。区分事实与推断 |
| suggested_action | string | B | 核对应收账款账龄结构附注…… | 建议核查动作，由 B 的 suggestions 数组拼成 |
| evidence_chain | array | B | 见示例 | 六层证据链，见下 |

`severity` 三值对应中文含义。high 高，medium 中，low 低或观察项。`severity_tag` 是给 E 直接显示的中文标签，重大 / 关注 / 提示。E 按 severity 排序渲染。

**类别映射。** B 的类别英文 slug 映射到六类中文。

| B 的 slug | 我的类别 | B 的类别含义 |
|---|---|---|
| growth | 收入与资产 | 收入、利润、扣非利润的增速与结构 |
| profitability | 盈利质量 | 毛利率、回报率、费用率与资本回报 |
| solvency | 偿债与流动性 | 杠杆、期限错配、利息覆盖与再融资 |
| efficiency | 收入与资产 | 应收、存货、应付周转与现金转换周期 |
| cashflow_quality | 盈利质量 | 现金流与利润的匹配、现金含量 |
| asset_quality | 会计政策 | 资产减值、商誉等资产质量 |
| governance | 治理与合规 | 质押、股东与公司治理 |

`审计与披露` 一类没有对应的 B slug，留给 A 的审计意见类风险。`asset_quality` 主要落在会计政策一类。

**evidence_chain 六层**，照 B 的实际输出。数据、计算、出处、判断、归因、建议。出处层给 sources 与 pages，判断层给 result 与 severity，归因层给杜邦分解、利润桥、现金流桥。E 的「点击展开」用这六层。

### 5.5.1 rules_evaluated（B 填）

`rules_evaluated` 是数组，放所有 **status 不是 triggered** 的规则，即 passed、not_evaluable、not_applicable。

字段与 risks 基本一致，去掉 risk_ 前缀的展示字段，保留核验需要的项。

| 字段名 | 类型 | 说明 |
|---|---|---|
| rule_id | string | 规则编号 |
| rule_name | string | 规则简称 |
| category | string | 六类中文之一 |
| status | string | passed、not_evaluable、not_applicable 之一 |
| severity | string \| null | 触发时才有，未触发为 null |
| severity_tag | string \| null | 同上 |
| trigger | string | 触发条件原文 |
| explanation | string | 一句话说明为什么没触发或为什么不可评估 |
| trigger_values | object | 相关指标的当期值 |

**为什么分开。** B 把全部规则都放进 risks 数组，包括没触发的（severity 为 null）。E 若逐条渲染会显示几十个「风险点」，其中大半是空壳。适配层按 `status == "triggered"` 过滤，触发的进 `risks`，其余进 `rules_evaluated`。核验页读后者。

### 5.6 valuation.comps（C 填）

相对估值，对应 C 的 relative 块。输入取自 financials，输出估值区间与可比公司区间。

输入字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| revenue | number | C | 18,650,000,000 | 营业收入，来自 financials.revenue |
| net_income | number | C | 1,580,000,000 | 归母净利润，来自 financials.net_income_parent |
| ebitda | number | C | 3,410,000,000 | 息税折旧摊销前利润，营业利润加折旧摊销 |
| net_debt | number | C | 1,900,000,000 | 净负债，有息负债减货币资金 |
| share_price | number | C | 16.50 | 评估日收盘价，元 |
| shares_outstanding | number | C | 2,200,000,000 | 总股本，单位股 |
| shares_unit | string | C | 股 | 股本单位，固定「股」 |
| market_cap | number | C | 36,300,000,000 | 总市值，元，等于股价乘股本 |
| currency | string | C | CNY | 币种 |

输出字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| peer_companies | array | C | 见示例 | 可比公司，每家含 name、ticker、pe、pb、ev_ebitda、ps |
| peer_multiples | object | C | 见示例 | 可比公司倍数的区间，键为 pe、pb、ev_ebitda、ps，每个含 min、median、max |
| implied_value_per_share | object | C | 见示例 | 各方法推出的每股价值，每个含 low、mid、high |
| valuation_range | object | C | {low, mid, high} | 综合每股估值区间，含 currency，单位元每股 |

`peer_multiples` 是「可比公司区间」，`valuation_range` 是本公司的估值区间，两者都要给。

注意 C 的 `range_low` / `range_high` 是股权价值总额（元），不是每股，映射到 valuation_range 时要转成每股。

### 5.7 valuation.dcf（C 填）

绝对估值。输入按分工说明的 DCF 清单，输出估值区间、终值假设与敏感性矩阵。敏感性嵌在 dcf 内。

输入字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| revenue_base | number | C | 18,650,000,000 | 预测起点营业收入，元 |
| ebit_margin | number | C | 0.1190 | 息税前利润率，小数 |
| tax_rate | number | C | 0.1900 | 所得税率，小数 |
| da | number | C | 1,200,000,000 | 折旧与摊销，元 |
| capex | number | C | 1,680,000,000 | 资本开支，元 |
| nwc | number | C | 4,930,000,000 | 净营运资本，元 |
| wacc | number | C | 0.0800 | 加权平均资本成本，小数 |
| terminal_growth | number | C | 0.0300 | 永续增长率，小数 |
| forecast_years | integer | C | 5 | 明确预测期年数 |

输出字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| forecast | array | C | 见示例 | 预测期逐年，每项含 year、revenue、ebit、fcff |
| terminal_assumptions | object | C | 见示例 | 终值假设，含 terminal_growth、terminal_fcff、terminal_value、pv_terminal_value、tv_pct_of_ev、wacc |
| valuation_range | object | C | {low, mid, high} | 每股估值区间，含 currency |
| sensitivity | object | C | 见示例 | 敏感性，含 metric、unit、wacc_values、terminal_growth_values、matrix |

`sensitivity.matrix` 的行对应 wacc_values，列对应 terminal_growth_values。示例里 wacc 8.00% 与终值增长 3.00% 交叉得到 13.9 元每股，与 valuation_range.mid 对齐。

### 5.8 sources（A 归集）

`sources` 是数组，每条对应一个被引用的文件页。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| company_name | string | A | 恒锐精密制造股份有限公司 | 公司全称 |
| report_period | string | A | 2025 | 报告期 |
| file_name | string | A | 恒锐精密_2025年年度报告.pdf | 原始文件名 |
| page | integer | A | 60 | 被引用的页码 |
| retrieved_at | string | A | 2026-10-05T14:20:00+08:00 | 获取时间，ISO 8601 带时区 |
| source_url | string | A | http://www.cninfo.com.cn/... | 来源链接，本地文件留 null |

不同页码要写不同条目。同一次分析里被引用多少个页，就写多少条。

### 5.9 valuation.blended（C 填）

融合估值。把相对估值与绝对估值加权成一个每股价值，给出相对现价的上行空间与结论。E 页面的头条数字。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| blended_per_share | number | C | 14.7 | 融合后每股价值，元每股 |
| current_price | number | C | 16.50 | 当前股价，元 |
| upside | number | C | -0.1091 | 上行空间，小数，blended_per_share / current_price - 1 |
| verdict | string | C | 高估 | 结论，取 显著低估、低估、大致合理、高估、显著高估 |
| components | array | C | 见示例 | 各估值法的每股价值与权重，每项含 key、label、per_share、weight、equity_value |

### 5.10 valuation.scenarios（C 填）

三情景估值。乐观、中性、悲观各一套假设与结果。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| bull | object | C | 见示例 | 乐观情景 |
| base | object | C | 见示例 | 中性情景 |
| bear | object | C | 见示例 | 悲观情景 |

每个情景的字段。

| 字段名 | 类型 | 示例 | 说明 |
|---|---|---|---|
| per_share | number | 18.6 | 该情景每股价值，元每股 |
| equity_value | number | 40,920,000,000 | 该情景股权价值，元 |
| growth_y1 | number | 0.1500 | 第一年收入增速，小数 |
| ebit_margin | number | 0.1390 | EBIT 利润率，小数 |
| wacc | number | 0.0700 | 折现率，小数 |
| terminal_growth | number | 0.0350 | 永续增速，小数 |

### 5.11 valuation.sotp（C 填）

分部估值。可选，无分部数据时写 `{"ok": false, "skipped": true}`。

有分部数据时，按业务分部列每块的收入、利润、估值方法与分部价值，再汇总。

### 5.12 valuation 的其他键（C 填）

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| market_data | object | C | 见示例 | 行情，含 price、shares_outstanding、market_cap、price_date |
| warnings | array | C | 见示例 | 结论的一部分，不是报错。见下 |
| sources | array | C | 见示例 | 估值用到的数据来源，每项含 name、as_of、official |
| disclaimer | string | C | 见示例 | 免责声明 |

`warnings` 说明的是估值结论本身的局限，如终值算法分歧、折现率偏低、样本过少。C 明确它是结论的一部分，不是错误日志。E 要把它当结论渲染，不能当报错隐藏。

`disclaimer` 申明结果仅供研究与教学，不构成投资建议。

## 6. 各模块输入输出约定

链路按分工说明第五节的顺序走，每一步的输出是下一步的输入。统一对象在链路上只增字段，不换字段名。

| 步骤 | 谁做 | 读什么 | 写什么 |
|---|---|---|---|
| 财报抽取 | A | 年报 PDF | company（补全基本信息）、financials、sources |
| 指标计算 | B | financials | ratios |
| 风险诊断 | B | financials、ratios | risks、rules_evaluated |
| 相对估值 | C | financials、ratios、company | valuation.comps |
| 绝对估值 | C | financials、ratios（EBIT、折旧摊销等） | valuation.dcf、valuation.blended、valuation.scenarios、valuation.sotp |
| 前端渲染 | E | 整个对象，全字段只读 | 不写任何字段 |

四条硬约束。

1. B 算指标只从 financials 取数，不自己重新抽数值。
2. C 估值的输入只从 financials 与 ratios 取，行情与股本除外。行情值写进 valuation.market_data 与 valuation.sources。
3. risks 只放触发的卡，其余规则进 rules_evaluated。适配层按 status 过滤。
4. E 只读。页面要显示的任何数字，都必须在对象里已经存在，E 不派生。

WACC 的环这样解。B 算 `roic_minus_wacc` 和三条风险规则要用 WACC，而 WACC 由 C 产出，链路是 A 到 B 到 C。加一趟回填：第一趟 B 把依赖 WACC 的项标 not_evaluable，C 产出 WACC 后写回，第二趟只重算 B 里依赖 WACC 的那部分。编排层要把 B 跑两趟记进运行日志。

## 7. 数据边界与待定项

### 7.1 本 Schema 覆盖了什么

覆盖单公司一次分析的完整链路，含三表关键科目、六类指标、风险卡片、相对与绝对估值、融合与三情景、来源。示例公司为制造业，科目标签以通用口径给出。

### 7.2 明确没覆盖，需要时再加

- 时间序列。financials 每条记录只带一期内含 prior_value，够算一期同比。三年复合增速所需的 2023 年数据靠 B 的指标时间序列，未在本对象展开。要做多期趋势，另开时间序列字段。
- 分产品分地区收入、分部毛利、账龄结构、借款明细等附注级明细。当前不展开，A 抽到后按需并入 financials 或单独挂。sotp 用到的分部数据也在此列。
- 假设台账与预测三表。设计文档 M6 的假设台账字段较多，本 Schema 只保留 dcf.inputs 的关键假设。完整台账建议另设文件。
- 同业对比（M8）的多公司数组结构。本对象是单公司对象，多公司对比由 D 在编排层把多个对象拼成数组。拼接键待定。

### 7.3 待与成员商榷

下面每条都附了结论。本次已定案的标「已定案」，其余保留待定。审查发现的 H1、H2 两处本次已定案。

**1. 有息负债与折旧摊销的口径（找 A、B）— 已定案**

问题：这两个科目要从附注汇总，口径不一致会让 B 的偿债指标跟着错。

定案：A 按「短期借款 + 一年内到期的非流动负债 + 长期借款 + 应付债券」汇总，并在 source 里注明含哪几项。折旧摊销取现金流量表补充资料里固定资产折旧与无形资产摊销的合计。B 直接用 A 给的值，不自己重拼。

**2. 税率与基期数据由谁给（找 A、B，对应审查 H2）— 已定案**

问题：B 算 ROIC 要用税率，算三年复合增速要用 2023 年的数。

定案：税率由 A 抽「所得税费用 ÷ 利润总额」，键名 tax_rate，放进 financials 补抽清单。基期数据不要求 A 抽三代，由 B 在指标层自己维护三年序列（示例里 revenue_cagr_3y 的 inputs 直接带上 revenue_2023）。

**3. 估值输入的出处（找 C、E，对应审查 H1）— 已定案**

问题：valuation 的输入没有页码和来源，估值区间成了黑箱。

定案：由适配层从每条记录的 page 和 source 归集出顶层 sources。行情与估值参数登记在 valuation.sources 与 valuation.market_data，标注获取时间。C 的输出没有 page 字段，由适配层按字段补。

**4. 三个抽了没有下游用的科目（找 B）— 已定案**

问题：selling_expense、admin_expense、goodwill 抽了但没指标用。

定案：保留字段，B 补指标。本次 ratios 已加入 selling_expense_ratio、admin_expense_ratio、goodwill_to_equity。

**5. 风险等级档位（找 B）— 已定案**

问题：severity 只有 high / medium / low 三档。

定案：维持三档，不加 info。另加 `severity_tag`（重大 / 关注 / 提示）做中文展示，不改 severity 的取值。

**6. DCF 终值与 WACC 的拆解深度（找 C）— 待定**

问题：设计文档 4.12 要求终值并列永续增长与退出倍数两种方式，WACC 要拆出无风险利率、Beta、股权风险溢价、债务成本。

方案：中期汇报不要求 DCF，先保留现状。WACC 加四个可选字段 rf、beta、erp、cost_of_debt，C 有余力就填。退出倍数法放到第二阶段。这一条本次未定案。

**7. 非财务事实的命名规则（找 B、E）— 待定**

问题：风险卡里出现 pledge_ratio，financials 和 ratios 都没定义这个键。

方案：规定非财务事实的 metric 名一律带前缀，写成 governance.pledge_ratio、governance.auditor_change 这类，并在 source 里注明页码。本例的 R03 暂用 `pledge_ratio`，前缀规则本次未定案。

**8. 母公司口径（找 A、B）— 已定案**

问题：现在只存合并报表口径。

定案：暂不单独存一套。scope 保留「合并报表 / 母公司报表」两值，需要时区分。当前分析以合并为主。

**9. ROE 加权口径（找 B）— 已定案**

问题：示例 roe_weighted 用期初期末平均净资产简化计算，设计文档要求加权口径。

定案：映射关系固定——B 的 roe 即我的 roe_weighted，口径为「归母净利润 / 平均归母净资产」。附注数据可得时改用加权口径，并在 formula 里注明用的是加权还是平均。

注记：第 4 节示例里的数字全部是虚构的，只用于对齐格式。示例营业收入 18,650,000,000 元对应 186.5 亿元（由原示例的金额口径换算而来）。正式交付时由 A 用真实年报数据替换，替换后仍须满足第 4 节的勾稽关系。
