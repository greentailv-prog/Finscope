# INPUT.md — investment-memo 输入契约

> 本文件说明本 Skill 从统一对象里读什么、不读什么。
> 输出契约见 `OUTPUT.md`，取数映射与安全规则见 `RULES.md`。

## 一句话版本

**输入是一份 FinScope 统一数据对象（顶层固定七键）加一份 `run_log.json`。**

本 Skill 只读，不重算、不新增派生字段到统一对象里。

## 顶层七键

```
company / financials / ratios / risks / rules_evaluated / valuation / sources
```

| 键 | 谁填 | 本 Skill 取什么 |
| --- | --- | --- |
| `company` | D 定义、A 补全 | 名称、代码、行业、报告期、币种（标题与页眉） |
| `financials` | A | 收入 / 成本 / 净利润 / 现金流等原始值；并核对每个科目的 `status`（栏目⑥） |
| `ratios` | B | 六类指标的本期值 / 上期值 / 变动 / 单位 / 状态（栏目①②③） |
| `risks` | B | 触发的风险卡，含证据链（栏目①④，归因层进③） |
| `rules_evaluated` | B | `status = not_evaluable` 的规则进待核验（栏目⑥） |
| `valuation` | C | 融合估值、DCF、Comps、三情景、敏感性、警告、免责声明（栏目①⑤⑦） |
| `sources` | A | 引用文件与页码（栏目⑦） |

## 附加输入：run_log.json

链路运行日志。本 Skill 只读它的 `warnings` 字段，汇入栏目⑥的「运行日志警告」。

```json
{ "b_pass": 2, "steps": ["..."], "warnings": [] }
```

## 栏目取数映射（按项目设计文档 M10）

| 栏目 | 从哪取 |
| --- | --- |
| ① 结论摘要 | `valuation.blended` 的 verdict / blended_per_share / current_price / upside 与两个 component；`risks` 前几条的 severity_tag 与 risk_name；`ratios` 的营收增速与 ROE |
| ② 关键指标仪表盘 | `ratios` 六类里的骨干指标，每条带 value / prev / delta / unit / status；两期趋势 |
| ③ 经营情况与变化归因 | 收入线、成本费用线、现金流线各取对应 ratios；归因原文取 `risks[*].evidence_chain` 里 `step` 为「归因」的那一层（杜邦分解 + 现金流桥） |
| ④ 风险雷达 | `risks[]` 按 severity（high > medium > low）再按 score 降序，逐条取 severity_tag / risk_name / category / trigger / involved_values（含页码）/ numeric_evidence / explanation / suggested_action |
| ⑤ 预测与估值 | 假设取 `valuation.dcf.inputs`；预测取 `dcf.forecast` 与 `terminal_assumptions`；区间取 `dcf.valuation_range`、`comps.valuation_range`、`blended`；三情景取 `valuation.scenarios`；敏感性取 `dcf.sensitivity` |
| ⑥ 待核验事项 | `rules_evaluated` 里 `status = not_evaluable` 的；`financials.*` 里 `status` 非 `found` 的；`valuation.warnings`；`run_log.warnings` |
| ⑦ 数据来源与免责声明 | `sources[]` 含页码；`valuation.disclaimer` 加小组固定免责句 |

## 依赖字段（缺失时的行为）

| 缺失 | 行为 |
| --- | --- |
| 某 ratios 指标为 `null`（`not_evaluable` / `not_meaningful`） | 显示「数据缺失·待核验」，不参与计算 |
| `valuation.blended.components` 里没有 `key=dcf` 或 `key=comps` | 对应每股价值与权重显示「数据缺失」 |
| `risks[*].evidence_chain` 里没有「归因」层 | 栏目③的归因段显示「数据缺失」，其余照常 |
| `valuation.dcf.sensitivity.matrix` 某格为 `null` | 该格显示「数据缺失」 |
| `sources` 为空 | 来源表渲染为空，不报错 |

## 字段单位约定（来自统一接口 Schema）

- 金额一律「元」，展示时由渲染器换算成亿元并加千分符
- 比率一律小数（`0.2847` 表示 28.47%），展示时乘 100 加百分号
- 百分点为本期与上期的比率差，乘 100 后带正负号
- `unit` 只在 元 / 小数 / 倍 / 天 / 次 里取值；每股价值另按元/股口径

## 明确不读的东西

- 不读 A 的原始 PDF，不读 `financials.series`（A 的多年序列有已知错误，见 RULES.md）
- 不读 B/C 的中间产物（`b_ratios.json` / `c_output.json`），只认拼好的统一对象
- 不改统一对象任何字段，不往里面写回渲染结果
