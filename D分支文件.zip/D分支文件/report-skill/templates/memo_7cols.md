# {{company_name}}（{{ticker}}）投资研究简报

报告期：{{report_period}} 年　行业：{{industry}}　上市地：{{exchange}}　币种：{{currency_label}}

> 本简报由 FinScope 链路确定性渲染：财务数据取自 A 的年报抽取，指标与风险取自 B，估值取自 C，编排与渲染取自 D。正文所有数字由代码从统一对象按点路径注入，不经过任何语言模型。

## 一、结论摘要

- 综合估值结论：**{{verdict}}**。融合每股价值 {{blended_ps}} 元/股，当前股价 {{current_price}} 元/股，相对现价空间 {{upside}}。
- 估值构成：DCF（收益法）每股 {{dcf_ps}} 元，权重 {{dcf_weight}}；相对估值（市场法）每股 {{comps_ps}} 元，权重 {{comps_weight}}。
- 财务表现：营业收入同比 {{revenue_growth}}，加权 ROE {{roe}}，较上期变动 {{roe_delta}} 个百分点。
- 主要风险：

{{#top_risks}}
  - 【{{severity_tag}}】{{risk_name}}（评分 {{score}}）
{{/top_risks}}

## 二、关键指标仪表盘

> 受 A 端部分科目录取缺失影响，部分指标本期无法评估，按「数据缺失·待核验」显示。趋势仅展示本期与上期两期，回读多年序列的功能待 A 修正 series 后再开放。

| 指标 | 类别 | 本期 | 上期 | 变动 | 状态 |
| --- | --- | --- | --- | --- | --- |
{{#dashboard}}
| {{label}} | {{category}} | {{value_str}} | {{prev_str}} | {{delta_str}} | {{status_str}} |
{{/dashboard}}

## 三、经营情况与变化归因

### 收入线

- 营业收入 {{revenue}}，同比 {{revenue_growth}}。
- 归母净利润 {{ni_parent}}，同比 {{ni_growth}}。

### 成本费用线

- 营业成本 {{operating_cost}}，同比 {{cost_growth}}。
- 毛利率 {{gross_margin}}，较上期变动 {{gross_margin_delta}} 个百分点。

### 现金流线

- 经营活动现金流净额 {{ocf}}，同比 {{ocf_growth}}。
- 净现比（经营现金流 ÷ 归母净利润）{{cfo_to_ni}}；自由现金流 {{fcf}}。

### 变化归因

> 以下归因直接取自 B 风险证据链中「归因」层，D 不新增叙述、不改写措辞。

杜邦分解（ROE 变动 {{dupont_roe_delta}} 个百分点）：净利率贡献 {{dupont_net_margin}}、总资产周转贡献 {{dupont_asset_turnover}}、权益乘数贡献 {{dupont_leverage}} 个百分点。

现金流桥（单位：亿元）：

{{#cashflow_bridge}}
- {{item}}：{{amount_yi}}
{{/cashflow_bridge}}

## 四、风险雷达

> 触发风险共 {{risk_count}} 项，按严重度（重大 > 关注 > 提示）再按评分降序排列。

{{#risks}}
### {{risk_id}}　【{{severity_tag}}】{{risk_name}}

- 类别：{{category}}　评分：{{score}}
- 触发条件：{{trigger}}
- 涉及数值：{{involved_str}}
- 数字证据：{{numeric_evidence}}
- 解释：{{explanation}}
- 建议动作：{{suggested_action}}

{{/risks}}

## 五、预测与估值

### 估值假设（DCF）

- 预测期 {{forecast_years}} 年；WACC {{wacc}}；永续增长率 {{terminal_growth}}；所得税率 {{tax_rate}}。
- 收入基数 {{revenue_base}}；EBIT 利润率 {{ebit_margin}}。

### 预测（缩水的 DCF forecast）

> 如实说明：C 只产出 DCF 的收入、EBIT、FCFF 三行预测，**没有完整的资产负债表与现金流量表预测**，它不是完整的「预测三表」。

| 年度 | 营业收入 | EBIT | FCFF |
| --- | --- | --- | --- |
{{#forecast}}
| {{year}} | {{revenue_yi}} | {{ebit_yi}} | {{fcff_yi}} |
{{/forecast}}

### 估值区间（元/股）

- DCF（收益法）：{{dcf_low}} 至 {{dcf_high}}，中值 {{dcf_mid}}。
- 相对估值（市场法）：{{comps_low}} 至 {{comps_high}}，中值 {{comps_mid}}。
- 融合：每股 {{blended_ps}} 元/股，结论 **{{verdict}}**。
- 终值占比：终值占企业价值 {{tv_pct}}，解读须结合下方敏感性与「待核验事项」中的估值警告。

### 三情景

| 情景 | 每股价值（元/股） | 第一年收入增速 | EBIT 利润率 | WACC |
| --- | --- | --- | --- | --- |
{{#scenarios}}
| {{label}} | {{per_share}} | {{growth_y1}} | {{ebit_margin}} | {{wacc}} |
{{/scenarios}}

### 敏感性（每股价值，元/股）

行＝WACC，列＝永续增长率。

| WACC \ 永续增长 | {{sens_header_cells}} |
| --- | --- |
{{#sensitivity_rows}}
| {{wacc}} | {{cells}} |
{{/sensitivity_rows}}

## 六、待核验事项

### 规则不可评估（{{n_rules}} 项）

{{#review_rules}}
- 【{{rule_id}}】{{rule_name}}：{{explanation}}
{{/review_rules}}

### 财务科目录取异常（{{n_fin}} 项）

{{#review_fin}}
- {{name}}：状态 {{status}}。
{{/review_fin}}

### 估值警告（{{n_valwarn}} 项）

{{#review_valwarn}}
- {{text}}
{{/review_valwarn}}

### 运行日志警告（{{n_runwarn}} 项）

{{#review_runwarn}}
- {{text}}
{{/review_runwarn}}

## 七、数据来源与免责声明

### 数据来源

| 文件名 | 页码 | 获取时间 |
| --- | --- | --- |
{{#sources}}
| {{file_name}} | {{page}} | {{retrieved_at}} |
{{/sources}}

页码为年报原始印刷页码，可逐条核对。

### 免责声明

{{disclaimer}}

{{group_disclaimer}}
