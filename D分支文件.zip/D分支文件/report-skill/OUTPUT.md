# OUTPUT.md — investment-memo 输出契约

> 输出落点：`out_data/reports/<key>/`，`<key>` 形如 `600519.SH_2025`（ticker + 报告期）。

## 七栏目固定结构

| 栏目 | 标题 | 内容 |
| --- | --- | --- |
| ① | 结论摘要 | 融合估值结论、估值构成、财务表现，主要风险前三条 |
| ② | 关键指标仪表盘 | 骨干指标表：指标 / 类别 / 本期 / 上期 / 变动 / 状态 |
| ③ | 经营情况与变化归因 | 收入线、成本费用线、现金流线，以及取自 B「归因」层的杜邦分解与现金流桥 |
| ④ | 风险雷达 | 触发风险逐条：触发条件、涉及数值（含页码）、数字证据、解释、建议动作 |
| ⑤ | 预测与估值 | DCF 假设、缩水的 DCF forecast 三行、估值区间、三情景、敏感性矩阵 |
| ⑥ | 待核验事项 | 规则不可评估、财务科目录取异常、估值警告、运行日志警告 |
| ⑦ | 数据来源与免责声明 | 来源文件与页码表；C 的免责声明 + 小组固定免责句 |

栏目顺序与标题在项目设计文档 M10 定死，模板 `templates/memo_7cols.md` 是唯一出处。

## 文件清单

每次渲染在 `<key>/` 下产出五个文件：

| 文件 | 说明 | 唯一真源 |
| --- | --- | --- |
| `memo.md` | 模板渲染的 Markdown，**唯一真源** | 是 |
| `memo.html` | 由 memo.md 转换，内嵌打印 CSS，浏览器打印即得 PDF | 否 |
| `memo.json` | 带数字溯源的结构化版本 | 否 |
| `memo.csv` | 仪表盘那一块的关键指标表（UTF-8 BOM，Excel 直接开） | 否 |
| `render_log.json` | 合规命中记录 + 数字白名单校验结果 | 否 |

其余格式（html / json / csv）都从同一份渲染结果派生，不改数字。

## memo.json 的结构

```jsonc
{
  "meta":       { "key", "company_name", "ticker", "report_period", "generated_at", "engine" },
  "columns":    [ 七个栏目标题 ],
  "scalars":    [ { "placeholder", "source_path", "raw_value", "formatted" } ],   // 标量占位符溯源
  "collections":[ { "name", "items": [ { 字段: { "source_path", "raw_value", "formatted" } } ] } ],
  "numbers":    [ { "token", "sources": [ 点路径... ] } ],   // 成稿里每个数字 → 出自哪些路径
  "compliance": { "hits": [...] },
  "validation": { "passed", "allowed_count", "scanned_tokens", "violations" }
}
```

**`numbers` 就是数字溯源索引**：成稿里出现过的任何数字，都能在这里查到它来自统一对象的哪个点路径。
这是核对「报告里每个数字的出处」的入口。

## render_log.json 的结构

```jsonc
{
  "key": "...",
  "engine": "deterministic-template-v1（不使用大模型）",
  "numbers": { "placeholder_outputs": 328, "distinct_numbers": 151 },
  "compliance": { "hits": [ { "pattern": "目标价", "replacement": "按当前假设的隐含每股价值", "count": 1 } ] },
  "number_whitelist": { "passed": true, "allowed_count": 151, "scanned_tokens": 151, "violations": [] }
}
```

- `compliance.hits` 非空表示成稿里有禁用词被改写；为空表示未命中
- `number_whitelist.passed = false` 时**不会有任何文件落盘**，渲染器直接报错退出

## 本次茅台案例的实际结果

- key：`600519.SH_2025`
- 七栏目齐全，非空壳
- 数字白名单：允许 151 个数字、扫描 151 个、越界 0 个
- 禁用词命中：0 处（真实数据里没有评级用语）
- 栏目⑥列出 21 项规则不可评估、1 项财务科目录取异常、7 条估值警告、0 条运行日志警告

## 不做（后补）

Word / Excel / PPT 三件套本轮不做。本机没有 python-docx / python-pptx / pandoc，
只能用标准库 `zipfile` 手写 OOXML，工作量大且排版朴素。HTML 打印是主要交付方式。
