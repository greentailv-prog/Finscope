---
name: investment-memo
description: >
  把 FinScope 统一数据对象（七键：company / financials / ratios / risks /
  rules_evaluated / valuation / sources）确定性渲染成一份七栏目投研简报，
  输出 memo.md / memo.html / memo.json / memo.csv 四种格式。正文每个数字都由代码按
  点路径注入，不经过任何语言模型；渲染后跑数字白名单校验与合规禁用词过滤。
  当用户说「生成投研简报」「出报告」「把统一对象变成报告」「按七栏目出简报」
  「渲染 memo」「做一份可核对出处的投研报告」时使用。不用于选股、买卖建议、
  估值建模本身（那分别属于别的模块）。
version: 1.0.0
owner: D
---

# investment-memo — 投研简报确定性渲染

## 这个 Skill 做什么

输入一个 FinScope **统一数据对象**（A/B/C 三段拼成的七键对象，外加一份 `run_log.json`），
输出一份**七栏目、每个数字可回溯到点路径的投研简报**。

它回答一个问题：**把已经算好的事实，排成一份能核对出处的简报。**

它**不做**的事：

- 不算财务指标（B 的活）、不做估值（C 的活）、不重新抽数（A 的活）
- **不写任何数字。** 正文里的每个数字都来自占位符 → 点路径 → 格式化，模型只允许
  写模板里的固定文字，写了数字会被白名单校验打回
- 不调用任何大模型。整份简报是确定性渲染的结果

## 一句话原则

**模型不许写数。** 这不是靠自觉，是靠 `render_memo.py` 在成稿后跑一遍数字白名单：
用正则抓出所有数字，逐个核对是否在允许集合里，越界就拒绝出稿并报错。

## 怎么跑

```bash
cd report-skill/scripts
python render_memo.py \
    --unified ../demo/input_unified.json \
    --run-log ../demo/input_run_log.json \
    --out-root ../../out_data/reports
```

输出落到 `out_data/reports/<key>/`，`<key>` 形如 `600519.SH_2025`（由 ticker 加报告期拼成）：

```
memo.md          唯一真源，模板渲染所得
memo.html        带打印 CSS，浏览器直接打印即得 PDF
memo.json        带数字溯源：每个占位符 / 字段用了哪个点路径的哪个值
memo.csv         关键指标表（仪表盘那一块）
render_log.json  本次渲染的合规命中与白名单校验结果
```

自检（数字白名单 + 合规改写，只跑不落盘）：

```bash
python selftest.py
```

## 渲染流程（四步）

```
统一对象 + run_log
      │
      ├─ 1. 查路径   resolve.py：按 number_bindings.json 解析点路径
      ├─ 2. 格式化   元 / 亿元 / 小数 / 百分点 / 倍 / 天 / 次
      ├─ 3. 填空     模板 memo_7cols.md 的占位符，循环体逐项展开
      ├─ 4. 安全闸   合规过滤（改词不动数）→ 数字白名单校验（越界拒稿）
      │
      ▼
memo.md（唯一真源）→ memo.html / memo.json / memo.csv
```

## 模板与配置各管什么

| 文件 | 管什么 |
| --- | --- |
| `templates/memo_7cols.md` | 七个栏目的骨架 + 占位符，**只写固定文字，不写数字** |
| `config/number_bindings.json` | 占位符 → 点路径 + 格式化器；仪表盘选哪些指标；固定常量 |
| `config/compliance.json` | 合规禁用词表与改写规则 |

改文案改模板；改取数改 `number_bindings.json`；改合规口径改 `compliance.json`。
**不要改渲染逻辑去绕过白名单。**

## 占位符语法

- 标量：`{{占位符名}}`，可选覆盖格式化器 `{{占位符名|pct}}`
- 循环：`{{#集合名}} … {{/集合名}}`，集合内用 `{{字段名}}`、`{{@index}}`
- 集合为空时渲染为「无」，不会留空壳

所有占位符必须在配置里有登记，否则渲染直接报错（防止把 `{{}}` 静默留空）。

## 与统一对象的边界

- 只读统一对象，不改一个字段
- 取数严格按方案第二部分第七节的栏目映射表，归因散文直接取 B 的「归因」层，
  风险按 severity 再按 score 排序，**D 不新增叙述**
- 缺失数据一律显示「数据缺失·待核验」，**不猜、不补 0**

## 文件导航

| 文件 | 用途 |
| --- | --- |
| `SKILL.md` | 本文件：怎么用 |
| `INPUT.md` | 输入契约（从统一对象哪七个键取数） |
| `OUTPUT.md` | 输出契约（七栏目结构 + 各格式文件清单） |
| `RULES.md` | 数字锁定规则、合规禁用词、口径换算规则 |
| `templates/memo_7cols.md` | 七栏目模板 |
| `config/number_bindings.json` | 占位符到点路径的绑定表 |
| `config/compliance.json` | 合规禁用词表 |
| `scripts/render_memo.py` | 入口：渲染 + 白名单校验 + 合规过滤 |
| `scripts/resolve.py` | 点路径解析 |
| `scripts/export_html.py` / `export_csv.py` / `export_json.py` | 各格式导出 |
| `scripts/selftest.py` | 自检：白名单拦截 + 合规改写 |
| `demo/` | 茅台真数据最小案例（输入 + 期望产出） |

---

*研究用途，不构成投资建议。*
