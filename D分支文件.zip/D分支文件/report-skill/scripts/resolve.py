# -*- coding: utf-8 -*-
"""resolve.py — 统一对象点路径解析。

路径语法（片段以 . 分隔）：

    company.name                       普通字典键
    valuation.dcf.forecast[0].revenue   列表按下标取
    valuation.blended.components{key=dcf}.per_share
                                        列表按字段等值选取（找 key == "dcf" 的那一项）

返回三元组 (found, value, resolved_path)：
    found        是否解析成功
    value        解析到的值（可能是 dict / list / 标量 / None）
    resolved_path 规范化后的可读路径，用于 memo.json 溯源

只读，不改动任何传入对象。
"""

import re

_INDEX = re.compile(r"^([A-Za-z_][\w]*)\[(\d+)\]$")
_SELECT = re.compile(r"^([A-Za-z_][\w]*)\{(\w+)=([^}]+)\}$")


class ResolveError(Exception):
    pass


def _as_dict(value, seg):
    if not isinstance(value, dict):
        raise ResolveError("在非对象上取字段 %r" % seg)
    if seg not in value:
        raise ResolveError("字段不存在: %s" % seg)
    return value[seg]


def _as_index(value, i):
    if not isinstance(value, list):
        raise ResolveError("在非列表上取下标 %d" % i)
    if i < 0 or i >= len(value):
        raise ResolveError("下标越界: [%d]" % i)
    return value[i]


def _as_select(value, field, want):
    if not isinstance(value, list):
        raise ResolveError("在非列表上做 {field=value} 选取")
    for item in value:
        if isinstance(item, dict) and str(item.get(field)) == str(want):
            return item
    raise ResolveError("未找到 %s=%s 的项" % (field, want))


def resolve(root, path):
    """解析点路径。永不抛异常，失败时返回 (False, None, path)。"""
    if not isinstance(path, str) or not path:
        return False, None, path
    cur = root
    parts = []
    try:
        for raw in path.split("."):
            seg = raw.strip()
            if not seg:
                raise ResolveError("空片段")
            m = _INDEX.match(seg)
            if m:
                name, idx = m.group(1), int(m.group(2))
                cur = _as_index(_as_dict(cur, name), idx)
                parts.append("%s[%d]" % (name, idx))
                continue
            m = _SELECT.match(seg)
            if m:
                name, field, want = m.group(1), m.group(2), m.group(3)
                cur = _as_select(_as_dict(cur, name), field, want)
                parts.append("%s{%s=%s}" % (name, field, want))
                continue
            cur = _as_dict(cur, seg)
            parts.append(seg)
    except ResolveError:
        return False, None, path
    return True, cur, ".".join(parts)


def canonical_path(root, path):
    """只取规范化路径，值丢弃。"""
    ok, _v, resolved = resolve(root, path)
    return resolved if ok else path
