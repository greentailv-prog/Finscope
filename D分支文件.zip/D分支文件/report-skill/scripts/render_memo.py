# -*- coding: utf-8 -*-
"""render_memo.py — FinScope 投研简报渲染入口。

职责（只做三件事，外加两道校验）：

  1. 查路径 —— 模板里写占位符，渲染器按 config/number_bindings.json 解析统一对象的点路径
  2. 按单位格式化 —— 元 / 亿元 / 小数 / 百分点 / 倍 / 天 / 次，统一在 formatters 里
  3. 填空 —— 把格式化后的字符串替进模板

  安全闸：
  A. 数字白名单校验：渲染成稿后用正则抓出所有数字，逐个核对是否在允许集合里。
     允许集合 = 所有占位符/循环字段渲染出来的数字 ∪ 配置登记的常量。
     有越界数字 → 拒绝出稿并报错（这就是「模型不许写数」的机器强制）。
  B. 合规过滤：扫禁用词表，命中改写为合规表述，记录进 render_log.json，改写不动任何数字。

整份报告确定性渲染，不调用任何大模型。
只用 Python 标准库。
"""

import argparse
import datetime
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from resolve import resolve  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)  # report-skill/

DEFAULT_TEMPLATE = os.path.join(ROOT, "templates", "memo_7cols.md")
DEFAULT_CONFIG_DIR = os.path.join(ROOT, "config")
DEFAULT_OUT_ROOT = os.path.abspath(
    os.path.join(ROOT, os.pardir, os.pardir, "out_data", "reports")
)

MISSING = "数据缺失"
MISSING_REVIEW = "数据缺失·待核验"
EMPTY_LIST_TEXT = "  - 无"

NUMBER_RE = re.compile(r"[-+]?\d[\d,]*(?:\.\d+)?")

CURRENCY_LABEL = {"CNY": "人民币元", "USD": "美元", "HKD": "港元"}

SEVERITY_RANK = {"high": 0, "medium": 1, "low": 2}


# --------------------------------------------------------------------------
# 格式化器
# --------------------------------------------------------------------------
def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def fmt_text(v):
    return MISSING if v is None else str(v)


def fmt_int(v):
    if v is None:
        return MISSING
    f = _f(v)
    return MISSING if f is None else str(int(round(f)))


def fmt_num0(v):
    f = _f(v)
    return MISSING if f is None else "{:,.0f}".format(f)


def fmt_num2(v):
    f = _f(v)
    return MISSING if f is None else "{:,.2f}".format(f)


def fmt_num4(v):
    f = _f(v)
    return MISSING if f is None else "{:.4f}".format(f)


def fmt_amt(v):
    f = _f(v)
    return MISSING if f is None else "{:,.2f} 元".format(f)


def fmt_yi(v):
    """金额 → 亿元。"""
    f = _f(v)
    return MISSING if f is None else "{:,.2f} 亿元".format(f / 1e8)


def fmt_pct(v):
    f = _f(v)
    return MISSING if f is None else "{:.2f}%".format(f * 100)


def fmt_pp(v):
    """比率 → 百分点（带正负号）。"""
    f = _f(v)
    return MISSING if f is None else "{:+.2f}".format(f * 100)


def fmt_x(v):
    f = _f(v)
    return MISSING if f is None else "{:.2f} 倍".format(f)


def fmt_days(v):
    f = _f(v)
    return MISSING if f is None else "{:.2f} 天".format(f)


def fmt_times(v):
    f = _f(v)
    return MISSING if f is None else "{:.2f} 次".format(f)


def fmt_currency(v):
    return CURRENCY_LABEL.get(v, fmt_text(v))


FORMATTERS = {
    "text": fmt_text,
    "int": fmt_int,
    "num0": fmt_num0,
    "num2": fmt_num2,
    "num4": fmt_num4,
    "amt": fmt_amt,
    "yi": fmt_yi,
    "pct": fmt_pct,
    "pp": fmt_pp,
    "x": fmt_x,
    "days": fmt_days,
    "times": fmt_times,
    "currency": fmt_currency,
}


def apply_fmt(name, value):
    fn = FORMATTERS.get(name)
    if fn is None:
        raise KeyError("未知格式化器: %s" % name)
    return fn(value)


# --------------------------------------------------------------------------
# 数字工具
# --------------------------------------------------------------------------
def extract_tokens(text):
    return NUMBER_RE.findall(text or "")


def canon_num(tok):
    s = tok.replace(",", "")
    if s.startswith("+"):
        s = s[1:]
    if "." in s:
        s = s.rstrip("0").rstrip(".")
        if s in ("", "-"):
            s = "0"
    if s == "-0":
        s = "0"
    return s


# --------------------------------------------------------------------------
# 派生数据
# --------------------------------------------------------------------------
def find_attribution(root):
    """找 B 证据链里第一个 step 为「归因」的那一层。返回 (ri, ci, layer) 或 None。"""
    risks = root.get("risks") or []
    for ri, r in enumerate(risks):
        for ci, step in enumerate(r.get("evidence_chain") or []):
            if isinstance(step, dict) and step.get("step") == "归因":
                return ri, ci, step
    return None


def build_derived(root):
    """构造 @dupont.* 派生量，附带真实来源路径。"""
    derived = {}
    found = find_attribution(root)
    if not found:
        return derived, None
    ri, ci, layer = found
    dupont = layer.get("dupont") or {}
    base = "risks[%d].evidence_chain[%d].dupont" % (ri, ci)
    for k in ("net_margin_effect", "asset_turnover_effect", "leverage_effect", "roe_delta"):
        derived[k] = {"value": dupont.get(k), "path": "%s.%s" % (base, k)}
    bridge = []
    for j, it in enumerate(layer.get("cash_flow_bridge_items_yi") or []):
        p = "risks[%d].evidence_chain[%d].cash_flow_bridge_items_yi[%d]" % (ri, ci, j)
        bridge.append(
            {
                "item": {"value": it.get("item"), "fmt": "text", "path": p + ".item"},
                "amount_yi": {"value": it.get("amount_yi"), "fmt": "num2", "path": p + ".amount_yi"},
            }
        )
    meta = {"risk_index": ri, "chain_index": ci, "bridge": bridge}
    return derived, meta


# --------------------------------------------------------------------------
# 集合（循环体）构造
# --------------------------------------------------------------------------
def _rf(idx, name, value, fmt="text"):
    return {"value": value, "fmt": fmt, "path": "risks[%d].%s" % (idx, name)}


def fmt_involved(item):
    v = item.get("value")
    u = item.get("unit")
    p = item.get("page")
    if v is None:
        s = MISSING
    elif u == "元":
        s = "{:,.2f} 元".format(v)
    elif u == "小数":
        s = "{:.4f}".format(v)
    elif u == "倍":
        s = "{:.2f} 倍".format(v)
    elif u == "天":
        s = "{:.2f} 天".format(v)
    elif u == "次":
        s = "{:.2f} 次".format(v)
    else:
        s = str(v)
    page = "（P%s）" % p if p else ""
    return "%s %s%s" % (item.get("metric"), s, page)


def build_collections(root, run_log, cfg):
    colls = {}
    meta = cfg.get("meta", {})

    # ---- 风险排序：severity 再 score ----
    risks = list(root.get("risks") or [])
    ordered = sorted(
        range(len(risks)),
        key=lambda i: (
            SEVERITY_RANK.get(risks[i].get("severity"), 9),
            -(risks[i].get("score") or 0),
        ),
    )

    def risk_item(i):
        r = risks[i]
        return {
            "risk_id": _rf(i, "risk_id", r.get("risk_id")),
            "severity_tag": _rf(i, "severity_tag", r.get("severity_tag")),
            "risk_name": _rf(i, "risk_name", r.get("risk_name")),
            "category": _rf(i, "category", r.get("category")),
            "score": _rf(i, "score", r.get("score"), "num0"),
            "trigger": _rf(i, "trigger", r.get("trigger")),
            "involved_str": _rf(i, "involved_values", "；".join(fmt_involved(x) for x in (r.get("involved_values") or []))),
            "numeric_evidence": _rf(i, "numeric_evidence", r.get("numeric_evidence")),
            "explanation": _rf(i, "explanation", r.get("explanation")),
            "suggested_action": _rf(i, "suggested_action", r.get("suggested_action")),
        }

    top_n = int(meta.get("top_risks_n", 3))
    colls["top_risks"] = [risk_item(i) for i in ordered[:top_n]]
    colls["risks"] = [risk_item(i) for i in ordered]

    # ---- 仪表盘 ----
    dash = []
    for entry in cfg.get("dashboard", []):
        category, path = entry[0], entry[1]
        label = entry[2] if len(entry) > 2 else path.split(".")[-1]
        ok, rec, rpath = resolve(root, path)
        rec = rec if (ok and isinstance(rec, dict)) else {}
        unit = rec.get("unit")
        if unit == "小数":
            vfmt, pfmt, dfmt = "pct", "pct", "pp"
        elif unit == "倍":
            vfmt = pfmt = dfmt = "x"
        elif unit == "天":
            vfmt = pfmt = "days"
            dfmt = "num2"
        elif unit == "次":
            vfmt = pfmt = "times"
            dfmt = "num2"
        elif unit == "元":
            vfmt = pfmt = dfmt = "yi"
        else:
            vfmt = pfmt = dfmt = "num2"
        status = rec.get("status")
        if status == "ok":
            status_str = "正常"
        elif status is None:
            status_str = MISSING_REVIEW
        else:
            status_str = MISSING_REVIEW
        dash.append(
            {
                "label": {"value": label, "fmt": "text", "path": path + "（标签）"},
                "category": {"value": category, "fmt": "text", "path": "（配置 category）"},
                "value_str": {"value": rec.get("value"), "fmt": vfmt, "path": rpath + ".value"},
                "prev_str": {"value": rec.get("prev"), "fmt": pfmt, "path": rpath + ".prev"},
                "delta_str": {"value": rec.get("delta"), "fmt": dfmt, "path": rpath + ".delta"},
                "status_str": {"value": status_str, "fmt": "text", "path": rpath + ".status"},
            }
        )
    colls["dashboard"] = dash

    # ---- 现金流桥 ----
    _derived, dmeta = build_derived(root)
    colls["cashflow_bridge"] = dmeta["bridge"] if dmeta else []

    # ---- DCF 预测 ----
    dcf = (root.get("valuation") or {}).get("dcf") or {}
    fc = []
    for j, row in enumerate(dcf.get("forecast") or []):
        p = "valuation.dcf.forecast[%d]" % j
        fc.append(
            {
                "year": {"value": row.get("year"), "fmt": "int", "path": p + ".year"},
                "revenue_yi": {"value": row.get("revenue"), "fmt": "yi", "path": p + ".revenue"},
                "ebit_yi": {"value": row.get("ebit"), "fmt": "yi", "path": p + ".ebit"},
                "fcff_yi": {"value": row.get("fcff"), "fmt": "yi", "path": p + ".fcff"},
            }
        )
    colls["forecast"] = fc

    # ---- 三情景 ----
    scen = (root.get("valuation") or {}).get("scenarios") or {}
    label_map = {"bull": "乐观", "base": "中性", "bear": "悲观"}
    sc = []
    for k in ("bull", "base", "bear"):
        rec = scen.get(k) or {}
        p = "valuation.scenarios.%s" % k
        sc.append(
            {
                "label": {"value": rec.get("label") or label_map[k], "fmt": "text", "path": p + ".label"},
                "per_share": {"value": rec.get("per_share"), "fmt": "num2", "path": p + ".per_share"},
                "growth_y1": {"value": rec.get("growth_y1"), "fmt": "pct", "path": p + ".growth_y1"},
                "ebit_margin": {"value": rec.get("ebit_margin"), "fmt": "pct", "path": p + ".ebit_margin"},
                "wacc": {"value": rec.get("wacc"), "fmt": "pct", "path": p + ".wacc"},
            }
        )
    colls["scenarios"] = sc

    # ---- 敏感性 ----
    sens = dcf.get("sensitivity") or {}
    tgv = sens.get("terminal_growth_values") or []
    wv = sens.get("wacc_values") or []
    matrix = sens.get("matrix") or []
    colls["sensitivity_rows"] = [
        {
            "wacc": {"value": wv[i] if i < len(wv) else None, "fmt": "pct", "path": "valuation.dcf.sensitivity.wacc_values[%d]" % i},
            "cells": {
                "value": " | ".join(
                    fmt_num2(c) if c is not None else MISSING
                    for c in (matrix[i] if i < len(matrix) else [])
                ),
                "fmt": "text",
                "path": "valuation.dcf.sensitivity.matrix[%d]" % i,
            },
        }
        for i in range(len(wv) or len(matrix))
    ]

    # ---- 待核验事项 ----
    rules = [
        r for r in (root.get("rules_evaluated") or [])
        if r.get("status") == "not_evaluable"
    ]
    colls["review_rules"] = [
        {
            "rule_id": {"value": r.get("rule_id"), "fmt": "text", "path": "rules_evaluated[%d].rule_id" % i},
            "rule_name": {"value": r.get("rule_name"), "fmt": "text", "path": "rules_evaluated[%d].rule_name" % i},
            "explanation": {"value": r.get("explanation"), "fmt": "text", "path": "rules_evaluated[%d].explanation" % i},
        }
        for i, r in enumerate(root.get("rules_evaluated") or [])
        if r.get("status") == "not_evaluable"
    ]

    fin = []
    for name, rec in (root.get("financials") or {}).items():
        if not isinstance(rec, dict):
            continue
        st = rec.get("status")
        if st and st != "found":
            fin.append(
                {
                    "name": {"value": name, "fmt": "text", "path": "financials.%s（科目名）" % name},
                    "status": {"value": st, "fmt": "text", "path": "financials.%s.status" % name},
                }
            )
    colls["review_fin"] = fin

    valw = ((root.get("valuation") or {}).get("warnings")) or []
    colls["review_valwarn"] = [
        {"text": {"value": w, "fmt": "text", "path": "valuation.warnings[%d]" % i}}
        for i, w in enumerate(valw)
    ]

    runw = (run_log or {}).get("warnings") or []
    colls["review_runwarn"] = [
        {"text": {"value": w, "fmt": "text", "path": "run_log.warnings[%d]" % i}}
        for i, w in enumerate(runw)
    ]

    # ---- 来源 ----
    src = []
    for i, s in enumerate(root.get("sources") or []):
        p = "sources[%d]" % i
        src.append(
            {
                "file_name": {"value": s.get("file_name"), "fmt": "text", "path": p + ".file_name"},
                "page": {"value": s.get("page"), "fmt": "int", "path": p + ".page"},
                "retrieved_at": {"value": s.get("retrieved_at") or "未标注", "fmt": "text", "path": p + ".retrieved_at"},
            }
        )
    colls["sources"] = src

    return colls


def compute_scalars(root, run_log):
    """由统一对象确定性算出的标量（计数、列头拼接），附带说明性来源路径。"""
    out = {}
    out["risk_count"] = {"value": len(root.get("risks") or []), "path": "risks（长度）"}
    out["n_rules"] = {
        "value": sum(1 for r in (root.get("rules_evaluated") or []) if r.get("status") == "not_evaluable"),
        "path": "rules_evaluated（status=not_evaluable 计数）",
    }
    out["n_fin"] = {
        "value": sum(
            1 for r in (root.get("financials") or {}).values()
            if isinstance(r, dict) and r.get("status") and r.get("status") != "found"
        ),
        "path": "financials（status≠found 计数）",
    }
    valw = ((root.get("valuation") or {}).get("warnings")) or []
    out["n_valwarn"] = {"value": len(valw), "path": "valuation.warnings（长度）"}
    runw = (run_log or {}).get("warnings") or []
    out["n_runwarn"] = {"value": len(runw), "path": "run_log.warnings（长度）"}

    tgv = (((root.get("valuation") or {}).get("dcf") or {}).get("sensitivity") or {}).get(
        "terminal_growth_values"
    ) or []
    out["sens_header_cells"] = {
        "value": " | ".join(apply_fmt("pct", v) for v in tgv),
        "path": "valuation.dcf.sensitivity.terminal_growth_values",
    }
    return out


def build_bindings(root, cfg, run_log=None):
    derived, _meta = build_derived(root)
    computed = compute_scalars(root, run_log)
    bindings = {}
    for name, spec in cfg.get("bindings", {}).items():
        path, fname = spec[0], spec[1]
        if path.startswith("@const."):
            key = path[len("@const."):]
            val = cfg.get("constants", {}).get(key)
            bindings[name] = {"value": val, "fmt": fname, "path": path, "raw": val}
        elif path.startswith("@computed."):
            key = path[len("@computed."):]
            c = computed.get(key) or {}
            bindings[name] = {"value": c.get("value"), "fmt": fname, "path": c.get("path", path), "raw": c.get("value")}
        elif path.startswith("@dupont."):
            key = path[len("@dupont."):]
            d = derived.get(key) or {}
            bindings[name] = {"value": d.get("value"), "fmt": fname, "path": d.get("path", path), "raw": d.get("value")}
        else:
            ok, val, rpath = resolve(root, path)
            bindings[name] = {
                "value": val if ok else None,
                "fmt": fname,
                "path": rpath if ok else path,
                "raw": val if ok else None,
                "found": ok,
            }
    return bindings


# --------------------------------------------------------------------------
# 渲染
# --------------------------------------------------------------------------
class RenderState(object):
    def __init__(self):
        self.scalars = []          # {placeholder, path, raw, formatted}
        self.collections = []      # {name, items:[{index, fields:{f:{path,raw,formatted}}}]}
        self.num_index = {}        # canon -> set(path)
        self.emitted = []          # 所有渲染输出串（供白名单）

    def emit(self, name, path, raw, formatted):
        self.emitted.append(formatted)
        for t in extract_tokens(formatted):
            self.num_index.setdefault(canon_num(t), set()).add(path)

    def allowed(self):
        return set(self.num_index.keys())


LOOP_RE = re.compile(r"\{\{#(\w+)\}\}(.*?)\{\{/\1\}\}", re.DOTALL)
FIELD_RE = re.compile(r"\{\{\s*([^#/][^}]*?)\s*\}\}")


def _parse_placeholder(expr):
    if "|" in expr:
        n, f = expr.split("|", 1)
        return n.strip(), f.strip()
    return expr.strip(), None


def render(template_text, bindings, collections, state):
    # 1) 展开循环（本模板不含嵌套循环）
    def expand_loop(m):
        cname = m.group(1)
        body = m.group(2)
        if cname not in collections:
            raise KeyError("模板引用了不存在的集合: %s" % cname)
        items = collections[cname]
        if not items:
            return EMPTY_LIST_TEXT
        out = []
        for idx, item in enumerate(items):
            def repl(mm):
                expr = mm.group(1)
                if expr == "@index":
                    return str(idx + 1)
                fname, fover = _parse_placeholder(expr)
                if fname not in item:
                    raise KeyError("集合 %s 的项缺字段: %s" % (cname, fname))
                fd = item[fname]
                fmt = fover or fd["fmt"]
                formatted = apply_fmt(fmt, fd["value"])
                state.emit("%s.%s" % (cname, fname), fd["path"], fd["value"], formatted)
                return formatted

            out.append(FIELD_RE.sub(repl, body))
        return "".join(out)

    text = LOOP_RE.sub(expand_loop, template_text)

    # 2) 展开标量占位符
    def repl_scalar(m):
        name, fover = _parse_placeholder(m.group(1))
        if name not in bindings:
            raise KeyError("模板引用了未登记的占位符: %s" % name)
        b = bindings[name]
        fmt = fover or b["fmt"]
        formatted = apply_fmt(fmt, b["value"])
        state.emit(name, b["path"], b["raw"], formatted)
        state.scalars.append(
            {"placeholder": name, "path": b["path"], "raw": b["raw"], "formatted": formatted}
        )
        return formatted

    text = FIELD_RE.sub(repl_scalar, text)

    if "{{" in text or "}}" in text:
        raise ValueError("模板残留未解析的占位符，请检查模板与配置是否一致")
    return text


# --------------------------------------------------------------------------
# 版式整理：删掉表格行之间、列表项之间的多余空行
# --------------------------------------------------------------------------
def tighten_blocks(text):
    lines = text.split("\n")
    out = []

    def is_table(l):
        return l.lstrip().startswith("|")

    def is_list(l):
        return l.startswith("- ") or l.lstrip().startswith("- ")

    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        if line.strip() == "":
            prev = out[-1] if out else ""
            j = i
            while j < n and lines[j].strip() == "":
                j += 1
            nxt = lines[j] if j < n else ""
            drop = (
                prev.strip()
                and nxt.strip()
                and ((is_table(prev) and is_table(nxt)) or (is_list(prev) and is_list(nxt)))
            )
            if not drop:
                out.append(line)
            i += 1
        else:
            out.append(line)
            i += 1
    return "\n".join(out)


# --------------------------------------------------------------------------
# 合规过滤
# --------------------------------------------------------------------------
def apply_compliance(text, rules):
    hits = []
    before = set(canon_num(t) for t in extract_tokens(text))
    for r in sorted(rules, key=lambda x: -len(x["pattern"])):
        p = r["pattern"]
        cnt = text.count(p)
        if cnt:
            hits.append({"pattern": p, "replacement": r["replacement"], "count": cnt})
            text = text.replace(p, r["replacement"])
    after = set(canon_num(t) for t in extract_tokens(text))
    if before != after:
        raise AssertionError("合规改写动到了数字，禁止出稿")
    return text, hits


# --------------------------------------------------------------------------
# 数字白名单校验
# --------------------------------------------------------------------------
def validate_numbers(text, allowed):
    violations = []
    for m in NUMBER_RE.finditer(text):
        tok = m.group(0)
        if canon_num(tok) not in allowed:
            s = max(0, m.start() - 20)
            violations.append({"token": tok, "context": text[s:m.end() + 10].replace("\n", " ")})
    return violations


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def run(unified_path, run_log_path, template_path, config_dir, out_root, key_override=None,
        write=True):
    root = load_json(unified_path)
    run_log = load_json(run_log_path) if run_log_path and os.path.exists(run_log_path) else {}

    with open(os.path.join(config_dir, "number_bindings.json"), "r", encoding="utf-8") as f:
        cfg = json.load(f)
    with open(os.path.join(config_dir, "compliance.json"), "r", encoding="utf-8") as f:
        comp = json.load(f)

    with open(template_path, "r", encoding="utf-8") as f:
        template_text = f.read()

    company = root.get("company") or {}
    key = key_override or cfg["meta"]["key_template"].format(
        ticker=company.get("ticker", "UNKNOWN"),
        report_period=company.get("report_period", "NA"),
    )

    bindings = build_bindings(root, cfg, run_log)
    collections = build_collections(root, run_log, cfg)

    state = RenderState()
    md = render(template_text, bindings, collections, state)
    md = tighten_blocks(md)

    # 合规过滤
    md, comp_hits = apply_compliance(md, comp.get("banned", []))

    # 数字白名单校验
    allowed = state.allowed()
    violations = validate_numbers(md, allowed)
    validation = {
        "passed": len(violations) == 0,
        "allowed_count": len(allowed),
        "scanned_tokens": len(set(canon_num(t) for t in extract_tokens(md))),
        "violations": violations,
    }
    if violations:
        detail = "；".join("%s（…%s…）" % (v["token"], v["context"]) for v in violations[:10])
        raise SystemExit(
            "[拒绝出稿] 数字白名单校验未通过，检测到 %d 处越界数字：%s"
            % (len(violations), detail)
        )

    # 组装各格式
    result = {
        "key": key,
        "md": md,
        "state": state,
        "cfg": cfg,
        "collections": collections,
        "company": company,
        "validation": validation,
        "compliance_hits": comp_hits,
        "generated_at": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
    }

    if write:
        out_dir = os.path.join(out_root, key)
        os.makedirs(out_dir, exist_ok=True)
        _write_outputs(result, out_dir)

    return result


def _write_outputs(result, out_dir):
    import export_html
    import export_csv
    import export_json

    md = result["md"]
    key = result["key"]

    with open(os.path.join(out_dir, "memo.md"), "w", encoding="utf-8") as f:
        f.write(md)

    html = export_html.convert(md, title="%s 投资研究简报" % key)
    with open(os.path.join(out_dir, "memo.html"), "w", encoding="utf-8") as f:
        f.write(html)

    export_csv.write_csv(result, os.path.join(out_dir, "memo.csv"), apply_fmt)
    export_json.write_json(result, os.path.join(out_dir, "memo.json"), apply_fmt)

    render_log = {
        "key": key,
        "generated_at": result["generated_at"],
        "engine": "deterministic-template-v1（不使用大模型）",
        "inputs": {
            "unified": "统一对象七键",
            "bindings": "config/number_bindings.json",
            "compliance": "config/compliance.json",
        },
        "files": ["memo.md", "memo.html", "memo.json", "memo.csv"],
        "numbers": {
            "placeholder_outputs": len(result["state"].emitted),
            "distinct_numbers": result["validation"]["allowed_count"],
        },
        "compliance": {"hits": result["compliance_hits"]},
        "number_whitelist": result["validation"],
    }
    with open(os.path.join(out_dir, "render_log.json"), "w", encoding="utf-8") as f:
        json.dump(render_log, f, ensure_ascii=False, indent=2)


def main(argv=None):
    ap = argparse.ArgumentParser(description="FinScope 投研简报渲染器")
    ap.add_argument("--unified", required=True, help="统一对象 JSON")
    ap.add_argument("--run-log", default=None, help="run_log.json")
    ap.add_argument("--template", default=DEFAULT_TEMPLATE)
    ap.add_argument("--config-dir", default=DEFAULT_CONFIG_DIR)
    ap.add_argument("--out-root", default=DEFAULT_OUT_ROOT)
    ap.add_argument("--key", default=None, help="覆盖输出目录名，默认 <ticker>_<period>")
    ap.add_argument("--check-only", action="store_true", help="只校验不落盘")
    args = ap.parse_args(argv)

    result = run(
        unified_path=args.unified,
        run_log_path=args.run_log,
        template_path=args.template,
        config_dir=args.config_dir,
        out_root=args.out_root,
        key_override=args.key,
        write=not args.check_only,
    )
    v = result["validation"]
    print("[OK] key=%s  数字白名单通过（允许 %d 个、扫描 %d 个）  禁用词命中 %d 处"
          % (result["key"], v["allowed_count"], v["scanned_tokens"], len(result["compliance_hits"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
