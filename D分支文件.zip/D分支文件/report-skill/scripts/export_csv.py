# -*- coding: utf-8 -*-
"""export_csv.py — 关键指标表 CSV。

取仪表盘集合（config/number_bindings.json 的 dashboard 选择）写成 CSV。
用 utf-8-sig（带 BOM），Excel 打开中文不乱码。
格式化器由入口传入（apply_fmt），避免循环导入。
"""

import csv


def build_rows(result, apply_fmt):
    colls = result["collections"]
    rows = [["指标", "类别", "本期", "上期", "变动", "状态"]]
    for item in colls.get("dashboard", []):
        rows.append([
            item["label"]["value"],
            item["category"]["value"],
            apply_fmt(item["value_str"]["fmt"], item["value_str"]["value"]),
            apply_fmt(item["prev_str"]["fmt"], item["prev_str"]["value"]),
            apply_fmt(item["delta_str"]["fmt"], item["delta_str"]["value"]),
            apply_fmt(item["status_str"]["fmt"], item["status_str"]["value"]),
        ])
    return rows


def write_csv(result, path, apply_fmt):
    rows = build_rows(result, apply_fmt)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(rows)
    return path
