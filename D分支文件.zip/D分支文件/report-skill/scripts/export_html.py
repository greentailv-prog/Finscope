# -*- coding: utf-8 -*-
"""export_html.py — 把 memo.md 转成带打印 CSS 的 HTML。

只用标准库，手写一个够用的 Markdown 子集转换器：标题、段落、无序列表、
引用块、表格、加粗。memo_7cols 模板只用到这些。
浏览器打印即得 PDF（@page + @media print）。
"""

import html as _html
import re

_BOLD = re.compile(r"\*\*(.+?)\*\*")

PRINT_CSS = """
:root { color-scheme: light; }
body { font-family: "Microsoft YaHei", "PingFang SC", "SimSun", sans-serif;
       max-width: 920px; margin: 32px auto; padding: 0 24px; line-height: 1.7;
       color: #1a1a1a; font-size: 15px; }
h1 { font-size: 24px; border-bottom: 3px solid #14532d; padding-bottom: 8px; }
h2 { font-size: 19px; margin-top: 32px; border-left: 5px solid #14532d; padding-left: 10px; }
h3 { font-size: 16px; margin-top: 22px; color: #14532d; }
blockquote { background: #f3f7f4; border-left: 4px solid #9bb8a6; margin: 12px 0;
             padding: 8px 14px; color: #44544b; font-size: 14px; }
table { border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 13px; }
th, td { border: 1px solid #cbd5cf; padding: 6px 9px; text-align: left; vertical-align: top; }
th { background: #e8f0ea; font-weight: 600; }
ul { margin: 6px 0; padding-left: 22px; }
li { margin: 3px 0; }
strong { color: #0b3d1f; }
hr { border: none; border-top: 1px solid #d6ddd8; margin: 24px 0; }
@page { size: A4; margin: 16mm; }
@media print {
  body { max-width: none; margin: 0; font-size: 12px; }
  h2 { page-break-after: avoid; }
  table, blockquote { page-break-inside: avoid; }
}
"""


def _inline(text):
    return _BOLD.sub(r"<strong>\1</strong>", _html.escape(text, quote=False))


def _flush_table(buf, out):
    if not buf:
        return
    rows = [r for r in buf if not re.match(r"^\s*\|?\s*:?-{2,}", r)]
    if not rows:
        buf.clear()
        return
    out.append("<table>")
    for i, r in enumerate(rows):
        cells = [c.strip() for c in r.strip().strip("|").split("|")]
        tag = "th" if i == 0 else "td"
        out.append("<tr>" + "".join(
            "<%s>%s</%s>" % (tag, _inline(c), tag) for c in cells) + "</tr>")
    out.append("</table>")
    buf.clear()


def convert(md_text, title="投资研究简报"):
    out = []
    table_buf = []
    ul_buf = []

    def flush_ul():
        if ul_buf:
            out.append("<ul>" + "".join(
                "<li>%s</li>" % _inline(x) for x in ul_buf) + "</ul>")
            ul_buf.clear()

    for line in md_text.splitlines():
        is_table = line.lstrip().startswith("|")
        if is_table:
            flush_ul()
            table_buf.append(line)
            continue
        else:
            _flush_table(table_buf, out)

        if line.startswith("- ") or line.startswith("  - "):
            ul_buf.append(line.strip()[2:])
            continue
        flush_ul()

        s = line.rstrip()
        if not s.strip():
            continue
        if re.match(r"^#{1,6} ", s):
            lvl = len(s) - len(s.lstrip("#"))
            out.append("<h%d>%s</h%d>" % (lvl, _inline(s[lvl:].strip()), lvl))
        elif s.startswith("> "):
            out.append("<blockquote>%s</blockquote>" % _inline(s[2:]))
        elif s.strip() == "---":
            out.append("<hr>")
        else:
            out.append("<p>%s</p>" % _inline(s))

    _flush_table(table_buf, out)
    flush_ul()

    body = "\n".join(out)
    return (
        "<!DOCTYPE html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
        "<title>%s</title>\n<style>%s</style>\n</head>\n<body>\n%s\n</body>\n</html>\n"
        % (_html.escape(title, quote=True), PRINT_CSS, body)
    )
