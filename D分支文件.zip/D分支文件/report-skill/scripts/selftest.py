# -*- coding: utf-8 -*-
"""selftest.py — 自检：数字白名单与合规过滤。

跑四件事：
  1. 正常渲染茅台统一对象，白名单通过
  2. 把成稿里一个数字改成越界值，白名单必须拦下
  3. 模板里塞一个字面量越界数字，渲染器必须拒绝出稿（SystemExit）
  4. 含「目标价」的句子必须被改写为合规表述，且数字不动

用法：python selftest.py
"""

import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import render_memo as rm  # noqa: E402

DEMO = os.path.join(ROOT, "demo", "input_unified.json")
RUNLOG = os.path.join(ROOT, "demo", "input_run_log.json")
TEMPLATE = os.path.join(ROOT, "templates", "memo_7cols.md")
CONFIG = os.path.join(ROOT, "config")

results = []


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    print("[%s] %s %s" % ("PASS" if ok else "FAIL", name, detail))


def test_normal():
    res = rm.run(DEMO, RUNLOG, TEMPLATE, CONFIG, out_root="", write=False)
    v = res["validation"]
    record("1 正常渲染白名单通过", v["passed"],
           "（允许 %d / 扫描 %d）" % (v["allowed_count"], v["scanned_tokens"]))
    return res


def test_tamper(res):
    md = res["md"]
    allowed = res["state"].allowed()
    target = None
    for tok in rm.extract_tokens(md):
        if rm.canon_num(tok) == rm.canon_num("1,431.30"):
            target = tok
            break
    if target is None:
        record("2 篡改一个数字应被拦下", False, "未在成稿里找到基准数字 1,431.30")
        return
    tampered = md.replace(target, "9,999.99", 1)
    viols = rm.validate_numbers(tampered, allowed)
    ok = any(rm.canon_num(x["token"]) == "9999.99" for x in viols)
    record("2 篡改一个数字应被拦下", ok,
           "越界 %d 处，样例：%s" % (len(viols), viols[0]["token"] if viols else "-"))


def test_rogue_template():
    with open(TEMPLATE, "r", encoding="utf-8") as f:
        tpl = f.read()
    tpl = tpl + "\n本行由测试脚本故意写入一个越界数字 88888，用于验证拦截。\n"
    fd, path = tempfile.mkstemp(suffix=".md")
    os.close(fd)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(tpl)
        raised = False
        msg = ""
        try:
            rm.run(DEMO, RUNLOG, path, CONFIG, out_root="", write=False)
        except SystemExit as e:
            raised = True
            msg = str(e)
        record("3 模板字面量越界数字必须拒绝出稿", raised, msg[:60])
    finally:
        os.remove(path)


def test_compliance():
    import json
    with open(os.path.join(CONFIG, "compliance.json"), "r", encoding="utf-8") as f:
        rules = json.load(f)["banned"]
    text = "综合判断给出目标价 1,431.30 元，建议买入。"
    out, hits = rm.apply_compliance(text, rules)
    ok = (
        "目标价" not in out
        and "买入" not in out
        and "1,431.30" in out
        and len(hits) >= 2
    )
    record("4 合规改写且数字不动", ok, "→ %s；命中 %d 处" % (out, len(hits)))


def test_provenance(res):
    md = res["md"]
    idx = res["state"].num_index
    missing = []
    for tok in set(rm.canon_num(t) for t in rm.extract_tokens(md)):
        if tok not in idx:
            missing.append(tok)
    ok = not missing
    record("5 成稿每个数字都有点路径出处", ok,
           "缺失 %s" % (missing[:5] if missing else "无"))


def main():
    res = test_normal()
    test_tamper(res)
    test_rogue_template()
    test_compliance()
    test_provenance(res)
    passed = sum(1 for _n, ok, _d in results if ok)
    print("\n== 自检汇总：%d/%d 通过 ==" % (passed, len(results)))
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
