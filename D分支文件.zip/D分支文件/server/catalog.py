# -*- coding: utf-8 -*-
"""扫 A 已抽取的公司，并给出统一对象的键（key）规则。

A 的抽取结果落在 A/data/extracted/<公司名>_<代码>_<年份>.json，company 段里
ticker 是 6 位裸代码（如 "600519"）。统一对象与报告目录用的键是
<ticker 带交易所后缀>_<四位年份>（如 "600519.SH_2025"），后缀规则与
agent/adapters/from_a.py 的 _ticker_with_suffix 一致，保证两边算出来的键相同。

只用标准库。本模块不 import 任何重依赖，供 app / routes 快速调用。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

try:                       # 作为包导入
    from . import config
except ImportError:        # 直接运行
    import config  # type: ignore

_YEAR_RE = re.compile(r"^(\d{4})")


def ticker_with_suffix(ticker):
    """'600519' -> '600519.SH'；'000333'/'300750' -> '.SZ'；已有后缀不动。"""
    if ticker is None:
        return None
    t = str(ticker).strip()
    if not t:
        return t
    if "." in t:
        return t
    if t.startswith("6"):
        return t + ".SH"
    if t.startswith("0") or t.startswith("3"):
        return t + ".SZ"
    return t


def strip_year(raw):
    """'2025年度' / '2025' / '2025-12-31' -> '2025'。认不出原样返回。"""
    if raw is None:
        return None
    m = _YEAR_RE.match(str(raw).strip())
    return m.group(1) if m else str(raw)


def unified_key(ticker, year):
    """由 ticker（可带或不带后缀）与年份拼出统一对象的键。"""
    return "%s_%s" % (ticker_with_suffix(ticker), strip_year(year))


def key_of_a_obj(a_obj):
    """从一份 A 抽取结果算出键。缺字段返回 None。"""
    company = (a_obj or {}).get("company") or {}
    ticker = company.get("ticker")
    year = company.get("report_period")
    if not ticker or not year:
        return None
    return unified_key(ticker, year)


def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def scan():
    """扫 A/data/extracted/*.json。

    返回按代码排序的列表，每条：
      {file, stem, name, code, ticker, year, key, unified_exists, unified_path,
       extracted_path, error}
    error 非空表示该 JSON 读不动（仍列出文件名）。
    """
    out = []
    directory = config.A_EXTRACTED
    if not directory.exists():
        return out
    for path in sorted(directory.glob("*.json")):
        item = {
            "file": path.name,
            "stem": path.stem,
            "name": None,
            "code": None,
            "ticker": None,
            "year": None,
            "key": None,
            "unified_exists": False,
            "unified_path": None,
            "extracted_path": str(path),
            "error": None,
        }
        try:
            a_obj = _read_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            item["error"] = "读取失败：%s" % exc
            out.append(item)
            continue
        company = a_obj.get("company") or {}
        code = company.get("ticker")
        year = strip_year(company.get("report_period"))
        item["name"] = company.get("name")
        item["code"] = code
        item["ticker"] = ticker_with_suffix(code)
        item["year"] = year
        if code and year:
            key = unified_key(code, year)
            item["key"] = key
            upath = config.unified_path(key)
            item["unified_path"] = str(upath)
            item["unified_exists"] = upath.exists()
        out.append(item)
    return out


def find_extracted(code, year):
    """按代码与年份找 A 抽取结果 JSON 的路径。找不到返回 None。

    代码比对去交易所后缀与大小写，例如 '600519.SH' 与 '600519' 等价。
    """
    want_code = config.normalize_code(code)
    want_year = strip_year(year)
    if not want_code:
        return None
    for item in scan():
        if item.get("error"):
            continue
        if config.normalize_code(item.get("code")) != want_code:
            continue
        if want_year and item.get("year") != want_year:
            continue
        return Path(item["extracted_path"])
    return None


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    rows = scan()
    print("已抽取公司 %d 家：" % len(rows))
    for it in rows:
        print("  %-12s %-10s %-10s key=%-16s unified=%s%s"
              % (it["name"], it["code"], it["year"], it["key"],
                 it["unified_exists"], ("  ERROR:%s" % it["error"]) if it["error"] else ""))
