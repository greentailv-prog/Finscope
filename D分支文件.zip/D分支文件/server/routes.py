# -*- coding: utf-8 -*-
"""各 API 端点的处理函数。返回统一的小 Response 对象，由 app.py 负责写回。

每个处理函数只依赖标准库与 server 包内模块，不碰 HTTP 细节。
"""
from __future__ import annotations

import json
import re
import uuid
from pathlib import Path
from urllib.parse import unquote

_THIS = Path(__file__).resolve()
_D_ROOT = _THIS.parent.parent
import sys
if str(_D_ROOT) not in sys.path:
    sys.path.insert(0, str(_D_ROOT))

from server import config, catalog, jobs, chain_runner  # noqa: E402

_JSON_CT = "application/json; charset=utf-8"
_CODE_RE = re.compile(r"^\d{6}$")
_YEAR_ONLY_RE = re.compile(r"^\d{4}$")


class Response:
    def __init__(self, status=200, body=b"", content_type=_JSON_CT, headers=None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.status = status
        self.body = body
        self.content_type = content_type
        self.headers = headers or {}


def json_resp(obj, status=200):
    return Response(status=status,
                    body=json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                    content_type=_JSON_CT)


def error_resp(status, message, **extra):
    payload = {"ok": False, "error": message}
    payload.update(extra)
    return json_resp(payload, status=status)


# --------------------------------------------------------------------------
# 文件名解析：<公司名>_<代码>_<年份>.pdf
# --------------------------------------------------------------------------
def parse_report_name(filename):
    """从文件名拆出公司名/代码/年份。拆不出对应字段留 None。

    容错：文件名可能带额外段（如 ..._年报），按「第一个 6 位数字是代码、
    代码之前的段拼成公司名、代码之后第一个 4 位数字是年份」来认，
    与 A 的 indicators.py 用 split("_")[0]/[1] 取名/代码的口径保持一致。
    """
    out = {"name": None, "code": None, "year": None, "ok": False}
    if not filename:
        return out
    stem = filename[:-4] if filename.lower().endswith(".pdf") else filename
    toks = [t.strip() for t in stem.split("_") if t.strip()]
    if not toks:
        return out
    for i, t in enumerate(toks):
        if out["code"] is None and _CODE_RE.match(t):
            out["code"] = t
            if i > 0:
                out["name"] = "_".join(toks[:i])
        elif out["code"] is not None and out["year"] is None and _YEAR_ONLY_RE.match(t):
            out["year"] = t
    out["ok"] = bool(out["name"] and out["code"] and out["year"])
    return out


# --------------------------------------------------------------------------
# GET /api/health
# --------------------------------------------------------------------------
def health():
    companies = catalog.scan()
    report_ready = chain_runner.RENDER_MEMO.exists()
    steps = {
        "a_pdf_pagemap": config.A_PDF_PAGEMAP.exists(),
        "a_indicators": config.A_INDICATORS.exists(),
        "a_annual_reports_dir": config.A_ANNUAL_REPORTS.exists(),
        "b_compute_ratios": config.B_COMPUTE_RATIOS.exists(),
        "b_detect_risks": config.B_DETECT_RISKS.exists(),
        "b_risk_rules": config.B_RISK_RULES.exists(),
        "c_engine": (config.C_VALUATION / "engine" / "__init__.py").exists(),
        "report_skill": report_ready,
    }
    unified_files = list(config.OUT_UNIFIED.glob("*.json")) if config.OUT_UNIFIED.exists() else []
    unified_files = [p for p in unified_files if not p.name.endswith(".run_log.json")]
    market_files = list(config.MARKET_DATA.glob("*.json")) if config.MARKET_DATA.exists() else []
    recent_jobs = jobs.recent(50)
    job_status = {}
    for j in recent_jobs:
        job_status[j["status"]] = job_status.get(j["status"], 0) + 1
    return json_resp({
        "ok": True,
        "service": "FinScope D 后端",
        "host": config.HOST,
        "port": config.PORT,
        "company_count": len(companies),
        "unified_count": len(unified_files),
        "market_cache_count": len(market_files),
        "steps": steps,
        "ready": all(steps.values()),
        "jobs": job_status,
    })


# --------------------------------------------------------------------------
# GET /api/companies
# --------------------------------------------------------------------------
def companies():
    rows = catalog.scan()
    return json_resp({"ok": True, "count": len(rows), "companies": rows})


# --------------------------------------------------------------------------
# POST /api/upload
# --------------------------------------------------------------------------
def upload(headers, query, body):
    if not body:
        return error_resp(400, "请求体为空，未收到 PDF 字节流。")

    raw_name = (headers.get("x-filename") or query.get("filename")
                or headers.get("x-upload-name"))
    filename = unquote(raw_name) if raw_name else None
    if not filename:
        # 允许用 query 的 company/code/year 拼一个
        company = query.get("company")
        code = query.get("code")
        year = query.get("year")
        if company and code and year:
            filename = "%s_%s_%s.pdf" % (company, code, year)
    if not filename:
        return error_resp(400, "缺少文件名，请在 X-Filename 头（URL 编码）或 "
                               "?filename= 里给出 <公司名>_<代码>_<年份>.pdf。")

    parsed = parse_report_name(filename)
    # 允许 query 覆盖/补齐
    name = query.get("company") or parsed["name"]
    code = query.get("code") or parsed["code"]
    year = query.get("year") or parsed["year"]

    # 是不是 PDF：看魔术字节 %PDF
    is_pdf = body[:5] == b"%PDF-"
    if not is_pdf:
        return error_resp(400, "上传内容不是 PDF（缺少 %PDF 头）。")

    uid = uuid.uuid4().hex[:12]
    config.STATE_UPLOADS.mkdir(parents=True, exist_ok=True)
    stored = config.STATE_UPLOADS / ("%s.pdf" % uid)
    stored.write_bytes(body)
    meta = {
        "upload_id": uid,
        "filename": filename,
        "name": name,
        "code": config.normalize_code(code) if code else None,
        "year": year,
        "size": len(body),
        "stored_path": str(stored),
        "parsed_ok": parsed["ok"],
    }
    (config.STATE_UPLOADS / ("%s.json" % uid)).write_text(
        json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")

    return json_resp({
        "ok": True,
        "upload_id": uid,
        "filename": filename,
        "name": name,
        "code": meta["code"],
        "year": year,
        "size": len(body),
        "parse_ok": parsed["ok"],
        "hint": ("文件名已含公司名/代码/年份，可直接 analyze。"
                 if parsed["ok"] else
                 "文件名未能拆出完整的三段，请在 /api/analyze 参数里补 company/code/year。"),
    })


# --------------------------------------------------------------------------
# POST /api/analyze
# --------------------------------------------------------------------------
def analyze(payload):
    if not isinstance(payload, dict):
        return error_resp(400, "请求体必须是 JSON 对象。")
    mode = payload.get("mode")
    if mode == "existing":
        if not payload.get("code"):
            return error_resp(400, "mode=existing 需要 code（年份可选，默认最新）。")
        params = {
            "mode": "existing",
            "code": payload.get("code"),
            "year": payload.get("year"),
        }
    elif mode == "upload":
        if not payload.get("upload_id"):
            return error_resp(400, "mode=upload 需要 upload_id。")
        params = {
            "mode": "upload",
            "upload_id": payload.get("upload_id"),
            "company": payload.get("company"),
            "code": payload.get("code"),
            "year": payload.get("year"),
        }
    else:
        return error_resp(400, "mode 只能是 'existing' 或 'upload'。")

    job = jobs.submit("analyze", params)
    return json_resp({"ok": True, "job_id": job["id"], "job": job}, status=202)


# --------------------------------------------------------------------------
# GET /api/jobs, GET /api/jobs/<id>, POST /api/jobs/<id>/cancel
# --------------------------------------------------------------------------
def jobs_list():
    rows = jobs.recent(20)
    return json_resp({"ok": True, "count": len(rows), "jobs": rows})


def job_detail(job_id):
    job = jobs.get(job_id)
    if not job:
        return error_resp(404, "任务不存在：%s" % job_id)
    return json_resp({"ok": True, "job": job})


def job_cancel(job_id):
    ok = jobs.cancel(job_id)
    if not ok:
        return error_resp(409, "任务不存在或已结束，无法取消：%s" % job_id)
    return json_resp({"ok": True, "job_id": job_id, "cancelled": True})


# --------------------------------------------------------------------------
# GET /api/unified/<key>
# --------------------------------------------------------------------------
def unified(key):
    """返回统一对象全文。七键就在顶层（data.company / data.valuation ... 直接可用），
    运行日志作为额外的顶层键 run_log 附上（它不属于七键，E 可忽略）。"""
    path = config.unified_path(key)
    if not path.exists():
        return error_resp(404, "统一对象不存在：%s（key=%s）" % (path, key),
                          key=key)
    obj = json.loads(path.read_text(encoding="utf-8"))
    log_path = path.with_name(path.stem + ".run_log.json")
    if log_path.exists():
        try:
            obj["run_log"] = json.loads(log_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass
    return json_resp(obj)


# --------------------------------------------------------------------------
# GET /api/report/<key>?format=md|html|json|csv
# --------------------------------------------------------------------------
_FORMATS = {
    "md": ("memo.md", "text/markdown; charset=utf-8"),
    "html": ("memo.html", "text/html; charset=utf-8"),
    "json": ("memo.json", "application/json; charset=utf-8"),
    "csv": ("memo.csv", "text/csv; charset=utf-8"),
}


def report(key, fmt):
    fmt = (fmt or "html").lower()
    if fmt not in _FORMATS:
        return error_resp(400, "format 只能是 %s 之一。" % "/".join(_FORMATS))
    fname, ctype = _FORMATS[fmt]
    rdir = config.report_dir(key)
    target = rdir / fname

    if not target.exists():
        # 按需生成：需要统一对象与运行日志
        upath = config.unified_path(key)
        if not upath.exists():
            return error_resp(404, "报告与统一对象都不存在：key=%s" % key)
        log_path = upath.with_name(upath.stem + ".run_log.json")
        result = chain_runner.render_report(key, upath, log_path)
        if not target.exists():
            return error_resp(500, "报告生成失败：%s" % result.get("message"),
                              key=key, detail=result)

    return Response(status=200, body=target.read_bytes(), content_type=ctype,
                    headers={"Content-Disposition": 'inline; filename="%s.%s"' % (key, fmt)})
