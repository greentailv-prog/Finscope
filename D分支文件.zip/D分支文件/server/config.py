# -*- coding: utf-8 -*-
"""FinScope D 分支后端：路径与端口的唯一硬编码点。

全项目所有绝对路径都从这里取，其它脚本不许再写盘符字符串。
本文件用 `__file__` 往上推目录，不依赖当前工作目录：

    server/config.py
      parents[0] = server/
      parents[1] = D分支文件/        <- D_ROOT
      parents[2] = AI网页搭建文件/   <- PROJECT_ROOT（A/B/C/D 四家同级）

只用标准库 pathlib。dirs 目前不保证存在，调用方用 ensure_dirs() 或自行 mkdir。
"""
from __future__ import annotations

from pathlib import Path

# --------------------------------------------------------------------------
# 四家根目录
# --------------------------------------------------------------------------
SERVER_DIR = Path(__file__).resolve().parent          # D分支文件/server
D_ROOT = SERVER_DIR.parent                            # D分支文件
PROJECT_ROOT = D_ROOT.parent                          # AI网页搭建文件（A/B/C/D 的父目录）

# --------------------------------------------------------------------------
# D 分支自己：适配层与运行器
# --------------------------------------------------------------------------
AGENT_DIR = D_ROOT / "agent"                          # D分支文件/agent
RUNNER_DIR = AGENT_DIR / "runner"                     # D分支文件/agent/runner
RUN_PIPELINE = AGENT_DIR / "run_pipeline.py"          # 适配层命令行入口
ORCHESTRATOR = AGENT_DIR / "orchestrator.py"          # 三段拼装 + WACC 回填
RUN_CHAIN = RUNNER_DIR / "run_chain.py"               # 手动单跑：整条链
RUN_C_ENGINE = RUNNER_DIR / "run_c_engine.py"         # 转调 C 的 engine.run

# --------------------------------------------------------------------------
# A 分支：年报抽取
# --------------------------------------------------------------------------
A_ROOT = PROJECT_ROOT / "A分支文件" / "A"
A_SRC = A_ROOT / "src"                                # A 的脚本目录
A_DATA = A_ROOT / "data"
A_EXTRACTED = A_DATA / "extracted"                    # A 抽取结果 JSON（吃这一层）
A_ANNUAL_REPORTS = A_DATA / "annual_reports"          # 上传的 PDF 落点（文件名决定公司/代码）
A_PDF_PAGEMAP = A_SRC / "pdf_pagemap.py"              # 第一步：建页码映射
A_INDICATORS = A_SRC / "indicators.py"                # 第二步：抽 17 个科目

# --------------------------------------------------------------------------
# B 分支：指标与风险
# --------------------------------------------------------------------------
B_ROOT = PROJECT_ROOT / "B分支文件" / "Finscope-main"
B_DIAGNOSIS = B_ROOT / "financial-diagnosis"          # 指标引擎
B_RISK_RADAR = B_ROOT / "risk-radar"                  # 风险引擎
B_COMPUTE_RATIOS = B_DIAGNOSIS / "scripts" / "compute_ratios.py"
B_DETECT_RISKS = B_RISK_RADAR / "scripts" / "detect_risks.py"
B_RISK_RULES = B_RISK_RADAR / "risk_rules.json"

# --------------------------------------------------------------------------
# C 分支：估值
# --------------------------------------------------------------------------
C_ROOT = PROJECT_ROOT / "C分支文件" / "Finscope-C-Comps-DCF"
C_VALUATION = C_ROOT / "valuation"                    # 内含 engine/ 与 demo/
C_DEMO_INPUT = C_VALUATION / "demo" / "input_ashare_600519.json"  # 仅 --gap-fill demo 对照用

# --------------------------------------------------------------------------
# D 分支运行态目录（本项目新建）
# --------------------------------------------------------------------------
OUT_DATA = D_ROOT / "out_data"                        # 统一对象与报告
OUT_UNIFIED = OUT_DATA / "unified"                    # 统一对象：<ticker>_<year>.json
OUT_REPORTS = OUT_DATA / "reports"                    # 投研报告：reports/<key>/
MARKET_DATA = D_ROOT / "market_data"                  # 行情与可比公司缓存：<code>.json
MARKET_DATA_README = MARKET_DATA / "README.md"

SERVER_STATIC = SERVER_DIR / "static"                 # E 的静态页
SERVER_STATE = SERVER_DIR / "state"                   # 运行态
STATE_UPLOADS = SERVER_STATE / "uploads"              # 上传的 PDF 暂存
STATE_JOBS = SERVER_STATE / "jobs"                    # 任务进度落盘

# --------------------------------------------------------------------------
# 服务参数
# --------------------------------------------------------------------------
HOST = "127.0.0.1"
PORT = 8790                                           # 与 A 的 8765 错开
API_PREFIX = "/api"

# 运行态目录清单（ensure_dirs 用）
_RUNTIME_DIRS = (
    OUT_UNIFIED, OUT_REPORTS, MARKET_DATA,
    SERVER_STATIC, SERVER_STATE, STATE_UPLOADS, STATE_JOBS,
)


def ensure_dirs():
    """建齐运行态目录（幂等）。服务启动时调一次。"""
    MARKET_DATA.mkdir(parents=True, exist_ok=True)
    for d in _RUNTIME_DIRS:
        d.mkdir(parents=True, exist_ok=True)
    return _RUNTIME_DIRS


# --------------------------------------------------------------------------
# 按代码取文件名的小工具
# --------------------------------------------------------------------------
def market_cache_path(code):
    """行情缓存路径：market_data/<code>.json。code 统一去交易所后缀，取 6 位。"""
    return MARKET_DATA / ("%s.json" % normalize_code(code))


def unified_path(key):
    """统一对象路径：out_data/unified/<key>.json。"""
    return OUT_UNIFIED / ("%s.json" % key)


def report_dir(key):
    """报告目录：out_data/reports/<key>/。"""
    return OUT_REPORTS / key


def normalize_code(code):
    """'600519.SH' / 'sh600519' / '600519' -> '600519'。"""
    if code is None:
        return ""
    s = str(code).strip().upper()
    s = s.replace(".SH", "").replace(".SZ", "").replace(".BJ", "")
    s = s.replace("SH", "").replace("SZ", "").replace("BJ", "")
    return s.strip()


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print("SERVER_DIR   =", SERVER_DIR)
    print("D_ROOT       =", D_ROOT)
    print("PROJECT_ROOT =", PROJECT_ROOT)
    for name in ("AGENT_DIR", "RUNNER_DIR", "A_EXTRACTED", "A_ANNUAL_REPORTS",
                 "B_COMPUTE_RATIOS", "B_DETECT_RISKS", "B_RISK_RULES",
                 "C_VALUATION", "OUT_UNIFIED", "MARKET_DATA", "SERVER_STATE"):
        print("%-18s = %s" % (name, globals()[name]))
    print("PORT         =", PORT)
