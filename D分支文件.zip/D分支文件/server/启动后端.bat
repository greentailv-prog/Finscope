@echo off
chcp 65001 >nul
title FinScope D 后端
cd /d "%~dp0"

echo ============================================
echo   FinScope D 后端服务
echo   接口前缀 http://127.0.0.1:8790/api
echo   静态首页 http://127.0.0.1:8790/
echo   关闭窗口或按 Ctrl+C 停止
echo ============================================
echo.

set PYTHONIOENCODING=utf-8
python app.py

echo.
echo 服务已停止。
pause
