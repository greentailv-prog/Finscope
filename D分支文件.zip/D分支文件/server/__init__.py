# -*- coding: utf-8 -*-
"""FinScope D 分支后端服务包。

刻意保持空：让 `import server.config` 之类轻量可用，
不在这里 import app / routes，避免拉起重依赖。
"""
