# -*- coding: utf-8 -*-
"""A 分支抽取的封装 + D 侧抽取后校验。

两件事：

1. 封装「调 A 的抽取脚本」。上传的 PDF 落进 A/data/annual_reports/<名>_<码>_<年>.pdf
   后，依次 subprocess 跑 A 的 pdf_pagemap.py 与 indicators.py（--pdf 只跑一份）。
   A 的产物自动落到 A/data/extracted/<stem>.json。用 subprocess 而非 import：
   隔离崩溃、复用 A 自己的入口、能逐行读 stdout 出进度。

2. 抽取后校验（**只报告，不改 A 的数据**）。本次已定案：不动 A 的代码，
   只在 D 侧把可疑值暴露出来。两条判据：

     判据①「同文件量级异常」：某货币科目的 |value| 比同一份抽取结果里
       其余货币科目量级的中位数低 MAG_GAP 个数量级以上。典型是 A 取到了
       「占总资产比」那一列（例如总资产 3038 亿，货币资金却抽出 17.01）。

     判据②「value_original / value 比例异常」：A 的记录里 value_original 是年报
       原始数，value 是换算后的元，二者的比值应等于 unit_raw 对应的单位系数
       （元→1，千元→1000，万元→10000）。比例与 unit_raw 不符、或两值符号相反，
       即命中。

   命中写进一条 warning，说明「疑似抽到占比列或取错列，建议回原表核对」。

只用标准库。
"""
from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
from pathlib import Path

# 允许以 `python server/a_extract.py` 直接运行
_HERE = Path(__file__).resolve().parent
_D_ROOT = _HERE.parent
if str(_D_ROOT) not in sys.path:
    sys.path.insert(0, str(_D_ROOT))

from server import config  # noqa: E402

# 判据①的阈值：与同文件量级中位数相差多少个数量级算异常。
# 取 3 而非 1，是因为正常的小科目（如研发费用）本就可能比中位数低约 2 个数量级，
# 用 1 会误报；占比列的值（十几、二十几）通常低 8 个数量级以上，用 3 分离得开。
MAG_GAP = 3.0

# 单位系数：unit_raw 里的字面单位 -> 换算到「元」的倍数。
# 顺序敏感：先匹配「万亿」再「亿」，先「万」再「千」。
_UNIT_STEPS = (("万亿", 1e12), ("亿", 1e8), ("万", 1e4), ("千", 1e3), ("元", 1.0))


def _unit_factor(unit_raw):
    """'千元' -> 1000.0；'万元' -> 10000.0；'元' -> 1.0；认不出返回 None。"""
    s = str(unit_raw or "")
    for token, factor in _UNIT_STEPS:
        if token in s:
            return factor
    return None


def _median(xs):
    if not xs:
        return None
    ys = sorted(xs)
    n = len(ys)
    mid = n // 2
    return ys[mid] if n % 2 else (ys[mid - 1] + ys[mid]) / 2.0


def validate(a_obj):
    """扫一遍 A 的抽取结果，返回命中列表（不改动入参）。

    每条：{metric, label, value, value_original, unit_raw, page, reasons[]}
    """
    fin = (a_obj or {}).get("financials") or {}
    recs = []
    for key, rec in fin.items():
        if not isinstance(rec, dict):
            continue
        if rec.get("status") != "found":
            continue
        v = rec.get("value")
        if not isinstance(v, (int, float)) or isinstance(v, bool) or v == 0:
            continue
        if rec.get("kind") and rec.get("kind") != "currency":
            continue
        recs.append((key, rec, float(v)))

    mags = [math.log10(abs(v)) for _, _, v in recs]
    med = _median(mags)

    findings = []
    for key, rec, v in recs:
        reasons = []
        vmag = math.log10(abs(v))

        # 判据①：与同文件量级中位数差 >= MAG_GAP 个数量级
        if med is not None and (med - vmag) >= MAG_GAP:
            reasons.append(
                "量级异常：|value|=%.6g 比同文件货币科目量级中位数 10^%.2f "
                "低约 %.1f 个数量级，疑似抽到占比列或取错列" % (abs(v), med, med - vmag))

        # 判据②：value_original / value 的比例
        vo = rec.get("value_original")
        if isinstance(vo, (int, float)) and not isinstance(vo, bool) and vo != 0:
            if v * vo < 0:
                reasons.append(
                    "比例异常：value=%.6g 与 value_original=%.6g 符号相反" % (v, vo))
            else:
                ratio = abs(v / vo)
                factor = _unit_factor(rec.get("unit_raw"))
                if factor is not None:
                    if abs(ratio - factor) / factor > 0.02:
                        reasons.append(
                            "比例异常：|value/value_original|=%.6g 与 unit_raw=%s "
                            "应有的系数 %.0f 不符" % (ratio, rec.get("unit_raw"), factor))
                else:
                    exp = round(math.log10(ratio)) if ratio > 0 else 0
                    if ratio <= 0 or abs(ratio - 10 ** exp) / (10 ** exp) > 0.02:
                        reasons.append(
                            "比例异常：|value/value_original|=%.6g 不是数量级系数" % ratio)

        if reasons:
            findings.append({
                "metric": key,
                "label": rec.get("label"),
                "value": v,
                "value_original": rec.get("value_original"),
                "unit_raw": rec.get("unit_raw"),
                "page": rec.get("page"),
                "reasons": reasons,
            })
    return findings


def validate_warnings(a_obj):
    """把命中折成一条 warning（列表形式，0 或 1 条）。不含命中则返回 []。"""
    findings = validate(a_obj)
    if not findings:
        return []
    names = "、".join(
        "%s(%s)" % (f["label"] or f["metric"], f["metric"]) for f in findings)
    return ["[抽取后校验] %d 个科目疑似抽到占比列或取错列：%s，"
            "建议回原表核对。不改 A 的数据，仅报告。" % (len(findings), names)]


# --------------------------------------------------------------------------
# 抽取封装
# --------------------------------------------------------------------------
def _run_step(script, pdf, log):
    """跑 A 的一个脚本（--pdf 只处理一份）。返回 (returncode, stdout, stderr)。"""
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"     # 统一子进程编码，避免 GBK 解码失败
    cmd = [sys.executable, str(script), "--pdf", str(pdf)]
    if log:
        log("$ %s" % " ".join('"%s"' % c if " " in c else c for c in cmd))
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", env=env)
    if log and (proc.stdout or "").strip():
        log((proc.stdout or "").strip())
    if log and (proc.stderr or "").strip():
        log("[stderr] " + (proc.stderr or "").strip())
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def extract(pdf_path, log=print):
    """跑 A 的 pdf_pagemap.py -> indicators.py，返回抽取结果 JSON 的路径。

    A 的产物固定落在 A/data/extracted/<pdf stem>.json，所以上传的 PDF
    文件名必须是 <公司名>_<代码>_<年份>.pdf（A 靠下划线切分取公司名与代码）。
    """
    pdf = Path(pdf_path)
    if not pdf.exists():
        raise FileNotFoundError("PDF 不存在: %s" % pdf)

    steps = (("pdf_pagemap", config.A_PDF_PAGEMAP),
             ("indicators", config.A_INDICATORS))
    for name, script in steps:
        if log:
            log("=== A 抽取：%s ===" % name)
        code, out, err = _run_step(script, pdf, log)
        if code != 0:
            raise RuntimeError(
                "A 的 %s 失败（returncode=%d）\n%s" % (name, code, err.strip()))

    out_path = config.A_EXTRACTED / ("%s.json" % pdf.stem)
    if not out_path.exists():
        raise RuntimeError("A 抽取完成但未找到产物：%s" % out_path)
    return out_path


def extract_and_validate(pdf_path, log=print):
    """抽取 + 校验。返回 (抽取结果路径, 命中列表)。"""
    out_path = extract(pdf_path, log=log)
    with open(out_path, "r", encoding="utf-8") as f:
        a_obj = json.load(f)
    findings = validate(a_obj)
    if log:
        for w in validate_warnings(a_obj):
            log("[warning] " + w)
    return out_path, findings


def _print_findings(findings):
    if not findings:
        print("校验通过：未发现疑似占比列/取错列。")
        return
    print("校验命中 %d 个科目：" % len(findings))
    for f in findings:
        print("  - %s(%s) value=%s value_original=%s unit_raw=%s page=%s"
              % (f["label"] or f["metric"], f["metric"], f["value"],
                 f["value_original"], f["unit_raw"], f["page"]))
        for r in f["reasons"]:
            print("      %s" % r)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="A 抽取封装 + 抽取后校验")
    ap.add_argument("--pdf", help="跑抽取：上传/本地的年报 PDF")
    ap.add_argument("--validate", help="只校验：一份已有的 A 抽取结果 JSON")
    args = ap.parse_args()

    if args.validate:
        with open(args.validate, "r", encoding="utf-8") as f:
            a_obj = json.load(f)
        _print_findings(validate(a_obj))
        return 0

    if args.pdf:
        out_path, findings = extract_and_validate(args.pdf)
        print("\n抽取结果 -> %s" % out_path)
        _print_findings(findings)
        return 0

    ap.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
