# -*- coding: utf-8 -*-
"""公共链：A 抽取结果 -> 七键统一对象。

两条路径（上传 PDF 的路径 A、选已有公司的路径 B）都汇到这一个函数。
步骤（只调用不改 A/B/C 任何代码）：

  1. to_b_input.build(a_obj)                    -> B 的输入
  2. market_data.resolve(code)                  -> 行情/可比公司
     to_c_input.build(a_obj, market)            -> C 的输入
  3. subprocess 跑 B 的 compute_ratios.py        （b_ratios）
  4. subprocess 跑 B 的 detect_risks.py          （b_risks）
  5. subprocess 跑 agent/runner/run_c_engine.py  （c_engine，内部 import C 的 engine.run）
  6. import 调 agent/orchestrator.run(...)       （adapt，含 WACC 回填 + 第二趟重判）
  7. 落 out_data/unified/<key>.json + <key>.run_log.json
  8. 可选：subprocess 调 report-skill/scripts/render_memo.py 出四种报告

本模块的 `run_chain` 是可 import 的函数，agent/runner/run_chain.py 与
server/jobs.py 都调它，不再各写一份。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# 让 `from server import config` 与 `import to_b_input`（runner 目录）都找得到
_THIS = Path(__file__).resolve()          # .../D分支文件/server/chain_runner.py
_D_ROOT = _THIS.parent.parent             # .../D分支文件
_AGENT = _D_ROOT / "agent"
_RUNNER = _AGENT / "runner"
for _p in (str(_D_ROOT), str(_AGENT), str(_RUNNER)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from server import config, market_data, catalog  # noqa: E402

# 报告 Skill 的渲染入口
REPORT_SKILL = _D_ROOT / "report-skill"
RENDER_MEMO = REPORT_SKILL / "scripts" / "render_memo.py"

# 默认工作目录（CLI 单跑时中间产物落这里）
DEFAULT_WORK_DIR = _RUNNER


class ChainError(RuntimeError):
    """链路中某一步失败。"""


# --------------------------------------------------------------------------
# 进度上报接口
# --------------------------------------------------------------------------
class ConsoleReporter:
    """命令行用的极简上报：直接打印，subprocess 同步跑。"""

    def step(self, name):
        print("\n=== %s ===" % name)

    def log(self, msg):
        if msg:
            print(msg)

    def cancelled(self):
        return False

    def run(self, cmd):
        cmd = [str(c) for c in cmd]
        print("$ %s" % " ".join('"%s"' % c if " " in c else c for c in cmd))
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", env=env)
        if (proc.stdout or "").strip():
            print(proc.stdout.strip())
        if (proc.stderr or "").strip():
            print("[stderr] " + proc.stderr.strip(), file=sys.stderr)
        return proc.returncode


def _dump(path, obj, indent=2):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# --------------------------------------------------------------------------
# 报告生成（可选，失败不致命）
# --------------------------------------------------------------------------
def render_report(key, unified_path, run_log_path, out_root=None, reporter=None):
    """调 report-skill 的渲染器出四种报告。返回 dict（含 ok / 说明）。

    渲染器带数字白名单校验，越界会拒绝出稿（非零退出）；这里把它当可选步骤，
    失败只回报，不抛异常。
    """
    out_root = out_root or config.OUT_REPORTS
    cmd = [sys.executable, str(RENDER_MEMO),
           "--unified", str(unified_path),
           "--run-log", str(run_log_path),
           "--out-root", str(out_root),
           "--key", key]
    if reporter is not None:
        reporter.log("$ " + " ".join(cmd))
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", env=env)
    ok = proc.returncode == 0
    msg = (proc.stdout or "").strip() or (proc.stderr or "").strip()
    if reporter is not None:
        reporter.log(("[报告] " if ok else "[报告失败] ") + msg)
    return {
        "ok": ok,
        "returncode": proc.returncode,
        "message": msg,
        "dir": str(config.report_dir(key)),
    }


# --------------------------------------------------------------------------
# 主链路
# --------------------------------------------------------------------------
def run_chain(a_obj, *, code=None, online=False, gap_fill="none", work_dir=None,
              reporter=None, out_path=None, log_path=None, key=None,
              want_report=False, report_out_root=None, extra_warnings=None,
              flagged_metrics=None):
    """跑公共链，返回结果 dict。

    参数
      a_obj        A 的抽取结果（对象）
      code         A 的股票代码；缺省取 a_obj.company.ticker
      reporter     进度上报对象（step / log / cancelled / run）；缺省用 ConsoleReporter
      work_dir     中间产物目录；缺省 runner/；传 None 则用临时目录
      out_path     统一对象输出路径；缺省 out_data/unified/<key>.json
      log_path     运行日志输出路径；缺省 <out_path 去扩展>.run_log.json
      key          统一对象的键；缺省由 company.ticker+report_period 推
      want_report  是否顺手出报告（默认否）
    返回
      {unified, run_log, key, unified_path, run_log_path, report, market_source,
       summary}
    """
    reporter = reporter or ConsoleReporter()
    a_obj = a_obj or {}
    code = code or (a_obj.get("company") or {}).get("ticker")

    # 键：优先显式传入，其次由 A 对象推（与 catalog 同一套规则）
    key = key or catalog.key_of_a_obj(a_obj)
    if not key:
        raise ChainError("无法确定统一对象的键：A 结果缺 company.ticker / report_period。")

    if work_dir is None:
        work_dir = Path(tempfile.mkdtemp(prefix="finscope_chain_"))
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    out_path = Path(out_path) if out_path else config.unified_path(key)
    if log_path is None:
        log_path = out_path.with_name(out_path.stem + ".run_log.json")
    log_path = Path(log_path)

    suffix = "" if gap_fill == "none" else "_" + gap_fill

    # 运行日志（与 orchestrator 的 log 合并后一起落盘）
    chain_log = {"steps": [], "notes": [], "warnings": [], "gap_fill": gap_fill,
                 "key": key, "a_input": None}
    # 上游（如抽取后校验）来的警告，先并进来，随 run_log 一起落盘
    for w in (extra_warnings or []):
        chain_log["warnings"].append(w)

    # ---- 0. 行情与可比公司：三档优先级 ----
    market, market_source, market_warns = market_data.resolve(code, online=online)
    if market is not None:
        market["_source"] = market_source
    chain_log["market_source"] = market_source
    chain_log["market_code"] = config.normalize_code(code)
    for w in market_warns:
        chain_log["warnings"].append(w)
    chain_log["notes"].append("行情来源：%s（code=%s）"
                              % (market_source, config.normalize_code(code)))
    reporter.log("[行情] 来源=%s code=%s" % (market_source, config.normalize_code(code)))

    # gap-fill demo 的对照来源（仅调试用）
    gap_source = _load(config.C_DEMO_INPUT) if gap_fill == "demo" else None

    # ---- 1. 转换器：A -> B 输入、A + 行情 -> C 输入 ----
    import to_b_input
    import to_c_input

    b_input, b_report = to_b_input.build(a_obj)
    b_input_path = work_dir / ("b_input%s.json" % suffix)
    _dump(b_input_path, b_input)
    chain_log["notes"].append("A -> B 输入：期间 %s，给 %d 个科目，缺 %d 个。"
                              % (b_report["periods"], b_report["given_count"],
                                 b_report["missing_count"]))
    chain_log["b_input_given"] = b_report["given_fields"]
    chain_log["b_input_missing"] = b_report["missing_fields"]

    c_input, c_sources, c_years, c_warnings = to_c_input.build(
        a_obj, market, gap_fill, gap_source)
    c_input_path = work_dir / ("c_input%s.json" % suffix)
    _dump(c_input_path, c_input)
    chain_log["c_input_field_sources"] = c_sources
    chain_log["c_input_years"] = c_years
    chain_log["valuation_warnings"] = c_warnings
    for w in c_warnings:
        chain_log["warnings"].append(w)
    reporter.log("[转换] A->B 给 %d 科目；A->C 年份 %s"
                 % (b_report["given_count"], c_years))

    py = sys.executable

    def _run(cmd, step_name, label):
        """跑一步：报步骤、跑子进程、非零退出抛错。"""
        if reporter.cancelled():
            raise ChainError("任务已取消")
        reporter.step(step_name)
        reporter.log("[%s] %s" % (step_name, label))
        rc = reporter.run(cmd)
        if rc != 0:
            raise ChainError("步骤失败：%s（returncode=%s）" % (step_name, rc))
        return rc

    # ---- 2. B 指标（第一趟，wacc 为空） ----
    b_ratios_path = work_dir / ("b_ratios%s.json" % suffix)
    _run([py, config.B_COMPUTE_RATIOS, "-i", b_input_path, "-o", b_ratios_path, "--pretty"],
         "b_ratios", "B 指标 compute_ratios")

    # ---- 3. B 风险（第一趟，WACC 相关规则 not_evaluable） ----
    b_risks_path = work_dir / ("b_risks%s.json" % suffix)
    _run([py, config.B_DETECT_RISKS, "--ratios", b_ratios_path, "--rules", config.B_RISK_RULES,
          "--output", b_risks_path, "--pretty"],
         "b_risks", "B 风险 detect_risks")

    # ---- 4. C 估值（产出 WACC） ----
    c_out_path = work_dir / ("c_output%s.json" % suffix)
    _run([py, config.RUN_C_ENGINE, "--c-dir", config.C_VALUATION,
          "--input", c_input_path, "--out", c_out_path],
         "c_engine", "C 估值 engine.run")

    # 把 D 侧的行情缺口 warning 并进 C 输出，随 valuation.warnings 进统一对象
    if c_warnings:
        c_out = _load(c_out_path)
        c_out["warnings"] = list(c_warnings) + list(c_out.get("warnings") or [])
        _dump(c_out_path, c_out, indent=1)

    # ---- 5. D 适配层（含 WACC 回填 + 第二趟重判），直接 import 调 ----
    reporter.step("adapt")
    reporter.log("[adapt] D 适配层 orchestrator.run（WACC 回填 + 第二趟重判）")
    if reporter.cancelled():
        raise ChainError("任务已取消")

    from orchestrator import run as orchestrate  # agent/ 在 sys.path 上

    unified, run_log = orchestrate(a_obj, _load(b_ratios_path), _load(b_risks_path),
                                   _load(c_out_path))

    # 抽取后校验命中的科目（只处理「量级异常」这一判据）：在统一对象里标 not_evaluable，
    # 让它带着「待核验」的状态流到报告，而不是悄悄当成正常值。不改 A 的数据。
    if flagged_metrics:
        marked = []
        fin = unified.get("financials") or {}
        for m in flagged_metrics:
            rec = fin.get(m)
            if isinstance(rec, dict):
                rec["status"] = "not_evaluable"
                rec["_d_extract_check"] = "抽取后校验：疑似抽到占比列或取错列，待核验"
                marked.append(m)
        if marked:
            run_log.setdefault("warnings", []).append(
                "[抽取后校验] 已在统一对象内把 %s 标为 not_evaluable（仅报告，未改 A 数据）。"
                % "、".join(marked))
            reporter.log("[抽取后校验] 已标 not_evaluable：%s" % "、".join(marked))

    # 合并两层日志（链路层 + 编排层）
    merged = dict(run_log)
    merged.setdefault("steps", [])
    merged["steps"] = list(chain_log["steps"]) + list(run_log.get("steps") or [])
    merged.setdefault("notes", []).extend(chain_log["notes"])
    merged.setdefault("warnings", []).extend(chain_log["warnings"])
    merged["market_source"] = market_source
    merged["market_code"] = config.normalize_code(code)
    merged["chain"] = chain_log
    merged["key"] = key
    merged["a_input"] = chain_log.get("a_input")

    # ---- 6. 落盘：统一对象 + 运行日志 ----
    _dump(out_path, unified, indent=1)
    _dump(log_path, merged, indent=1)
    reporter.log("[落盘] 统一对象 -> %s" % out_path)

    # ---- 7. 可选：出报告 ----
    report = None
    if want_report:
        try:
            report = render_report(key, out_path, log_path,
                                   out_root=report_out_root, reporter=reporter)
        except Exception as exc:  # noqa: BLE001 报告失败不拖垮整链
            report = {"ok": False, "returncode": None,
                      "message": "报告生成异常：%s" % exc,
                      "dir": str(config.report_dir(key))}

    summary = _summarize(unified, market_source, merged)
    summary["report"] = report
    return {
        "unified": unified,
        "run_log": merged,
        "key": key,
        "unified_path": str(out_path),
        "run_log_path": str(log_path),
        "report": report,
        "market_source": market_source,
        "summary": summary,
    }


def _summarize(unified, market_source, run_log):
    val = unified.get("valuation") or {}
    dcf = val.get("dcf") or {}
    comps = val.get("comps") or {}
    blended = val.get("blended") or {}
    return {
        "company": (unified.get("company") or {}).get("name"),
        "ticker": (unified.get("company") or {}).get("ticker"),
        "financials": len(unified.get("financials") or {}),
        "ratios": sum(len(v) for v in (unified.get("ratios") or {}).values()),
        "risks": len(unified.get("risks") or []),
        "rules_evaluated": len(unified.get("rules_evaluated") or []),
        "sources": len(unified.get("sources") or []),
        "b_passes": run_log.get("b_passes"),
        "wacc": (dcf.get("inputs") or {}).get("wacc"),
        "dcf_range": [(dcf.get("valuation_range") or {}).get("low"),
                      (dcf.get("valuation_range") or {}).get("high")],
        "comps_peers_used": len(comps.get("peer_companies") or []),
        "blended_per_share": blended.get("blended_per_share"),
        "verdict": blended.get("verdict"),
        "market_source": market_source,
        "valuation_warnings": val.get("warnings") or [],
    }


if __name__ == "__main__":
    # 命令行小自检：对 A 已抽取的茅台跑一遍公共链
    import argparse
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="公共链自检")
    ap.add_argument("--a", default=str(config.A_EXTRACTED / "贵州茅台_600519_2025.json"))
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()
    res = run_chain(_load(args.a), want_report=args.report)
    print("\n" + "=" * 50)
    for k, v in res["summary"].items():
        print("  %-22s %s" % (k, v))
    print("统一对象 -> %s" % res["unified_path"])
