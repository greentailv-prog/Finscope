# FinScope 后端接口说明

给 E：照着这个接就行，不用去读后端的代码。

---

## 一、先把服务跑起来

双击 `server/启动后端.bat`，浏览器打开 `http://127.0.0.1:8790/`。

命令行方式：`python server/app.py`。

服务只绑本机 `127.0.0.1`，端口 **8790**（A 的问答页是 8765，不冲突）。

跨域已经开好了，你的页面放在哪里都能调这个服务，不用管 CORS。

---

## 二、接口

### 通用约定

- 全部以 `/api` 打头，返回 JSON，UTF-8
- 成功长这样 `{"ok": true, ...}`，失败长这样 `{"ok": false, "error": "中文错误说明"}`
- 失败时的 HTTP 状态码：`400` 参数不对、`404` 找不到、`409` 状态冲突、`500` 内部错误
- `key` 是统一对象的编号，格式是 `<证券代码>_<年份>`，例如 `600519.SH_2025`、`000333.SZ_2025`
- 所有接口都支持 `OPTIONS` 预检，会返回 204

---

### 1. 健康检查

```
GET /api/health
```

返回服务状态和各家模块是否就绪。

```json
{
  "ok": true,
  "service": "FinScope D 后端",
  "port": 8790,
  "company_count": 9,
  "unified_count": 0,
  "market_cache_count": 1,
  "steps": { "a_pdf_pagemap": true, "b_compute_ratios": true, "...": true },
  "ready": true,
  "jobs": { "done": 3 }
}
```

`company_count` 是可选公司数，`unified_count` 是已经分析好的公司数，`market_cache_count` 是有行情数据的公司数。

---

### 2. 可选公司列表

```
GET /api/companies
```

```json
{
  "ok": true,
  "count": 9,
  "companies": [
    {
      "stem": "贵州茅台_600519_2025",
      "name": "贵州茅台酒股份有限公司",
      "code": "600519",
      "ticker": "600519.SH",
      "year": "2025",
      "key": "600519.SH_2025",
      "unified_exists": true
    }
  ]
}
```

页面 1 的下拉框读这个接口。

`unified_exists` 为真说明这家已经分析过了，可以直接读统一对象，不用再跑一遍。

每条里另有两个路径字段 `extracted_path` 和 `unified_path`，还有一个 `error`（解析失败时才有值），你用不上，忽略即可。

---

### 3. 上传年报 PDF

```
POST /api/upload
Content-Type: application/octet-stream
X-Filename: <URL 编码的 <公司名>_<代码>_<年份>.pdf>
```

请求体是 PDF 的原始字节，不是表单。

**文件名必须带 `X-Filename` 头，而且必须 URL 编码。** 浏览器里这样写：

```js
await fetch("/api/upload", {
  method: "POST",
  headers: { "X-Filename": encodeURIComponent(file.name) },
  body: file,           // 直接传 File 对象
});
```

文件名格式要能拆成 `<公司名>_<代码>_<年份>.pdf`，例如 `美的集团_000333_2025_年报.pdf`。末尾多一段没关系。

返回：

```json
{
  "ok": true,
  "upload_id": "a1b2c3d4e5f6",
  "filename": "美的集团_000333_2025_年报.pdf",
  "name": "美的集团",
  "code": "000333",
  "year": "2025",
  "size": 6187000,
  "parse_ok": true
}
```

拿到 `upload_id` 后去调下面的分析接口。`parse_ok` 为假说明文件名没拆干净，调分析接口时要补 `company`、`code`、`year`。

---

### 4. 提交分析任务

```
POST /api/analyze
Content-Type: application/json
```

两种模式二选一。

**选已有公司**（快，几秒）：

```json
{ "mode": "existing", "code": "600519", "year": "2025" }
```

**上传新文件**（慢，几分钟）：

```json
{ "mode": "upload", "upload_id": "a1b2c3d4e5f6" }
```

返回 `202`：

```json
{ "ok": true, "job_id": "7f3a9c21b8e4", "job": { "status": "queued", "percent": 0 } }
```

同一个公司重复提交会返回同一个 `job_id`，不会重复跑。

---

### 5. 查任务进度

```
GET /api/jobs/<job_id>
```

**页面靠轮询这个接口出进度条。** 建议一秒一次。

```json
{
  "ok": true,
  "job": {
    "id": "7f3a9c21b8e4",
    "status": "running",
    "step": "indicators",
    "step_label": "抽取财务指标",
    "percent": 52,
    "log": ["[pagemap] 完成", "[indicators] 开始"],
    "result": null,
    "error": null
  }
}
```

`status` 的取值：

| 值 | 含义 |
| --- | --- |
| `queued` | 排队中 |
| `running` | 执行中，看 `percent` 和 `step_label` |
| `done` | 完成，`result` 里有产物路径 |
| `error` | 出错，`error` 里是说明 |
| `cancelled` | 已取消 |
| `interrupted` | 服务重启导致中断 |

完成后 `result.key` 就是统一对象的 key，拿去读第 8 个接口。

六个步骤的 `step_label` 依次是：建立页码映射、抽取财务指标、B 指标、B 风险、C 估值、D 适配与落盘。

---

### 6. 最近的任务

```
GET /api/jobs
```

返回最近 20 个任务的快照，结构同上。页面做「历史记录」可以用。

---

### 7. 取消任务

```
POST /api/jobs/<job_id>/cancel
```

成功返回 `{"ok": true, "job_id": "...", "cancelled": true}`。任务已经结束会返回 409。

---

### 8. 读统一对象

```
GET /api/unified/<key>
```

**这是页面 2 到 5 的主要数据来源。**

**七个键直接在顶层**，不用再往里钻：

```json
{
  "company":          { "name": "...", "ticker": "...", "industry": "...", "report_period": "2025", "currency": "CNY", "..." : "..." },
  "financials":       { "revenue": { "value": 168838102514.79, "unit": "元", "period": "2025", "page": 82 }, "...": {} },
  "ratios":           { "growth": {}, "profitability": {}, "solvency": {}, "efficiency": {}, "cashflow_quality": {}, "banking": {} },
  "risks":            [ { "risk_id": "C01", "risk_name": "...", "severity": "high", "..." : "..." } ],
  "rules_evaluated":  [ { "status": "not_evaluable", "..." : "..." } ],
  "valuation":        { "comps": {}, "dcf": {}, "blended": {}, "scenarios": {}, "sotp": {}, "..." : {} },
  "sources":          [ { "page": 82, "..." : "..." } ],

  "run_log": { }
}
```

所以用的时候直接 `data.company.name`、`data.valuation.blended.blended_per_share`。

`run_log` 是额外附上的运行日志，**不属于七个键**，不用它也行。

字段的完整说明看 `output/SCHEMA.md`。统一对象不存在会返回 404。

---

### 9. 读投研报告

```
GET /api/report/<key>?format=html
```

`format` 取值 `md`、`html`、`json`、`csv`，默认 `html`。

**注意这个接口直接返回文件本身，不是 JSON。** 所以：

```js
document.querySelector("#memo").src = "/api/report/600519.SH_2025?format=html";
```

用 iframe 嵌最省事。HTML 那份自带了打印样式，浏览器直接打印就能存成 PDF。

报告还没生成的话，这个接口会自动生成一次再返回。

---

### 10. 静态页面

```
GET /
```

托管 `server/static/` 目录。你把页面文件放进去，双击启动脚本就能看到。

---

## 三、六个页面各读什么

| 页面 | 读哪个接口 | 读哪些字段 |
| --- | --- | --- |
| 1 上传 | `GET /api/companies`、`POST /api/upload`、`POST /api/analyze`、`GET /api/jobs/<id>` | 公司列表、上传返回的 `upload_id`、任务进度 |
| 2 公司概览 | `GET /api/unified/<key>` | `company.*`、`financials.revenue`、`financials.net_income_parent`、`ratios.profitability.roe_weighted` |
| 3 财务诊断 | 同上 | `ratios` 下面五类，每类里的指标都带 `value` / `prev` / `delta` |
| 4 风险雷达 | 同上 | `risks[]`，每条带 `severity_tag`、`risk_name`、`involved_values`（含 `page`，可以跳页码）、`evidence_chain`（六层证据，展开用） |
| 5 估值 | 同上 | `valuation.comps`（区间）、`valuation.dcf`（区间和敏感性）、`valuation.blended`（融合每股价值和结论）、`valuation.scenarios` |
| 6 投研报告 | `GET /api/report/<key>?format=html` | 直接 iframe 嵌 |

页面 4 的「点击展开看 数据 → 计算 → 年报页码 → AI 解释」，数据全在 `risks[i].evidence_chain` 里，那是个六层数组，每层有 `step` 字段标明是哪一层。

页面 5 最顶上那个大字用 `valuation.blended.blended_per_share` 和 `verdict`（值是「显著低估 / 低估 / 大致合理 / 高估 / 显著高估」之一）。

---

## 四、几个必须知道的坑

**一、很多字段是 null。** A 那边有约 25 个科目没抽，导致 B 有 30 个指标算不出、21 条风险规则无法评估。这些在数据里是 `null`，`status` 字段会写 `not_evaluable`。**每个要显示的地方都要做空值兜底**，别直接渲染成 `null` 或 `undefined`。

**二、估值大多只有 DCF。** Comps 需要股价和可比公司，那些数据要人工填到 `market_data/<代码>.json` 才有。现在只有茅台有。别的公司 `valuation.comps` 是空的，`blended` 只有 DCF 一块。**页面 5 要做空态**，别画一个空图。

**三、DCF 的区间上限不要画。** 茅台的 DCF 区间是 1,267 到 24,654，上限是模型放大出来的（折现率和永续增长太接近），不是真结论。画图时截掉上限，或者只画融合区间。

**四、上传接口的文件名必须 URL 编码**，原因见第 3 个接口。中文直接塞进 HTTP 头会乱码。

**五、报告接口返回文件不是 JSON**，别去 `await res.json()`。

**六、公司的 key 格式**是 `<代码带交易所后缀>_<年份>`，例如 `600519.SH_2025`。用 `/api/companies` 返回的 `key` 字段最保险，不要自己拼。

---

## 五、一个能跑的最小例子

```html
<!doctype html>
<meta charset="utf-8">
<h3>上传年报并分析</h3>
<input type="file" id="f" accept=".pdf">
<button id="go">开始</button>
<pre id="out"></pre>

<script>
const out = document.getElementById("out");
const log = (m) => out.textContent += m + "\n";

document.getElementById("go").onclick = async () => {
  const file = document.getElementById("f").files[0];
  if (!file) return;

  // 1. 上传
  const up = await (await fetch("/api/upload", {
    method: "POST",
    headers: { "X-Filename": encodeURIComponent(file.name) },
    body: file,
  })).json();
  log("上传完成：" + up.upload_id);

  // 2. 提交分析
  const an = await (await fetch("/api/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mode: "upload", upload_id: up.upload_id }),
  })).json();
  const jobId = an.job_id;
  log("任务已提交：" + jobId);

  // 3. 轮询进度
  let key = null;
  while (true) {
    await new Promise((r) => setTimeout(r, 1000));
    const { job } = await (await fetch("/api/jobs/" + jobId)).json();
    log(job.percent + "%  " + (job.step_label || job.status));
    if (job.status === "done") { key = job.result.key; break; }
    if (job.status === "error" || job.status === "cancelled") {
      log("失败：" + job.error); return;
    }
  }

  // 4. 读统一对象
  const data = await (await fetch("/api/unified/" + key)).json();
  log("公司：" + data.company.name);
  log("营业收入：" + data.financials.revenue.value);
  log("风险条数：" + data.risks.length);
};
</script>
```

另有一个写好版本的页面在 `server/static/index.html`，可以直接打开看效果。

---

有任何对不上的地方直接问 D。接口有变动 D 会更新这份文档。
