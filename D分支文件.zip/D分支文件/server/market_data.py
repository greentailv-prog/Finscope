# -*- coding: utf-8 -*-
"""行情与可比公司缓存：三档优先级。

A 的抽取只出财务科目，行情（股价 / 股本 / 市值 / beta）与可比公司（peers）
它抽不出来。这层负责把这块补齐，优先级：

  1. 本地缓存   market_data/<code>.json   —— 主路径，手工维护，可核对
  2. 联网兜底   akshare                    —— 默认关闭，只有显式 online=True 才走；整段 try/except，失败回落
  3. 都没有     market=None                —— 交给 to_c_input 留空并记 warning，绝不套用别家公司

联网只补行情标量（price / shares / market_cap），拿不到 peers 与 beta：
peers 要人工挑可比公司，beta 要指数回归，这两项不自动生成。
所以联网也凑不齐 Comps，缺 peers 时 C 本来就不出相对估值。

只用标准库（akshare 是可选、延迟 import）。
"""
from __future__ import annotations

import json
import os

try:                       # 作为包导入：from server import market_data
    from . import config
except ImportError:        # 直接运行：python server/market_data.py
    import config

# 缓存里允许被 to_c_input 直接采信的字段
_SCALAR_FIELDS = ("price", "shares_outstanding", "market_cap", "beta")
_PASSTHRU_FIELDS = ("peers", "assumptions", "relative_multiples", "sources",
                    "price_date", "market", "currency", "sector", "industry",
                    "name", "ticker")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_cached(code):
    """读 market_data/<code>.json。没有返回 None。"""
    path = config.market_cache_path(code)
    if not path.exists():
        return None
    obj = _read_json(path)
    obj.setdefault("code", config.normalize_code(code))
    obj["_source"] = "cache:%s" % path.name
    return obj


def fetch_online(code):
    """联动 akshare 取行情标量。默认不走；任何异常都吞掉返回 None。

    成功返回的 dict 里 peers 为空列表、beta 为 None —— 这两项不自动生成，
    缺 peers 时 C 的 Comps 依旧不出，属预期。
    """
    try:
        import akshare as ak  # 延迟 import：没装也不影响本模块
    except Exception:
        return None
    try:
        norm = config.normalize_code(code)
        info = ak.stock_individual_info_em(symbol=norm)
        # info 是 DataFrame，列 [item, value]，转成 dict
        kv = {str(r["item"]): r["value"] for _, r in info.iterrows()}

        def _num(*keys):
            for k in keys:
                if k in kv:
                    try:
                        return float(kv[k])
                    except (TypeError, ValueError):
                        return None
            return None

        out = {
            "code": norm,
            "name": kv.get("股票简称"),
            "shares_outstanding": _num("总股本"),
            "market_cap": _num("总市值"),
            "industry": kv.get("行业"),
        }
        out["price"] = None
        out["beta"] = None
        out["peers"] = []
        out["assumptions"] = {}
        out["relative_multiples"] = ["pe", "ps", "pb"]
        out["sources"] = [{"name": "akshare·东方财富", "as_of": None,
                           "official": False, "purpose": "行情（联网兜底）"}]
        # 至少要有市值或股价，否则视为失败
        if not (out.get("market_cap") or out.get("price")):
            return None
        return out
    except Exception:
        return None


def resolve(code, online=False):
    """三档优先级入口。返回 (market, source, warnings)。

    market 为 None 表示缓存与联网都没有，调用方应留空并记 warning。
    """
    warnings = []
    if not code:
        return None, "none", ["缺股票代码，无法取行情缓存。"]

    cached = load_cached(code)
    if cached is not None:
        return cached, cached.get("_source", "cache"), warnings

    if online:
        fetched = fetch_online(code)
        if fetched is not None:
            return fetched, "akshare(online)", warnings
        warnings.append("联网兜底失败或未取到行情（akshare），回落为空。")

    warnings.append("market_data/%s.json 缓存不存在。" % config.normalize_code(code))
    return None, "none", warnings


def merge_missing(market, code, online=False):
    """缓存存在但缺字段时，可选联网补缺（默认不用）。返回合并后的 market。

    保守：只在缓存确实缺 price / shares_outstanding / market_cap 时联网，
    且联网值只补空位，不覆盖缓存里已有的值。
    """
    if market is None or not online:
        return market
    missing = [k for k in ("price", "shares_outstanding", "market_cap")
               if not market.get(k)]
    if not missing:
        return market
    fetched = fetch_online(code)
    if not fetched:
        return market
    merged = dict(market)
    for k in missing:
        if fetched.get(k):
            merged[k] = fetched[k]
            merged.setdefault("_online_filled", []).append(k)
    return merged


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    for c in ("600519", "000333"):
        m, src, w = resolve(c)
        print("%s -> source=%s warnings=%s" % (c, src, w))
        if m:
            print("   price=%s shares=%s cap=%s beta=%s peers=%d"
                  % (m.get("price"), m.get("shares_outstanding"),
                     m.get("market_cap"), m.get("beta"), len(m.get("peers") or [])))
