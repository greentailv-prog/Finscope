# -*- coding: utf-8 -*-
"""用三家的真实样例做测试。只读样例文件，不跑三家的代码。

运行：
    python -m unittest discover -s tests -v
或：
    python tests/test_adapters.py
"""

import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
AGENT = os.path.dirname(HERE)
sys.path.insert(0, AGENT)

from adapters import adapt_a, adapt_b, adapt_c  # noqa: E402
from adapters.from_b import RATIO_RENAME  # noqa: E402
from orchestrator import run  # noqa: E402

A_PATH = r"D:/浏览器下载/AI网页搭建文件/A分支文件/A/data/extracted/贵州茅台_600519_2025.json"
A_PATH2 = r"D:/浏览器下载/AI网页搭建文件/A分支文件/A/data/extracted/美的集团_000333_2025.json"
B_RATIOS = r"D:/浏览器下载/AI网页搭建文件/B分支文件/Finscope-main/financial-diagnosis/demo/output_ratios.json"
B_RISKS = r"D:/浏览器下载/AI网页搭建文件/B分支文件/Finscope-main/risk-radar/demo/output_risks.json"
C_PATH = r"D:/浏览器下载/AI网页搭建文件/C分支文件/Finscope-C-Comps-DCF/valuation/demo/output_sample.json"
SCHEMA_PATH = r"D:/浏览器下载/AI网页搭建文件/D分支文件/output/Schema.json"


def load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


class TestFromA(unittest.TestCase):
    def setUp(self):
        self.a = load(A_PATH)
        self.out = adapt_a(self.a)

    def test_单独跑不报错且三段齐全(self):
        self.assertEqual(set(self.out.keys()), {"company", "financials", "sources"})
        self.assertTrue(self.out["financials"])
        self.assertTrue(self.out["sources"])

    def test_六项改名与十一个同名(self):
        fin = self.out["financials"]
        # 6 项改名
        for new_key in ("net_income_parent", "net_income_excl_nonrecurring",
                        "equity_parent", "cash_and_equivalents", "rnd_expense",
                        "net_income"):
            self.assertIn(new_key, fin)
        # 旧名不再出现
        for old in ("net_profit_attr", "net_profit_deducted", "equity_attr",
                    "cash", "rd_expense", "net_profit"):
            self.assertNotIn(old, fin)
        # 11 项同名直接过
        for same in ("revenue", "operating_cost", "total_assets",
                     "total_liabilities", "accounts_receivable", "inventory",
                     "goodwill", "cfo", "cfi", "cff", "capex"):
            self.assertIn(same, fin)

    def test_记录九字段齐全(self):
        required = {"value", "unit", "period", "prior_value", "prior_period",
                    "scope", "page", "source", "confidence"}
        for key, rec in self.out["financials"].items():
            self.assertTrue(required.issubset(rec.keys()), key)

    def test_scope由basis改名且basis被删(self):
        rec = self.out["financials"]["revenue"]
        self.assertEqual(rec["scope"], "合并报表")
        self.assertNotIn("basis", rec)

    def test_prior从series取上一年(self):
        rec = self.out["financials"]["revenue"]
        # 茅台 revenue series: 2025=168838102514.79, 2024=170899152276.34
        self.assertEqual(rec["prior_period"], "2024")
        self.assertEqual(rec["prior_value"], 170899152276.34)

    def test_抽不到的科目没有value键留null(self):
        # 茅台 goodwill status=not_applicable，A 记录里没有 value 键
        rec = self.out["financials"]["goodwill"]
        self.assertIsNone(rec["value"])

    def test_company六个缺字段不编造(self):
        c = self.out["company"]
        self.assertEqual(c["report_period"], "2025")     # 2025年度 -> 2025
        self.assertEqual(c["ticker"], "600519.SH")        # 6 开头补 .SH
        self.assertEqual(c["amount_unit"], "元")
        self.assertIsNone(c["auditor"])                    # A 没抽，留空
        self.assertIsNone(c["audit_opinion"])

    def test_sources按页码归集(self):
        pages = [s["page"] for s in self.out["sources"]]
        self.assertEqual(pages, sorted(pages))
        self.assertEqual(len(pages), len(set(pages)))  # 去重

    def test_美的样例同样跑通(self):
        out2 = adapt_a(load(A_PATH2))
        self.assertEqual(out2["company"]["ticker"], "000333.SZ")  # 0 开头补 .SZ
        self.assertEqual(out2["company"]["report_period"], "2025")
        self.assertEqual(out2["financials"]["cash_and_equivalents"]["value"], 85247150000)

    def test_符合schema的company与financials结构(self):
        schema = load(SCHEMA_PATH)
        schema.setdefault("company", {})
        c = self.out["company"]
        # company 十个字段都在（值可空）
        for f in ("name", "ticker", "industry", "report_period", "exchange",
                  "report_type", "auditor", "audit_opinion", "currency", "amount_unit"):
            self.assertIn(f, c)
        # financials 记录的字段类型与 schema 对齐
        rec = self.out["financials"]["revenue"]
        self.assertIsInstance(rec["value"], (int, float))
        self.assertEqual(rec["unit"], "元")


class TestFromB(unittest.TestCase):
    def setUp(self):
        self.b_ratios = load(B_RATIOS)
        self.b_risks = load(B_RISKS)
        self.out = adapt_b(self.b_ratios, self.b_risks)

    def test_六类齐全(self):
        self.assertEqual(
            set(self.out["ratios"].keys()),
            {"growth", "profitability", "solvency", "efficiency",
             "cashflow_quality", "banking"})

    def test_65个B指标全部出现且键名映射后(self):
        # B 的 65 个原键，逐个应能在输出里找到对应键（映射后）
        b_keys = [k for cat in self.b_ratios["ratios"].values() for k in cat]
        self.assertEqual(len(b_keys), 65)
        produced = set()
        for cat in self.out["ratios"].values():
            produced.update(cat.keys())
        for bk in b_keys:
            ck = RATIO_RENAME.get(bk, bk)
            self.assertIn(ck, produced, "B 键 %s -> %s 未出现" % (bk, ck))

    def test_三个撞名的映射对(self):
        prof = self.out["ratios"]["profitability"]
        growth = self.out["ratios"]["growth"]
        cash = self.out["ratios"]["cashflow_quality"]
        self.assertIn("net_margin_total", prof)   # B net_margin -> 全口径
        self.assertIn("net_margin", prof)         # B net_margin_parent -> 归母
        self.assertIn("net_income_total_growth", growth)  # B net_income_growth
        self.assertIn("cfo_to_net_income_total", cash)    # B ocf_to_net_income
        # 撞名的 B 原键不应再出现
        self.assertNotIn("net_margin_total_parent", prof)

    def test_比率总数68条(self):
        total = sum(len(v) for v in self.out["ratios"].values())
        self.assertEqual(total, 68)

    def test_单位换算(self):
        growth = self.out["ratios"]["growth"]
        self.assertEqual(growth["revenue_growth_yoy"]["unit"], "小数")   # ratio -> 小数
        solv = self.out["ratios"]["solvency"]
        self.assertEqual(solv["interest_bearing_debt"]["unit"], "元")    # CNY -> 元
        self.assertEqual(solv["interest_coverage"]["unit"], "倍")        # x -> 倍
        eff = self.out["ratios"]["efficiency"]
        # 周转率类标「次」，天数标「天」
        self.assertEqual(eff["ar_turnover"]["unit"], "次")
        self.assertEqual(eff["inventory_turnover"]["unit"], "次")
        self.assertEqual(eff["total_asset_turnover"]["unit"], "次")
        self.assertEqual(eff["ar_turnover_days"]["unit"], "天")

    def test_比率记录字段保留(self):
        rec = self.out["ratios"]["profitability"]["gross_margin"]
        for f in ("value", "unit", "formula", "prev", "delta", "inputs",
                  "inputs_prev", "status", "higher_is_better", "period"):
            self.assertIn(f, rec)

    def test_我独有的三个指标留空标not_evaluable(self):
        self.assertEqual(self.out["ratios"]["growth"]["revenue_cagr_3y"]["status"],
                         "not_evaluable")
        self.assertEqual(self.out["ratios"]["profitability"]["ebitda_margin"]["status"],
                         "not_evaluable")
        self.assertEqual(self.out["ratios"]["cashflow_quality"]["capex_to_da_ratio"]["status"],
                         "not_evaluable")

    def test_风险分流(self):
        for card in self.out["risks"]:
            self.assertEqual(card["status"], "triggered")
        for card in self.out["rules_evaluated"]:
            self.assertNotEqual(card["status"], "triggered")
        # 两条合并 = 40 条规则
        self.assertEqual(len(self.out["risks"]) + len(self.out["rules_evaluated"]), 40)

    def test_风险卡字段映射(self):
        card = self.out["risks"][0]
        for f in ("risk_id", "risk_name", "category", "severity", "severity_tag",
                  "score", "status", "trigger", "involved_values",
                  "numeric_evidence", "text_evidence", "explanation",
                  "suggested_action", "evidence_chain"):
            self.assertIn(f, card)
        # category 六类中文之一
        self.assertIn(card["category"],
                      {"盈利质量", "收入与资产", "偿债与流动性",
                       "治理与合规", "会计政策", "审计与披露"})
        # involved_values 是数组，每项结构完整
        iv = card["involved_values"]
        self.assertIsInstance(iv, list)
        if iv:
            self.assertEqual(set(iv[0].keys()),
                             {"metric", "value", "unit", "period", "page"})

    def test_未触发规则字段(self):
        card = self.out["rules_evaluated"][0]
        for f in ("rule_id", "rule_name", "category", "status", "severity",
                  "severity_tag", "trigger", "explanation", "trigger_values"):
            self.assertIn(f, card)

    def test_WACC项第一趟标not_evaluable(self):
        rmw = self.out["ratios"]["profitability"]["roic_minus_wacc"]
        self.assertEqual(rmw["status"], "not_evaluable")
        self.assertIsNone(rmw["value"])


class TestFromC(unittest.TestCase):
    def setUp(self):
        self.c = load(C_PATH)
        self.out = adapt_c(self.c)
        self.v = self.out["valuation"]

    def test_五块齐全(self):
        for blk in ("comps", "dcf", "blended", "scenarios", "sotp"):
            self.assertIn(blk, self.v)

    def test_relative改名成comps(self):
        self.assertNotIn("relative", self.v)
        comps = self.v["comps"]
        for f in ("inputs", "peer_companies", "peer_multiples",
                  "implied_value_per_share", "valuation_range"):
            self.assertIn(f, comps)

    def test_peer_multiples收拢成min中max(self):
        pm = self.v["comps"]["peer_multiples"]
        self.assertIn("pe", pm)
        self.assertEqual(set(pm["pe"].keys()), {"min", "median", "max"})
        self.assertEqual(pm["pe"]["median"], 9.69)
        self.assertIsNone(pm["pe"]["min"])   # C 只有一个中位数

    def test_每股换算(self):
        shares = self.c["market_data"]["shares_outstanding"]
        vr = self.v["comps"]["valuation_range"]
        self.assertEqual(vr["currency"], "元/股")
        # range_low 是股权价值总额，换算成每股
        self.assertAlmostEqual(vr["low"], round(510458100357.08997 / shares, 2))

    def test_dcf参数收拢进inputs(self):
        self.assertNotIn("wacc_block", self.v["dcf"])
        for f in ("revenue_base", "ebit_margin", "tax_rate", "da", "capex",
                  "nwc", "wacc", "terminal_growth", "forecast_years"):
            self.assertIn(f, self.v["dcf"]["inputs"])

    def test_forecast补year(self):
        fc = self.v["dcf"]["forecast"]
        self.assertEqual(fc[0]["year"], 2026)   # report_period 2025 + year_index 1
        self.assertEqual(fc[-1]["year"], 2030)
        self.assertEqual(len(fc), 5)

    def test_终值收拢(self):
        ta = self.v["dcf"]["terminal_assumptions"]
        for f in ("terminal_growth", "terminal_fcff", "terminal_value",
                  "pv_terminal_value", "tv_pct_of_ev", "wacc"):
            self.assertIn(f, ta)
        self.assertNotIn("tv_gordon", self.v["dcf"])  # 已收进 terminal_assumptions

    def test_sensitivity移进dcf且键名改(self):
        self.assertNotIn("sensitivity", {"x": 1} if False else self.v)
        s = self.v["dcf"]["sensitivity"]
        self.assertIn("matrix", s)
        self.assertIn("wacc_values", s)
        self.assertIn("terminal_growth_values", s)
        self.assertEqual(len(s["matrix"]), 5)

    def test_blended组件key改名(self):
        comps = self.v["blended"]["components"]
        keys = {c["key"] for c in comps}
        self.assertIn("comps", keys)   # C 的 relative -> comps
        self.assertNotIn("relative", keys)

    def test_sotp三情景与附属键(self):
        self.assertIn("bull", self.v["scenarios"])
        self.assertIn("market_data", self.v)
        self.assertIn("warnings", self.v)
        self.assertIn("sources", self.v)
        self.assertIn("disclaimer", self.v)
        self.assertFalse(self.v["sotp"].get("ok", False))


class TestOrchestrator(unittest.TestCase):
    def setUp(self):
        self.a = load(A_PATH)
        self.b_ratios = load(B_RATIOS)
        self.b_risks = load(B_RISKS)
        self.c = load(C_PATH)
        self.obj, self.log = run(self.a, self.b_ratios, self.b_risks, self.c)

    def test_顶层七个键(self):
        self.assertEqual(
            set(self.obj.keys()),
            {"company", "financials", "ratios", "risks", "rules_evaluated",
             "valuation", "sources"})

    def test_没有多余的顶层键(self):
        self.assertEqual(len(self.obj), 7)

    def test_company以A为主(self):
        self.assertEqual(self.obj["company"]["name"], "贵州茅台酒股份有限公司")
        # 补自 B：审计意见
        self.assertEqual(self.obj["company"]["audit_opinion"], "标准无保留意见")

    def test_公司不一致记进日志(self):
        names = {self.obj["company"]["name"]}
        self.assertTrue(self.log["warnings"])  # A/B/C 公司不同，应有告警

    def test_WACC回填(self):
        c_wacc = self.c["dcf"]["wacc"]
        # 统一对象里的数值收口到最多四位小数，比对时也按四位
        self.assertAlmostEqual(self.obj["valuation"]["dcf"]["inputs"]["wacc"], c_wacc, places=4)
        rmw = self.obj["ratios"]["profitability"]["roic_minus_wacc"]
        self.assertEqual(rmw["status"], "ok")
        self.assertAlmostEqual(rmw["value"],
                               round(self.obj["ratios"]["profitability"]["roic"]["value"] - c_wacc, 4),
                               places=4)

    def test_运行日志记录B跑两趟(self):
        self.assertEqual(self.log["b_passes"], 2)
        joined = " ".join(self.log["notes"])
        self.assertIn("两趟", joined)

    def test_风险分流后数量一致(self):
        for card in self.obj["risks"]:
            self.assertEqual(card["status"], "triggered")
        for card in self.obj["rules_evaluated"]:
            self.assertNotEqual(card["status"], "triggered")

    def test_sources含风险页(self):
        pages = {s["page"] for s in self.obj["sources"]}
        self.assertIn(6, pages)   # A 的 revenue 页

    def test_符合schema的valuation结构(self):
        v = self.obj["valuation"]
        for blk in ("comps", "dcf", "blended", "scenarios", "sotp",
                    "market_data", "warnings", "sources", "disclaimer"):
            self.assertIn(blk, v)


if __name__ == "__main__":
    unittest.main(verbosity=2)
