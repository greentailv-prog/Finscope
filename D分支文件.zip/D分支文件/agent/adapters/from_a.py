"""A 的抽取结果 -> company / financials / sources。

依据「接口对齐方案」第 2 节。A 只抽 17 个科目，SCHEMA 要 26 个，
缺的 9 个不补，留空（不编造）。
"""

from ._util import strip_period

# A 的科目键 -> 我的科目键。映射表见接口对齐方案 2.1。
FIELD_MAP = {
    # 11 个同名，不在表里，直接过：revenue / operating_cost / total_assets /
    # total_liabilities / accounts_receivable / inventory / goodwill /
    # cfo / cfi / cff / capex
    "net_profit_attr": "net_income_parent",
    "net_profit_deducted": "net_income_excl_nonrecurring",
    "equity_attr": "equity_parent",
    "cash": "cash_and_equivalents",
    "rd_expense": "rnd_expense",
    "net_profit": "net_income",
}

# A 的 basis 值 -> 我的 scope 值。已定案：A 的 basis 改名成 scope，值从「合并」改成「合并报表」。
SCOPE_MAP = {
    "合并": "合并报表",
    "合并报表": "合并报表",
    "母公司": "母公司报表",
    "母公司报表": "母公司报表",
}


def _ticker_with_suffix(ticker):
    """按代码前缀补交易所后缀。6 -> .SH；0 和 3 -> .SZ。已有后缀则不动。"""
    if ticker is None:
        return None
    t = str(ticker).strip()
    if "." in t:
        return t
    if t.startswith("6"):
        return t + ".SH"
    if t.startswith("0") or t.startswith("3"):
        return t + ".SZ"
    return t


def _exchange_from_ticker(ticker):
    """由后缀推上市地。推不出留 None，不编造板块。"""
    if ticker is None:
        return None
    t = str(ticker)
    if t.endswith(".SH"):
        return "上海证券交易所"
    if t.endswith(".SZ"):
        return "深圳证券交易所"
    return None


def _currency_from_ticker(ticker):
    """A 股交易所对应币种 CNY。美股港股不在 A 的范围内，留 None。"""
    if ticker is None:
        return None
    if str(ticker).endswith(".SH") or str(ticker).endswith(".SZ"):
        return "CNY"
    return None


def _prior_from_series(series, period):
    """从 series（{年份: 值}）取上一年。返回 (prior_period, prior_value)。"""
    if not series or period is None:
        return None, None
    try:
        want = str(int(period) - 1)
    except (TypeError, ValueError):
        return None, None
    if want in series:
        return want, series[want]
    # 找不到确切上一年，退而取小于 period 的最大年份
    years = []
    for y in series:
        try:
            if int(y) < int(period):
                years.append(y)
        except (TypeError, ValueError):
            continue
    if years:
        y = max(years, key=lambda s: int(s))
        return y, series[y]
    return None, None


def _adapt_record(rec, period):
    """单条 A 记录 -> 统一记录。"""
    status = rec.get("status")
    # A 的记录里根本没有 value 键（不是 value: null），要判 status 再决定。
    if status == "found" and "value" in rec:
        value = rec.get("value")
    else:
        value = None

    scope = SCOPE_MAP.get(rec.get("basis"), "合并报表")
    prior_period, prior_value = _prior_from_series(rec.get("series"), period)

    return {
        "value": value,
        "unit": "元",  # A 恒为「元」，与改后的 Schema 一致
        "period": rec.get("period") or period,
        "prior_value": prior_value,
        "prior_period": prior_period,
        "scope": scope,
        # basis（期间口径）不逐条存，按 SCHEMA 3.2 的科目类型写死规则
        "page": rec.get("page"),
        "source": rec.get("source"),
        "confidence": rec.get("confidence"),
        # 扩展字段：保留 A 的抽取状态，便于 E 和核验页区分「没有」与「是零」
        "status": status,
    }


def _adapt_company(a_company, report_period, pdf_name):
    """A 的 5 个字段 -> 我的 10 个字段。缺的留 None 或写占位，不编造。"""
    ticker = _ticker_with_suffix(a_company.get("ticker"))
    title = a_company.get("report_title") or ""
    report_type = "年度报告" if "年度报告" in title else None
    return {
        "name": a_company.get("name"),
        "ticker": ticker,
        "industry": a_company.get("industry"),
        "report_period": report_period,
        "exchange": _exchange_from_ticker(ticker),
        "report_type": report_type,
        "auditor": None,          # A 没抽，不编造
        "audit_opinion": None,    # A 没抽。审计意见要触发风险规则，属 A 待补项
        "currency": _currency_from_ticker(ticker),  # SCHEMA 说由 D 填，按交易所推 CNY
        "amount_unit": "元",       # 固定「元」
        # 扩展：A 的原始文件名（sources 归集要用）
        "_pdf_name": pdf_name,
    }


def _collect_sources(company, financials, pdf_name):
    """从每条记录的 page 和 source 归集顶层 sources。按页码去重排序。"""
    seen = {}
    for rec in financials.values():
        page = rec.get("page")
        if page is None:
            continue
        if page not in seen:
            seen[page] = {
                "company_name": company.get("name"),
                "report_period": company.get("report_period"),
                "file_name": pdf_name,
                "page": page,
                "retrieved_at": None,   # A 没有获取时间，留空
                "source_url": None,     # 本地文件，留空
                "source": rec.get("source"),  # 扩展：A 记的来源名
            }
    return [seen[p] for p in sorted(seen)]


def adapt_a(a_obj):
    """入口。a_obj 是 A 的抽取结果 JSON 对象。

    返回 {company, financials, sources}。三家 company 段都有，这里给 A 的那份。
    """
    a_company = a_obj.get("company", {}) or {}
    report_period = strip_period(a_company.get("report_period"))
    pdf_name = (a_obj.get("extraction_meta") or {}).get("pdf")

    company = _adapt_company(a_company, report_period, pdf_name)

    financials = {}
    for a_key, rec in (a_obj.get("financials") or {}).items():
        my_key = FIELD_MAP.get(a_key, a_key)
        financials[my_key] = _adapt_record(rec, report_period)

    sources = _collect_sources(company, financials, pdf_name)

    return {"company": company, "financials": financials, "sources": sources}
