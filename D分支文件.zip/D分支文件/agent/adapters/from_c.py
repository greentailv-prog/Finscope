"""C 的估值输出 -> valuation（五块 + 附属键）。

依据「接口对齐方案」第 4 节与已定案第 3 条：
**C 的算法和数值一律不动，只统一字段名和层级。**
"""

from ._util import round_value, strip_period

# C 的结果里 multiple -> 我的倍数键
MULTIPLE_KEYS = ("pe", "pb", "ev_ebitda", "ps")

# 组件 key 改名：C 的 relative -> 我的 comps
COMPONENT_KEY_MAP = {"relative": "comps"}


def _per_share(total, shares):
    """股权价值总额除以总股本。shares 为 0 或 None 返回 None。"""
    if total is None or not shares:
        return None
    return round(total / shares, 2)


def _build_comps(c, shares):
    """C 的 relative -> valuation.comps。"""
    rel = c.get("relative", {}) or {}
    mkt = c.get("market_data", {}) or {}
    results = rel.get("results", []) or []
    by_multiple = {r.get("multiple"): r for r in results if r.get("multiple")}

    def metric_value(basis):
        for r in results:
            if r.get("metric_basis") == basis:
                return r.get("metric_value")
        return None

    # C 的 ev_ebitda 结果里 net_debt_deducted 就是净负债
    net_debt = None
    if "ev_ebitda" in by_multiple:
        net_debt = by_multiple["ev_ebitda"].get("net_debt_deducted")

    inputs = {
        "revenue": metric_value("营业收入"),
        "net_income": metric_value("净利润"),
        "ebitda": metric_value("EBITDA"),
        "net_debt": net_debt,
        "share_price": mkt.get("price"),
        "shares_outstanding": mkt.get("shares_outstanding"),
        "shares_unit": "股",
        "market_cap": mkt.get("market_cap"),
        "currency": c.get("currency"),
    }

    peer_companies = []
    for p in rel.get("peers_detail", []) or []:
        peer_companies.append({
            "name": p.get("name"),
            "ticker": p.get("ticker"),
            "pe": p.get("pe"),
            "pb": p.get("pb"),
            "ev_ebitda": p.get("ev_ebitda"),
            "ps": p.get("ps"),
        })

    # C 每种倍数只有一个中位数，我的 Schema 要 min/median/max 三值，缺的写 null。
    peer_multiples = {}
    implied_value_per_share = {}
    for m in MULTIPLE_KEYS:
        r = by_multiple.get(m)
        peer_multiples[m] = {
            "min": None,
            "median": r.get("peer_median") if r else None,
            "max": None,
        }
        implied_value_per_share[m] = {
            "low": None,
            "mid": round(r.get("implied_per_share"), 2) if r and r.get("implied_per_share") is not None else None,
            "high": None,
        }

    # C 的 range_low/range_high 是股权价值总额（元），换算成每股再填。
    valuation_range = {
        "low": _per_share(rel.get("range_low"), shares),
        "mid": round(rel.get("implied_per_share"), 2) if rel.get("implied_per_share") is not None else None,
        "high": _per_share(rel.get("range_high"), shares),
        "currency": "元/股",
    }

    return {
        "inputs": inputs,
        "peer_companies": peer_companies,
        "peer_multiples": peer_multiples,
        "implied_value_per_share": implied_value_per_share,
        "valuation_range": valuation_range,
    }


def _build_dcf(c, revenue_base, base_year):
    """C 的 dcf -> valuation.dcf。顶层平铺参数收拢进 inputs，终值收拢进
    terminal_assumptions，sensitivity 从顶层移进来。"""
    dcf = c.get("dcf", {}) or {}
    wb = dcf.get("wacc_block", {}) or {}
    rows = dcf.get("rows", []) or []

    # 预测起点收入：C 没有直接字段，用相对估值里的营业收入口径（与 rows 自洽）。
    rb = dcf.get("revenue_base")
    if rb is None and rows:
        g1 = rows[0].get("growth")
        if g1:
            rb = rows[0].get("revenue") / (1 + g1)
    if rb is None:
        rb = revenue_base

    def pct_to_amount(key):
        p = dcf.get(key)
        if p is None or rb is None:
            return None
        return round(p * rb, 2)

    inputs = {
        "revenue_base": round(rb, 2) if rb is not None else None,
        "ebit_margin": dcf.get("ebit_margin"),
        "tax_rate": wb.get("tax_rate"),
        "da": pct_to_amount("da_pct"),
        "capex": pct_to_amount("capex_pct"),
        "nwc": pct_to_amount("nwc_pct"),
        "wacc": dcf.get("wacc"),
        "terminal_growth": dcf.get("terminal_growth"),
        "forecast_years": dcf.get("forecast_years"),
    }

    # rows -> forecast，补 year 字段（C 只有 year_index 从 1 数起）
    forecast = []
    for row in rows:
        item = dict(row)  # 数值一律不动，原字段全保留
        yi = row.get("year_index")
        if yi is not None and base_year is not None:
            item["year"] = base_year + int(yi)
        forecast.append(item)

    terminal_assumptions = {
        "terminal_growth": dcf.get("terminal_growth"),
        "terminal_fcff": forecast[-1].get("fcff") if forecast else None,
        "terminal_value": dcf.get("tv_base"),
        "pv_terminal_value": dcf.get("pv_terminal"),
        "tv_pct_of_ev": dcf.get("tv_ratio"),
        "wacc": dcf.get("wacc"),
        # C 另算的两个终值，一并保留，便于讲清分歧
        "tv_gordon": dcf.get("tv_gordon"),
        "tv_exit": dcf.get("tv_exit"),
        "exit_multiple": dcf.get("exit_multiple"),
        "tv_divergence": dcf.get("tv_divergence"),
    }

    # C 没有 DCF 区间对象，用它的敏感性矩阵边界配每股中值推一个。
    valuation_range = {"low": None, "mid": None, "high": None, "currency": "元/股"}
    if dcf.get("per_share") is not None:
        valuation_range["mid"] = round(dcf["per_share"], 2)

    sensitivity = None
    sc = c.get("sensitivity") or dcf.get("sensitivity")
    if sc:
        grid = sc.get("grid") or sc.get("matrix")
        # C 的敏感性矩阵里 WACC<=g 的格子是 None（无解），取区间时必须剔除，
        # 否则 min/max 会在 None 与 float 之间比较报 TypeError。
        flat = [v for row in (grid or []) for v in row if v is not None]
        if flat:
            valuation_range["low"] = round(min(flat), 2)
            valuation_range["high"] = round(max(flat), 2)
        sensitivity = {
            "metric": "value_per_share",
            "unit": "元/股",
            "wacc_values": sc.get("wacc_axis") or sc.get("wacc_values"),
            "terminal_growth_values": sc.get("growth_axis") or sc.get("terminal_growth_values"),
            "matrix": grid,
            "base_wacc": sc.get("base_wacc"),
            "base_growth": sc.get("base_growth"),
        }

    return {
        "inputs": inputs,
        "forecast": forecast,
        "terminal_assumptions": terminal_assumptions,
        "valuation_range": valuation_range,
        "sensitivity": sensitivity,
    }


def _build_blended(c):
    """C 的 blended -> valuation.blended。组件 key relative -> comps。"""
    b = c.get("blended", {}) or {}
    components = []
    for comp in b.get("components", []) or []:
        comp = dict(comp)
        comp["key"] = COMPONENT_KEY_MAP.get(comp.get("key"), comp.get("key"))
        components.append(comp)
    return {
        "blended_per_share": b.get("blended_per_share"),
        "current_price": b.get("current_price"),
        "upside": b.get("upside"),
        "verdict": b.get("verdict"),
        "components": components,
        "blended_equity_value": b.get("blended_equity_value"),
        "most_bullish": b.get("most_bullish"),
        "most_bearish": b.get("most_bearish"),
        "weight_source": b.get("weight_source"),
    }


def _build_scenarios(c):
    """C 的 scenarios -> valuation.scenarios。三情景字段名已一致。"""
    sc = c.get("scenarios", {}) or {}
    keys = ("per_share", "equity_value", "growth_y1", "ebit_margin",
            "wacc", "terminal_growth", "label", "levers")
    out = {}
    for name in ("bull", "base", "bear"):
        block = sc.get(name)
        if isinstance(block, dict):
            out[name] = {k: block.get(k) for k in keys}
    return out


def adapt_c(c_obj):
    """入口。返回 {valuation, company}。

    company 是补全片段（C 有 name/ticker/industry/currency/report_period）。
    """
    c = c_obj or {}
    mkt = c.get("market_data", {}) or {}
    shares = mkt.get("shares_outstanding")

    # 预测年份基准：优先 C 的报告期，其次 as_of
    base_year_raw = c.get("company", {}).get("report_period") or c.get("as_of")
    base_year_s = strip_period(base_year_raw)
    base_year = int(base_year_s) if base_year_s and base_year_s.isdigit() else None

    comps = _build_comps(c, shares)
    revenue_base = comps["inputs"].get("revenue")
    dcf = _build_dcf(c, revenue_base, base_year)

    valuation = {
        "comps": comps,
        "dcf": dcf,
        "blended": _build_blended(c),
        "scenarios": _build_scenarios(c),
        "sotp": c.get("sotp") or {"ok": False, "skipped": True},
        "market_data": mkt,
        "warnings": c.get("warnings") or [],
        "sources": c.get("sources") or [],
        "disclaimer": c.get("disclaimer"),
    }

    c_company = c.get("company", {}) or {}
    company_fragment = {
        "name": c_company.get("name"),
        "ticker": c_company.get("ticker"),
        "industry": c_company.get("industry"),
        "report_period": strip_period(c_company.get("report_period")),
        "currency": c_company.get("currency") or c.get("currency"),
    }

    return {"valuation": valuation, "company": company_fragment}
