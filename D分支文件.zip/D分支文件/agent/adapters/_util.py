"""适配层共用工具。只用标准库。"""

import json
import re


def load_json(path):
    """读 JSON。返回 (对象, 错误字符串)。错误不抛出，交给上层记日志。"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, "文件不存在: %s" % path
    except json.JSONDecodeError as exc:
        return None, "JSON 解析失败: %s (%s)" % (path, exc)


def round_value(v, unit):
    """按单位口径统一精度。

    小数四位；倍 / 天 / 次两位；元、元/股两位；股取整。
    None 原样返回。非数字原样返回。
    """
    if v is None:
        return None
    if not isinstance(v, (int, float)) or isinstance(v, bool):
        return v
    if unit == "小数":
        return round(v, 4)
    if unit in ("倍", "天", "次"):
        return round(v, 2)
    if unit in ("元", "元/股"):
        return round(v, 2)
    if unit == "股":
        return int(v)
    return v


def strip_period(raw):
    """把各种报告期写法截成四位年份。

    '2025年度' -> '2025'；'2025-12-31' -> '2025'；'2025' -> '2025'。
    """
    if raw is None:
        return None
    s = str(raw).strip()
    m = re.match(r"^(\d{4})", s)
    return m.group(1) if m else s


def is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)
