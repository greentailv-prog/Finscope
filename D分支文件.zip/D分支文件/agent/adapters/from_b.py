"""B 的指标与风险输出 -> ratios / risks / rules_evaluated。

依据「接口对齐方案」第 3 节与 SCHEMA 5.4 / 5.5 / 5.5.1。

三条硬规则：
1. B 多出的 40 个指标并入 ratios 同一层，键名沿用（撞名的三个按已定案改）。
2. 比率按 status == "triggered" 过滤：触发的进 risks，其余进 rules_evaluated。
3. WACC 相关项第一趟标 not_evaluable（C 还没产出 WACC），由编排层第二趟回填重算。
"""

from ._util import round_value

# B 键 -> 我的键。映射表见接口对齐方案 3.1 与 SCHEMA 5.4。未列出的 B 键沿用原名。
RATIO_RENAME = {
    "revenue_growth": "revenue_growth_yoy",
    "net_income_parent_growth": "net_income_growth_yoy",
    "net_income_deducted_growth": "net_income_excl_nonrecurring_growth_yoy",
    "net_income_growth": "net_income_total_growth",   # 撞名，全口径后缀
    "net_margin": "net_margin_total",                 # 撞名：B 的 net_margin 是全口径
    "net_margin_parent": "net_margin",                # 我的 net_margin 要归母
    "roe": "roe_weighted",
    "debt_to_assets": "debt_to_asset_ratio",
    "dso": "ar_turnover_days",
    "dio": "inventory_turnover_days",
    "dpo": "payable_turnover_days",
    "ocf_to_net_income": "cfo_to_net_income_total",   # 撞名，全口径后缀
    "ocf_to_net_income_parent": "cfo_to_net_income",
    "sales_cash_ratio": "cash_collection_ratio",
}

# 我独有、B 没有的 3 个主干指标（SCHEMA 5.4）：留空，标 not_evaluable。
MY_ONLY_RATIOS = {
    "growth": ("revenue_cagr_3y", "小数"),
    "profitability": ("ebitda_margin", "小数"),
    "cashflow_quality": ("capex_to_da_ratio", "倍"),
}

# B 的 unit -> 我的 unit。x 再按是否为周转率细分为「次」或「倍」。
UNIT_MAP = {"ratio": "小数", "days": "天", "CNY": "元"}

# 周转率类标「次」，其余倍率类标「倍」。已定案。
TURNOVER_KEYS = {
    "ar_turnover", "inventory_turnover", "ap_turnover",
    "total_asset_turnover", "fixed_asset_turnover",
}

# B 的类别 slug -> 我的六类中文。SCHEMA 5.5 的类别映射表。
CATEGORY_MAP = {
    "growth": "收入与资产",
    "profitability": "盈利质量",
    "solvency": "偿债与流动性",
    "efficiency": "收入与资产",
    "cashflow_quality": "盈利质量",
    "asset_quality": "会计政策",
    "governance": "治理与合规",
}

# WACC 相关项：第一趟标 not_evaluable，编排层第二趟回填重算。
WACC_RATIO_KEY = "roic_minus_wacc"
WACC_TOKENS = ("wacc", "roic_minus_wacc")


def _to_my_unit(b_unit, canonical_key):
    """B 的 unit 转我的 unit。周转率类标次，其余倍率类标倍。"""
    if b_unit == "x":
        return "次" if canonical_key in TURNOVER_KEYS else "倍"
    return UNIT_MAP.get(b_unit, b_unit)


def _evidence_page(evidence, metric, period):
    """从 B 顶层 evidence 子树按指标名取页码。取不到返回 None。"""
    if not isinstance(evidence, dict):
        return None
    node = evidence.get(metric)
    if isinstance(node, dict):
        if period in node and isinstance(node[period], dict):
            return node[period].get("page")
        # 没有当期，取最新有 page 的一期
        for y in sorted(node.keys(), reverse=True):
            if isinstance(node[y], dict) and node[y].get("page") is not None:
                return node[y]["page"]
        if node.get("page") is not None:
            return node["page"]
    return None


def _ratio_record(rec, canonical_key, origin_key, period, evidence):
    """B 的比率记录 -> 我的比率记录。B 的 value/unit/formula/prev/delta/inputs/
    inputs_prev/status/higher_is_better 全部保留。period 补自 company，
    page 从 evidence 子树取。"""
    unit = _to_my_unit(rec.get("unit"), canonical_key)
    page = _evidence_page(evidence, canonical_key, period)
    if page is None:
        page = _evidence_page(evidence, origin_key, period)
    return {
        "value": round_value(rec.get("value"), unit),
        "unit": unit,
        "period": period,
        "formula": rec.get("formula"),
        "page": page,
        "prev": round_value(rec.get("prev"), unit),
        "delta": round_value(rec.get("delta"), unit),
        "inputs": rec.get("inputs"),
        "inputs_prev": rec.get("inputs_prev"),
        "status": rec.get("status"),
        "higher_is_better": rec.get("higher_is_better"),
    }


def _stub_record(unit, period):
    """我独有、B 没有的指标：留空，标 not_evaluable，不编造。"""
    return {
        "value": None,
        "unit": unit,
        "period": period,
        "formula": None,
        "page": None,
        "prev": None,
        "delta": None,
        "inputs": None,
        "inputs_prev": None,
        "status": "not_evaluable",
        "higher_is_better": None,
    }


def _adapt_ratios(b_ratios, period, evidence):
    """B 的 ratios -> 我的 ratios。五类 + banking，共 68 个键。"""
    out = {}
    units = {}  # canonical -> unit，供风险 involved_values 推断单位
    for cat, items in b_ratios.items():
        out[cat] = {}
        for b_key, rec in (items or {}).items():
            c_key = RATIO_RENAME.get(b_key, b_key)
            record = _ratio_record(rec, c_key, b_key, period, evidence)
            if c_key == WACC_RATIO_KEY:
                # 第一趟：WACC 未产出，标 not_evaluable
                record["value"] = None
                record["prev"] = None
                record["delta"] = None
                record["status"] = "not_evaluable"
                roic = (b_ratios.get("profitability") or {}).get("roic", {})
                record["inputs"] = {"roic": roic.get("value"), "wacc": None}
            out[cat][c_key] = record
            units[c_key] = record["unit"]
            units[b_key] = record["unit"]  # 兼容 B 原始名
        # 插入我独有的指标
        if cat in MY_ONLY_RATIOS:
            k, u = MY_ONLY_RATIOS[cat]
            out[cat][k] = _stub_record(u, period)
            units[k] = u
    # banking 若无则补空对象（SCHEMA 五类之外的可选一类）
    out.setdefault("banking", {})
    return out, units


def _card_is_wacc(card):
    """判断风险卡是否依赖 WACC。"""
    blob = "%s %s %s" % (
        card.get("trigger") or "",
        card.get("trigger_display") or "",
        " ".join((card.get("trigger_values") or {}).keys()),
    )
    low = blob.lower()
    return any(tok in low for tok in WACC_TOKENS)


def _involved_values(card, units, period, evidence):
    """B 的 trigger_values -> 我的 involved_values 数组。

    B 是 {变量名: 数值}，我的要求数组，每项带 metric/value/unit/period/page。
    """
    out = []
    tv = card.get("trigger_values") or {}
    # 数据层里有页码的先建索引
    page_index = {}
    for step in card.get("evidence_chain") or []:
        if step.get("step") == "数据" and step.get("item"):
            page_index.setdefault(step["item"], step.get("page"))
    for metric, value in tv.items():
        unit = units.get(metric)
        if unit is None:
            unit = "小数"  # trigger_values 多为比率，缺省按小数
        page = page_index.get(metric)
        if page is None:
            page = _evidence_page(evidence, metric, period)
        out.append({
            "metric": metric,
            "value": round_value(value, unit),
            "unit": unit,
            "period": period,
            "page": page,
        })
    return out


def _numeric_evidence(card):
    """从 evidence_chain 的「判断」层拼数字证据。"""
    for step in card.get("evidence_chain") or []:
        if step.get("step") == "判断":
            item = step.get("item") or ""
            result = step.get("result")
            return "%s（%s）" % (item, result) if result else item
    return None


def _text_evidence(card):
    """从 evidence_chain 的「出处」层取 sources 与 pages。B 没有原文引用，quote 写 null。"""
    for step in card.get("evidence_chain") or []:
        if step.get("step") == "出处":
            pages = step.get("pages") or []
            return {
                "quote": None,
                "page": pages[0] if pages else None,
                "sources": step.get("sources") or [],
                "pages": pages,
            }
    return {"quote": None, "page": None, "sources": [], "pages": []}


def _join_suggestions(card):
    """B 的 suggestions 数组拼成字符串。B 只有 triggered 的卡片才有这个键。"""
    sugg = card.get("suggestions")
    if not sugg:
        return None
    return "；".join(str(s) for s in sugg)


def _adapt_risk_card(card, units, period, evidence):
    """B 的触发风险卡 -> 我的 risks 一条。"""
    return {
        "risk_id": card.get("risk_id"),
        "risk_name": card.get("risk_name"),
        "category": CATEGORY_MAP.get(card.get("category"), card.get("category")),
        "severity": card.get("severity"),
        "severity_tag": card.get("severity_tag"),
        "score": card.get("score"),
        "status": card.get("status"),
        "trigger": card.get("trigger_display") or card.get("trigger"),
        # 扩展：保留 B 的原始比较表达式，供编排层第二趟回填后重判，不对外展示
        "_trigger_expr": card.get("trigger"),
        "involved_values": _involved_values(card, units, period, evidence),
        "numeric_evidence": _numeric_evidence(card),
        "text_evidence": _text_evidence(card),
        "explanation": card.get("explanation"),
        "suggested_action": _join_suggestions(card),
        "evidence_chain": card.get("evidence_chain") or [],
    }


def _adapt_rule_card(card):
    """B 的未触发规则卡 -> 我的 rules_evaluated 一条。"""
    return {
        "rule_id": card.get("risk_id"),
        "rule_name": card.get("risk_name"),
        "category": CATEGORY_MAP.get(card.get("category"), card.get("category")),
        "status": card.get("status"),
        "severity": card.get("severity"),
        "severity_tag": card.get("severity_tag"),
        "trigger": card.get("trigger_display") or card.get("trigger"),
        "_trigger_expr": card.get("trigger"),
        "explanation": card.get("explanation"),
        "trigger_values": card.get("trigger_values") or {},
        "confidence": card.get("confidence"),
        "evidence_required": card.get("evidence_required") or [],
    }


def adapt_b(ratios_obj, risks_obj):
    """入口。返回 {ratios, risks, rules_evaluated, company}。

    company 是补全用的片段（B 只有 name/ticker/industry/report_period），
    另把 meta.audit_opinion 挪进 company.audit_opinion（接口对齐方案 3.5）。
    """
    company = ratios_obj.get("company", {}) or {}
    meta = ratios_obj.get("meta", {}) or {}
    period = company.get("report_period") or meta.get("report_period")
    evidence = ratios_obj.get("evidence", {}) or {}

    ratios, units = _adapt_ratios(ratios_obj.get("ratios", {}) or {}, period, evidence)

    # 风险分流：triggered 的进 risks，其余进 rules_evaluated。
    # WACC 相关项第一趟一律标 not_evaluable，进 rules_evaluated，等编排层第二趟。
    risks = []
    rules_evaluated = []
    for card in risks_obj.get("risks", []) or []:
        if _card_is_wacc(card):
            card = dict(card)
            card["status"] = "not_evaluable"
            card["severity"] = None
            card["severity_tag"] = None
            card["score"] = None
            rules_evaluated.append(_adapt_rule_card(card))
            continue
        if card.get("status") == "triggered":
            risks.append(_adapt_risk_card(card, units, period, evidence))
        else:
            rules_evaluated.append(_adapt_rule_card(card))

    company_fragment = {
        "name": company.get("name"),
        "ticker": company.get("ticker"),
        "industry": company.get("industry"),
        "report_period": period,
        "currency": meta.get("currency"),
        "audit_opinion": meta.get("audit_opinion"),  # 接口对齐方案 3.5
    }

    return {
        "ratios": ratios,
        "risks": risks,
        "rules_evaluated": rules_evaluated,
        "company": company_fragment,
    }
