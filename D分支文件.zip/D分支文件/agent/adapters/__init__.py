"""FinScope D 分支适配层。

把 A / B / C 三家的产物转成统一数据对象（七键）。
只读三家输出，不改三家代码。
"""

from .from_a import adapt_a
from .from_b import adapt_b, RATIO_RENAME
from .from_c import adapt_c

__all__ = ["adapt_a", "adapt_b", "adapt_c", "RATIO_RENAME"]
