#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 A -> B(指标) -> B(风险) -> C(估值) -> D(适配层) 整条链跑一遍（命令行单跑入口）。

真正的链路逻辑已抽到 server/chain_runner.py 的 run_chain()，本文件只是薄壳：
解析命令行参数 -> 调 run_chain -> 打印汇总。后端服务 (server/jobs.py) 调的是
同一个函数，所以两边逻辑不会分叉。

用法：
    python run_chain.py
    python run_chain.py --a <另一家公司的 A 抽取结果.json>
    python run_chain.py --online                 # 缓存没有时联网兜底（默认关）
    python run_chain.py --gap-fill demo          # C 缺的财务字段用对照样例补
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent                 # .../D分支文件/agent/runner
AGENT = HERE.parent                                     # .../D分支文件/agent
D_ROOT = AGENT.parent                                   # .../D分支文件

# 让 `from server import ...` 找得到
for _p in (str(D_ROOT), str(AGENT), str(HERE)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from server import config, chain_runner  # noqa: E402


def _load(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")   # 控制台默认 GBK，摘要里的 − 会炸
    except Exception:
        pass

    ap = argparse.ArgumentParser(description="FinScope 真链运行器")
    ap.add_argument("--a", default=str(config.A_EXTRACTED / "贵州茅台_600519_2025.json"),
                    help="A 的抽取结果 JSON（默认茅台）")
    ap.add_argument("--online", action="store_true",
                    help="行情缓存缺失时允许联网兜底（akshare，默认关）")
    ap.add_argument("--gap-fill", choices=["none", "demo"], default="none",
                    help="C 缺的财务字段：none 留空（默认） / demo 用同公司样例补（对照）")
    ap.add_argument("--out", default=str(AGENT / "output" / "unified.json"))
    ap.add_argument("--log", default=str(AGENT / "output" / "run_log.json"))
    args = ap.parse_args()

    out_path = args.out if args.gap_fill == "none" else args.out.replace(".json", "_%s.json" % args.gap_fill)
    log_path = args.log if args.gap_fill == "none" else args.log.replace(".json", "_%s.json" % args.gap_fill)

    a_obj = _load(args.a)
    try:
        res = chain_runner.run_chain(
            a_obj,
            online=args.online,
            gap_fill=args.gap_fill,
            work_dir=HERE,
            out_path=out_path,
            log_path=log_path,
        )
    except chain_runner.ChainError as exc:
        print("[run_chain] 步骤失败：%s" % exc, file=sys.stderr)
        return 1

    # 兼容旧行为：把链路日志另写一份 chain_log.json
    suffix = "" if args.gap_fill == "none" else "_" + args.gap_fill
    with open(HERE / ("chain_log%s.json" % suffix), "w", encoding="utf-8") as f:
        json.dump(res["run_log"], f, ensure_ascii=False, indent=2)

    print("\n" + "=" * 56)
    print("链路汇总")
    print("=" * 56)
    for k, v in res["summary"].items():
        if k == "report":
            continue
        print("  %-22s %s" % (k, v))
    print("\n统一对象 -> %s" % res["unified_path"])
    print("运行日志 -> %s" % res["run_log_path"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
