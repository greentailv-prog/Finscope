#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A 抽取结果 -> B（financial-diagnosis）输入。

A 的输出是「单条记录 + value + series{年份:值}」，B 要的是
「指标名 -> {期间 -> {value, unit, source, page}}」的多期嵌套。
本脚本把 A 的 series 展开成 B 要的多期结构，字段名按 B 的 INPUT_SCHEMA.md 对齐。
A 没有的 B 字段不出现（B 会把它标成 not_evaluable，不编造）。

只读 A 的输出，不改 A/B 的任何代码。只用标准库。

用法：
    python to_b_input.py --a <A.json> --out <b_input.json>
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

# A 的科目键 -> B 的科目键（依据 B 的 INPUT_SCHEMA.md 字段清单与接口对齐方案 2.1）。
# A 的 operating_cost / cfo / cfi / cff 在 B 里换了名字，其余同名。
A_TO_B = {
    "revenue": "revenue",
    "operating_cost": "cost_of_revenue",      # B 叫 cost_of_revenue
    "net_profit": "net_income",               # 全口径净利润
    "net_profit_attr": "net_income_parent",   # 归母
    "net_profit_deducted": "net_income_deducted",
    "total_assets": "total_assets",
    "total_liabilities": "total_liabilities",
    "equity_attr": "equity_parent",
    "cash": "cash_and_equivalents",
    "accounts_receivable": "accounts_receivable",
    "inventory": "inventory",
    "goodwill": "goodwill",
    "cfo": "ocf",                             # B 叫 ocf
    "cfi": "cf_investing",                    # B 叫 cf_investing
    "cff": "cf_financing",                    # B 叫 cf_financing
    "rd_expense": "rd_expense",
    "capex": "capex",
}

# B 的 INPUT_SCHEMA 完整字段清单（用于在日志里报「A 没给哪些」）。
B_FIELDS = [
    "revenue", "cost_of_revenue", "operating_profit", "pretax_profit",
    "income_tax_expense", "net_income", "net_income_parent", "net_income_deducted",
    "selling_expense", "admin_expense", "rd_expense", "finance_expense",
    "interest_expense", "depreciation_amortization", "impairment_loss", "rd_capitalized",
    "cash_and_equivalents", "restricted_cash", "accounts_receivable", "notes_receivable",
    "contract_assets", "inventory", "total_current_assets", "fixed_assets", "goodwill",
    "total_assets", "accounts_payable", "total_current_liabilities", "short_term_borrowings",
    "current_portion_lt_debt", "long_term_borrowings", "bonds_payable", "total_liabilities",
    "equity_parent", "total_equity", "ocf", "cf_investing", "cf_financing", "capex",
    "cash_received_from_sales", "interest_paid", "dividend_paid",
]


def strip_year(raw):
    """'2025年度' -> '2025'；'2025' -> '2025'。"""
    if raw is None:
        return None
    m = re.match(r"^(\d{4})", str(raw).strip())
    return m.group(1) if m else str(raw)


def _series_of(rec):
    """取一条 A 记录的 {年份:值}。series 缺失时，若有单值则退回单期。"""
    series = rec.get("series") or {}
    out = {}
    for y, v in series.items():
        if v is not None:
            out[str(y)] = v
    if not out and rec.get("status") == "found" and rec.get("value") is not None:
        y = strip_year(rec.get("period"))
        if y:
            out[y] = rec["value"]
    return out


def build(a_obj):
    """返回 (b_input_obj, report)。report 记录映射明细与缺口，供运行日志用。"""
    company = a_obj.get("company", {}) or {}
    fin = a_obj.get("financials", {}) or {}

    # 1) 期间：A 所有 series 里出现过的年份，升序。
    years = set()
    for rec in fin.values():
        years.update(_series_of(rec).keys())
    periods = sorted(years)

    # 2) 逐科目展开成「期间 -> 单元格」
    financials = {}
    mapped = {}
    for a_key, rec in fin.items():
        b_key = A_TO_B.get(a_key)
        if b_key is None:
            continue
        series = _series_of(rec)
        if not series:
            continue
        cells = {}
        for y, v in series.items():
            cells[y] = {
                "value": v,
                "unit": "元",
                "source": rec.get("source"),
                "page": rec.get("page"),
            }
        financials[b_key] = {y: cells[y] for y in sorted(cells)}
        mapped[b_key] = sorted(cells)

    given = sorted(financials)
    missing = [f for f in B_FIELDS if f not in financials]
    report = {
        "periods": periods,
        "given_fields": given,
        "given_count": len(given),
        "missing_fields": missing,
        "missing_count": len(missing),
        "cells_per_field": mapped,
    }

    meta = {
        "schema_version": "finradar.extraction/1.0",
        "default_unit": "元",
        "currency": "CNY",
        "periods": periods,
        "report_period": periods[-1] if periods else strip_year(company.get("report_period")),
        # WACC 第一趟不给：留给编排层用 C 的产出回填，第二趟重算（接口对齐方案第 6 节）。
        "wacc": None,
        "days_in_year": 365,
        "industry": company.get("industry"),
        # 行业毛利率基准由 C 从可比公司池回填，这里留空 -> P06 不可评估。
        "industry_gross_margin_benchmark": None,
        # A 未抽审计意见 -> A03 不可评估（不编造）。
        "audit_opinion": None,
    }

    b_company = {
        "name": company.get("name"),
        "ticker": company.get("ticker"),
        "industry": company.get("industry"),
        "report_period": periods[-1] if periods else None,
    }

    return {
        "schema_version": "finradar.extraction/1.0",
        "meta": meta,
        "company": b_company,
        "financials": financials,
    }, report


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description="A 抽取结果 -> B 输入转换器")
    ap.add_argument("--a", required=True, help="A 的抽取结果 JSON")
    ap.add_argument("--out", default=os.path.join(here, "b_input.json"))
    ap.add_argument("--pretty", action="store_true", default=True)
    args = ap.parse_args()

    with open(args.a, "r", encoding="utf-8") as f:
        a_obj = json.load(f)
    b_input, report = build(a_obj)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(b_input, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print("[OK] A -> B 输入 -> %s" % args.out)
    print("     期间: %s   科目: %d 个" % (report["periods"], report["given_count"]))
    print("     已给: %s" % ", ".join(report["given_fields"]))
    print("     缺 %d 个（B 标 not_evaluable）: %s"
          % (report["missing_count"], ", ".join(report["missing_fields"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
