# FinScope D 分支 · 数据适配层

把 A / B / C 三家格式各异的产物拉成同一个统一数据对象（七键）。
只读三家的输出文件，不改三家代码。只用 Python 标准库。

依据：「接口对齐方案.md」与「SCHEMA.md / Schema.json」。

## 目录

```
agent/
├── adapters/
│   ├── __init__.py      适配器导出
│   ├── _util.py         共用工具：读 JSON、按单位统一精度、截报告期
│   ├── from_a.py        A 抽取结果 -> company / financials / sources
│   ├── from_b.py        B 指标与风险   -> ratios / risks / rules_evaluated
│   └── from_c.py        C 估值输出     -> valuation
├── orchestrator.py      三段拼装 + company 合并 + sources 归集 + WACC 回填
├── run_pipeline.py      命令行入口
├── tests/test_adapters.py   用三家真实样例的 40 项测试
└── output/              运行产物（unified.json、run_log.json），可删
```

## 怎么用

```bash
# 缺省用三家现在的样例文件
python run_pipeline.py

# 指定文件
python run_pipeline.py --a <A.json> --b-ratios <ratios.json> \
    --b-risks <risks.json> --c <c.json> \
    --out output/unified.json --log output/run_log.json

# 跑测试
python -m unittest discover -s tests -v
```

产出两个文件：

- `unified.json`：统一对象，顶层固定七键
  `company / financials / ratios / risks / rules_evaluated / valuation / sources`
- `run_log.json`：运行日志。记了「B 跑过两趟」，以及公司不一致等告警。
  日志单独存，是因为顶层必须锁死七键，不能塞第八个。

## 当前跑到什么程度

用三家现有样例跑得通，40 项测试全过。

| 段 | 状态 | 说明 |
|---|---|---|
| A -> company/financials/sources | 通 | 17 个科目全映射；缺的 9 个科目按已定案不补 |
| B -> ratios | 通 | 65 个 B 指标全部落到输出，键名映射后；加我独有的 3 个空值，共 68 键 |
| B -> risks/rules_evaluated | 通 | 按 status 分流：triggered 进 risks，其余进 rules_evaluated |
| C -> valuation | 通 | 五块 + 行情/警告/来源/免责，字段名与层级对齐 |
| 编排 | 通 | 七键、company 合并、sources 归集、WACC 回填重算 |

**样例是拼的，不是真链路。** A 是贵州茅台，B 是华衍智能装备（B 自带 demo 输入），
C 是贵州茅台（C 自带输入）。所以现在统一对象里的 financials 与 ratios 不是同一家、
也不是由同一份输入算出来的。要让链路真的串起来，得把 A 的输出喂进 B 的代码跑一遍、
再把 A+B 喂进 C 跑一遍——这一步不能在我们的适配层里做（不许跑三家代码）。
编排层已能容忍三段用不同公司的样例（只记告警不报错）。

## WACC 的环怎么解的

按接口对齐方案第 6 节。`roic_minus_wacc` 与依赖 WACC 的风险规则，B 在 C 前面跑却要用 C 的产出。

1. 第一趟：`from_b` 把 `roic_minus_wacc` 及所有引用 wacc 的风险规则标 `not_evaluable`，
   规则落到 `rules_evaluated`。
2. 回填：编排层把 C 的 `valuation.dcf.inputs.wacc` 写回对象。
3. 第二趟：编排层重算 `roic_minus_wacc = roic - wacc`，再用原始比较表达式重判
   依赖 WACC 的规则，翻成 triggered 或 passed，重新分流。

跑样例的结果：B 自带 demo 里 P03（roe<wacc）、P04（roic_minus_wacc<0）在 B 内部
用 wacc=0.085 判过；回填 C 的 wacc=0.0588 后，两条都翻成 passed
（roic_minus_wacc 由负转正 0.0113）。这正说明回填这趟不是摆设。

## 已定案的落点

- 金额单位一律「元」，×1e6 换算只对旧口径；三家现输出本就是元，不做换算。
- 比率四位小数；倍数/天数/次数两位；元两位。
- unit 取值：元 / 小数 / 倍 / 天 / 次，另留「股」「元/股」。
- 周转率类（ar/inventory/ap/total_asset/fixed_asset turnover）标「次」，其余倍率类标「倍」。
- A 缺的 9 个科目留空、标 not_evaluable，不编造。
- 风险按 `status == "triggered"` 分流。

## 映射表没写清、我自己判断的地方（请 D 复核）

1. **A 的 货币资金 / 存货 在茅台样例里抽错了。** A 取到了「占总资产比」那一列：
   货币资金 value=17.01、存货 value=20.22，实际金额应是 51690610946.50 / 61427421796.18
   （A 的 `cross_check` 里有正确值）。美的样例的货币资金是对的（85247150000）。
   适配层照实映射，没去改。**这会直接带错 B 的现金类指标和 C 的 DCF 桥接，要退给 A 修。**

2. **WACC 规则的编号对不上。** 方案第 6 节说依赖 WACC 的是 `roic_minus_wacc` 及
   P06 / P03 / B12。实际 B 输出里：P03 是 roe<wacc、P04 是 roic_minus_wacc<0，
   没有 B12，P06 是「毛利率 vs 行业中位数」（与 WACC 无关）。
   编排层改成**按内容动态识别**（trigger/trigger_values 里出现 wacc 或 roic_minus_wacc），
   不写死编号。

3. **`trigger` 字段存中文还是英文表达式。** SCHEMA 要「触发条件原文」，B 同时给了
   英文表达式和中文展示（trigger_display）。我给 `trigger` 存中文展示（给人看），
   另存内部字段 `_trigger_expr` 存英文表达式给第二趟求值。若 D 要英文原文，改一处即可。

4. **B 没有独立的 rule_id。** 风险卡的编号键就是 `risk_id`。rules_evaluated 里
   `rule_id` 直接取 B 的 `risk_id`。

5. **text_evidence.quote 只能写 null。** B 没有原文引用片段，「出处」层只有来源名和页码。
   我填 `{"quote": null, "page": 首页码, "sources": [...], "pages": [...]}`。

6. **numeric_evidence 是从「判断」层拼的。** B 没有 SCHEMA 例子里那种带数字的一句话证据，
   我用「判断」层的 item 文本 + result，形如 `……（触发）`。信息量弱于示例。

7. **involved_values 的 unit / page 靠推断。** B 的 trigger_values 只有 {名字: 数值}。
   unit 从 ratios 的单位表反查，查不到默认「小数」；page 从证据链数据层或 evidence
   子树取，派生比率（如 xxx_growth）取不到就 null。

8. **DCF 的 valuation_range 是我拼的。** C 没有 DCF 区间对象。我用 C 敏感性矩阵的
   min/max 当 low/high，C 的每股 `per_share` 当 mid。数值全部来自 C，没有新增计算。

9. **dcf.inputs 的 da / capex / nwc 由百分比还原成元。** C 给的是 da_pct / capex_pct /
   nwc_pct（占收入比），SCHEMA 要元。乘以 revenue_base（取 C 相对估值里的营业收入
   metric_value，与 rows 自洽）还原。

10. **company 缺字段的处理。** exchange / report_type / currency / amount_unit
    由 ticker 前缀和报告标题推：6→.SH→上海证券交易所·CNY，0/3→.SZ→深圳·CNY，
    标题含「年度报告」则 report_type=年度报告。auditor 留 null（A 没抽）。
    audit_opinion 由 B 的 meta.audit_opinion 补（接口对齐方案 3.5）。这些算推导不算编造。

11. **A 只抽 17 个科目，缺的 9 个我用「不出现该键」而不是「null」表示。** 
    即 financials 里没有 selling_expense 等键；依赖它们的 13 个比率应由 B 标 not_evaluable。

12. **在 SCHEMA 九字段之外加了少量扩展键**（带 `_` 前缀或单列）：
    financials 记录的 `status`（保留 A 的 found/not_applicable）、sources 的 `source`、
    风险卡的 `_trigger_expr`、blended/scenarios 的 levers 等原样保留字段。都是超集不冲突。

## 会让第三步（真串链路）失败的坑

1. **三家输入不是同一条链。** 现在 ratios / valuation 各自来自 B/C 自带的输入，
   与 A 的茅台无关。真串链路必须重跑 B、C，把 A 的输出喂进去——这步在 D 的适配层之外。
2. **formula 的名字对不上。** SCHEMA 要求 ratios 的 formula 引用 financials 的键名。
   B 的 formula 用的是自己的变量名（revenue_t、ni_parent_t…），不是我的科目键，也没页码。
   跨段校验过不去，要 B 按统一键名重写 formula。
3. **A 的 22 个补抽科目还没有。** 依赖它们的 13 个比率、多条风险规则、C 的部分 DCF 输入
   会缺。中期按已定案标 not_evaluable，但真交付必须补数。
4. **A 的货币资金/存货抽错**（见上）会污染 B 现金比、净负债和 C 的现金桥。
5. **roe_weighted 口径未核。** 已定案「B 的 roe 即我的 roe_weighted，归母 / 平均归母净资产」，
   但我没有 B 的代码，无法确认 B 的 roe 到底是加权还是平均。formula 里要注明。
6. **C 的 range_low/high 是股权价值总额。** 已按每股换算进 comps.valuation_range；
   若 E 或交接文档仍直接拿旧字段当股价，会差三个数量级。
7. **`company` 段三家都有，冲突时以 A 为主。** 现在只看告警，真接入后要定谁优先、
   industry 取谁（A「食品饮料-白酒」 vs C「白酒」）。

## 测试覆盖（40 项，全过）

- 每个适配器单独跑不报错，输出结构对照 Schema.json（company 十字段、financials 九字段、
  valuation 九块、ratios 六类）。
- 比率条数：B 的 65 个指标全部出现且是映射后的键名，总数 68。
- 三个撞名映射对：net_margin/net_margin_total、net_income_total_growth、
  cfo_to_net_income_total。
- 单位换算抽查：ratio→小数、x→倍/次（周转率类判次）、days→天、CNY→元。
- 风险分流：risks 全为 triggered，其余在 rules_evaluated，两处合计 40。
- 顶层七键，且无第八键。
- WACC 回填后 roic_minus_wacc = roic - wacc，第二趟重判生效，日志记 b_passes=2。
- C 映射抽查：range_low/high 换成每股（407.63 / 660.13）、forecast 补 year 2026–2030、
  终值收拢、sensitivity 收进 dcf、blended 组件 relative→comps。
