"""FinScope D 分支：命令行入口。

吃四个文件路径（A 结果、B 指标、B 风险、C 估值），吐一个统一对象 JSON。
参数缺省时用三家现在的样例文件。

用法：
    python run_pipeline.py
    python run_pipeline.py --a <A.json> --b-ratios <ratios.json> \
        --b-risks <risks.json> --c <c.json> --out <unified.json>

注意：本脚本只读三家的输出文件，不执行 A/B/C 的代码。
"""

import argparse
import json
import os
import sys

# 允许从任意工作目录运行
HERE = os.path.dirname(os.path.abspath(__file__))            # .../D分支文件/agent
sys.path.insert(0, HERE)
_D_ROOT = os.path.dirname(HERE)                              # .../D分支文件
if _D_ROOT not in sys.path:
    sys.path.insert(0, _D_ROOT)

from adapters._util import load_json  # noqa: E402
from orchestrator import run  # noqa: E402
from server import config  # noqa: E402

# 三家真实样例的缺省路径（全部来自 server/config.py，本文件不再写盘符）
DEFAULT_A = str(config.A_EXTRACTED / "贵州茅台_600519_2025.json")
DEFAULT_B_RATIOS = str(config.B_DIAGNOSIS / "demo" / "output_ratios.json")
DEFAULT_B_RISKS = str(config.B_RISK_RADAR / "demo" / "output_risks.json")
DEFAULT_C = str(config.C_VALUATION / "demo" / "output_sample.json")


def _parse_args(argv=None):
    here = os.path.dirname(os.path.abspath(__file__))
    p = argparse.ArgumentParser(description="FinScope 数据适配层命令行入口")
    p.add_argument("--a", default=DEFAULT_A, help="A 的抽取结果 JSON")
    p.add_argument("--b-ratios", default=DEFAULT_B_RATIOS, help="B 的指标输出 JSON")
    p.add_argument("--b-risks", default=DEFAULT_B_RISKS, help="B 的风险输出 JSON")
    p.add_argument("--c", default=DEFAULT_C, help="C 的估值输出 JSON")
    p.add_argument("--out", default=os.path.join(here, "output", "unified.json"),
                   help="统一对象输出路径")
    p.add_argument("--log", default=os.path.join(here, "output", "run_log.json"),
                   help="运行日志输出路径")
    p.add_argument("--print", dest="do_print", action="store_true",
                   help="同时把统一对象打到标准输出")
    return p.parse_args(argv)


def main(argv=None):
    args = _parse_args(argv)

    a_obj, err = load_json(args.a)
    if err:
        print("读 A 失败：" + err, file=sys.stderr)
        return 2
    b_ratios, err = load_json(args.b_ratios)
    if err:
        print("读 B 指标失败：" + err, file=sys.stderr)
        return 2
    b_risks, err = load_json(args.b_risks)
    if err:
        print("读 B 风险失败：" + err, file=sys.stderr)
        return 2
    c_obj, err = load_json(args.c)
    if err:
        print("读 C 失败：" + err, file=sys.stderr)
        return 2

    obj, log = run(a_obj, b_ratios, b_risks, c_obj)

    for path, payload in ((args.out, obj), (args.log, log)):
        if path:
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)

    if args.do_print:
        print(json.dumps(obj, ensure_ascii=False, indent=2))

    print("完成。统一对象 -> %s" % args.out)
    print("运行日志   -> %s" % args.log)
    print("company   = %s" % (obj["company"].get("name"),))
    print("financials= %d 条" % len(obj["financials"]))
    print("ratios    = %d 条" % sum(len(v) for v in obj["ratios"].values()))
    print("risks     = %d 条，rules_evaluated = %d 条"
          % (len(obj["risks"]), len(obj["rules_evaluated"])))
    print("sources   = %d 条" % len(obj["sources"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
