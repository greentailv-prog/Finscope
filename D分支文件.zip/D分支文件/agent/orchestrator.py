"""把 A / B / C 三段拼成统一对象，处理 WACC 回填。

顶层七键固定：company / financials / ratios / risks / rules_evaluated / valuation / sources。

WACC 的环按接口对齐方案第 6 节解：
  第一趟  A -> B（WACC 相关项标 not_evaluable）-> C（产出 WACC）
  回填    把 C 的 dcf.wacc 写回 valuation.dcf
  第二趟  只重算 ratios.roic_minus_wacc 与依赖 WACC 的风险规则，其余不动
「B 跑过两趟」记进运行日志（run_log，单独返回，不塞进七键对象）。
"""

import re

from adapters import adapt_a, adapt_b, adapt_c
from adapters.from_b import RATIO_RENAME, WACC_TOKENS


# company 的十个字段。合并时以 A 的为主，B/C 补 A 没有的。
COMPANY_FIELDS = (
    "name", "ticker", "industry", "report_period", "exchange",
    "report_type", "auditor", "audit_opinion", "currency", "amount_unit",
)

_CMP = re.compile(
    r"^\s*([A-Za-z_][A-Za-z0-9_]*|-?\d+(?:\.\d+)?)\s*"
    r"(<=|>=|==|<|>)\s*"
    r"([A-Za-z_][A-Za-z0-9_]*|-?\d+(?:\.\d+)?)\s*$"
)


def _merge_company(a_company, *others):
    """以 A 为主，B/C 补 A 为空的字段。都不补得出就留 None。"""
    out = {}
    a_company = a_company or {}
    for field in COMPANY_FIELDS:
        val = a_company.get(field)
        if val is None:
            for other in others:
                if other and other.get(field) is not None:
                    val = other[field]
                    break
        out[field] = val
    return out


def _collect_sources(a_sources, company, risks):
    """顶层 sources：A 的记录页码，再补上风险卡引用的页码（接口对齐方案 7.3-3）。"""
    entries = list(a_sources or [])
    have = {e.get("page") for e in entries}
    file_name = entries[0].get("file_name") if entries else None

    for card in risks or []:
        pages = set()
        te = card.get("text_evidence") or {}
        if te.get("page") is not None:
            pages.add(te["page"])
        for p in te.get("pages") or []:
            pages.add(p)
        for step in card.get("evidence_chain") or []:
            if step.get("step") == "出处":
                for p in step.get("pages") or []:
                    pages.add(p)
            if step.get("page") is not None:
                pages.add(step["page"])
        for p in sorted(pages):
            if p not in have:
                have.add(p)
                entries.append({
                    "company_name": company.get("name"),
                    "report_period": company.get("report_period"),
                    "file_name": file_name,
                    "page": p,
                    "retrieved_at": None,
                    "source_url": None,
                    "source": "风险诊断证据链",
                })
    return sorted(entries, key=lambda e: (e.get("page") is None, e.get("page")))


def _ratio_values(obj):
    """构造指标名 -> 值的字典，含我的键名与 B 的原键名，供触发表达式求值。"""
    values = {}
    reverse = {v: k for k, v in RATIO_RENAME.items()}  # 我的键 -> B 原键
    for _cat, items in (obj.get("ratios") or {}).items():
        for key, rec in (items or {}).items():
            if isinstance(rec, dict) and "value" in rec:
                values[key] = rec.get("value")
                b_name = reverse.get(key)
                if b_name:
                    values[b_name] = rec.get("value")
    return values


def _eval_trigger(expr, values):
    """求值一个简单比较表达式（如 'roe < wacc'）。返回 True/False/None（未知）。"""
    if not expr:
        return None
    m = _CMP.match(expr.strip())
    if not m:
        return None
    left, op, right = m.groups()

    def operand(tok):
        if re.match(r"^-?\d", tok):
            return float(tok)
        return values.get(tok)

    a, b = operand(left), operand(right)
    if a is None or b is None:
        return None
    return {
        "<": a < b, ">": a > b, "<=": a <= b, ">=": a >= b, "==": a == b,
    }[op]


def _card_is_wacc(card):
    blob = "%s %s %s %s" % (
        card.get("trigger") or "",
        card.get("_trigger_expr") or "",
        card.get("trigger_display") or "",
        " ".join((card.get("trigger_values") or {}).keys()),
    )
    low = blob.lower()
    return any(tok in low for tok in WACC_TOKENS)


def _trigger_of(card):
    """取可求值的比较表达式。优先内部保留的 B 原始表达式。"""
    return card.get("_trigger_expr") or card.get("trigger")


def recompute_wacc(obj, c_wacc, log):
    """回填 C 的 WACC，重算 B 里依赖 WACC 的部分（第二趟）。"""
    if c_wacc is None:
        log["notes"].append("C 未产出 WACC，第二趟跳过，WACC 相关项保持 not_evaluable。")
        return obj

    # 1. 写回 valuation.dcf
    dcf = (obj.get("valuation") or {}).get("dcf") or {}
    if isinstance(dcf.get("inputs"), dict):
        dcf["inputs"]["wacc"] = c_wacc
    if isinstance(dcf.get("terminal_assumptions"), dict):
        dcf["terminal_assumptions"]["wacc"] = c_wacc

    # 2. 重算 ratios.roic_minus_wacc
    prof = (obj.get("ratios") or {}).get("profitability") or {}
    rmw = prof.get("roic_minus_wacc")
    roic = prof.get("roic") or {}
    if isinstance(rmw, dict) and roic.get("value") is not None:
        new_val = round(roic["value"] - c_wacc, 4)
        rmw["value"] = new_val
        rmw["unit"] = "小数"
        rmw["status"] = "ok"
        rmw["inputs"] = {"roic": roic["value"], "wacc": c_wacc}
        if roic.get("prev") is not None:
            rmw["prev"] = round(roic["prev"] - c_wacc, 4)
            rmw["delta"] = round(new_val - rmw["prev"], 4)
        log["notes"].append("已重算 ratios.roic_minus_wacc = roic - wacc(%.6f)。" % c_wacc)

    # 3. 重判依赖 WACC 的风险规则
    values = _ratio_values(obj)
    values["wacc"] = c_wacc
    if isinstance(rmw, dict) and rmw.get("value") is not None:
        values["roic_minus_wacc"] = rmw["value"]

    risks = obj.get("risks") or []
    rules = obj.get("rules_evaluated") or []
    new_risks, new_rules = [], []
    rejudged = 0
    for card in rules:
        if not _card_is_wacc(card):
            new_rules.append(card)
            continue
        rejudged += 1
        _update_wacc_values(card, values, c_wacc)
        verdict = _eval_trigger(_trigger_of(card), values)
        if verdict is True:
            card["status"] = "triggered"
            card["_wacc_second_pass"] = True
            new_risks.append(card)
        else:
            card["status"] = "passed" if verdict is False else "not_evaluable"
            new_rules.append(card)
    for card in risks:
        if not _card_is_wacc(card):
            new_risks.append(card)
            continue
        rejudged += 1
        _update_wacc_values(card, values, c_wacc)
        verdict = _eval_trigger(_trigger_of(card), values)
        if verdict is True:
            card["status"] = "triggered"
            card["_wacc_second_pass"] = True
            new_risks.append(card)
        else:
            card["status"] = "passed" if verdict is False else "not_evaluable"
            new_rules.append(card)

    obj["risks"] = new_risks
    obj["rules_evaluated"] = new_rules
    log["notes"].append("第二趟重判 %d 条依赖 WACC 的规则。" % rejudged)
    return obj


def _update_wacc_values(card, values, c_wacc):
    """把卡片里的 wacc / roic_minus_wacc 换成回填后的值。"""
    tv = card.get("trigger_values")
    if isinstance(tv, dict):
        if "wacc" in tv:
            tv["wacc"] = c_wacc
        if "roic_minus_wacc" in tv and values.get("roic_minus_wacc") is not None:
            tv["roic_minus_wacc"] = values["roic_minus_wacc"]


def run(a_obj, b_ratios_obj, b_risks_obj, c_obj):
    """跑完整条链路。返回 (统一对象, 运行日志)。

    三家可以用不同公司的样例：company 以 A 为主，差异只记进日志，不报错。
    """
    log = {"b_passes": 2, "notes": [], "steps": [], "warnings": []}

    a_part = adapt_a(a_obj)
    log["steps"].append("A 适配：financials %d 条，sources %d 条。"
                        % (len(a_part["financials"]), len(a_part["sources"])))

    b_part = adapt_b(b_ratios_obj, b_risks_obj)
    n_ratios = sum(len(v) for v in b_part["ratios"].values())
    log["steps"].append("B 适配（第一趟）：ratios %d 条，risks %d 条，rules_evaluated %d 条。"
                        % (n_ratios, len(b_part["risks"]), len(b_part["rules_evaluated"])))

    c_part = adapt_c(c_obj)
    c_wacc = ((c_part.get("valuation") or {}).get("dcf") or {}).get("inputs", {}).get("wacc")
    log["steps"].append("C 适配：产出 WACC = %s。" % c_wacc)

    company = _merge_company(a_part["company"], b_part.get("company"), c_part.get("company"))

    obj = {
        "company": company,
        "financials": a_part["financials"],
        "ratios": b_part["ratios"],
        "risks": b_part["risks"],
        "rules_evaluated": b_part["rules_evaluated"],
        "valuation": c_part["valuation"],
        "sources": [],
    }

    # 校验三家是不是同一家公司（测试阶段会不一致）
    names = {
        "A": a_part["company"].get("name"),
        "B": (b_part.get("company") or {}).get("name"),
        "C": (c_part.get("company") or {}).get("name"),
    }
    if len({n for n in names.values() if n}) > 1:
        log["warnings"].append("三家样例公司不一致：%s。company 以 A 为主，请核对。" % names)

    # 回填 + 第二趟
    recompute_wacc(obj, c_wacc, log)

    # sources：A 的记录页码 + 风险证据页码
    obj["sources"] = _collect_sources(a_part["sources"], company, obj["risks"])

    # 七键完整性自检
    expected = {"company", "financials", "ratios", "risks",
                "rules_evaluated", "valuation", "sources"}
    missing = expected - set(obj.keys())
    extra = set(obj.keys()) - expected
    if missing or extra:
        log["warnings"].append("顶层键异常：缺 %s，多 %s。" % (sorted(missing), sorted(extra)))

    log["notes"].append("B 跑过两趟：第一趟 WACC 相关项 not_evaluable，第二趟回填 C 的 WACC 后重算。")
    return _cap_precision(_strip_internal(obj)), log


def _strip_internal(o):
    """去掉只在链路内部用的字段（下划线打头的键）。

    例如风险卡上的 _trigger_expr，是第二趟重判规则时用的原始表达式，
    对外没有意义，不该随统一对象交给 E。
    """
    if isinstance(o, dict):
        return {k: _strip_internal(v) for k, v in o.items() if not k.startswith("_")}
    if isinstance(o, list):
        return [_strip_internal(v) for v in o]
    return o


def _cap_precision(o, key=None):
    """把数值统一收口到 SCHEMA 3.1 的精度上限：最多四位小数。

    三家来源的精度规则不同，C 的输出里不少数是原始浮点数
    （例如 1431.3032604620216、0.13325673829138696）。
    只在最外层统一收口一次，避免各处漏改。
    已经有单位精度的地方（金额两位、倍数两天两位）round 到四位不会回退。
    """
    if isinstance(o, dict):
        return {k: _cap_precision(v, k) for k, v in o.items()}
    if isinstance(o, list):
        return [_cap_precision(v, key) for v in o]
    if isinstance(o, bool) or o is None:
        return o
    if isinstance(o, int):
        return o
    if isinstance(o, float):
        return round(o, 4)
    return o
