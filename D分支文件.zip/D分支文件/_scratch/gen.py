# -*- coding: utf-8 -*-
"""FinScope 统一接口生成器。本脚本产出 Schema.json，并跑自检。
放在 _scratch 目录，不写进 output。
"""
import json, math, sys

OUT_JSON = r"D:\浏览器下载\AI网页搭建文件\D分支文件\output\Schema.json"

def R4(x): return round(x, 4)
def R2(x): return round(x, 2)
def AMT(x):
    x = round(x, 2)
    if x == int(x):
        return int(x)
    return x

# ---------------- 财务数值快照（元） ----------------
d = dict(
    revenue=18650000000, operating_cost=13340000000, selling_expense=1120000000,
    admin_expense=840000000, rnd_expense=980000000, operating_profit=2210000000,
    net_income_parent=1580000000, net_income_excl_nonrecurring=1360000000, net_income=1700000000,
    total_assets=26800000000, current_assets=16800000000, total_liabilities=11260000000,
    current_liabilities=9250000000, equity_parent=15540000000, cash_and_equivalents=4150000000,
    accounts_receivable=3860000000, inventory=4420000000, accounts_payable=3350000000,
    goodwill=1280000000, interest_bearing_debt=6050000000, capex=1680000000,
    depreciation_amortization=1200000000, cfo=1520000000, cfi=-1850000000, cff=210000000,
    cash_received_from_sales=20500000000,
    finance_expense=213000000, income_tax_expense=380000000, pretax_profit=2080000000,
    interest_expense=205000000, short_term_borrowings=3000000000, current_portion_lt_debt=650000000,
    long_term_borrowings=2100000000, bonds_payable=300000000, restricted_cash=420000000,
    fixed_assets=6300000000, notes_receivable=350000000, contract_assets=120000000,
    interest_paid=195000000, dividend_paid=550000000, minority_interest=210000000,
)
d0 = dict(
    revenue=16800000000, operating_cost=12180000000, selling_expense=1040000000,
    admin_expense=760000000, rnd_expense=820000000, operating_profit=1940000000,
    net_income_parent=1320000000, net_income_excl_nonrecurring=1100000000, net_income=1430000000,
    total_assets=24600000000, current_assets=15200000000, total_liabilities=10340000000,
    current_liabilities=8600000000, equity_parent=14260000000, cash_and_equivalents=4270000000,
    accounts_receivable=3050000000, inventory=3800000000, accounts_payable=2900000000,
    goodwill=1280000000, interest_bearing_debt=5400000000, capex=1400000000,
    depreciation_amortization=1100000000, cfo=1650000000, cfi=-1580000000, cff=150000000,
    cash_received_from_sales=18200000000,
    finance_expense=180000000, income_tax_expense=310000000, pretax_profit=1740000000,
    interest_expense=175000000, short_term_borrowings=2700000000, current_portion_lt_debt=560000000,
    long_term_borrowings=1900000000, bonds_payable=240000000, restricted_cash=400000000,
    fixed_assets=5800000000, notes_receivable=280000000, contract_assets=100000000,
    interest_paid=170000000, dividend_paid=200000000, minority_interest=200000000,
)
d2 = dict(
    revenue=14900000000, operating_cost=10900000000, selling_expense=930000000,
    admin_expense=700000000, rnd_expense=720000000, operating_profit=1720000000,
    net_income_parent=1080000000, net_income_excl_nonrecurring=900000000, net_income=1180000000,
    total_assets=22600000000, current_assets=13800000000, total_liabilities=9500000000,
    current_liabilities=8000000000, equity_parent=13100000000, cash_and_equivalents=3600000000,
    accounts_receivable=2450000000, inventory=3300000000, accounts_payable=2500000000,
    goodwill=1180000000, interest_bearing_debt=4800000000, capex=1200000000,
    depreciation_amortization=1000000000, cfo=1400000000, cfi=-1300000000, cff=120000000,
    cash_received_from_sales=16000000000,
    finance_expense=150000000, income_tax_expense=250000000, pretax_profit=1430000000,
    interest_expense=150000000, short_term_borrowings=2400000000, current_portion_lt_debt=520000000,
    long_term_borrowings=1600000000, bonds_payable=280000000, restricted_cash=350000000,
    fixed_assets=5600000000, notes_receivable=220000000, contract_assets=90000000,
    interest_paid=140000000, dividend_paid=120000000, minority_interest=100000000,
)

WACC = 0.0800

def ebit(v): return v['operating_profit'] + v['finance_expense']
def txe(v): return v['income_tax_expense'] / v['pretax_profit']
def nopat(v): return ebit(v) * (1 - txe(v))
def invcap(v, vp): return (v['interest_bearing_debt'] + vp['interest_bearing_debt']) / 2 + (v['equity_parent'] + vp['equity_parent']) / 2
def roic_f(v, vp): return nopat(v) / invcap(v, vp)
def avg(v, vp, k): return (v[k] + vp[k]) / 2

# ---------------- 财务科目记录 ----------------
def fin(key, value, unit, period, prior, prior_p, scope, page, source, conf):
    return dict(value=value, unit=unit, period=period, prior_value=prior, prior_period=prior_p,
               scope=scope, page=page, source=source, confidence=conf)

F = {}
F_meta = [
    ('revenue', d['revenue'], d0['revenue'], '累计数', 82, '2025年年度报告', 0.98),
    ('operating_cost', d['operating_cost'], d0['operating_cost'], '累计数', 82, '2025年年度报告', 0.98),
    ('selling_expense', d['selling_expense'], d0['selling_expense'], '累计数', 84, '2025年年度报告', 0.97),
    ('admin_expense', d['admin_expense'], d0['admin_expense'], '累计数', 84, '2025年年度报告', 0.97),
    ('rnd_expense', d['rnd_expense'], d0['rnd_expense'], '累计数', 85, '2025年年度报告', 0.96),
    ('operating_profit', d['operating_profit'], d0['operating_profit'], '累计数', 86, '2025年年度报告', 0.97),
    ('net_income_parent', d['net_income_parent'], d0['net_income_parent'], '累计数', 87, '2025年年度报告', 0.98),
    ('net_income', d['net_income'], d0['net_income'], '累计数', 87, '2025年年度报告', 0.97),
    ('net_income_excl_nonrecurring', d['net_income_excl_nonrecurring'], d0['net_income_excl_nonrecurring'], '累计数', 88, '2025年年度报告（主要会计数据）', 0.95),
    ('total_assets', d['total_assets'], d0['total_assets'], '期末数', 60, '2025年年度报告', 0.99),
    ('current_assets', d['current_assets'], d0['current_assets'], '期末数', 60, '2025年年度报告', 0.98),
    ('total_liabilities', d['total_liabilities'], d0['total_liabilities'], '期末数', 61, '2025年年度报告', 0.99),
    ('current_liabilities', d['current_liabilities'], d0['current_liabilities'], '期末数', 61, '2025年年度报告', 0.98),
    ('equity_parent', d['equity_parent'], d0['equity_parent'], '期末数', 62, '2025年年度报告', 0.99),
    ('cash_and_equivalents', d['cash_and_equivalents'], d0['cash_and_equivalents'], '期末数', 60, '2025年年度报告', 0.98),
    ('accounts_receivable', d['accounts_receivable'], d0['accounts_receivable'], '期末数', 60, '2025年年度报告', 0.97),
    ('inventory', d['inventory'], d0['inventory'], '期末数', 60, '2025年年度报告', 0.97),
    ('accounts_payable', d['accounts_payable'], d0['accounts_payable'], '期末数', 61, '2025年年度报告', 0.97),
    ('goodwill', d['goodwill'], d0['goodwill'], '期末数', 63, '2025年年度报告（附注）', 0.95),
    ('interest_bearing_debt', d['interest_bearing_debt'], d0['interest_bearing_debt'], '期末数', 64, '2025年年度报告（借款附注汇总）', 0.92),
    ('capex', d['capex'], d0['capex'], '累计数', 70, '2025年年度报告', 0.96),
    ('depreciation_amortization', d['depreciation_amortization'], d0['depreciation_amortization'], '累计数', 71, '2025年年度报告（附注）', 0.93),
    ('cfo', d['cfo'], d0['cfo'], '累计数', 68, '2025年年度报告', 0.98),
    ('cfi', d['cfi'], d0['cfi'], '累计数', 69, '2025年年度报告', 0.98),
    ('cff', d['cff'], d0['cff'], '累计数', 70, '2025年年度报告', 0.98),
    ('cash_received_from_sales', d['cash_received_from_sales'], d0['cash_received_from_sales'], '累计数', 68, '2025年年度报告', 0.97),
]
for k, val, pv, pg, conf in [(m[0], m[1], m[2], m[4], m[6]) for m in F_meta]:
    pass
for m in F_meta:
    key, val, pv, basis, page, source, conf = m
    F[key] = dict(value=AMT(val), unit="元", period="2025", prior_value=AMT(pv),
                  prior_period="2024", scope="合并报表", page=page, source=source, confidence=conf)

# ---------------- 指标 ----------------
# 每条: key, category, unit, formula, func(v,vp), page, higher_is_better, inputs, inputs_prev
R = {}
def put(cat, key, unit, formula, fn, page, hib, inputs, inputs_prev):
    v = fn(d, d0)
    p = fn(d0, d2) if fn is not None else None
    if unit == "小数":
        v = R4(v); p = R4(p) if p is not None else None
    elif unit in ("倍", "天", "次"):
        v = R2(v); p = R2(p) if p is not None else None
    elif unit == "元/股":
        v = R2(v); p = R2(p) if p is not None else None
    else:
        v = v; p = p
    setdefault(R, cat, {})[key] = dict(
        value=v, unit=unit, period="2025", formula=formula, page=page,
        prev=p, delta=(R4(v - p) if (p is not None and unit == "小数") else (R2(v - p) if p is not None else None)),
        inputs=inputs, inputs_prev=inputs_prev, status="ok", higher_is_better=hib,
    )
def setdefault(dic, k, default):
    if k not in dic: dic[k] = default
    return dic[k]

cats = ["growth", "profitability", "solvency", "efficiency", "cashflow_quality"]

# growth
put("growth", "revenue_growth_yoy", "小数", "revenue / prior_revenue - 1",
    lambda v, vp: v['revenue']/vp['revenue']-1, 82, True,
    {"revenue": d['revenue'], "prior_revenue": d0['revenue']},
    {"revenue": d0['revenue'], "prior_revenue": d2['revenue']})
put("growth", "net_income_growth_yoy", "小数", "net_income_parent / prior_net_income_parent - 1",
    lambda v, vp: v['net_income_parent']/vp['net_income_parent']-1, 87, True,
    {"net_income_parent": d['net_income_parent'], "prior_net_income_parent": d0['net_income_parent']},
    {"net_income_parent": d0['net_income_parent'], "prior_net_income_parent": d2['net_income_parent']})
put("growth", "net_income_excl_nonrecurring_growth_yoy", "小数", "net_income_excl_nonrecurring / prior_net_income_excl_nonrecurring - 1",
    lambda v, vp: v['net_income_excl_nonrecurring']/vp['net_income_excl_nonrecurring']-1, 88, True,
    {"net_income_excl_nonrecurring": d['net_income_excl_nonrecurring'], "prior_net_income_excl_nonrecurring": d0['net_income_excl_nonrecurring']},
    {"net_income_excl_nonrecurring": d0['net_income_excl_nonrecurring'], "prior_net_income_excl_nonrecurring": d2['net_income_excl_nonrecurring']})
# cagr 特殊
cagr_v = R4((d['revenue']/d2['revenue'])**(1/3)-1)
R['growth']['revenue_cagr_3y'] = dict(value=cagr_v, unit="小数", period="2025",
    formula="(revenue / revenue_2023) ^ (1/3) - 1", page=32, prev=None, delta=None,
    inputs={"revenue": d['revenue'], "revenue_2023": d2['revenue']}, inputs_prev=None,
    status="ok", higher_is_better=True)
put("growth", "cost_of_revenue_growth", "小数", "operating_cost / prior_operating_cost - 1",
    lambda v, vp: v['operating_cost']/vp['operating_cost']-1, 82, None,
    {"operating_cost": d['operating_cost'], "prior_operating_cost": d0['operating_cost']},
    {"operating_cost": d0['operating_cost'], "prior_operating_cost": d2['operating_cost']})
put("growth", "total_assets_growth", "小数", "total_assets / prior_total_assets - 1",
    lambda v, vp: v['total_assets']/vp['total_assets']-1, 60, None,
    {"total_assets": d['total_assets'], "prior_total_assets": d0['total_assets']},
    {"total_assets": d0['total_assets'], "prior_total_assets": d2['total_assets']})
put("growth", "equity_parent_growth", "小数", "equity_parent / prior_equity_parent - 1",
    lambda v, vp: v['equity_parent']/vp['equity_parent']-1, 62, None,
    {"equity_parent": d['equity_parent'], "prior_equity_parent": d0['equity_parent']},
    {"equity_parent": d0['equity_parent'], "prior_equity_parent": d2['equity_parent']})
put("growth", "ocf_growth", "小数", "cfo / prior_cfo - 1",
    lambda v, vp: v['cfo']/vp['cfo']-1, 68, True,
    {"cfo": d['cfo'], "prior_cfo": d0['cfo']},
    {"cfo": d0['cfo'], "prior_cfo": d2['cfo']})
put("growth", "profit_revenue_scissors", "小数", "(revenue / prior_revenue - 1) - (net_income_parent / prior_net_income_parent - 1)",
    lambda v, vp: (v['revenue']/vp['revenue']-1)-(v['net_income_parent']/vp['net_income_parent']-1), 82, False,
    {"revenue_growth": R4(d['revenue']/d0['revenue']-1), "net_income_parent_growth": R4(d['net_income_parent']/d0['net_income_parent']-1)},
    {"revenue_growth": R4(d0['revenue']/d2['revenue']-1), "net_income_parent_growth": R4(d0['net_income_parent']/d2['net_income_parent']-1)})
put("growth", "net_income_total_growth", "小数", "net_income / prior_net_income - 1",
    lambda v, vp: v['net_income']/vp['net_income']-1, 87, True,
    {"net_income": d['net_income'], "prior_net_income": d0['net_income']},
    {"net_income": d0['net_income'], "prior_net_income": d2['net_income']})

# profitability
put("profitability", "gross_margin", "小数", "(revenue - operating_cost) / revenue",
    lambda v, vp: (v['revenue']-v['operating_cost'])/v['revenue'], 82, True,
    {"revenue": d['revenue'], "operating_cost": d['operating_cost']},
    {"revenue": d0['revenue'], "operating_cost": d0['operating_cost']})
put("profitability", "net_margin_total", "小数", "net_income / revenue",
    lambda v, vp: v['net_income']/v['revenue'], 87, True,
    {"net_income": d['net_income'], "revenue": d['revenue']},
    {"net_income": d0['net_income'], "revenue": d0['revenue']})
put("profitability", "net_margin", "小数", "net_income_parent / revenue",
    lambda v, vp: v['net_income_parent']/v['revenue'], 87, True,
    {"net_income_parent": d['net_income_parent'], "revenue": d['revenue']},
    {"net_income_parent": d0['net_income_parent'], "revenue": d0['revenue']})
put("profitability", "net_margin_deducted", "小数", "net_income_excl_nonrecurring / revenue",
    lambda v, vp: v['net_income_excl_nonrecurring']/v['revenue'], 88, True,
    {"net_income_excl_nonrecurring": d['net_income_excl_nonrecurring'], "revenue": d['revenue']},
    {"net_income_excl_nonrecurring": d0['net_income_excl_nonrecurring'], "revenue": d0['revenue']})
put("profitability", "operating_margin", "小数", "operating_profit / revenue",
    lambda v, vp: v['operating_profit']/v['revenue'], 86, True,
    {"operating_profit": d['operating_profit'], "revenue": d['revenue']},
    {"operating_profit": d0['operating_profit'], "revenue": d0['revenue']})
put("profitability", "ebit_margin", "小数", "(operating_profit + finance_expense) / revenue",
    lambda v, vp: (v['operating_profit']+v['finance_expense'])/v['revenue'], 86, True,
    {"operating_profit": d['operating_profit'], "finance_expense": d['finance_expense'], "revenue": d['revenue']},
    {"operating_profit": d0['operating_profit'], "finance_expense": d0['finance_expense'], "revenue": d0['revenue']})
put("profitability", "selling_expense_ratio", "小数", "selling_expense / revenue",
    lambda v, vp: v['selling_expense']/v['revenue'], 84, False,
    {"selling_expense": d['selling_expense'], "revenue": d['revenue']},
    {"selling_expense": d0['selling_expense'], "revenue": d0['revenue']})
put("profitability", "admin_expense_ratio", "小数", "admin_expense / revenue",
    lambda v, vp: v['admin_expense']/v['revenue'], 84, False,
    {"admin_expense": d['admin_expense'], "revenue": d['revenue']},
    {"admin_expense": d0['admin_expense'], "revenue": d0['revenue']})
put("profitability", "rd_expense_ratio", "小数", "rnd_expense / revenue",
    lambda v, vp: v['rnd_expense']/v['revenue'], 85, None,
    {"rnd_expense": d['rnd_expense'], "revenue": d['revenue']},
    {"rnd_expense": d0['rnd_expense'], "revenue": d0['revenue']})
put("profitability", "finance_expense_ratio", "小数", "finance_expense / revenue",
    lambda v, vp: v['finance_expense']/v['revenue'], 84, False,
    {"finance_expense": d['finance_expense'], "revenue": d['revenue']},
    {"finance_expense": d0['finance_expense'], "revenue": d0['revenue']})
put("profitability", "period_expense_ratio", "小数", "(selling_expense + admin_expense + rnd_expense + finance_expense) / revenue",
    lambda v, vp: (v['selling_expense']+v['admin_expense']+v['rnd_expense']+v['finance_expense'])/v['revenue'], 84, False,
    {"selling_expense": d['selling_expense'], "admin_expense": d['admin_expense'], "rnd_expense": d['rnd_expense'], "finance_expense": d['finance_expense'], "revenue": d['revenue']},
    {"selling_expense": d0['selling_expense'], "admin_expense": d0['admin_expense'], "rnd_expense": d0['rnd_expense'], "finance_expense": d0['finance_expense'], "revenue": d0['revenue']})
put("profitability", "roe_weighted", "小数", "net_income_parent / ((equity_parent + prior_equity_parent) / 2)",
    lambda v, vp: v['net_income_parent']/((v['equity_parent']+vp['equity_parent'])/2), 62, True,
    {"net_income_parent": d['net_income_parent'], "equity_parent": d['equity_parent'], "prior_equity_parent": d0['equity_parent']},
    {"net_income_parent": d0['net_income_parent'], "equity_parent": d0['equity_parent'], "prior_equity_parent": d2['equity_parent']})
put("profitability", "roa", "小数", "net_income / ((total_assets + prior_total_assets) / 2)",
    lambda v, vp: v['net_income']/((v['total_assets']+vp['total_assets'])/2), 60, True,
    {"net_income": d['net_income'], "total_assets": d['total_assets'], "prior_total_assets": d0['total_assets']},
    {"net_income": d0['net_income'], "total_assets": d0['total_assets'], "prior_total_assets": d2['total_assets']})
put("profitability", "roic", "小数", "nopat / ((interest_bearing_debt + prior_interest_bearing_debt + equity_parent + prior_equity_parent) / 2), nopat = (operating_profit + finance_expense) * (1 - effective_tax_rate)",
    roic_f, 64, True,
    {"operating_profit": d['operating_profit'], "finance_expense": d['finance_expense'], "effective_tax_rate": txe(d), "interest_bearing_debt": d['interest_bearing_debt'], "prior_interest_bearing_debt": d0['interest_bearing_debt'], "equity_parent": d['equity_parent'], "prior_equity_parent": d0['equity_parent']},
    {"operating_profit": d0['operating_profit'], "finance_expense": d0['finance_expense'], "effective_tax_rate": txe(d0), "interest_bearing_debt": d0['interest_bearing_debt'], "prior_interest_bearing_debt": d2['interest_bearing_debt'], "equity_parent": d0['equity_parent'], "prior_equity_parent": d2['equity_parent']})
put("profitability", "effective_tax_rate", "小数", "income_tax_expense / pretax_profit",
    lambda v, vp: v['income_tax_expense']/v['pretax_profit'], 86, None,
    {"income_tax_expense": d['income_tax_expense'], "pretax_profit": d['pretax_profit']},
    {"income_tax_expense": d0['income_tax_expense'], "pretax_profit": d0['pretax_profit']})
put("profitability", "deducted_to_parent", "小数", "net_income_excl_nonrecurring / net_income_parent",
    lambda v, vp: v['net_income_excl_nonrecurring']/v['net_income_parent'], 88, True,
    {"net_income_excl_nonrecurring": d['net_income_excl_nonrecurring'], "net_income_parent": d['net_income_parent']},
    {"net_income_excl_nonrecurring": d0['net_income_excl_nonrecurring'], "net_income_parent": d0['net_income_parent']})
put("profitability", "ebitda_margin", "小数", "(operating_profit + depreciation_amortization) / revenue",
    lambda v, vp: (v['operating_profit']+v['depreciation_amortization'])/v['revenue'], 71, True,
    {"operating_profit": d['operating_profit'], "depreciation_amortization": d['depreciation_amortization'], "revenue": d['revenue']},
    {"operating_profit": d0['operating_profit'], "depreciation_amortization": d0['depreciation_amortization'], "revenue": d0['revenue']})
put("profitability", "roic_minus_wacc", "小数", "roic - wacc",
    lambda v, vp: roic_f(v, vp)-WACC, 64, True,
    {"roic": R4(roic_f(d, d0)), "wacc": WACC},
    {"roic": R4(roic_f(d0, d2)), "wacc": WACC})

# solvency
put("solvency", "current_ratio", "倍", "current_assets / current_liabilities",
    lambda v, vp: v['current_assets']/v['current_liabilities'], 60, True,
    {"current_assets": d['current_assets'], "current_liabilities": d['current_liabilities']},
    {"current_assets": d0['current_assets'], "current_liabilities": d0['current_liabilities']})
put("solvency", "quick_ratio", "倍", "(current_assets - inventory) / current_liabilities",
    lambda v, vp: (v['current_assets']-v['inventory'])/v['current_liabilities'], 60, True,
    {"current_assets": d['current_assets'], "inventory": d['inventory'], "current_liabilities": d['current_liabilities']},
    {"current_assets": d0['current_assets'], "inventory": d0['inventory'], "current_liabilities": d0['current_liabilities']})
put("solvency", "cash_ratio", "倍", "cash_and_equivalents / current_liabilities",
    lambda v, vp: v['cash_and_equivalents']/v['current_liabilities'], 60, True,
    {"cash_and_equivalents": d['cash_and_equivalents'], "current_liabilities": d['current_liabilities']},
    {"cash_and_equivalents": d0['cash_and_equivalents'], "current_liabilities": d0['current_liabilities']})
put("solvency", "debt_to_asset_ratio", "小数", "total_liabilities / total_assets",
    lambda v, vp: v['total_liabilities']/v['total_assets'], 61, False,
    {"total_liabilities": d['total_liabilities'], "total_assets": d['total_assets']},
    {"total_liabilities": d0['total_liabilities'], "total_assets": d0['total_assets']})
put("solvency", "equity_multiplier", "倍", "total_assets / equity_parent",
    lambda v, vp: v['total_assets']/v['equity_parent'], 62, None,
    {"total_assets": d['total_assets'], "equity_parent": d['equity_parent']},
    {"total_assets": d0['total_assets'], "equity_parent": d0['equity_parent']})
put("solvency", "interest_bearing_debt", "元", "interest_bearing_debt（原值）",
    lambda v, vp: v['interest_bearing_debt'], 64, None,
    {"interest_bearing_debt": d['interest_bearing_debt']}, {"interest_bearing_debt": d0['interest_bearing_debt']})
put("solvency", "interest_bearing_debt_ratio", "小数", "interest_bearing_debt / total_assets",
    lambda v, vp: v['interest_bearing_debt']/v['total_assets'], 64, False,
    {"interest_bearing_debt": d['interest_bearing_debt'], "total_assets": d['total_assets']},
    {"interest_bearing_debt": d0['interest_bearing_debt'], "total_assets": d0['total_assets']})
put("solvency", "interest_bearing_debt_growth", "小数", "interest_bearing_debt / prior_interest_bearing_debt - 1",
    lambda v, vp: v['interest_bearing_debt']/vp['interest_bearing_debt']-1, 64, False,
    {"interest_bearing_debt": d['interest_bearing_debt'], "prior_interest_bearing_debt": d0['interest_bearing_debt']},
    {"interest_bearing_debt": d0['interest_bearing_debt'], "prior_interest_bearing_debt": d2['interest_bearing_debt']})
put("solvency", "net_debt", "元", "interest_bearing_debt - cash_and_equivalents",
    lambda v, vp: v['interest_bearing_debt']-v['cash_and_equivalents'], 64, None,
    {"interest_bearing_debt": d['interest_bearing_debt'], "cash_and_equivalents": d['cash_and_equivalents']},
    {"interest_bearing_debt": d0['interest_bearing_debt'], "cash_and_equivalents": d0['cash_and_equivalents']})
put("solvency", "cash_to_short_term_debt", "倍", "cash_and_equivalents / (short_term_borrowings + current_portion_lt_debt)",
    lambda v, vp: v['cash_and_equivalents']/(v['short_term_borrowings']+v['current_portion_lt_debt']), 64, True,
    {"cash_and_equivalents": d['cash_and_equivalents'], "short_term_borrowings": d['short_term_borrowings'], "current_portion_lt_debt": d['current_portion_lt_debt']},
    {"cash_and_equivalents": d0['cash_and_equivalents'], "short_term_borrowings": d0['short_term_borrowings'], "current_portion_lt_debt": d0['current_portion_lt_debt']})
put("solvency", "interest_coverage", "倍", "(operating_profit + finance_expense) / interest_expense",
    lambda v, vp: (v['operating_profit']+v['finance_expense'])/v['interest_expense'], 64, True,
    {"operating_profit": d['operating_profit'], "finance_expense": d['finance_expense'], "interest_expense": d['interest_expense']},
    {"operating_profit": d0['operating_profit'], "finance_expense": d0['finance_expense'], "interest_expense": d0['interest_expense']})
put("solvency", "net_debt_to_ebitda", "倍", "(interest_bearing_debt - cash_and_equivalents) / (operating_profit + depreciation_amortization)",
    lambda v, vp: (v['interest_bearing_debt']-v['cash_and_equivalents'])/(v['operating_profit']+v['depreciation_amortization']), 64, False,
    {"interest_bearing_debt": d['interest_bearing_debt'], "cash_and_equivalents": d['cash_and_equivalents'], "operating_profit": d['operating_profit'], "depreciation_amortization": d['depreciation_amortization']},
    {"interest_bearing_debt": d0['interest_bearing_debt'], "cash_and_equivalents": d0['cash_and_equivalents'], "operating_profit": d0['operating_profit'], "depreciation_amortization": d0['depreciation_amortization']})
put("solvency", "restricted_cash_ratio", "小数", "restricted_cash / cash_and_equivalents",
    lambda v, vp: v['restricted_cash']/v['cash_and_equivalents'], 64, False,
    {"restricted_cash": d['restricted_cash'], "cash_and_equivalents": d['cash_and_equivalents']},
    {"restricted_cash": d0['restricted_cash'], "cash_and_equivalents": d0['cash_and_equivalents']})
put("solvency", "working_capital", "元", "current_assets - current_liabilities",
    lambda v, vp: v['current_assets']-v['current_liabilities'], 60, None,
    {"current_assets": d['current_assets'], "current_liabilities": d['current_liabilities']},
    {"current_assets": d0['current_assets'], "current_liabilities": d0['current_liabilities']})

# efficiency
put("efficiency", "ar_turnover", "次", "revenue / ((accounts_receivable + prior_accounts_receivable) / 2)",
    lambda v, vp: v['revenue']/((v['accounts_receivable']+vp['accounts_receivable'])/2), 60, True,
    {"revenue": d['revenue'], "accounts_receivable": d['accounts_receivable'], "prior_accounts_receivable": d0['accounts_receivable']},
    {"revenue": d0['revenue'], "accounts_receivable": d0['accounts_receivable'], "prior_accounts_receivable": d2['accounts_receivable']})
put("efficiency", "inventory_turnover", "次", "operating_cost / ((inventory + prior_inventory) / 2)",
    lambda v, vp: v['operating_cost']/((v['inventory']+vp['inventory'])/2), 60, True,
    {"operating_cost": d['operating_cost'], "inventory": d['inventory'], "prior_inventory": d0['inventory']},
    {"operating_cost": d0['operating_cost'], "inventory": d0['inventory'], "prior_inventory": d2['inventory']})
put("efficiency", "ap_turnover", "次", "operating_cost / ((accounts_payable + prior_accounts_payable) / 2)",
    lambda v, vp: v['operating_cost']/((v['accounts_payable']+vp['accounts_payable'])/2), 61, None,
    {"operating_cost": d['operating_cost'], "accounts_payable": d['accounts_payable'], "prior_accounts_payable": d0['accounts_payable']},
    {"operating_cost": d0['operating_cost'], "accounts_payable": d0['accounts_payable'], "prior_accounts_payable": d2['accounts_payable']})
put("efficiency", "ar_turnover_days", "天", "((accounts_receivable + prior_accounts_receivable) / 2) / revenue * 365",
    lambda v, vp: ((v['accounts_receivable']+vp['accounts_receivable'])/2)/v['revenue']*365, 60, False,
    {"accounts_receivable": d['accounts_receivable'], "prior_accounts_receivable": d0['accounts_receivable'], "revenue": d['revenue']},
    {"accounts_receivable": d0['accounts_receivable'], "prior_accounts_receivable": d2['accounts_receivable'], "revenue": d0['revenue']})
put("efficiency", "inventory_turnover_days", "天", "((inventory + prior_inventory) / 2) / operating_cost * 365",
    lambda v, vp: ((v['inventory']+vp['inventory'])/2)/v['operating_cost']*365, 60, False,
    {"inventory": d['inventory'], "prior_inventory": d0['inventory'], "operating_cost": d['operating_cost']},
    {"inventory": d0['inventory'], "prior_inventory": d2['inventory'], "operating_cost": d0['operating_cost']})
put("efficiency", "payable_turnover_days", "天", "((accounts_payable + prior_accounts_payable) / 2) / operating_cost * 365",
    lambda v, vp: ((v['accounts_payable']+vp['accounts_payable'])/2)/v['operating_cost']*365, 61, None,
    {"accounts_payable": d['accounts_payable'], "prior_accounts_payable": d0['accounts_payable'], "operating_cost": d['operating_cost']},
    {"accounts_payable": d0['accounts_payable'], "prior_accounts_payable": d2['accounts_payable'], "operating_cost": d0['operating_cost']})
put("efficiency", "cash_conversion_cycle", "天", "ar_turnover_days + inventory_turnover_days - payable_turnover_days",
    lambda v, vp: ((v['accounts_receivable']+vp['accounts_receivable'])/2)/v['revenue']*365 + ((v['inventory']+vp['inventory'])/2)/v['operating_cost']*365 - ((v['accounts_payable']+vp['accounts_payable'])/2)/v['operating_cost']*365, 60, False,
    {"ar_turnover_days": R2(((d['accounts_receivable']+d0['accounts_receivable'])/2)/d['revenue']*365), "inventory_turnover_days": R2(((d['inventory']+d0['inventory'])/2)/d['operating_cost']*365), "payable_turnover_days": R2(((d['accounts_payable']+d0['accounts_payable'])/2)/d['operating_cost']*365)},
    {"ar_turnover_days": R2(((d0['accounts_receivable']+d2['accounts_receivable'])/2)/d0['revenue']*365), "inventory_turnover_days": R2(((d0['inventory']+d2['inventory'])/2)/d0['operating_cost']*365), "payable_turnover_days": R2(((d0['accounts_payable']+d2['accounts_payable'])/2)/d0['operating_cost']*365)})
put("efficiency", "total_asset_turnover", "次", "revenue / ((total_assets + prior_total_assets) / 2)",
    lambda v, vp: v['revenue']/((v['total_assets']+vp['total_assets'])/2), 60, True,
    {"revenue": d['revenue'], "total_assets": d['total_assets'], "prior_total_assets": d0['total_assets']},
    {"revenue": d0['revenue'], "total_assets": d0['total_assets'], "prior_total_assets": d2['total_assets']})
put("efficiency", "fixed_asset_turnover", "次", "revenue / ((fixed_assets + prior_fixed_assets) / 2)",
    lambda v, vp: v['revenue']/((v['fixed_assets']+vp['fixed_assets'])/2), 63, True,
    {"revenue": d['revenue'], "fixed_assets": d['fixed_assets'], "prior_fixed_assets": d0['fixed_assets']},
    {"revenue": d0['revenue'], "fixed_assets": d0['fixed_assets'], "prior_fixed_assets": d2['fixed_assets']})
put("efficiency", "accounts_receivable_growth", "小数", "accounts_receivable / prior_accounts_receivable - 1",
    lambda v, vp: v['accounts_receivable']/vp['accounts_receivable']-1, 60, False,
    {"accounts_receivable": d['accounts_receivable'], "prior_accounts_receivable": d0['accounts_receivable']},
    {"accounts_receivable": d0['accounts_receivable'], "prior_accounts_receivable": d2['accounts_receivable']})
put("efficiency", "inventory_growth", "小数", "inventory / prior_inventory - 1",
    lambda v, vp: v['inventory']/vp['inventory']-1, 60, False,
    {"inventory": d['inventory'], "prior_inventory": d0['inventory']},
    {"inventory": d0['inventory'], "prior_inventory": d2['inventory']})
put("efficiency", "ar_and_inventory_to_assets", "小数", "(accounts_receivable + notes_receivable + contract_assets + inventory) / total_assets",
    lambda v, vp: (v['accounts_receivable']+v['notes_receivable']+v['contract_assets']+v['inventory'])/v['total_assets'], 60, False,
    {"accounts_receivable": d['accounts_receivable'], "notes_receivable": d['notes_receivable'], "contract_assets": d['contract_assets'], "inventory": d['inventory'], "total_assets": d['total_assets']},
    {"accounts_receivable": d0['accounts_receivable'], "notes_receivable": d0['notes_receivable'], "contract_assets": d0['contract_assets'], "inventory": d0['inventory'], "total_assets": d0['total_assets']})

# cashflow_quality
put("cashflow_quality", "ocf", "元", "cfo（原值）",
    lambda v, vp: v['cfo'], 68, True,
    {"cfo": d['cfo']}, {"cfo": d0['cfo']})
put("cashflow_quality", "cfo_to_net_income_total", "小数", "cfo / net_income",
    lambda v, vp: v['cfo']/v['net_income'], 68, True,
    {"cfo": d['cfo'], "net_income": d['net_income']},
    {"cfo": d0['cfo'], "net_income": d0['net_income']})
put("cashflow_quality", "cfo_to_net_income", "小数", "cfo / net_income_parent",
    lambda v, vp: v['cfo']/v['net_income_parent'], 68, True,
    {"cfo": d['cfo'], "net_income_parent": d['net_income_parent']},
    {"cfo": d0['cfo'], "net_income_parent": d0['net_income_parent']})
put("cashflow_quality", "ocf_to_revenue", "小数", "cfo / revenue",
    lambda v, vp: v['cfo']/v['revenue'], 68, True,
    {"cfo": d['cfo'], "revenue": d['revenue']},
    {"cfo": d0['cfo'], "revenue": d0['revenue']})
put("cashflow_quality", "cash_collection_ratio", "小数", "cash_received_from_sales / revenue",
    lambda v, vp: v['cash_received_from_sales']/v['revenue'], 68, True,
    {"cash_received_from_sales": d['cash_received_from_sales'], "revenue": d['revenue']},
    {"cash_received_from_sales": d0['cash_received_from_sales'], "revenue": d0['revenue']})
put("cashflow_quality", "capex", "元", "capex（原值）",
    lambda v, vp: v['capex'], 70, None,
    {"capex": d['capex']}, {"capex": d0['capex']})
put("cashflow_quality", "capex_to_ocf", "倍", "capex / cfo",
    lambda v, vp: v['capex']/v['cfo'], 70, False,
    {"capex": d['capex'], "cfo": d['cfo']},
    {"capex": d0['capex'], "cfo": d0['cfo']})
put("cashflow_quality", "free_cash_flow", "元", "cfo - capex",
    lambda v, vp: v['cfo']-v['capex'], 68, True,
    {"cfo": d['cfo'], "capex": d['capex']},
    {"cfo": d0['cfo'], "capex": d0['capex']})
put("cashflow_quality", "fcf_to_revenue", "小数", "(cfo - capex) / revenue",
    lambda v, vp: (v['cfo']-v['capex'])/v['revenue'], 68, True,
    {"cfo": d['cfo'], "capex": d['capex'], "revenue": d['revenue']},
    {"cfo": d0['cfo'], "capex": d0['capex'], "revenue": d0['revenue']})
put("cashflow_quality", "ocf_to_interest_paid", "倍", "cfo / interest_paid",
    lambda v, vp: v['cfo']/v['interest_paid'], 68, True,
    {"cfo": d['cfo'], "interest_paid": d['interest_paid']},
    {"cfo": d0['cfo'], "interest_paid": d0['interest_paid']})
put("cashflow_quality", "payout_ratio", "小数", "dividend_paid / net_income_parent",
    lambda v, vp: v['dividend_paid']/v['net_income_parent'], 62, None,
    {"dividend_paid": d['dividend_paid'], "net_income_parent": d['net_income_parent']},
    {"dividend_paid": d0['dividend_paid'], "net_income_parent": d0['net_income_parent']})
put("cashflow_quality", "cf_financing_dependency", "小数", "(abs(cfi) - cfo) / abs(cfi)",
    lambda v, vp: (abs(v['cfi'])-v['cfo'])/abs(v['cfi']), 69, False,
    {"cfi": d['cfi'], "cfo": d['cfo']},
    {"cfi": d0['cfi'], "cfo": d0['cfo']})
put("cashflow_quality", "goodwill_to_equity", "小数", "goodwill / equity_parent",
    lambda v, vp: v['goodwill']/v['equity_parent'], 63, False,
    {"goodwill": d['goodwill'], "equity_parent": d['equity_parent']},
    {"goodwill": d0['goodwill'], "equity_parent": d0['equity_parent']})
put("cashflow_quality", "capex_to_da_ratio", "倍", "capex / depreciation_amortization",
    lambda v, vp: v['capex']/v['depreciation_amortization'], 70, None,
    {"capex": d['capex'], "depreciation_amortization": d['depreciation_amortization']},
    {"capex": d0['capex'], "depreciation_amortization": d0['depreciation_amortization']})

R["banking"] = {}

# 顺序整理
RATIOS = {c: R[c] for c in cats + ["banking"]}

print("ratio counts:", {c: len(R[c]) for c in cats}, "banking", 0)
print("total ratios:", sum(len(R[c]) for c in cats))

# ---------------- risks ----------------
def iv(metric, value, unit, period, page):
    return {"metric": metric, "value": value, "unit": unit, "period": period, "page": page}

risks = [
    {
        "risk_id": "R01",
        "risk_name": "应收账款增速快于营业收入增速",
        "category": "收入与资产",
        "severity": "medium",
        "severity_tag": "关注",
        "score": 60.0,
        "status": "triggered",
        "trigger": "应收账款增速 - 营业收入增速 > 5 个百分点",
        "involved_values": [
            iv("accounts_receivable", d['accounts_receivable'], "元", "2025", 60),
            iv("accounts_receivable", d0['accounts_receivable'], "元", "2024", 60),
            iv("accounts_receivable_growth", R4(d['accounts_receivable']/d0['accounts_receivable']-1), "小数", "2025", 60),
            iv("revenue_growth_yoy", R4(d['revenue']/d0['revenue']-1), "小数", "2025", 82),
        ],
        "numeric_evidence": "应收账款由 3050000000 元增至 3860000000 元，增速 26.6%；营业收入增速 11.0%，相差 15.5 个百分点，超过 5 个百分点阈值。",
        "text_evidence": {"quote": "报告期内公司适度放宽了部分战略客户的信用账期。", "page": 45},
        "explanation": "应收增速显著高于收入增速，可能通过放宽信用政策换取收入增长，也可能是收入确认节奏前移，需结合账龄与坏账计提判断回款质量。",
        "suggested_action": "核对应收账款账龄结构附注与前五大欠款方，比较信用政策是否变化。",
        "evidence_chain": [
            {"step": "数据", "item": "accounts_receivable", "value": 3860000000, "unit": "元", "prev_value": 3050000000, "source": "2025年年度报告", "page": 60},
            {"step": "数据", "item": "revenue", "value": 18650000000, "unit": "元", "prev_value": 16800000000, "source": "2025年年度报告", "page": 82},
            {"step": "计算", "item": "触发表达式", "formula": "accounts_receivable_growth - revenue_growth > 0.05", "values": {"accounts_receivable_growth": R4(d['accounts_receivable']/d0['accounts_receivable']-1), "revenue_growth": R4(d['revenue']/d0['revenue']-1)}},
            {"step": "出处", "item": "年报来源与页码", "sources": ["2025年年度报告"], "pages": [60, 82]},
            {"step": "判断", "item": "应收增速 - 收入增速 > 5 个百分点", "result": "触发", "severity": "medium"},
            {"step": "建议", "item": "下一步动作", "actions": ["读取应收账款附注按账龄结构查看一年以上占比", "检查前五大客户集中度与关联方占比", "检查坏账计提比例是否随账龄恶化同步提高"]},
        ],
    },
    {
        "risk_id": "R02",
        "risk_name": "存货周转天数上行且高于同业",
        "category": "收入与资产",
        "severity": "low",
        "severity_tag": "提示",
        "score": 40.0,
        "status": "triggered",
        "trigger": "存货周转天数连续两期上行，且高于同业中位数",
        "involved_values": [
            iv("inventory_turnover_days", R2(((d['inventory']+d0['inventory'])/2)/d['operating_cost']*365), "天", "2025", 60),
            iv("inventory_turnover_days", R2(((d0['inventory']+d2['inventory'])/2)/d0['operating_cost']*365), "天", "2024", 60),
        ],
        "numeric_evidence": "存货周转天数由 106.38 天升至 112.46 天，同业中位数约 95 天，偏高约 17 天。",
        "text_evidence": {"quote": "受下游需求波动影响，部分在产品备货周期有所拉长。", "page": 47},
        "explanation": "库存周转放缓叠加高于同业，可能指向需求走弱或产品滞销。当前幅度有限，列为观察项。",
        "suggested_action": "核对存货构成与跌价准备计提，结合在手订单判断是否存在积压。",
        "evidence_chain": [
            {"step": "数据", "item": "inventory", "value": 4420000000, "unit": "元", "prev_value": 3800000000, "source": "2025年年度报告", "page": 60},
            {"step": "计算", "item": "触发表达式", "formula": "inventory_turnover_days_delta > 0", "values": {"inventory_turnover_days": R2(((d['inventory']+d0['inventory'])/2)/d['operating_cost']*365), "prev": R2(((d0['inventory']+d2['inventory'])/2)/d0['operating_cost']*365)}},
            {"step": "出处", "item": "年报来源与页码", "sources": ["2025年年度报告"], "pages": [60]},
            {"step": "判断", "item": "存货周转天数连续两期上行且高于同业中位数", "result": "触发", "severity": "low"},
            {"step": "建议", "item": "下一步动作", "actions": ["核对存货构成与跌价准备计提", "结合在手订单判断是否存在积压"]},
        ],
    },
    {
        "risk_id": "R03",
        "risk_name": "控股股东股权质押比例偏高",
        "category": "治理与合规",
        "severity": "medium",
        "severity_tag": "关注",
        "score": 60.0,
        "status": "triggered",
        "trigger": "控股股东质押股份占其持股比例超过 50%",
        "involved_values": [iv("pledge_ratio", 0.58, "小数", "2025", 51)],
        "numeric_evidence": "控股股东累计质押 1.05 亿股，占其所持 1.81 亿股的 58.0%，超过 50% 观察线。",
        "text_evidence": {"quote": "截至报告期末，控股股东已质押股份 1.05 亿股，占其所持股份的 58.0%。", "page": 51},
        "explanation": "高比例质押在股价波动时可能引发控制权稳定风险，属治理类信号，与当期财务数字无关但影响风险评级。",
        "suggested_action": "跟踪质押平仓线与控股股东资金用途披露。",
        "evidence_chain": [
            {"step": "数据", "item": "pledge_ratio", "value": 0.58, "unit": "小数", "source": "2025年年度报告（公司治理章节）", "page": 51},
            {"step": "计算", "item": "触发表达式", "formula": "pledge_ratio > 0.50", "values": {"pledge_ratio": 0.58}},
            {"step": "出处", "item": "年报来源与页码", "sources": ["2025年年度报告"], "pages": [51]},
            {"step": "判断", "item": "控股股东质押比例 > 50%", "result": "触发", "severity": "medium"},
            {"step": "建议", "item": "下一步动作", "actions": ["跟踪质押平仓线与控股股东资金用途披露"]},
        ],
    },
]

rules_evaluated = [
    {"rule_id": "P03", "rule_name": "毛利率未低于行业中位数", "category": "盈利质量", "status": "not_evaluable",
     "severity": None, "severity_tag": None, "trigger": "gross_margin < industry_gross_margin_benchmark",
     "explanation": "缺少行业毛利率基准，标记为 not_evaluable，转人工核验，不做无风险假设。",
     "trigger_values": {"gross_margin": R4((d['revenue']-d['operating_cost'])/d['revenue']), "industry_gross_margin_benchmark": None}},
    {"rule_id": "S06", "rule_name": "流动比率未偏低", "category": "偿债与流动性", "status": "passed",
     "severity": None, "severity_tag": None, "trigger": "current_ratio < 1.2",
     "explanation": "规则已执行，条件不成立，本项无异常。",
     "trigger_values": {"current_ratio": R2(d['current_assets']/d['current_liabilities'])}},
    {"rule_id": "S07", "rule_name": "净负债/EBITDA 未偏高", "category": "偿债与流动性", "status": "passed",
     "severity": None, "severity_tag": None, "trigger": "net_debt_to_ebitda > 3",
     "explanation": "规则已执行，条件不成立，本项无异常。",
     "trigger_values": {"net_debt_to_ebitda": R2((d['interest_bearing_debt']-d['cash_and_equivalents'])/(d['operating_profit']+d['depreciation_amortization']))}},
    {"rule_id": "P04", "rule_name": "期间费用率未明显上升", "category": "盈利质量", "status": "passed",
     "severity": None, "severity_tag": None, "trigger": "period_expense_ratio_delta > 0.02",
     "explanation": "规则已执行，条件不成立，本项无异常。",
     "trigger_values": {"period_expense_ratio_delta": 0.0024}},
    {"rule_id": "G06", "rule_name": "营业收入未下滑", "category": "收入与资产", "status": "passed",
     "severity": None, "severity_tag": None, "trigger": "revenue_growth < 0",
     "explanation": "规则已执行，条件不成立，本项无异常。",
     "trigger_values": {"revenue_growth": R4(d['revenue']/d0['revenue']-1)}},
]

# ---------------- valuation ----------------
valuation = {
    "comps": {
        "inputs": {
            "revenue": d['revenue'], "net_income": d['net_income_parent'], "ebitda": d['operating_profit']+d['depreciation_amortization'],
            "net_debt": d['interest_bearing_debt']-d['cash_and_equivalents'], "share_price": 16.50,
            "shares_outstanding": 2200000000, "shares_unit": "股", "market_cap": 36300000000, "currency": "CNY",
        },
        "peer_companies": [
            {"name": "锐科装备", "ticker": "002xxx.SZ", "pe": 20.5, "pb": 2.1, "ev_ebitda": 11.0, "ps": 1.9},
            {"name": "精工制造", "ticker": "300xxx.SZ", "pe": 24.0, "pb": 2.6, "ev_ebitda": 13.2, "ps": 2.3},
            {"name": "恒达智造", "ticker": "600xxx.SH", "pe": 18.0, "pb": 1.9, "ev_ebitda": 9.8, "ps": 1.6},
        ],
        "peer_multiples": {
            "pe": {"min": 18.0, "median": 20.5, "max": 24.0},
            "pb": {"min": 1.9, "median": 2.1, "max": 2.6},
            "ev_ebitda": {"min": 9.8, "median": 11.0, "max": 13.2},
            "ps": {"min": 1.6, "median": 1.9, "max": 2.3},
        },
        "implied_value_per_share": {
            "pe": {"low": 12.9, "mid": 14.7, "high": 17.2},
            "pb": {"low": 13.4, "mid": 14.8, "high": 18.4},
            "ev_ebitda": {"low": 14.3, "mid": 16.2, "high": 19.6},
            "ps": {"low": 13.6, "mid": 16.1, "high": 19.5},
        },
        "valuation_range": {"low": 12.9, "mid": 15.5, "high": 19.6, "currency": "元/股"},
    },
    "dcf": {
        "inputs": {
            "revenue_base": d['revenue'], "ebit_margin": 0.1190, "tax_rate": 0.1900,
            "da": d['depreciation_amortization'], "capex": d['capex'], "nwc": 4930000000,
            "wacc": WACC, "terminal_growth": 0.0300, "forecast_years": 5,
        },
        "forecast": [
            {"year": 2026, "revenue": 20140000000, "ebit": 2400000000, "fcff": 1400000000},
            {"year": 2027, "revenue": 21550000000, "ebit": 2560000000, "fcff": 1520000000},
            {"year": 2028, "revenue": 22850000000, "ebit": 2720000000, "fcff": 1640000000},
            {"year": 2029, "revenue": 23990000000, "ebit": 2850000000, "fcff": 1760000000},
            {"year": 2030, "revenue": 24950000000, "ebit": 2970000000, "fcff": 1860000000},
        ],
        "terminal_assumptions": {
            "terminal_growth": 0.0300, "terminal_fcff": 1860000000, "terminal_value": 38320000000,
            "pv_terminal_value": 26080000000, "tv_pct_of_ev": 0.8020, "wacc": WACC,
        },
        "valuation_range": {"low": 11.7, "mid": 13.9, "high": 17.4, "currency": "元/股"},
        "sensitivity": {
            "metric": "value_per_share", "unit": "元/股",
            "wacc_values": [0.0750, 0.0800, 0.0850], "terminal_growth_values": [0.0250, 0.0300, 0.0350],
            "matrix": [[14.2, 15.6, 17.4], [12.8, 13.9, 15.3], [11.7, 12.6, 13.7]],
        },
    },
    "blended": {
        "blended_per_share": 14.7,
        "current_price": 16.50,
        "upside": -0.1091,
        "verdict": "高估",
        "components": [
            {"key": "comps", "label": "相对估值（市场法）", "per_share": 15.5, "weight": 0.5, "equity_value": 34100000000},
            {"key": "dcf", "label": "DCF（收益法）", "per_share": 13.9, "weight": 0.5, "equity_value": 30580000000},
        ],
    },
    "scenarios": {
        "bull": {"per_share": 18.6, "equity_value": 40920000000, "growth_y1": 0.1500, "ebit_margin": 0.1390, "wacc": 0.0700, "terminal_growth": 0.0350},
        "base": {"per_share": 14.7, "equity_value": 32340000000, "growth_y1": 0.1101, "ebit_margin": 0.1299, "wacc": 0.0800, "terminal_growth": 0.0300},
        "bear": {"per_share": 10.9, "equity_value": 23980000000, "growth_y1": 0.0700, "ebit_margin": 0.1150, "wacc": 0.0900, "terminal_growth": 0.0250},
    },
    "sotp": {"ok": False, "skipped": True},
    "market_data": {"price": 16.50, "shares_outstanding": 2200000000, "market_cap": 36300000000, "price_date": "2026-10-05"},
    "warnings": [
        "可比公司样本仅 3 家，中位数受个别公司影响较大，建议扩充样本。",
        "DCF 与相对估值结果相差 11.6%，加权平均值参考价值有限，需先定位哪一头偏差。",
    ],
    "sources": [
        {"name": "公开行情页（收盘价与总股本）", "as_of": "2026-10-05", "official": False},
        {"name": "中国债券信息网·10 年期国债", "as_of": "2026-10-05", "official": True},
    ],
    "disclaimer": "本结果由模型按既定假设计算，仅供研究与教学用途，不构成投资建议。",
}

# ---------------- company / sources ----------------
company = {
    "name": "恒锐精密制造股份有限公司", "ticker": "688123.SH", "industry": "高端装备制造",
    "report_period": "2025", "exchange": "上海证券交易所科创板", "report_type": "年度报告",
    "auditor": "华信会计师事务所（特殊普通合伙）", "audit_opinion": "标准无保留意见",
    "currency": "CNY", "amount_unit": "元",
}

sources = [
    {"company_name": "恒锐精密制造股份有限公司", "report_period": "2025", "file_name": "恒锐精密_2025年年度报告.pdf", "page": 60, "retrieved_at": "2026-10-05T14:20:00+08:00", "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"},
    {"company_name": "恒锐精密制造股份有限公司", "report_period": "2025", "file_name": "恒锐精密_2025年年度报告.pdf", "page": 82, "retrieved_at": "2026-10-05T14:20:00+08:00", "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"},
    {"company_name": "恒锐精密制造股份有限公司", "report_period": "2025", "file_name": "恒锐精密_2025年年度报告.pdf", "page": 68, "retrieved_at": "2026-10-05T14:20:00+08:00", "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"},
    {"company_name": "恒锐精密制造股份有限公司", "report_period": "2025", "file_name": "恒锐精密_2025年年度报告.pdf", "page": 45, "retrieved_at": "2026-10-05T14:20:00+08:00", "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"},
    {"company_name": "恒锐精密制造股份有限公司", "report_period": "2025", "file_name": "恒锐精密_2025年年度报告.pdf", "page": 51, "retrieved_at": "2026-10-05T14:20:00+08:00", "source_url": "http://www.cninfo.com.cn/new/disclosure/detail?stockCode=688123"},
]

obj = {
    "company": company,
    "financials": F,
    "ratios": RATIOS,
    "risks": risks,
    "rules_evaluated": rules_evaluated,
    "valuation": valuation,
    "sources": sources,
}

text = json.dumps(obj, ensure_ascii=False, indent=2)
with open(OUT_JSON, "w", encoding="utf-8") as f:
    f.write(text)
print("wrote", OUT_JSON, "bytes", len(text.encode('utf-8')))
