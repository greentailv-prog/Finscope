# -*- coding: utf-8 -*-
"""自检脚本：读 Schema.json 与 ratio_catalog.json，逐条核。"""
import json, math, sys, io

JSONPATH = r"D:\浏览器下载\AI网页搭建文件\D分支文件\output\Schema.json"
CATALOG = r"D:\浏览器下载\AI网页搭建文件\B分支文件\Finscope-main\financial-diagnosis\data\ratio_catalog.json"

ok = True
def check(name, cond, detail=""):
    global ok
    status = "PASS" if cond else "FAIL"
    if not cond: ok = False
    print(f"[{status}] {name} {detail}")

# 1. parse
with open(JSONPATH, encoding="utf-8") as f:
    obj = json.load(f)
check("1 JSON 可解析", True)

F = obj["financials"]
def val(k): return F[k]["value"]

# 2. 三表勾稽
ta = val("total_assets"); tl = val("total_liabilities"); eq = val("equity_parent")
check("2 三表勾稽 资产=负债+权益", ta == tl + eq, f"{ta} == {tl}+{eq}")

# 3. 货币资金勾稽
cash0 = F["cash_and_equivalents"]["prior_value"]; cash1 = val("cash_and_equivalents")
cfo = val("cfo"); cfi = val("cfi"); cff = val("cff")
check("3 货币资金勾稽", cash0 + cfo + cfi + cff == cash1, f"{cash0}+{cfo}+{cfi}+{cff} == {cash1}")

# 4. 抽 15 个比率复算
R = obj["ratios"]
def g(cat, key): return R[cat][key]["value"]
def pv(k): return F[k]["prior_value"]
tests = []
tests.append(("gross_margin", g("profitability","gross_margin"), round((val("revenue")-val("operating_cost"))/val("revenue"),4)))
tests.append(("net_margin", g("profitability","net_margin"), round(val("net_income_parent")/val("revenue"),4)))
tests.append(("operating_margin", g("profitability","operating_margin"), round(val("operating_profit")/val("revenue"),4)))
tests.append(("roe_weighted", g("profitability","roe_weighted"), round(val("net_income_parent")/((val("equity_parent")+pv("equity_parent"))/2),4)))
tests.append(("roa", g("profitability","roa"), round(val("net_income")/((val("total_assets")+pv("total_assets"))/2),4)))
tests.append(("ebitda_margin", g("profitability","ebitda_margin"), round((val("operating_profit")+val("depreciation_amortization"))/val("revenue"),4)))
tests.append(("debt_to_asset_ratio", g("solvency","debt_to_asset_ratio"), round(val("total_liabilities")/val("total_assets"),4)))
tests.append(("current_ratio", g("solvency","current_ratio"), round(val("current_assets")/val("current_liabilities"),2)))
tests.append(("quick_ratio", g("solvency","quick_ratio"), round((val("current_assets")-val("inventory"))/val("current_liabilities"),2)))
tests.append(("net_debt_to_ebitda", g("solvency","net_debt_to_ebitda"), round((val("interest_bearing_debt")-val("cash_and_equivalents"))/(val("operating_profit")+val("depreciation_amortization")),2)))
tests.append(("ar_turnover_days", g("efficiency","ar_turnover_days"), round(((val("accounts_receivable")+pv("accounts_receivable"))/2)/val("revenue")*365,2)))
tests.append(("inventory_turnover_days", g("efficiency","inventory_turnover_days"), round(((val("inventory")+pv("inventory"))/2)/val("operating_cost")*365,2)))
tests.append(("payable_turnover_days", g("efficiency","payable_turnover_days"), round(((val("accounts_payable")+pv("accounts_payable"))/2)/val("operating_cost")*365,2)))
tests.append(("cash_conversion_cycle", g("efficiency","cash_conversion_cycle"), round(((val("accounts_receivable")+pv("accounts_receivable"))/2)/val("revenue")*365 + ((val("inventory")+pv("inventory"))/2)/val("operating_cost")*365 - ((val("accounts_payable")+pv("accounts_payable"))/2)/val("operating_cost")*365,2)))
tests.append(("total_asset_turnover", g("efficiency","total_asset_turnover"), round(val("revenue")/((val("total_assets")+pv("total_assets"))/2),2)))
tests.append(("cash_collection_ratio", g("cashflow_quality","cash_collection_ratio"), round(val("cash_received_from_sales")/val("revenue"),4)))
tests.append(("cfo_to_net_income", g("cashflow_quality","cfo_to_net_income"), round(val("cfo")/val("net_income_parent"),4)))
tests.append(("free_cash_flow", g("cashflow_quality","free_cash_flow"), round(val("cfo")-val("capex"),4)))
bad = [t for t in tests if abs(t[1]-t[2]) > 1e-9]
check("4 复算 18 个比率", not bad, f"不符={bad}")

# 5. 市值/股本=每股
md = obj["valuation"]["market_data"]
check("5 市值÷股本=每股", abs(md["market_cap"]/md["shares_outstanding"] - obj["valuation"]["comps"]["inputs"]["share_price"]) < 1e-9,
      f"{md['market_cap']}/{md['shares_outstanding']}={md['market_cap']/md['shares_outstanding']}")

# 6. 覆盖 B 的 65
with open(CATALOG, encoding="utf-8") as f:
    cat = json.load(f)
bkeys = [m["key"] for m in cat["metrics"]]
print("   B catalog metric_count =", cat.get("metric_count"), "实际", len(bkeys))
mp = {
 "revenue_growth":"revenue_growth_yoy","net_income_growth":"net_income_total_growth",
 "net_income_parent_growth":"net_income_growth_yoy","net_income_deducted_growth":"net_income_excl_nonrecurring_growth_yoy",
 "cost_of_revenue_growth":"cost_of_revenue_growth","total_assets_growth":"total_assets_growth",
 "equity_parent_growth":"equity_parent_growth","ocf_growth":"ocf_growth","profit_revenue_scissors":"profit_revenue_scissors",
 "gross_margin":"gross_margin","net_margin":"net_margin_total","net_margin_parent":"net_margin",
 "net_margin_deducted":"net_margin_deducted","operating_margin":"operating_margin","ebit_margin":"ebit_margin",
 "selling_expense_ratio":"selling_expense_ratio","admin_expense_ratio":"admin_expense_ratio","rd_expense_ratio":"rd_expense_ratio",
 "finance_expense_ratio":"finance_expense_ratio","period_expense_ratio":"period_expense_ratio","roe":"roe_weighted",
 "roa":"roa","roic":"roic","effective_tax_rate":"effective_tax_rate","deducted_to_parent":"deducted_to_parent",
 "roic_minus_wacc":"roic_minus_wacc","current_ratio":"current_ratio","quick_ratio":"quick_ratio","cash_ratio":"cash_ratio",
 "debt_to_assets":"debt_to_asset_ratio","equity_multiplier":"equity_multiplier","interest_bearing_debt":"interest_bearing_debt",
 "interest_bearing_debt_ratio":"interest_bearing_debt_ratio","interest_bearing_debt_growth":"interest_bearing_debt_growth",
 "net_debt":"net_debt","cash_to_short_term_debt":"cash_to_short_term_debt","interest_coverage":"interest_coverage",
 "net_debt_to_ebitda":"net_debt_to_ebitda","restricted_cash_ratio":"restricted_cash_ratio","working_capital":"working_capital",
 "ar_turnover":"ar_turnover","inventory_turnover":"inventory_turnover","ap_turnover":"ap_turnover","dso":"ar_turnover_days",
 "dio":"inventory_turnover_days","dpo":"payable_turnover_days","cash_conversion_cycle":"cash_conversion_cycle",
 "total_asset_turnover":"total_asset_turnover","fixed_asset_turnover":"fixed_asset_turnover",
 "accounts_receivable_growth":"accounts_receivable_growth","inventory_growth":"inventory_growth",
 "ar_and_inventory_to_assets":"ar_and_inventory_to_assets","ocf":"ocf","ocf_to_net_income":"cfo_to_net_income_total",
 "ocf_to_net_income_parent":"cfo_to_net_income","ocf_to_revenue":"ocf_to_revenue","sales_cash_ratio":"cash_collection_ratio",
 "capex":"capex","capex_to_ocf":"capex_to_ocf","free_cash_flow":"free_cash_flow","fcf_to_revenue":"fcf_to_revenue",
 "ocf_to_interest_paid":"ocf_to_interest_paid","payout_ratio":"payout_ratio","cf_financing_dependency":"cf_financing_dependency",
 "goodwill_to_equity":"goodwill_to_equity",
}
check("6a 映射表覆盖全部 B 键", set(bkeys) == set(mp.keys()), f"未覆盖={set(bkeys)-set(mp)} 多余={set(mp)-set(bkeys)}")
mykeys = set()
for c, dd in R.items():
    for k in dd: mykeys.add(k)
mapped = set(mp.values())
missing = mapped - mykeys
extra = mykeys - mapped
check("6b B 全部映射到我的键", not missing, f"缺失={missing}")
counts = {c: len(dd) for c, dd in R.items()}
print("   五类键数：", counts)
print("   五类合计：", sum(v for c,v in counts.items() if c!="banking"))
print("   我的独有键（B 无）：", sorted(extra))
print("   B 指标数：", len(bkeys))

# 7. 百万元
import re
with open(JSONPATH, encoding="utf-8") as f:
    raw = f.read()
check("7 无「百万元」残留", "百万元" not in raw, f"出现 {raw.count('百万元')} 次")

print()
print("ALL PASS" if ok else "HAS FAILURES")
sys.exit(0 if ok else 1)
