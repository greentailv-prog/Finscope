# -*- coding: utf-8 -*-
"""拼装 SCHEMA.md：读 Schema.json，生成比率/类别表，嵌入 JSON（逐字节一致）。"""
import json

JSONPATH = r"D:\浏览器下载\AI网页搭建文件\D分支文件\output\Schema.json"
MDPATH = r"D:\浏览器下载\AI网页搭建文件\D分支文件\output\SCHEMA.md"

with open(JSONPATH, encoding="utf-8") as f:
    obj = json.load(f)
with open(JSONPATH, encoding="utf-8") as f:
    jsontxt = f.read()

# ---- 指标中文标签 ----
LBL = {
 "revenue_growth_yoy": "营业收入同比增长率",
 "net_income_growth_yoy": "归母净利润同比增长率",
 "net_income_excl_nonrecurring_growth_yoy": "扣非净利润同比增长率",
 "revenue_cagr_3y": "营业收入三年复合增速",
 "cost_of_revenue_growth": "营业成本增长率",
 "total_assets_growth": "总资产增长率",
 "equity_parent_growth": "归母净资产增长率",
 "ocf_growth": "经营活动现金流增长率",
 "profit_revenue_scissors": "收入利润剪刀差",
 "net_income_total_growth": "净利润（全口径）增长率",
 "gross_margin": "毛利率",
 "net_margin_total": "净利率（全口径）",
 "net_margin": "归母净利率",
 "net_margin_deducted": "扣非净利率",
 "operating_margin": "营业利润率",
 "ebit_margin": "EBIT 利润率",
 "selling_expense_ratio": "销售费用率",
 "admin_expense_ratio": "管理费用率",
 "rd_expense_ratio": "研发费用率",
 "finance_expense_ratio": "财务费用率",
 "period_expense_ratio": "期间费用率",
 "roe_weighted": "ROE（净资产收益率）",
 "roa": "ROA（总资产收益率）",
 "roic": "ROIC（投入资本回报率）",
 "effective_tax_rate": "有效税率",
 "deducted_to_parent": "扣非净利润占归母净利润比",
 "ebitda_margin": "EBITDA 利润率",
 "roic_minus_wacc": "ROIC 与 WACC 之差",
 "current_ratio": "流动比率",
 "quick_ratio": "速动比率",
 "cash_ratio": "现金比率",
 "debt_to_asset_ratio": "资产负债率",
 "equity_multiplier": "权益乘数",
 "interest_bearing_debt": "有息负债",
 "interest_bearing_debt_ratio": "有息负债率",
 "interest_bearing_debt_growth": "有息负债增长率",
 "net_debt": "净负债",
 "cash_to_short_term_debt": "货币资金对短期有息债务覆盖倍数",
 "interest_coverage": "利息保障倍数",
 "net_debt_to_ebitda": "净负债 / EBITDA",
 "restricted_cash_ratio": "受限资金占比",
 "working_capital": "营运资金",
 "ar_turnover": "应收账款周转率",
 "inventory_turnover": "存货周转率",
 "ap_turnover": "应付账款周转率",
 "ar_turnover_days": "应收账款周转天数（DSO）",
 "inventory_turnover_days": "存货周转天数（DIO）",
 "payable_turnover_days": "应付账款周转天数（DPO）",
 "cash_conversion_cycle": "现金转换周期（CCC）",
 "total_asset_turnover": "总资产周转率",
 "fixed_asset_turnover": "固定资产周转率",
 "accounts_receivable_growth": "应收账款增长率",
 "inventory_growth": "存货增长率",
 "ar_and_inventory_to_assets": "应收与存货合计占总资产比",
 "ocf": "经营活动现金流净额",
 "cfo_to_net_income_total": "净现比（经营现金流 / 净利润全口径）",
 "cfo_to_net_income": "净现比（经营现金流 / 归母净利润）",
 "ocf_to_revenue": "经营现金流收入比",
 "cash_collection_ratio": "收现比",
 "capex": "资本开支",
 "capex_to_ocf": "资本开支 / 经营现金流",
 "free_cash_flow": "自由现金流",
 "fcf_to_revenue": "自由现金流收入比",
 "ocf_to_interest_paid": "经营现金流利息覆盖倍数",
 "payout_ratio": "现金分红率",
 "cf_financing_dependency": "外部融资依赖度",
 "goodwill_to_equity": "商誉 / 归母净资产",
 "capex_to_da_ratio": "资本开支 / 折旧摊销",
}
# B 对应键（仅改名/新增的标注；同名留空）
BKEY = {
 "revenue_growth_yoy": "B revenue_growth，改名",
 "net_income_growth_yoy": "B net_income_parent_growth，改名",
 "net_income_excl_nonrecurring_growth_yoy": "B net_income_deducted_growth，改名",
 "revenue_cagr_3y": "B 无，我独有",
 "net_income_total_growth": "B net_income_growth，改名（全口径）",
 "net_margin_total": "B net_margin，改名（全口径）",
 "net_margin": "B net_margin_parent，改名",
 "roe_weighted": "B roe，改名",
 "ebitda_margin": "B 无（原在 derived），我独有",
 "debt_to_asset_ratio": "B debt_to_assets，改名",
 "net_debt_to_ebitda": "同名",
 "ar_turnover_days": "B dso，改名",
 "inventory_turnover_days": "B dio，改名",
 "payable_turnover_days": "B dpo，改名",
 "cfo_to_net_income_total": "B ocf_to_net_income，改名（全口径）",
 "cfo_to_net_income": "B ocf_to_net_income_parent，改名",
 "cash_collection_ratio": "B sales_cash_ratio，改名",
 "capex_to_da_ratio": "B 无，我独有",
}
CATNAME = {"growth":"成长性","profitability":"盈利能力","solvency":"偿债能力",
           "efficiency":"营运能力","cashflow_quality":"现金流质量","banking":"银行专属（可选）"}

def ratio_table(cat):
    rows = []
    for k, rec in obj["ratios"][cat].items():
        rows.append(f"| {k} | {LBL[k]} | {rec['unit']} | {BKEY.get(k, '同名')} |")
    return "\n".join(rows)

CATMAP = [
 ("growth", "收入与资产", "收入、利润、扣非利润的增速与结构"),
 ("profitability", "盈利质量", "毛利率、回报率、费用率与资本回报"),
 ("solvency", "偿债与流动性", "杠杆、期限错配、利息覆盖与再融资"),
 ("efficiency", "收入与资产", "应收、存货、应付周转与现金转换周期"),
 ("cashflow_quality", "盈利质量", "现金流与利润的匹配、现金含量"),
 ("asset_quality", "会计政策", "资产减值、商誉等资产质量"),
 ("governance", "治理与合规", "质押、股东与公司治理"),
]
catmap_rows = "\n".join(f"| {a} | {b} | {c} |" for a, b, c in CATMAP)

fin_list = []
finlbl = {
 "revenue":"营业收入","operating_cost":"营业成本","selling_expense":"销售费用","admin_expense":"管理费用",
 "rnd_expense":"研发费用","operating_profit":"营业利润","net_income_parent":"归母净利润","net_income":"净利润（全口径，含少数股东损益）",
 "net_income_excl_nonrecurring":"扣非归母净利润","total_assets":"资产总计","current_assets":"流动资产合计",
 "total_liabilities":"负债合计","current_liabilities":"流动负债合计","equity_parent":"归母净资产",
 "cash_and_equivalents":"货币资金","accounts_receivable":"应收账款","inventory":"存货","accounts_payable":"应付账款",
 "goodwill":"商誉","interest_bearing_debt":"有息负债","capex":"资本开支","depreciation_amortization":"折旧与摊销",
 "cfo":"经营活动现金流量净额","cfi":"投资活动现金流量净额","cff":"筹资活动现金流量净额",
 "cash_received_from_sales":"销售商品、提供劳务收到的现金",
}
for k, rec in obj["financials"].items():
    fin_list.append(f"| {k} | {finlbl[k]} | {rec['value']} |")
fin_rows = "\n".join(fin_list)

parts = []
parts.append("""# FinScope 统一数据接口 Schema

本文件是 D 部分交付的统一数据接口说明。配套文件 `Schema.json` 是填好示例值的完整对象，A/B/C 按它的格式交数据，E 只读、不重算。

## 1. 这份接口是干什么的

FinScope 的链路是「上传年报 → 财报抽取 → 指标计算与风险诊断 → 估值 → 投研报告」。五个角色各自产出 JSON，最后汇成同一个数据对象，交给 E 渲染页面。

这份 Schema 定死一件事。全组只认一个顶层对象，A/B/C 各填自己的字段，E 按字段渲染。字段名一旦定下，谁都不改。

顶层结构固定为七个键。

```
company / financials / ratios / risks / rules_evaluated / valuation / sources
```

`risks` 只放触发的风险卡；未触发、不可评估的规则放 `rules_evaluated`。两条的分工见 5.5 与 5.5.1。

## 2. 谁填哪块

| 顶层字段 | 负责人 | 说明 |
|---|---|---|
| company | D 定义，A 补全 | D 定字段名，A 从年报首页与公司简介填入公司基本信息 |
| financials | A | 三表与关键科目的数值，带口径与页码 |
| ratios | B | 六类财务指标，用公式从 financials 算出 |
| risks | B | 触发的风险卡片列表，每条带证据与页码 |
| rules_evaluated | B | 已评估但未触发的规则，含 passed / not_evaluable / not_applicable |
| valuation | C | 相对估值、绝对估值、融合、三情景、分部估值五块，外加行情与免责声明 |
| sources | A 归集 | 每条引用对应的文件名、页码、获取时间 |
| 全字段 | E 只读 | 不重算，不新增派生字段 |

""")

parts.append(f"""## 3. 全局约定

### 3.1 单位与数值

单位口径与 A/B/C 三家对齐，全组一致。

- **金额一律折算到「元」**。示例 18650000000 表示 186.5 亿元。数量级固定，不随公司规模变。
- **比率一律用小数**，不用百分数数值。示例 0.2847 表示 28.47%。小数保留四位。这是最容易被写错的一条，B 和 C 必须遵守。
- **股本用「股」**。示例 2200000000 表示 22 亿股。
- **每股价值用「元/股」**。它是股价口径，不是金额的口径，与金额的数量级无关。

`unit` 字段只管数量级，不管币种，取值只有五个。

| unit | 用于 | 示例 |
|---|---|---|
| 元 | 金额、金额类指标 | 18650000000 |
| 小数 | 比率类指标 | 0.2847 |
| 倍 | 覆盖倍数、杠杆倍数、比值类倍数 | 1.82 |
| 天 | 周转天数 | 67.62 |
| 次 | 周转次数 | 5.40 |

`元/股` 是第六个取值，作为每股价值的特殊约定保留。它与金额单位的区别在于，金额是「总量以元计」，每股价值是「每一股多少元」，两者不能混用，也不参与金额的换算。

**精度规则。**

- 金额保留到分，两位小数。整数部分为整时不补小数位，示例 `18650000000.00` 写成 `18650000000`。
- 比率（unit 为小数）保留四位小数。示例 `(18650000000 - 13340000000) / 18650000000 = 0.284718...` 写成 `0.2847`。
- 倍数、天数、次数保留两位小数。
- 年份、页数、年数这类计数保持整数。

**币种单独管。** 币种由 `company.currency` 表示，取值 CNY / USD / HKD。`unit` 不写币种。E 显示时把两者拼起来，`currency=CNY` 显示「人民币元」，`currency=USD` 显示「美元」。

这么分是为了美股。币种塞进 unit 会让美元公司的金额写成「元」，数量级和币种是两件事，分开存才不会串。

- 每一条金额记录都要带 unit 字段，不允许只写数字不写单位。
- 负值直接写负数，投资活动现金流、自由现金流可能为负。示例 -1850000000、-160000000。
- 图表与前端展示由 E 自适应。金额到亿元量级显示亿元，到元量级显示元，美元同理。图上和表头都必须标出单位并拼上币种。

### 3.2 口径字段取值

每个 financials 记录必须带口径字段，缺失即视为无效记录。

| 字段 | 取值 | 说明 |
|---|---|---|
| scope | 合并报表、母公司报表 | 同一指标优先取合并口径 |

`basis`（期间口径）不再逐条存，改按科目类型写死规则。

- **资产负债表科目一律「期末数」**。对应 total_assets、total_liabilities、equity_parent、current_assets 等。
- **利润表和现金流量表科目一律「累计数」**。对应 revenue、operating_cost、net_income_parent、cfo 等。

年报主表的口径本来就固定，不会变。以后接了半年报，或者要展示分季度数据，再把 basis 加回来。

### 3.3 空值与未产出

下游要能分清「没有」和「是零」。约定如下。

| 情况 | 写法 | 例子 |
|---|---|---|
| 该模块未产出 | 空对象 `{{}}` 或空数组 `[]` | C 没做 DCF，则 `"dcf": {{}}`；无分部数据，则 `"sotp": {{"ok": false, "skipped": true}}` |
| 该字段不适用 | `null` | 亏损公司算不出 PE，则相应倍数为 `null` |
| 缺失、未抽到 | 数值字段留 `null`，并在 confidence 或说明里标注 | `"value": null` |
| 指标因缺输入算不出 | value 写 `null`，status 写 `not_evaluable` | 缺行业基准，毛利率对比写 `not_evaluable` |
| 抽取到的真实零值 | 写 `0` | 某科目确实为零，写 `0` |

记住一条。`null` 是不知道，`0` 是确定为零。不要把不知道写成 0。

### 3.4 字段命名

- 一律英文小写下划线，如 `net_income_parent`。
- 全文件前后一致，同一含义不出现两个名字。归母净利润固定写 `net_income_parent`，全口径净利润固定写 `net_income`。
- 财务科目名以 `financials` 下的键为准，`ratios` 的 formula 里引用的就是这些键名，两边必须同名。
- formula 里用 `prior_<科目>` 表示该科目的上期值，即 financials 记录里的 `prior_value`。示例 `prior_revenue` 指上期营业收入。

""")

parts.append("## 4. 完整 JSON 示例\n\n")
parts.append("下面这份示例与 `Schema.json` 逐字节一致，可直接对照。示例公司为虚构的「恒锐精密制造股份有限公司」，报告期 2025 年。\n\n")
parts.append("数字经过自洽校验，三处勾稽成立。\n\n")
parts.append("- 资产总计 26800000000 = 负债合计 11260000000 + 所有者权益合计 15540000000\n")
parts.append("- 货币资金 4270000000 + 经营 1520000000 + 投资 -1850000000 + 筹资 210000000 = 4150000000，与期末货币资金一致\n")
parts.append("- 毛利率 0.2847 由营业收入 18650000000 与营业成本 13340000000 算出\n\n")
parts.append("```json\n")
parts.append(jsontxt)
parts.append("\n```\n\n")

parts.append(f"""## 5. 逐字段说明

### 5.1 company（D 定义，A 补全）

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| name | string | A | 恒锐精密制造股份有限公司 | 公司全称 |
| ticker | string | A | 688123.SH | 证券代码加交易所后缀 |
| industry | string | A | 高端装备制造 | 行业归属，同业对比用 |
| report_period | string | A | 2025 | 报告期年份，也用于 E 的页面标题 |
| exchange | string | A | 上海证券交易所科创板 | 上市地 |
| report_type | string | A | 年度报告 | 文件类型 |
| auditor | string | A | 华信会计师事务所（特殊普通合伙） | 审计机构 |
| audit_opinion | string | A | 标准无保留意见 | 审计意见类型，非标准意见要触发风险 |
| currency | string | D | CNY | 币种，取 CNY / USD / HKD。美股公司填 USD |
| amount_unit | string | D | 元 | 金额数量级，固定「元」。USD 币种时读作美元元，E 显示时与 currency 拼接 |

### 5.2 financials 记录的字段（A 填）

`financials` 是一个对象。键是科目名，值是记录对象。A 抽到的每个科目按下面九个字段交。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| value | number \\| null | A | 18650000000 | 本期数值，单位见 unit。抽不到填 null |
| unit | string | A | 元 | 金额科目固定「元」，全组一致 |
| period | string | A | 2025 | 数值所属期间 |
| prior_value | number \\| null | A | 16800000000 | 上期数值，供 B 算同比。不需要则 null |
| prior_period | string \\| null | A | 2024 | 上期期间，配合 prior_value |
| scope | string | A | 合并报表 | 合并报表或母公司报表，必填 |
| page | integer | A | 82 | 年报原始页码，可追溯的锚点 |
| source | string | A | 2025年年度报告 | 文件名或章节，写明出处 |
| confidence | number | A | 0.98 | 0 到 1 的抽取置信度，低于阈值进核验队列 |

期间口径（累计数／单季数／期末数）不逐条存，见 3.2 的规则。

### 5.3 financials 科目清单（A 的抽取范围，26 个）

| 键名 | 含义 | 示例值（元） |
|---|---|---|
{fin_rows}

本轮新增 `net_income`（净利润全口径，含少数股东损益）。B 的 roa、净利率、净现比和 C 的 DCF 都要用，原来只定义了归母的 `net_income_parent`。

清单之外还有约 25 个科目在 A 的补抽待办里，见 7.3。补抽前，依赖它们的指标标 `not_evaluable`。

### 5.4 ratios（B 填）

按六类组织。五类与设计文档 4.8 节的指标分组一致，第六类 `banking` 为可选的银行专属指标。每类是一个对象，键是指标名，值是记录对象。

指标记录的字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| value | number \\| null | B | 0.2847 | 比率类写小数，金额类写元。分母为零或失真填 null |
| unit | string | B | 小数 | 元、小数、倍、天、次之一 |
| period | string | B | 2025 | 计算所属期间。A 或适配层补 |
| formula | string | B | (revenue - operating_cost) / revenue | 计算式，引用的名字必须与 financials 的键同名 |
| page | integer | B | 82 | 主要输入所在的年报页码。A 或适配层补 |
| prev | number \\| null | B | 0.275 | 上期同口径的值，供看趋势 |
| delta | number \\| null | B | 0.0097 | value 减 prev |
| inputs | object | B | 见示例 | 代入值字典，列出复算需要的原始值 |
| inputs_prev | object \\| null | B | 见示例 | 上期代入值，算 prev 用 |
| status | string | B | ok | ok / not_evaluable，缺输入时写 not_evaluable |
| higher_is_better | boolean \\| null | B | true | 越大越好填 true，越小越好填 false，中性填 null |

六类指标清单。共 68 个键，覆盖 B 的全部 65 个指标，外加我独有的 3 个（revenue_cagr_3y、ebitda_margin、capex_to_da_ratio）。B 的键按第 3.1 节映射表归到我的命名，撞名的三个改用全口径后缀。

**growth（{CATNAME['growth']}），{len(obj['ratios']['growth'])} 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
{ratio_table('growth')}

**profitability（{CATNAME['profitability']}），{len(obj['ratios']['profitability'])} 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
{ratio_table('profitability')}

**solvency（{CATNAME['solvency']}），{len(obj['ratios']['solvency'])} 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
{ratio_table('solvency')}

**efficiency（{CATNAME['efficiency']}），{len(obj['ratios']['efficiency'])} 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
{ratio_table('efficiency')}

**cashflow_quality（{CATNAME['cashflow_quality']}），{len(obj['ratios']['cashflow_quality'])} 个**

| 键名 | 含义 | 单位 | B 对应 |
|---|---|---|---|
{ratio_table('cashflow_quality')}

**banking · {CATNAME['banking']}**

银行专属指标放这里，制造业公司为空对象 `{{}}`。

五类的小计：growth 10、profitability 18、solvency 14、efficiency 12、cashflow_quality 14，合计 68，加 banking 可选。

`roe_weighted` 用归母净利润除以平均归母净资产。附注数据可得时改用加权口径，并在 formula 里注明用的是加权还是平均。

`free_cash_flow`、`interest_bearing_debt`、`net_debt`、`working_capital`、`ocf`、`capex` 是金额，unit 写「元」，其余是比率、倍数、天数或次数。

**关于缺输入的指标。** 下面 13 个指标的公式引用了 26 个科目之外的值（finance_expense、interest_expense、income_tax_expense、pretax_profit、short_term_borrowings、current_portion_lt_debt、restricted_cash、fixed_assets、notes_receivable、contract_assets、interest_paid、dividend_paid），这些都在 A 的补抽清单里：ebit_margin、finance_expense_ratio、period_expense_ratio、roic、roic_minus_wacc、effective_tax_rate、cash_to_short_term_debt、interest_coverage、restricted_cash_ratio、fixed_asset_turnover、ar_and_inventory_to_assets、ocf_to_interest_paid、payout_ratio。示例为展示完整格式仍给出数值，其输入在各条记录的 inputs 里列明。正式跑链路时，A 补齐这些科目之前，这 13 个指标应改标 status 为 not_evaluable、value 为 null，符合接口对齐方案第五节的「先用现有科目跑通，缺的标 not_evaluable」。

### 5.5 risks（B 填）

`risks` 是数组，只放 **status 为 triggered** 的风险卡。字段对应设计文档 4.9 节的风险卡结构。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| risk_id | string | B | R01 | 卡片编号，同一次分析内唯一 |
| risk_name | string | B | 应收账款增速快于营业收入增速 | 风险简称 |
| category | string | B | 收入与资产 | 六类中文之一，映射见下表 |
| severity | string | B | medium | 等级，取 high、medium、low 三值 |
| severity_tag | string | B | 关注 | 中文标签，取 重大、关注、提示 |
| score | number \\| null | B | 60.0 | 0 到 100 的风险分 |
| status | string | B | triggered | 取 triggered、passed、not_evaluable、not_applicable |
| trigger | string | B | 应收账款增速 - 营业收入增速 > 5 个百分点 | 触发条件原文 |
| involved_values | array | B | 见示例 | 涉及数值列表，每项含 metric、value、unit、period、page |
| numeric_evidence | string | B | 应收账款由 3050000000 元增至…… | 数字证据，一句话说清算式与结果 |
| text_evidence | object | B | {{"quote": "...", "page": 45}} | 文本证据，含原文片段与页码。未找到管理层解释时 quote 写 null |
| explanation | string | B | 应收增速显著高于收入增速…… | 解释说明。区分事实与推断 |
| suggested_action | string | B | 核对应收账款账龄结构附注…… | 建议核查动作，由 B 的 suggestions 数组拼成 |
| evidence_chain | array | B | 见示例 | 六层证据链，见下 |

`severity` 三值对应中文含义。high 高，medium 中，low 低或观察项。`severity_tag` 是给 E 直接显示的中文标签，重大 / 关注 / 提示。E 按 severity 排序渲染。

**类别映射。** B 的类别英文 slug 映射到六类中文。

| B 的 slug | 我的类别 | B 的类别含义 |
|---|---|---|
{catmap_rows}

`审计与披露` 一类没有对应的 B slug，留给 A 的审计意见类风险。`asset_quality` 主要落在会计政策一类。

**evidence_chain 六层**，照 B 的实际输出。数据、计算、出处、判断、归因、建议。出处层给 sources 与 pages，判断层给 result 与 severity，归因层给杜邦分解、利润桥、现金流桥。E 的「点击展开」用这六层。

### 5.5.1 rules_evaluated（B 填）

`rules_evaluated` 是数组，放所有 **status 不是 triggered** 的规则，即 passed、not_evaluable、not_applicable。

字段与 risks 基本一致，去掉 risk_ 前缀的展示字段，保留核验需要的项。

| 字段名 | 类型 | 说明 |
|---|---|---|
| rule_id | string | 规则编号 |
| rule_name | string | 规则简称 |
| category | string | 六类中文之一 |
| status | string | passed、not_evaluable、not_applicable 之一 |
| severity | string \\| null | 触发时才有，未触发为 null |
| severity_tag | string \\| null | 同上 |
| trigger | string | 触发条件原文 |
| explanation | string | 一句话说明为什么没触发或为什么不可评估 |
| trigger_values | object | 相关指标的当期值 |

**为什么分开。** B 把全部规则都放进 risks 数组，包括没触发的（severity 为 null）。E 若逐条渲染会显示几十个「风险点」，其中大半是空壳。适配层按 `status == "triggered"` 过滤，触发的进 `risks`，其余进 `rules_evaluated`。核验页读后者。

### 5.6 valuation.comps（C 填）

相对估值，对应 C 的 relative 块。输入取自 financials，输出估值区间与可比公司区间。

输入字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| revenue | number | C | 18650000000 | 营业收入，来自 financials.revenue |
| net_income | number | C | 1580000000 | 归母净利润，来自 financials.net_income_parent |
| ebitda | number | C | 3410000000 | 息税折旧摊销前利润，营业利润加折旧摊销 |
| net_debt | number | C | 1900000000 | 净负债，有息负债减货币资金 |
| share_price | number | C | 16.50 | 评估日收盘价，元 |
| shares_outstanding | number | C | 2200000000 | 总股本，单位股 |
| shares_unit | string | C | 股 | 股本单位，固定「股」 |
| market_cap | number | C | 36300000000 | 总市值，元，等于股价乘股本 |
| currency | string | C | CNY | 币种 |

输出字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| peer_companies | array | C | 见示例 | 可比公司，每家含 name、ticker、pe、pb、ev_ebitda、ps |
| peer_multiples | object | C | 见示例 | 可比公司倍数的区间，键为 pe、pb、ev_ebitda、ps，每个含 min、median、max |
| implied_value_per_share | object | C | 见示例 | 各方法推出的每股价值，每个含 low、mid、high |
| valuation_range | object | C | {{low, mid, high}} | 综合每股估值区间，含 currency，单位元每股 |

`peer_multiples` 是「可比公司区间」，`valuation_range` 是本公司的估值区间，两者都要给。

注意 C 的 `range_low` / `range_high` 是股权价值总额（元），不是每股，映射到 valuation_range 时要转成每股。

### 5.7 valuation.dcf（C 填）

绝对估值。输入按分工说明的 DCF 清单，输出估值区间、终值假设与敏感性矩阵。敏感性嵌在 dcf 内。

输入字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| revenue_base | number | C | 18650000000 | 预测起点营业收入，元 |
| ebit_margin | number | C | 0.1190 | 息税前利润率，小数 |
| tax_rate | number | C | 0.1900 | 所得税率，小数 |
| da | number | C | 1200000000 | 折旧与摊销，元 |
| capex | number | C | 1680000000 | 资本开支，元 |
| nwc | number | C | 4930000000 | 净营运资本，元 |
| wacc | number | C | 0.0800 | 加权平均资本成本，小数 |
| terminal_growth | number | C | 0.0300 | 永续增长率，小数 |
| forecast_years | integer | C | 5 | 明确预测期年数 |

输出字段。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| forecast | array | C | 见示例 | 预测期逐年，每项含 year、revenue、ebit、fcff |
| terminal_assumptions | object | C | 见示例 | 终值假设，含 terminal_growth、terminal_fcff、terminal_value、pv_terminal_value、tv_pct_of_ev、wacc |
| valuation_range | object | C | {{low, mid, high}} | 每股估值区间，含 currency |
| sensitivity | object | C | 见示例 | 敏感性，含 metric、unit、wacc_values、terminal_growth_values、matrix |

`sensitivity.matrix` 的行对应 wacc_values，列对应 terminal_growth_values。示例里 wacc 8.00% 与终值增长 3.00% 交叉得到 13.9 元每股，与 valuation_range.mid 对齐。

### 5.8 sources（A 归集）

`sources` 是数组，每条对应一个被引用的文件页。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| company_name | string | A | 恒锐精密制造股份有限公司 | 公司全称 |
| report_period | string | A | 2025 | 报告期 |
| file_name | string | A | 恒锐精密_2025年年度报告.pdf | 原始文件名 |
| page | integer | A | 60 | 被引用的页码 |
| retrieved_at | string | A | 2026-10-05T14:20:00+08:00 | 获取时间，ISO 8601 带时区 |
| source_url | string | A | http://www.cninfo.com.cn/... | 来源链接，本地文件留 null |

不同页码要写不同条目。同一次分析里被引用多少个页，就写多少条。

### 5.9 valuation.blended（C 填）

融合估值。把相对估值与绝对估值加权成一个每股价值，给出相对现价的上行空间与结论。E 页面的头条数字。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| blended_per_share | number | C | 14.7 | 融合后每股价值，元每股 |
| current_price | number | C | 16.50 | 当前股价，元 |
| upside | number | C | -0.1091 | 上行空间，小数，blended_per_share / current_price - 1 |
| verdict | string | C | 高估 | 结论，取 显著低估、低估、大致合理、高估、显著高估 |
| components | array | C | 见示例 | 各估值法的每股价值与权重，每项含 key、label、per_share、weight、equity_value |

### 5.10 valuation.scenarios（C 填）

三情景估值。乐观、中性、悲观各一套假设与结果。

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| bull | object | C | 见示例 | 乐观情景 |
| base | object | C | 见示例 | 中性情景 |
| bear | object | C | 见示例 | 悲观情景 |

每个情景的字段。

| 字段名 | 类型 | 示例 | 说明 |
|---|---|---|---|
| per_share | number | 18.6 | 该情景每股价值，元每股 |
| equity_value | number | 40920000000 | 该情景股权价值，元 |
| growth_y1 | number | 0.1500 | 第一年收入增速，小数 |
| ebit_margin | number | 0.1390 | EBIT 利润率，小数 |
| wacc | number | 0.0700 | 折现率，小数 |
| terminal_growth | number | 0.0350 | 永续增速，小数 |

### 5.11 valuation.sotp（C 填）

分部估值。可选，无分部数据时写 `{{"ok": false, "skipped": true}}`。

有分部数据时，按业务分部列每块的收入、利润、估值方法与分部价值，再汇总。

### 5.12 valuation 的其他键（C 填）

| 字段名 | 类型 | 谁填 | 示例 | 说明 |
|---|---|---|---|---|
| market_data | object | C | 见示例 | 行情，含 price、shares_outstanding、market_cap、price_date |
| warnings | array | C | 见示例 | 结论的一部分，不是报错。见下 |
| sources | array | C | 见示例 | 估值用到的数据来源，每项含 name、as_of、official |
| disclaimer | string | C | 见示例 | 免责声明 |

`warnings` 说明的是估值结论本身的局限，如终值算法分歧、折现率偏低、样本过少。C 明确它是结论的一部分，不是错误日志。E 要把它当结论渲染，不能当报错隐藏。

`disclaimer` 申明结果仅供研究与教学，不构成投资建议。

## 6. 各模块输入输出约定

链路按分工说明第五节的顺序走，每一步的输出是下一步的输入。统一对象在链路上只增字段，不换字段名。

| 步骤 | 谁做 | 读什么 | 写什么 |
|---|---|---|---|
| 财报抽取 | A | 年报 PDF | company（补全基本信息）、financials、sources |
| 指标计算 | B | financials | ratios |
| 风险诊断 | B | financials、ratios | risks、rules_evaluated |
| 相对估值 | C | financials、ratios、company | valuation.comps |
| 绝对估值 | C | financials、ratios（EBIT、折旧摊销等） | valuation.dcf、valuation.blended、valuation.scenarios、valuation.sotp |
| 前端渲染 | E | 整个对象，全字段只读 | 不写任何字段 |

四条硬约束。

1. B 算指标只从 financials 取数，不自己重新抽数值。
2. C 估值的输入只从 financials 与 ratios 取，行情与股本除外。行情值写进 valuation.market_data 与 valuation.sources。
3. risks 只放触发的卡，其余规则进 rules_evaluated。适配层按 status 过滤。
4. E 只读。页面要显示的任何数字，都必须在对象里已经存在，E 不派生。

WACC 的环这样解。B 算 `roic_minus_wacc` 和三条风险规则要用 WACC，而 WACC 由 C 产出，链路是 A 到 B 到 C。加一趟回填：第一趟 B 把依赖 WACC 的项标 not_evaluable，C 产出 WACC 后写回，第二趟只重算 B 里依赖 WACC 的那部分。编排层要把 B 跑两趟记进运行日志。

## 7. 数据边界与待定项

### 7.1 本 Schema 覆盖了什么

覆盖单公司一次分析的完整链路，含三表关键科目、六类指标、风险卡片、相对与绝对估值、融合与三情景、来源。示例公司为制造业，科目标签以通用口径给出。

### 7.2 明确没覆盖，需要时再加

- 时间序列。financials 每条记录只带一期内含 prior_value，够算一期同比。三年复合增速所需的 2023 年数据靠 B 的指标时间序列，未在本对象展开。要做多期趋势，另开时间序列字段。
- 分产品分地区收入、分部毛利、账龄结构、借款明细等附注级明细。当前不展开，A 抽到后按需并入 financials 或单独挂。sotp 用到的分部数据也在此列。
- 假设台账与预测三表。设计文档 M6 的假设台账字段较多，本 Schema 只保留 dcf.inputs 的关键假设。完整台账建议另设文件。
- 同业对比（M8）的多公司数组结构。本对象是单公司对象，多公司对比由 D 在编排层把多个对象拼成数组。拼接键待定。

### 7.3 待与成员商榷

下面每条都附了结论。本次已定案的标「已定案」，其余保留待定。审查发现的 H1、H2 两处本次已定案。

**1. 有息负债与折旧摊销的口径（找 A、B）— 已定案**

问题：这两个科目要从附注汇总，口径不一致会让 B 的偿债指标跟着错。

定案：A 按「短期借款 + 一年内到期的非流动负债 + 长期借款 + 应付债券」汇总，并在 source 里注明含哪几项。折旧摊销取现金流量表补充资料里固定资产折旧与无形资产摊销的合计。B 直接用 A 给的值，不自己重拼。

**2. 税率与基期数据由谁给（找 A、B，对应审查 H2）— 已定案**

问题：B 算 ROIC 要用税率，算三年复合增速要用 2023 年的数。

定案：税率由 A 抽「所得税费用 ÷ 利润总额」，键名 tax_rate，放进 financials 补抽清单。基期数据不要求 A 抽三代，由 B 在指标层自己维护三年序列（示例里 revenue_cagr_3y 的 inputs 直接带上 revenue_2023）。

**3. 估值输入的出处（找 C、E，对应审查 H1）— 已定案**

问题：valuation 的输入没有页码和来源，估值区间成了黑箱。

定案：由适配层从每条记录的 page 和 source 归集出顶层 sources。行情与估值参数登记在 valuation.sources 与 valuation.market_data，标注获取时间。C 的输出没有 page 字段，由适配层按字段补。

**4. 三个抽了没有下游用的科目（找 B）— 已定案**

问题：selling_expense、admin_expense、goodwill 抽了但没指标用。

定案：保留字段，B 补指标。本次 ratios 已加入 selling_expense_ratio、admin_expense_ratio、goodwill_to_equity。

**5. 风险等级档位（找 B）— 已定案**

问题：severity 只有 high / medium / low 三档。

定案：维持三档，不加 info。另加 `severity_tag`（重大 / 关注 / 提示）做中文展示，不改 severity 的取值。

**6. DCF 终值与 WACC 的拆解深度（找 C）— 待定**

问题：设计文档 4.12 要求终值并列永续增长与退出倍数两种方式，WACC 要拆出无风险利率、Beta、股权风险溢价、债务成本。

方案：中期汇报不要求 DCF，先保留现状。WACC 加四个可选字段 rf、beta、erp、cost_of_debt，C 有余力就填。退出倍数法放到第二阶段。这一条本次未定案。

**7. 非财务事实的命名规则（找 B、E）— 待定**

问题：风险卡里出现 pledge_ratio，financials 和 ratios 都没定义这个键。

方案：规定非财务事实的 metric 名一律带前缀，写成 governance.pledge_ratio、governance.auditor_change 这类，并在 source 里注明页码。本例的 R03 暂用 `pledge_ratio`，前缀规则本次未定案。

**8. 母公司口径（找 A、B）— 已定案**

问题：现在只存合并报表口径。

定案：暂不单独存一套。scope 保留「合并报表 / 母公司报表」两值，需要时区分。当前分析以合并为主。

**9. ROE 加权口径（找 B）— 已定案**

问题：示例 roe_weighted 用期初期末平均净资产简化计算，设计文档要求加权口径。

定案：映射关系固定——B 的 roe 即我的 roe_weighted，口径为「归母净利润 / 平均归母净资产」。附注数据可得时改用加权口径，并在 formula 里注明用的是加权还是平均。

注记：第 4 节示例里的数字全部是虚构的，只用于对齐格式。示例营业收入 18650000000 元对应 186.5 亿元（由原示例的金额口径换算而来）。正式交付时由 A 用真实年报数据替换，替换后仍须满足第 4 节的勾稽关系。
""")

text = "".join(parts)
with open(MDPATH, "w", encoding="utf-8") as f:
    f.write(text)
print("wrote", MDPATH, "bytes", len(text.encode("utf-8")))
