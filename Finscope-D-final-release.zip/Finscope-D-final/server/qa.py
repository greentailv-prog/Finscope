# -*- coding: utf-8 -*-
"""年报问答的确定性兜底。

想法.txt 第 8 条要求把 demo 里的年报问答和模板的 AI 问答合并。D 的做法：
  - 有问题、有统一对象时，先走这里的规则问答，保证断网也能回答核心数字；
  - 需要开放叙述时再交给 DeepSeek（前端/后端另配 API Key），本模块不依赖它。

规则问答只回答统一对象里有的数，每个结论带 metric / page / source_id，
不编造、不做买卖建议。
"""
from __future__ import annotations

import re

MONEY_KEYS = {
    "revenue": "营业收入",
    "operating_cost": "营业成本",
    "net_income_parent": "归母净利润",
    "net_income": "净利润",
    "cfo": "经营活动现金流净额",
    "total_assets": "总资产",
    "total_liabilities": "总负债",
    "equity_parent": "归母净资产",
    "cash_and_equivalents": "货币资金",
    "accounts_receivable": "应收账款",
    "inventory": "存货",
    "capex": "资本开支",
}

RATIO_KEYS = {
    "revenue_growth_yoy": ("growth", "营业收入同比"),
    "net_income_growth_yoy": ("growth", "归母净利润同比"),
    "gross_margin": ("profitability", "毛利率"),
    "net_margin": ("profitability", "净利率"),
    "roe_weighted": ("profitability", "加权 ROE"),
    "debt_to_asset_ratio": ("solvency", "资产负债率"),
    "cfo_to_net_income": ("cashflow_quality", "净现比"),
    "ar_turnover_days": ("efficiency", "应收账款周转天数"),
    "inventory_turnover_days": ("efficiency", "存货周转天数"),
}

# 用户问「为什么算不出」时，把 B 的输入字段翻成中文，别直接抛 avg_equity_parent。
INPUT_LABELS = {
    "avg_equity_parent": "期初、期末平均归母净资产",
    "equity_parent": "归母净资产",
    "avg_total_assets": "期初、期末平均总资产",
    "total_assets": "总资产",
    "avg_accounts_receivable": "期初、期末平均应收账款",
    "accounts_receivable": "应收账款",
    "avg_inventory": "期初、期末平均存货",
    "inventory": "存货",
    "avg_fixed_assets": "期初、期末平均固定资产",
    "fixed_assets": "固定资产",
    "avg_invested_capital": "期初、期末平均投入资本",
    "total_current_assets": "流动资产合计",
    "total_current_liabilities": "流动负债合计",
    "short_term_borrowings": "短期借款",
    "current_portion_lt_debt": "一年内到期的非流动负债",
    "long_term_borrowings": "长期借款",
    "bonds_payable": "应付债券",
    "interest_bearing_debt": "有息负债",
    "cash_and_equivalents": "货币资金",
    "restricted_cash": "受限货币资金",
    "ebit": "息税前利润",
    "ebitda": "息税折旧摊销前利润",
    "nopat": "税后经营利润",
    "interest_expense": "利息费用",
    "operating_profit": "营业利润",
    "pretax_profit": "利润总额",
    "income_tax_expense": "所得税费用",
    "selling_expense": "销售费用",
    "admin_expense": "管理费用",
    "finance_expense": "财务费用",
    "revenue": "营业收入",
    "net_income_parent": "归母净利润",
    "days": "一年天数",
    "dso": "应收账款周转天数",
    "dio": "存货周转天数",
    "dpo": "应付账款周转天数",
    "wacc": "加权平均资本成本",
    "roic": "投入资本回报率",
    "ar_t": "本期应收账款",
    "ar_t_1": "上期应收账款",
    "ibd_t": "本期有息负债",
    "ibd_t_1": "上期有息负债",
}

METRIC_ALIASES = (
    ("加权roe", "roe_weighted"), ("加权净资产收益率", "roe_weighted"),
    ("净资产收益率", "roe_weighted"), ("roe", "roe_weighted"),
    ("毛利率", "gross_margin"), ("净利率", "net_margin"),
    ("流动比率", "current_ratio"), ("速动比率", "quick_ratio"),
    ("现金比率", "cash_ratio"), ("资产负债率", "debt_to_asset_ratio"),
    ("权益乘数", "equity_multiplier"), ("有息负债率", "interest_bearing_debt_ratio"),
    ("有息负债", "interest_bearing_debt"), ("净负债", "net_debt"),
    ("利息保障", "interest_coverage"), ("净现比", "cfo_to_net_income"),
    ("应收账款周转天数", "ar_turnover_days"), ("应收账款周转", "ar_turnover"),
    ("存货周转天数", "inventory_turnover_days"), ("存货周转", "inventory_turnover"),
    ("应付账款周转天数", "ap_turnover_days"), ("应付账款周转", "ap_turnover"),
    ("固定资产周转", "fixed_asset_turnover"), ("总资产周转", "total_asset_turnover"),
    ("现金转换周期", "cash_conversion_cycle"),
    ("销售费用率", "selling_expense_ratio"), ("管理费用率", "admin_expense_ratio"),
    ("财务费用率", "finance_expense_ratio"), ("研发费用率", "rd_expense_ratio"),
    ("营业利润率", "operating_margin"), ("ebit利润率", "ebit_margin"),
    ("总资产收益率", "roa"), ("投入资本回报率", "roic"),
)

INTENTS = [
    ("valuation", ("估值", "目标价", "每股价值", "低估", "高估", "贵不贵", "空间")),
    ("risk", ("风险", "预警", "危险", "问题")),
    ("change", ("异动", "变化", "为什么", "原因", "归因")),
    ("cashflow", ("现金流", "经营现金", "净现比", "自由现金流")),
    ("debt", ("负债", "偿债", "杠杆", "资产负债率")),
    ("profit", ("利润", "净利润", "盈利", "毛利", "净利", "roe", "回报")),
    ("revenue", ("收入", "营收", "营业额", "增长")),
]


def _money(v):
    if not isinstance(v, (int, float)):
        return "-"
    if abs(v) >= 1e8:
        return "%.2f 亿元" % (v / 1e8)
    if abs(v) >= 1e4:
        return "%.2f 万元" % (v / 1e4)
    return "%.2f 元" % v


def _pct(v):
    return "-" if not isinstance(v, (int, float)) else "%.2f%%" % (v * 100)


def _growth(v):
    if not isinstance(v, (int, float)):
        return "-"
    return "%s %.2f%%" % ("同比增长" if v >= 0 else "同比下降", abs(v) * 100)


def _ratio(ratios, group, key):
    return ((ratios or {}).get(group) or {}).get(key) or {}


def _fact(label, value, rec=None, unit=None):
    rec = rec or {}
    return {
        "label": label,
        "value": value,
        "unit": unit,
        "metric": rec.get("metric"),
        "page": rec.get("page"),
        "pdf_page": rec.get("pdf_page"),
        "source_id": rec.get("source_id"),
        "raw_text": rec.get("raw_text"),
    }


def _intent(question):
    q = (question or "").lower()
    for name, words in INTENTS:
        if any(w.lower() in q for w in words):
            return name
    return "overview"


def _human(text, fin):
    """把问答里可能出现的字段名/内部说法换成用户能看懂的中文。"""
    s = str(text or "")
    for k, r in (fin or {}).items():
        if isinstance(r, dict) and r.get("label"):
            s = s.replace(k, r["label"])
    for a, b in (("D 常识校验", "数据校验"), ("not_evaluable", "缺输入"),
                 ("row_present_without_value", "年报未列金额"),
                 ("P0", "核心科目")):
        s = s.replace(a, b)
    for tok in ("A 的", "B 的", "C 的", "D 的"):
        s = s.replace(tok, "")
    return s


def _input_label(name, fin):
    """把 B 的输入字段名翻成人话。``foo_t`` / ``foo_t_1`` 也处理。"""
    if not name:
        return "某个科目"
    if name in INPUT_LABELS:
        return INPUT_LABELS[name]
    suffix = ""
    base = name
    if name.endswith("_t_1"):
        base, suffix = name[:-4], "上期"
    elif name.endswith("_t"):
        base, suffix = name[:-2], "本期"
    elif name.endswith("_prev"):
        base, suffix = name[:-5], "上期"
    if base in INPUT_LABELS:
        return INPUT_LABELS[base] + suffix
    rec = (fin or {}).get(base) or {}
    if rec.get("label"):
        return rec["label"] + suffix
    return name


def _ratio_text(rec):
    v = rec.get("value")
    u = rec.get("unit")
    if not isinstance(v, (int, float)):
        return "-"
    if u == "元":
        return _money(v)
    if u == "小数":
        return _pct(v)
    return "%.2f %s" % (v, u or "")


def _signed(v, unit):
    if not isinstance(v, (int, float)):
        return "-"
    sign = "+" if v >= 0 else "-"
    a = abs(v)
    if unit == "元":
        return "%s%.2f 亿元" % (sign, a / 1e8)
    if unit in ("倍", "次", "天"):
        return "%s%.2f %s" % (sign, a, unit)
    return "%s%.4f" % (sign, a)


def _catalog(ratios):
    for group, items in (ratios or {}).items():
        for key, rec in (items or {}).items():
            if isinstance(rec, dict):
                yield group, key, rec


def _find_metric(ratios, question):
    q = (question or "").lower().replace(" ", "")
    for alias, key in METRIC_ALIASES:
        if alias in q:
            for group, k, rec in _catalog(ratios):
                if k == key:
                    return group, k, rec
    best = None
    for group, k, rec in _catalog(ratios):
        label = str(rec.get("label") or rec.get("name") or "")
        if label and label.lower().replace(" ", "") in q:
            if best is None or len(label) > len(str(best[2].get("label") or "")):
                best = (group, k, rec)
    return best


def _is_missing_question(question):
    q = question or ""
    why = any(w in q for w in ("为什么", "为何", "算不出", "没算", "缺输入", "待输入",
                               "缺失", "为空", "不显示", "什么意思", "怎么回事"))
    subject = any(w in q for w in ("算", "缺", "空", "没有", "显示", "杜邦", "ROE", "roe",
                                   "指标", "数据", "输入", "分析"))
    return why and subject


def _metric_answer(unified, question, hit):
    company = unified.get("company") or {}
    fin = unified.get("financials") or {}
    name = company.get("name_short") or company.get("name") or "该公司"
    period = company.get("report_period") or ""
    group, key, rec = hit
    label = rec.get("label") or rec.get("name") or key
    lines = ["【%s】%s %s 年为 %s。" % (label, name, period, _ratio_text(rec))]
    prev = rec.get("prev")
    delta = rec.get("delta")
    if isinstance(prev, (int, float)):
        unit = rec.get("unit")
        if unit == "小数":
            lines.append("• 上期 %s，变动 %s%.2f 个百分点。"
                         % (_pct(prev), "+" if (delta or 0) >= 0 else "", (delta or 0) * 100))
        else:
            lines.append("• 上期 %s，变动 %s。"
                         % (_ratio_text({"value": prev, "unit": unit}),
                            _signed(delta, unit)))
    if rec.get("formula"):
        lines.append("• 计算口径：%s" % _human(rec["formula"], fin))
    if rec.get("page") is not None:
        lines.append("• 出处：年报第 %s 页。" % rec["page"])
    return {
        "ok": True,
        "intent": "metric",
        "answer": "\n".join(lines),
        "facts": [_fact(label, _ratio_text(rec), rec, rec.get("unit"))],
        "refs": [{"page": rec.get("page"), "source_id": rec.get("source_id")}]
        if rec.get("page") is not None else [],
    }


def _missing_answer(unified, question, key=None):
    ratios = unified.get("ratios") or {}
    fin = unified.get("financials") or {}
    company = unified.get("company") or {}
    name = company.get("name_short") or company.get("name") or "该公司"
    q = question or ""
    lines = []

    if "缺输入" in q or "待输入" in q or "什么意思" in q:
        lines.append("【“未取到”是什么意思】")
        lines.append("• 它不是 0，也不是系统坏了。它表示算这个指标需要的一个年报科目没有从 PDF 里抽出来，页面用“-”表示不知道，而不是拿 0 代替。")
        lines.append("• 常见原因有三种：年报没有单列这个科目；表格识别到了母公司列或摘要列；只抽到了部分年份。")
        lines.append("• 想看具体缺哪一项，直接问“XX 为什么算不出”，我会把缺的科目列出来。")

    if "杜邦" in q:
        roe = ((ratios.get("profitability") or {}).get("roe_weighted") or {})
        eq = fin.get("equity_parent") or {}
        years = sorted(str(y) for y in (eq.get("series") or {}).keys() if str(y).isdigit())
        nm = ((ratios.get("profitability") or {}).get("net_margin") or {})
        tat = ((ratios.get("efficiency") or {}).get("total_asset_turnover") or {})
        em = ((ratios.get("solvency") or {}).get("equity_multiplier") or {})
        lines.append("【杜邦分解为什么没有】")
        if roe.get("value") is None:
            lines.append("• 杜邦分解要把 ROE 拆成净利率 × 总资产周转率 × 权益乘数，三项都要用“期初、期末平均值”的口径。")
            lines.append("• 本期能算的期末值：净利率 %s、总资产周转率 %s、权益乘数 %s。"
                         % (_ratio_text(nm), _ratio_text(tat), _ratio_text(em)))
            if isinstance((roe.get("inputs") or {}).get("avg_equity_parent"), (int, float)) is False:
                lines.append("• 但平均归母净资产缺了一期：这只股票只取到 %s 年的归母净资产，缺 2024 年，平均口径的权益乘数和 ROE 都算不出来。"
                             % "、".join(years) if years else "• 但平均归母净资产缺了一期，平均口径的权益乘数和 ROE 都算不出来。")
            lines.append("• 补齐 2024 年末归母净资产后，杜邦三项就能相乘，报告里的“变化归因”也会自动出现。")
        else:
            lines.append("• ROE 已经能算，杜邦分解应该可用；如果报告里没有展开，说明 B 没有把归因层写进风险证据链。")
        lines.append("• 这不是“分析不出来”，而是上游缺一个平均口径的权益数据，系统没有拿期末值硬凑。")

    hit = _find_metric(ratios, q)
    if hit:
        group, k, rec = hit
        label = rec.get("label") or rec.get("name") or k
        if rec.get("value") is not None:
            lines.append("【%s 其实算出来了】" % label)
            lines.append("• 本期 %s，上期 %s%s。"
                         % (_ratio_text(rec),
                            _ratio_text({"value": rec.get("prev"), "unit": rec.get("unit")}),
                            "，变动 " + _signed(rec.get("delta"), rec.get("unit"))
                            if isinstance(rec.get("delta"), (int, float)) else ""))
        else:
            inputs = rec.get("inputs") or {}
            missing = [_input_label(x, fin) for x, v in inputs.items() if v is None]
            present = ["%s=%s" % (_input_label(x, fin), _ratio_text({"value": v, "unit": "元"}))
                       for x, v in inputs.items() if isinstance(v, (int, float))]
            lines.append("【%s 为什么算不出】" % label)
            if missing:
                lines.append("• 缺的是：%s。" % "、".join(missing))
            else:
                lines.append("• 计算需要的输入没有全部取到。")
            if present:
                lines.append("• 已经有的：%s。" % "；".join(present[:6]))
            if k == "roe_weighted":
                eq = fin.get("equity_parent") or {}
                years = sorted(str(y) for y in (eq.get("series") or {}).keys() if str(y).isdigit())
                if years:
                    lines.append("• 加权 ROE 要用期初、期末归母净资产的平均值；目前只取到 %s 年，缺 2024 年，平均净资产为空。"
                                 % "、".join(years))
            if rec.get("formula"):
                lines.append("• 计算口径：%s" % _human(rec["formula"], fin))
            lines.append("• 这里的“未取到”不是 0；补齐对应年报科目后会自动重算。")

    if not lines:
        lines.append("【为什么有些指标是空的】")
        lines.append("• 这些位置不是 0，是计算所需的年报科目没有取到。")
        lines.append("• 你可以直接问“XX 为什么算不出”，我会列出缺的具体科目和页码。")

    return {
        "ok": True,
        "intent": "missing",
        "answer": "\n".join(lines),
        "facts": [],
        "refs": [],
    }


def answer(unified, question, key=None):
    company = unified.get("company") or {}
    fin = unified.get("financials") or {}
    ratios = unified.get("ratios") or {}
    valuation = unified.get("valuation") or {}
    changes = unified.get("changes") or []
    risks = unified.get("risks") or []
    meta = unified.get("meta") or {}
    name = company.get("name_short") or company.get("name") or company.get("ticker") or "该公司"
    period = company.get("report_period") or meta.get("report_period") or ""

    # 「为什么算不出 / 缺输入是什么意思 / 杜邦为什么没有」先走解释分支，
    # 不要落到固定的利润或概览模板里。
    if _is_missing_question(question):
        res = _missing_answer(unified, question, key=key)
        res.update({
            "key": key,
            "question": question,
            "suggested": [
                "加权 ROE 为什么算不出", "缺输入是什么意思", "杜邦分析为什么没有",
                "有息负债是多少", "主要风险有哪些",
            ],
            "disclaimer": "以上为按统一对象事实生成的研究摘要，不构成投资建议。",
        })
        return res

    # 用户直接问某个指标是多少，优先按指标回答，不再套固定段落。
    hit = _find_metric(ratios, question)
    if hit and any(w in question for w in ("多少", "是多少", "怎么样", "什么水平",
                                          "高不高", "低不低", "几位", "几倍")):
        res = _metric_answer(unified, question, hit)
        res.update({
            "key": key,
            "question": question,
            "suggested": [
                "营业收入是多少", "毛利率是多少", "加权 ROE 多少",
                "有息负债是多少", "主要风险有哪些",
            ],
            "disclaimer": "以上为按统一对象事实生成的研究摘要，不构成投资建议。",
        })
        return res

    intent = _intent(question)
    facts, refs, parts = [], [], []

    def add_fin(metric, label=None):
        rec = fin.get(metric) or {}
        if rec.get("value") is None:
            return None
        facts.append(_fact(label or rec.get("label") or MONEY_KEYS.get(metric, metric),
                           _money(rec.get("value")), rec, "元"))
        if rec.get("page") is not None:
            refs.append({"page": rec.get("page"), "source_id": rec.get("source_id"),
                         "quote": rec.get("raw_text")})
        return rec

    def add_ratio(key_, label=None):
        grp, default_label = RATIO_KEYS[key_]
        rec = _ratio(ratios, grp, key_)
        if rec.get("value") is None:
            return None
        unit = rec.get("unit")
        shown = _pct(rec["value"]) if unit == "小数" else (
            "%.2f %s" % (rec["value"], unit or ""))
        facts.append(_fact(label or default_label or key_, shown, rec, unit))
        return rec

    if intent == "revenue":
        rec = add_fin("revenue")
        g = _ratio(ratios, "growth", "revenue_growth_yoy")
        add_ratio("revenue_growth_yoy")
        if rec:
            series = rec.get("series") or {}
            trend = "、".join("%s 年 %s" % (y, _money(series[y]))
                              for y in sorted(series)[-3:])
            parts.append("%s %s 年营业收入 %s，%s。%s。"
                         % (name, period, _money(rec.get("value")),
                            _growth(g.get("value")), trend))
            if rec.get("page") is not None:
                parts.append("数据出自年报第 %s 页（%s）。"
                             % (rec.get("page"), rec.get("section") or "财务报表"))
            if rec.get("status") not in (None, "found"):
                parts.append("该科目状态为 %s，引用前请回原文核对。" % rec.get("status"))

    elif intent == "profit":
        rec = add_fin("net_income_parent")
        add_fin("net_income")
        if "收入" in question or "营收" in question:
            rev_rec = add_fin("revenue")
            if rev_rec:
                parts.append("%s %s 年营业收入 %s，%s。"
                             % (name, period, _money(rev_rec.get("value")),
                                _growth(_ratio(ratios, "growth", "revenue_growth_yoy").get("value"))))
        add_ratio("gross_margin")
        add_ratio("net_margin")
        add_ratio("roe_weighted")
        if rec:
            parts.append("%s %s 年归母净利润 %s，%s；毛利率 %s，加权 ROE %s。"
                         % (name, period, _money(rec.get("value")),
                            _growth(_ratio(ratios, "growth", "net_income_growth_yoy").get("value")),
                            _pct(_ratio(ratios, "profitability", "gross_margin").get("value")),
                            _pct(_ratio(ratios, "profitability", "roe_weighted").get("value"))))

    elif intent == "cashflow":
        rec = add_fin("cfo")
        add_ratio("cfo_to_net_income")
        if rec:
            parts.append("%s %s 年经营活动现金流净额 %s，净现比 %.2f 倍。"
                         % (name, period, _money(rec.get("value")),
                            _ratio(ratios, "cashflow_quality", "cfo_to_net_income").get("value") or 0))
            if (_ratio(ratios, "cashflow_quality", "cfo_to_net_income").get("value") or 1) < 0.8:
                parts.append("净现比低于 0.8，利润的现金含量偏低，建议对应收和存货占用做进一步核查。")

    elif intent == "debt":
        add_fin("total_liabilities")
        add_fin("total_assets")
        add_ratio("debt_to_asset_ratio")
        parts.append("%s %s 年资产负债率 %s。"
                     % (name, period,
                        _pct(_ratio(ratios, "solvency", "debt_to_asset_ratio").get("value"))))

    elif intent == "risk":
        top = sorted(risks, key=lambda r: (
            {"high": 0, "medium": 1, "low": 2}.get(r.get("severity"), 3),
            -(r.get("score") or 0)))[:5]
        if top:
            parts.append("%s 共触发 %d 条风险，前 %d 条是：" % (name, len(risks), len(top)))
            for r in top:
                parts.append("· 【%s】%s（评分 %s）。%s"
                             % (r.get("severity_tag") or r.get("severity"),
                                r.get("risk_name"), r.get("score"),
                                _human(r.get("explanation") or "", fin)))
                te = r.get("text_evidence") or {}
                if te.get("page") is not None:
                    refs.append({"page": te.get("page"), "risk_id": r.get("risk_id")})
        else:
            parts.append("%s 当前没有触发风险规则。" % name)

    elif intent == "valuation":
        blended = valuation.get("blended") or {}
        dcf = valuation.get("dcf") or {}
        ddm = valuation.get("ddm") or {}
        comps = valuation.get("comps") or {}
        ps = blended.get("blended_per_share")
        lines = ["【估值结论】"]
        if ps is not None:
            lines.append("• 融合每股价值 %.2f 元，现价 %.2f 元，相对现价空间 %s。"
                         % (ps, blended.get("current_price") or 0, _pct(blended.get("upside"))))
            lines.append("• 综合判断：%s。" % (blended.get("verdict") or "未给出"))
            facts.append(_fact("融合每股价值", "%.2f 元/股" % ps, {}, "元/股"))
        else:
            ref = valuation.get("reference") or {}
            if ref.get("low") is not None:
                lines.append("• 融合结论未给出，参考区间 %.2f 至 %.2f 元/股。"
                             % (ref["low"], ref["high"]))
                lines.append("• 原因：估值所需的假设或数据还没有全部通过复核，单点结论容易误导。")
            else:
                lines.append("• 当前没有可用的估值结论，原因是数据或行情不足。")

        lines.append("\n【方法拆解】")
        if dcf.get("per_share") is not None:
            lines.append("• DCF（收益法）：每股 %.2f 元，WACC %s，永续增长 %s。"
                         % (dcf["per_share"], _pct(dcf.get("wacc")), _pct(dcf.get("terminal_growth"))))
        if ddm.get("per_share") is not None:
            lines.append("• DDM/剩余收益：每股 %.2f 元（银行、保险、证券适用）。" % ddm["per_share"])
        if comps.get("implied_per_share") is not None:
            lines.append("• 相对估值：每股 %.2f 元，可比公司 %s 家。"
                         % (comps["implied_per_share"], comps.get("peers_used") or comps.get("peer_count") or "-"))
        if len(lines) == 3:
            lines.append("• 各方法都没有产出可用的每股价值。")

        lines.append("\n【需要知道的限制】")
        q = unified.get("data_quality") or {}
        if q.get("blocked"):
            lines.append("• 数据质量已经阻断，以上数字只能用于核对，不能据此判断高估或低估。")
        elif q.get("status") == "warn":
            lines.append("• 部分科目的读数需要复核，相关异常值已从计算中剔除；估值结论只作参考。")
        elif (valuation.get("status") in ("partial", "unsupported")):
            lines.append("• 行业口径限制了标准估值方法，结论按区间参考，不构成投资建议。")
        else:
            lines.append("• 估值依赖假设，结论对 WACC、永续增长率和可比公司选择敏感，不构成投资建议。")
        parts = lines

    elif intent == "change":
        if changes:
            parts.append("%s %s 年有 %d 项值得注意的异动：" % (name, period, len(changes)))
            for c in changes[:5]:
                parts.append("· %s：%s %s" % (c.get("title"), c.get("reading"),
                                              "（%s）" % c.get("analysis") if c.get("analysis") else ""))
                ev = c.get("evidence") or {}
                if ev.get("page") is not None:
                    refs.append({"page": ev.get("page"), "source_id": ev.get("source_id"),
                                 "change_id": c.get("id")})
        else:
            parts.append("统一对象里还没有异动卡，请先生成分析。")

    else:
        add_fin("revenue")
        add_fin("net_income_parent")
        add_ratio("gross_margin")
        add_ratio("debt_to_asset_ratio")
        ps = (valuation.get("blended") or {}).get("blended_per_share")
        parts.append("%s（%s）%s 年年报。营业收入 %s，归母净利润 %s，毛利率 %s，资产负债率 %s。"
                     % (name, company.get("ticker") or "", period,
                        _money((fin.get("revenue") or {}).get("value")),
                        _money((fin.get("net_income_parent") or {}).get("value")),
                        _pct(_ratio(ratios, "profitability", "gross_margin").get("value")),
                        _pct(_ratio(ratios, "solvency", "debt_to_asset_ratio").get("value"))))
        if ps is not None:
            parts.append("估值方面，融合每股价值 %.2f 元，现价 %.2f 元。"
                         % (ps, (valuation.get("blended") or {}).get("current_price") or 0))

    return {
        "ok": True,
        "key": key,
        "question": question,
        "intent": intent,
        "answer": "\n".join(_human(p, fin) for p in parts) if parts else "当前数据里没有能回答这个问题的信息。",
        "facts": facts,
        "refs": refs,
        "suggested": [
            "营业收入是多少", "归母净利润和毛利率", "经营现金流怎么样",
            "主要风险有哪些", "估值贵不贵", "今年有哪些异动",
        ],
        "disclaimer": "以上为按统一对象事实生成的研究摘要，不构成投资建议。",
    }

