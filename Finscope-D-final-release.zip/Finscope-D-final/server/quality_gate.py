# -*- coding: utf-8 -*-
"""D 的数据质量闸门。

A 自己已经做过一轮 data_quality（资产负债平衡、毛利率区间等），D 不重复造一套
互相打架的检查，只做三件事：

  1. 把 A 的检查原样保留；
  2. 补 A 没覆盖、但会直接让报告说错话的检查：口径/期间一致、单位量级、
     三年覆盖、来源完整性、现金流与利润的方向；
  3. 给出一个总状态 ok / warn / blocked。blocked 时报告不得输出估值结论。

所有检查只读统一对象，不改数。
"""
from __future__ import annotations

# 净资产为负、金融类公司等不适用「毛利率/资产负债率」常识区间，这里只做提示，
# 不阻断；阻断项只留「同一份报告里数字自相矛盾」这一类。
CHECK_ORDER = (
    "PERIOD_CONSISTENCY", "UNIT_SCALE", "UNIT_SCALE_PRIOR", "YEAR_COVERAGE",
    "SOURCE_COMPLETENESS", "BALANCE_SHEET", "BALANCE_SHEET_V2",
    "COST_VS_REVENUE", "GROSS_MARGIN_RANGE", "DEBT_RATIO_RANGE",
    "GROWTH_RANGE", "CFO_VS_PROFIT",
)


def _v(fin, key):
    rec = fin.get(key) or {}
    val = rec.get("value")
    return val if isinstance(val, (int, float)) else None


def _rec(fin, key):
    return fin.get(key) or {}


def _check(code, status, detail, metric=None, page=None, pdf_page=None,
           source_id=None, **extra):
    out = {"code": code, "status": status, "detail": detail,
           "metric": metric, "page": page, "pdf_page": pdf_page,
           "source_id": source_id, "origin": "D"}
    out.update(extra)
    return out


def _period_check(fin, meta):
    annual = str((meta or {}).get("report_period") or "")
    mismatched = []
    for key, rec in fin.items():
        period = str(rec.get("period") or "")
        if period and annual and period[:4] != annual[:4]:
            mismatched.append("%s(period=%s)" % (key, period))
    if mismatched:
        return _check("PERIOD_CONSISTENCY", "block",
                      "以下科目的期间与报告期 %s 不一致：%s"
                      % (annual, "、".join(mismatched[:8])), metrics=mismatched)
    return _check("PERIOD_CONSISTENCY", "pass",
                  "全部科目期间与报告期 %s 一致" % (annual or "未标注"))


def _unit_scale_check(fin):
    """当期值和上年值差 1000 倍以上，通常是元/万元/亿元混用。"""
    bad = []
    for key, rec in fin.items():
        cur, prev = rec.get("value"), rec.get("prior_value")
        if not isinstance(cur, (int, float)) or not isinstance(prev, (int, float)):
            continue
        if cur == 0 or prev == 0:
            continue
        ratio = abs(cur) / abs(prev)
        if ratio >= 1000 or ratio <= 1 / 1000:
            bad.append({"metric": key, "value": cur, "prior": prev,
                        "ratio": round(ratio, 4), "page": rec.get("page"),
                        "pdf_page": rec.get("pdf_page")})
    if bad:
        return _check("UNIT_SCALE_PRIOR", "block",
                      "%d 个科目的本期/上期比值超过 1000 倍，疑似单位混用：%s"
                      % (len(bad), "、".join(b["metric"] for b in bad[:8])),
                      items=bad)
    return _check("UNIT_SCALE_PRIOR", "pass", "未发现本期/上期量级突变")


def _year_coverage_check(fin, meta):
    years = set((meta or {}).get("years") or [])
    for rec in fin.values():
        years.update((rec.get("series") or {}).keys())
    years = sorted(y for y in years if str(y).isdigit())
    if len(years) >= 3:
        return _check("YEAR_COVERAGE", "pass", "覆盖 %d 个年度：%s"
                      % (len(years), "、".join(years[-4:])))
    return _check("YEAR_COVERAGE", "warn",
                  "只覆盖 %d 个年度，无法做三年趋势：%s"
                  % (len(years), "、".join(years) or "无"), years=years)


def _source_check(fin, sources):
    source_ids = {s.get("source_id") for s in (sources or []) if s.get("source_id")}
    no_source = []
    for key, rec in fin.items():
        if rec.get("status") != "found":
            continue
        has_page = rec.get("page") is not None or rec.get("pdf_page") is not None
        has_url = bool(rec.get("source_url"))
        sid = rec.get("source_id")
        if not has_page and not has_url:
            no_source.append(key)
        elif sid and source_ids and sid not in source_ids:
            no_source.append(key)
    if no_source:
        return _check("SOURCE_COMPLETENESS", "warn",
                      "%d 个已取数科目缺少页码或来源链接：%s"
                      % (len(no_source), "、".join(no_source[:8])),
                      metrics=no_source)
    return _check("SOURCE_COMPLETENESS", "pass", "已取数科目都有页码或来源链接")


def _balance_check(fin):
    a, l = _v(fin, "total_assets"), _v(fin, "total_liabilities")
    # 优先用所有者权益合计（含少数股东）；没有再用归母权益。
    # A 的合并报表有少数股东权益，用归母权益硬勾稽会把正常公司误判成不平衡。
    eq_total, eq_parent = _v(fin, "total_equity"), _v(fin, "equity_parent")
    e, eq_name = (eq_total, "所有者权益合计") if eq_total is not None else (eq_parent, "归母权益")
    if None in (a, l, e):
        return _check("BALANCE_SHEET_V2", "warn", "资产/负债/权益有缺项，无法勾稽")
    diff = a - l - e
    ratio = abs(diff) / (abs(a) or 1)
    status = "pass" if ratio <= 0.01 else ("warn" if ratio <= 0.05 else "block")
    return _check("BALANCE_SHEET_V2", status,
                  "资产 - 负债 - %s = %.2f 元，占资产 %.2f%%" % (eq_name, diff, ratio * 100),
                  metric="total_assets", page=_rec(fin, "total_assets").get("page"),
                  source_id=_rec(fin, "total_assets").get("source_id"))


def _cost_check(fin):
    cost, rev = _v(fin, "operating_cost"), _v(fin, "revenue")
    if None in (cost, rev) or rev == 0:
        return _check("COST_VS_REVENUE", "warn", "营业成本或营业收入缺失，无法检查")
    ratio = cost / rev
    status = "pass" if -0.05 <= ratio <= 1.2 else "warn"
    return _check("COST_VS_REVENUE", status,
                  "营业成本 / 营业收入 = %.2f" % ratio,
                  metric="operating_cost", page=_rec(fin, "operating_cost").get("page"))


def _margin_check(fin):
    rev, cost = _v(fin, "revenue"), _v(fin, "operating_cost")
    if None in (rev, cost) or rev == 0:
        return _check("GROSS_MARGIN_RANGE", "warn", "收入或成本缺失，无法算毛利率")
    gm = (rev - cost) / rev
    status = "pass" if -0.5 <= gm <= 1.0 else "warn"
    return _check("GROSS_MARGIN_RANGE", status, "毛利率 %.2f%%" % (gm * 100),
                  metric="gross_margin")


def _debt_check(fin):
    a, l = _v(fin, "total_assets"), _v(fin, "total_liabilities")
    if None in (a, l) or a == 0:
        return _check("DEBT_RATIO_RANGE", "warn", "资产或负债缺失，无法算资产负债率")
    dr = l / a
    status = "pass" if 0 <= dr <= 1.5 else "warn"
    return _check("DEBT_RATIO_RANGE", status, "资产负债率 %.2f%%" % (dr * 100),
                  metric="debt_to_asset")


def _growth_check(fin):
    bad = []
    for key in ("revenue", "net_income_parent", "cfo"):
        rec = _rec(fin, key)
        cur, prev = rec.get("value"), rec.get("prior_value")
        if not isinstance(cur, (int, float)) or not isinstance(prev, (int, float)) or prev == 0:
            continue
        g = (cur - prev) / abs(prev)
        if abs(g) > 10:
            bad.append("%s 同比 %.0f%%" % (key, g * 100))
    if bad:
        return _check("GROWTH_RANGE", "warn",
                      "增速超过 ±1000%%，需回原文核对：%s" % "；".join(bad))
    return _check("GROWTH_RANGE", "pass", "主要科目同比增速在合理范围")


def _cfo_check(fin):
    cfo, ni = _v(fin, "cfo"), _v(fin, "net_income_parent")
    if None in (cfo, ni):
        return _check("CFO_VS_PROFIT", "warn", "经营现金流或归母净利润缺失")
    if ni > 0 and cfo < 0:
        return _check("CFO_VS_PROFIT", "warn",
                      "归母净利润为正但经营现金流为负，需核对现金流质量",
                      metric="cfo", page=_rec(fin, "cfo").get("page"))
    return _check("CFO_VS_PROFIT", "pass", "经营现金流与利润方向一致")


def evaluate(unified, extra_checks=None):
    """跑完整闸门，返回可放进统一对象 data_quality 的对象。"""
    fin = unified.get("financials") or {}
    meta = unified.get("meta") or {}
    sources = unified.get("sources") or []

    checks = []
    # A 已有的检查先保留；D 同名检查优先用 D 的（D 的带更多字段）
    a_quality = unified.get("data_quality") or {}
    a_checks = list(a_quality.get("checks") or [])
    # D 已经把某些异常科目标成 not_evaluable 并从 series 剔除；A 的同类 blocked
    # 如果点名的科目全部已被 D 处理，降为 warn，避免链路继续被一个已知项卡死。
    not_eval = {k for k, r in fin.items()
                if isinstance(r, dict) and r.get("status") == "not_evaluable"}
    corrected = {k for k, r in fin.items()
                 if isinstance(r, dict) and r.get("unit_corrected")}
    for i, c in enumerate(a_checks):
        if c.get("status") != "blocked":
            continue
        detail = str(c.get("detail") or "")
        named = [k for k in fin if k in detail]
        if named and all(k in not_eval for k in named):
            c = dict(c)
            c["status"] = "warn"
            c["detail"] = detail + "（系统已将这些科目剔除，不再阻断链路）"
            a_checks[i] = c
        elif named and all(k in corrected for k in named):
            c = dict(c)
            c["status"] = "warn"
            c["detail"] = detail + "（系统已按原文单位换算修正）"
            a_checks[i] = c
    a_codes = {c.get("code") for c in a_checks}

    d_checks = [
        _period_check(fin, meta),
        _unit_scale_check(fin),
        _year_coverage_check(fin, meta),
        _source_check(fin, sources),
        _balance_check(fin),
        _cost_check(fin),
        _margin_check(fin),
        _debt_check(fin),
        _growth_check(fin),
        _cfo_check(fin),
    ]
    d_codes = {c["code"] for c in d_checks}
    checks.extend(c for c in a_checks if c.get("code") not in d_codes)
    checks.extend(d_checks)
    for c in extra_checks or []:
        if c.get("code") not in d_codes:
            checks.append(c)

    order = {code: i for i, code in enumerate(CHECK_ORDER)}
    checks.sort(key=lambda c: (order.get(c.get("code"), 99), c.get("code")))

    blocked = [c for c in checks if c.get("status") == "block"]
    warned = [c for c in checks if c.get("status") == "warn"]
    status = "blocked" if blocked else ("warn" if warned else "ok")

    return {
        "status": status,
        "blocked": bool(blocked),
        "block_reasons": [c.get("detail") for c in blocked],
        "warn_reasons": [c.get("detail") for c in warned],
        "counts": {"pass": sum(1 for c in checks if c.get("status") == "pass"),
                   "warn": len(warned), "block": len(blocked)},
        "checks": checks,
        "mode": (meta or {}).get("source_mode") or (a_quality or {}).get("mode"),
    }
