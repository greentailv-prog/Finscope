# -*- coding: utf-8 -*-
"""后台任务：单工作线程 + 队列 + 进度上报 + 落盘续看。

思路照 A 的 src/jobs.py：
  - 一个 queue.Queue，一个 daemon worker 线程，串行执行（重活吃 CPU，并发只会互相拖慢）
  - submit(kind, params) -> job_id，同一 key 已在排队/执行中直接返回既有 job（幂等）
  - 进度按步骤权重加权估算；状态落盘到 server/state/jobs/<id>.json，节流两秒
  - 启动时把上次遗留的 running/queued 标成 interrupted
  - 支持取消：置标志并杀当前子进程

两条路径：
  路径 A（上传 PDF）：pagemap -> indicators -> 公共链
  路径 B（选已有公司）：直接进公共链
路径 B 不跑前两步，把后四段权重归一化（见 _active_steps）。
"""
from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

_THIS = Path(__file__).resolve()          # .../server/jobs.py
_D_ROOT = _THIS.parent.parent
if str(_D_ROOT) not in sys.path:
    sys.path.insert(0, str(_D_ROOT))

from server import config, catalog, chain_runner  # noqa: E402

JOBS_DIR = config.STATE_JOBS
WORK_DIR = config.SERVER_STATE / "work"

LOG_KEEP = 300
PERSIST_INTERVAL = 2.0

# 上传 PDF（路径 A）的完整权重（实测各段耗时占比：抽取最久，C 估值次之）
ALL_STEPS = [
    {"name": "pagemap",    "weight": 0.18, "label": "建立页码映射"},
    {"name": "indicators", "weight": 0.34, "label": "抽取财务指标"},
    {"name": "b_ratios",   "weight": 0.06, "label": "B 指标"},
    {"name": "b_risks",    "weight": 0.06, "label": "B 风险"},
    {"name": "c_engine",   "weight": 0.30, "label": "C 估值"},
    {"name": "adapt",      "weight": 0.06, "label": "D 适配与落盘"},
]
# 输入代码（联网）多两步：检索公司 / 下载年报
CODE_STEPS = [
    {"name": "resolve",    "weight": 0.03, "label": "检索公司与年报"},
    {"name": "download",   "weight": 0.09, "label": "下载年报"},
    {"name": "pagemap",    "weight": 0.14, "label": "建立页码映射"},
    {"name": "indicators", "weight": 0.26, "label": "抽取财务指标"},
    {"name": "b_ratios",   "weight": 0.06, "label": "B 指标"},
    {"name": "b_risks",    "weight": 0.06, "label": "B 风险"},
    {"name": "c_engine",   "weight": 0.26, "label": "C 估值"},
    {"name": "adapt",      "weight": 0.10, "label": "D 适配与落盘"},
]
_STEP_BY_NAME = {s["name"]: s for s in ALL_STEPS + CODE_STEPS}
# 路径 B 只跑后四段
_B_STEP_NAMES = ["b_ratios", "b_risks", "c_engine", "adapt"]

JOBS: dict = {}
JOBS_LOCK = threading.RLock()
QUEUE: "queue.Queue[str]" = queue.Queue()
_worker_started = False
_last_persist: dict = {}


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class JobCancelled(Exception):
    pass


class JobError(RuntimeError):
    pass


def _active_steps(job):
    """任务实际跑的步骤列表。路径 B 只取后四段并归一化权重。"""
    mode = job.get("mode")
    if mode == "upload":
        return list(ALL_STEPS)
    if mode == "code":
        return list(CODE_STEPS)
    subset = [_STEP_BY_NAME[n] for n in _B_STEP_NAMES]
    total = sum(s["weight"] for s in subset)
    return [{"name": s["name"], "label": s["label"], "weight": s["weight"] / total}
            for s in subset]


def _percent_of(job):
    steps = _active_steps(job)
    idx = job.get("step_index", 0)
    idx = max(0, min(idx, len(steps) - 1))
    done = sum(s["weight"] for s in steps[:idx])
    frac = job.get("step_frac", 0.0) or 0.0
    return int(round(100 * (done + steps[idx]["weight"] * max(0.0, min(frac, 1.0)))))


def snapshot(job):
    """对外快照：内部字段（子进程句柄等）不出去。"""
    with JOBS_LOCK:
        out = {k: v for k, v in job.items() if not k.startswith("_")}
        out["log"] = list(job.get("log") or [])
    return out


# --------------------------------------------------------------------------
# 进度上报 / 子进程运行：供 chain_runner 复用
# --------------------------------------------------------------------------
class JobContext:
    def __init__(self, job):
        self.job = job

    # ---- 日志 ----
    def log(self, line):
        line = str(line).rstrip("\n")
        if not line:
            return
        with JOBS_LOCK:
            self.job["log"].append(line)
            self.job["updated_at"] = _now()
        _maybe_persist(self.job)

    # ---- 步骤 ----
    def step(self, name):
        steps = _active_steps(self.job)
        names = [s["name"] for s in steps]
        with JOBS_LOCK:
            if name in names:
                i = names.index(name)
                self.job["step_index"] = i
                self.job["step"] = name
                self.job["step_label"] = steps[i]["label"]
            else:
                # 不在当前任务步骤表里（例如路径 B 收到 pagemap），只记标记
                self.job["step"] = name
                self.job["step_label"] = _STEP_BY_NAME.get(name, {}).get("label", name)
            self.job["step_frac"] = 0.0
            self.job["percent"] = _percent_of(self.job)
            self.job["updated_at"] = _now()
        _persist(self.job)

    def set_frac(self, frac):
        with JOBS_LOCK:
            self.job["step_frac"] = max(0.0, min(float(frac), 1.0))
            self.job["percent"] = _percent_of(self.job)
        _maybe_persist(self.job)

    def cancelled(self):
        return bool(self.job.get("_cancel"))

    def check_cancel(self):
        if self.cancelled():
            raise JobCancelled()

    # ---- 子进程 ----
    def run(self, cmd):
        """跑子进程，逐行读 stdout 进日志，期间可取消。返回退出码。"""
        self.check_cancel()
        argv = [str(c) for c in cmd]
        # 给 python 加 -u：Windows 管道不加会缓冲，日志攒到最后才出
        if argv and os.path.basename(argv[0]).lower().startswith("python"):
            argv = [argv[0], "-u"] + argv[1:]
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        self.log("$ " + " ".join('"%s"' % c if " " in c else c for c in argv))
        proc = subprocess.Popen(argv, cwd=str(_D_ROOT), env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding="utf-8", errors="replace")
        with JOBS_LOCK:
            self.job["_proc"] = proc
        try:
            for line in proc.stdout:
                if line.strip():
                    self.log(line.rstrip("\n"))
                if self.cancelled():
                    proc.kill()
                    raise JobCancelled()
            code = proc.wait()
        finally:
            with JOBS_LOCK:
                self.job["_proc"] = None
        # 子进程被 cancel 杀掉时，退出码非零，但语义是「取消」不是「失败」
        if self.cancelled():
            raise JobCancelled()
        return code


# --------------------------------------------------------------------------
# 落盘
# --------------------------------------------------------------------------
def _persist(job):
    try:
        JOBS_DIR.mkdir(parents=True, exist_ok=True)
        path = JOBS_DIR / ("%s.json" % job["id"])
        tmp = path.with_suffix(".json.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(snapshot(job), f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
        _last_persist[job["id"]] = time.time()
    except OSError:
        pass


def _maybe_persist(job):
    if time.time() - _last_persist.get(job["id"], 0) >= PERSIST_INTERVAL:
        _persist(job)


# --------------------------------------------------------------------------
# 队列
# --------------------------------------------------------------------------
def _idempotent_key(kind, params):
    mode = params.get("mode")
    if mode == "upload":
        return "upload:%s" % params.get("upload_id")
    if mode == "code":
        return "code:%s_%s" % (str(params.get("query") or params.get("code") or "").strip(),
                               catalog.strip_year(params.get("year")))
    return "%s:%s_%s" % (kind, config.normalize_code(params.get("code")),
                         catalog.strip_year(params.get("year")))


def submit(kind, params):
    """入队一个任务。同一 key 已排队/运行中，直接返回既有 job（幂等）。"""
    key = _idempotent_key(kind, params)
    with JOBS_LOCK:
        for j in JOBS.values():
            if j.get("_key") == key and j["status"] in ("queued", "running"):
                return snapshot(j)
        job = {
            "id": uuid.uuid4().hex[:12],
            "kind": kind,
            "mode": params.get("mode"),
            "params": params,
            "status": "queued",
            "step_index": 0,
            "step": None,
            "step_label": None,
            "step_frac": 0.0,
            "percent": 0,
            "log": [],
            "result": None,
            "error": None,
            "created_at": _now(),
            "updated_at": _now(),
            "_proc": None,
            "_cancel": False,
            "_key": key,
        }
        # 步初始化
        steps = _active_steps(job)
        job["step"] = steps[0]["name"]
        job["step_label"] = steps[0]["label"]
        JOBS[job["id"]] = job
    _persist(job)
    _ensure_worker()
    QUEUE.put(job["id"])
    return snapshot(job)


def get(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    return snapshot(job) if job else None


def recent(limit=20):
    with JOBS_LOCK:
        jobs = sorted(JOBS.values(), key=lambda j: j["created_at"], reverse=True)
    return [snapshot(j) for j in jobs[:limit]]


def cancel(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
        if not job or job["status"] not in ("queued", "running"):
            return False
        job["_cancel"] = True
        proc = job.get("_proc")
    if proc and proc.poll() is None:
        try:
            proc.kill()
        except OSError:
            pass
    return True


def _finish(job, status, result=None, error=None):
    with JOBS_LOCK:
        job["status"] = status
        job["result"] = result
        job["error"] = error
        job["updated_at"] = _now()
        if status == "done":
            job["percent"] = 100
        job["_proc"] = None
    _persist(job)


def _ensure_worker():
    global _worker_started
    with JOBS_LOCK:
        if _worker_started:
            return
        _worker_started = True
    threading.Thread(target=_worker, name="finscope-jobs", daemon=True).start()


def _worker():
    while True:
        job_id = QUEUE.get()
        with JOBS_LOCK:
            job = JOBS.get(job_id)
        if not job or job["status"] != "queued":
            continue
        with JOBS_LOCK:
            job["status"] = "running"
            job["updated_at"] = _now()
        _persist(job)
        ctx = JobContext(job)
        try:
            result = _run_job(job, ctx)
            _finish(job, "done", result=result)
        except JobCancelled:
            ctx.log("任务已取消")
            _finish(job, "cancelled", error="任务已取消")
        except Exception as exc:  # noqa: BLE001
            ctx.log("[错误] %s" % exc)
            _finish(job, "error", error=str(exc))


# --------------------------------------------------------------------------
# 任务主体
# --------------------------------------------------------------------------
def _load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _python():
    return sys.executable


def _run_job(job, ctx):
    params = job["params"]
    mode = job.get("mode")
    work_dir = WORK_DIR / job["id"]
    work_dir.mkdir(parents=True, exist_ok=True)

    if mode == "upload":
        a_obj, extra_warnings, flagged, pdf_path = _prepare_upload(params, ctx)
        source_mode = "upload"
    elif mode == "code":
        a_obj, extra_warnings, flagged, pdf_path = _prepare_code(params, ctx)
        source_mode = (a_obj.get("meta") or {}).get("source_mode") or "online"
    elif mode == "existing":
        a_obj, extra_warnings, flagged, pdf_path = _prepare_existing(params, ctx)
        source_mode = (a_obj.get("meta") or {}).get("source_mode") or "upload"
    else:
        raise JobError("未知的 mode：%r" % mode)

    res = chain_runner.run_chain(
        a_obj,
        code=(a_obj.get("company") or {}).get("ticker"),
        work_dir=work_dir,
        reporter=ctx,
        want_report=True,
        extra_warnings=extra_warnings,
        flagged_metrics=flagged,
        source_mode=source_mode,
        online=True,
    )
    summary = dict(res["summary"])
    return {
        "key": res["key"],
        "unified_path": res["unified_path"],
        "run_log_path": res["run_log_path"],
        "report": res["report"],
        "summary": summary,
        "warnings": res["run_log"].get("warnings") or [],
    }


def _prepare_existing(params, ctx):
    code = params.get("code")
    year = params.get("year")
    ctx.log("[路径 B] 选已有公司：code=%s year=%s" % (code, year))
    path, kind = catalog.find_input(code, year)
    if not path:
        raise JobError("A 里找不到 %s %s 的抽取结果，请先上传该公司的年报。" % (code, year))
    ctx.log("[路径 B] 读 A 的%s：%s"
            % ("统一对象" if kind == "unified" else "抽取结果", path.name))
    a_obj = _load_json(path)
    return a_obj, [], [], None


def _prepare_code(params, ctx):
    """输入代码/名称 -> 检索 -> 下载年报 -> PDF 抽取 -> 统一对象。

    任何一步网络或 PDF 版式失败，都回退到东方财富在线三表，并在日志里写明原因。
    在线三表没有页码，报告里会明确标注，不假装有原文证据。
    """
    from server import a_online

    query = params.get("query") or params.get("code") or params.get("company")
    if not query:
        raise JobError("mode=code 需要 query（股票代码或公司简称）。")
    year = params.get("year")

    ctx.step("resolve")
    hit = a_online.resolve(query, year)
    code, name, year = hit["code"], hit["name"], hit["year"]
    ctx.log("[联网] %s %s -> 目标年度 %s" % (code, name, year))
    ctx.log("[联网] 年报：%s" % (hit["report"].get("title") or "已定位"))

    warnings = []
    a_obj = None
    pdf_path = None

    ctx.step("download")
    try:
        dl = a_online.download_pdf(code, name, year,
                                   force=bool(params.get("force_download")))
        pdf_path = Path(dl["path"])
        ctx.log("[联网] PDF %s：%s（%.1f MB）"
                % ("复用" if dl["cached"] else "下载完成", pdf_path.name,
                   dl["size"] / 1e6))
    except Exception as exc:  # noqa: BLE001 - 网络失败要降级，不让整单失败
        warnings.append("年报 PDF 下载失败，已回退在线三表：%s" % exc)
        ctx.log("[warning] " + warnings[-1])

    if pdf_path and pdf_path.exists():
        try:
            py = _python()
            ctx.step("pagemap")
            if ctx.run([py, config.A_PDF_PAGEMAP, "--pdf", pdf_path]) != 0:
                raise JobError("A 的 pdf_pagemap 失败")
            ctx.step("indicators")
            if ctx.run([py, config.A_INDICATORS, "--pdf", pdf_path]) != 0:
                raise JobError("A 的 indicators 失败")
            a_obj = _build_unified_from_pdf(code, year, pdf_path, ctx)
            ctx.log("[联网] 已生成 A 统一对象：financials %d 条，sources %d 条"
                    % (len(a_obj.get("financials") or {}), len(a_obj.get("sources") or [])))
        except Exception as exc:  # noqa: BLE001
            warnings.append("PDF 抽取失败，已回退在线三表：%s" % exc)
            ctx.log("[warning] " + warnings[-1])
            a_obj = None

    if a_obj is None:
        try:
            a_obj = a_online.online_snapshot(code, year)
        except Exception as exc:  # noqa: BLE001
            raise JobError("年报 PDF 与在线三表都取不到：%s" % exc)
        a_obj.setdefault("meta", {})["source_mode"] = "online"
        a_obj["meta"]["data_source"] = "eastmoney"
        a_obj["meta"]["fallback_reason"] = warnings[-1] if warnings else None
        warnings.append("在线三表模式没有印刷页码，报告中的页码证据为空。")

    meta = a_obj.setdefault("meta", {})
    meta["source_mode"] = "online"
    meta.setdefault("report_period", str(year))
    meta.setdefault("period_type", "annual")
    meta.setdefault("years", sorted({str(y) for r in (a_obj.get("financials") or {}).values()
                                     for y in (r.get("series") or {})}))
    if pdf_path and pdf_path.exists():
        meta.setdefault("pdf", pdf_path.name)
    company = a_obj.setdefault("company", {})
    company.setdefault("name", name)
    company.setdefault("ticker", config.ticker_with_suffix(code))
    company.setdefault("report_period", str(year))
    company.setdefault("report_type", "年度报告")
    company.setdefault("exchange", hit.get("exchange"))
    company.setdefault("currency", "CNY")
    company.setdefault("amount_unit", "元")
    return a_obj, warnings, [], pdf_path


def _build_unified_from_pdf(code, year, pdf_path, ctx):
    """用 A 的 cockpit 把刚抽出的 JSON 转成 04 规范统一对象。

    cockpit 失败时退回 A 的旧抽取 JSON（17 科），仍可跑完链路，只是覆盖少。
    """
    from server import a_online
    a_online._a()  # 把 A/src 放进 sys.path
    try:
        import cockpit  # type: ignore
        obj = cockpit.build_pdf_cockpit(code, year)
        obj.setdefault("schema_version", "2.0")
        obj.setdefault("meta", {})["source_mode"] = "online"
        obj["meta"]["data_source"] = "annual_report_pdf"
        obj["meta"]["pdf"] = pdf_path.name
        return obj
    except Exception as exc:  # noqa: BLE001
        ctx.log("[warning] cockpit 统一对象构建失败，退回旧抽取 JSON：%s" % exc)
        stem = "%s_%s_%s" % (pdf_path.stem.split("_")[0], code, year)
        legacy = config.A_EXTRACTED / ("%s.json" % stem)
        if legacy.exists():
            return _load_json(legacy)
        raise


def _prepare_upload(params, ctx):
    """把上传的 PDF 放进 A/data/annual_reports/，跑 A 的抽取，返回 A 对象。"""
    uid = params.get("upload_id")
    meta_path = config.STATE_UPLOADS / ("%s.json" % uid)
    if not meta_path.exists():
        raise JobError("上传记录不存在：%s" % uid)
    meta = _load_json(meta_path)

    name = params.get("company") or meta.get("name")
    code = params.get("code") or meta.get("code")
    year = catalog.strip_year(params.get("year") or meta.get("year"))
    if not (name and code and year):
        raise JobError("无法确定公司名/代码/年份，请在上传文件名用 "
                       "<公司名>_<代码>_<年份>.pdf，或在 analyze 参数里补 company/code/year。")

    stem = "%s_%s_%s" % (name, config.normalize_code(code), year)
    target = config.A_ANNUAL_REPORTS / ("%s.pdf" % stem)
    config.A_ANNUAL_REPORTS.mkdir(parents=True, exist_ok=True)
    src = Path(meta.get("stored_path"))
    if not src.exists():
        raise JobError("上传的 PDF 暂存文件不见了：%s" % src)
    target.write_bytes(src.read_bytes())
    ctx.log("[路径 A] PDF -> %s" % target)

    py = _python()
    # 1. 页码映射
    if ctx.run([py, config.A_PDF_PAGEMAP, "--pdf", target]) != 0:
        raise JobError("A 的 pdf_pagemap 失败")
    # 2. 抽取指标
    if ctx.run([py, config.A_INDICATORS, "--pdf", target]) != 0:
        raise JobError("A 的 indicators 失败")

    out_path = config.A_EXTRACTED / ("%s.json" % stem)
    if not out_path.exists():
        raise JobError("A 抽取完成但未找到产物：%s" % out_path)
    ctx.log("[路径 A] A 抽取结果 -> %s" % out_path.name)

    # 3. 优先用 A 的 cockpit 转成 04 规范统一对象（30 个 P0、页码、来源台账）
    warnings = []
    try:
        a_obj = _build_unified_from_pdf(code, year, target, ctx)
        a_obj.setdefault("meta", {})["source_mode"] = "upload"
        a_obj["meta"]["data_source"] = "annual_report_pdf"
        ctx.log("[路径 A] 已生成 A 统一对象：financials %d 条，sources %d 条"
                % (len(a_obj.get("financials") or {}), len(a_obj.get("sources") or [])))
        return a_obj, warnings, [], target
    except Exception as exc:  # noqa: BLE001
        warnings.append("统一对象构建失败，退回旧抽取结果：%s" % exc)
        ctx.log("[warning] " + warnings[-1])
        a_obj = _load_json(out_path)

    # 4. 旧抽取结果的 D 侧校验：命中就记进 run_log.warnings（不改 A 的数据）
    from server import a_extract
    from adapters.from_a import FIELD_MAP  # A 科目键 -> 统一对象科目键
    findings = a_extract.validate(a_obj)
    warnings.extend(a_extract.validate_warnings(a_obj))
    # 只有「量级异常」这一判据才连带标 not_evaluable（判据②的符号项多为费用类取绝对值的
    # 既定约定，标了反而伤正确值）。行把 A 的键映成统一对象的键（如 cash->cash_and_equivalents）。
    flagged = sorted({
        FIELD_MAP.get(f["metric"], f["metric"]) for f in findings
        if any(r.startswith("量级异常") for r in f.get("reasons") or [])
    })
    if findings:
        ctx.log("[抽取后校验] 命中 %d 个疑似科目：" % len(findings))
        for f in findings:
            ctx.log("   - %s(%s) value=%s value_original=%s unit_raw=%s page=%s"
                    % (f["label"] or f["metric"], f["metric"], f["value"],
                       f["value_original"], f["unit_raw"], f["page"]))
    else:
        ctx.log("[抽取后校验] 未发现疑似占比列/取错列。")
    for w in warnings:
        ctx.log("[warning] " + w)
    return a_obj, warnings, flagged, target


# --------------------------------------------------------------------------
# 启动续看
# --------------------------------------------------------------------------
def mark_interrupted_on_startup():
    """服务重启后，之前 running/queued 的任务其子进程已随旧进程死掉，标为中断。"""
    if not JOBS_DIR.exists():
        return 0
    n = 0
    for path in JOBS_DIR.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("status") in ("running", "queued"):
            data["status"] = "interrupted"
            data["error"] = "服务重启，任务已中断"
            data["_proc"] = None
            data["_cancel"] = False
            try:
                path.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                                encoding="utf-8")
                n += 1
            except OSError:
                pass
    return n


def load_history(limit=50):
    """把上次运行留下的任务读回内存。"""
    if not JOBS_DIR.exists():
        return
    files = sorted(JOBS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    with JOBS_LOCK:
        for path in files[:limit]:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            data["_proc"] = None
            data["_cancel"] = False
            data.setdefault("_key", None)
            JOBS.setdefault(data["id"], data)
