# -*- coding: utf-8 -*-
"""把 memo.md 转成一个不依赖第三方库的 .docx。

只覆盖研报用到的 Markdown 子集：标题、段落、列表、引用、表格、加粗。
用 zipfile 直接写 OOXML，避免要求老师机器额外装 python-docx / pandoc。
"""
from __future__ import annotations

import re
import zipfile
from xml.sax.saxutils import escape

_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

_DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="%s">
  <w:docDefaults><w:rPrDefault><w:rPr>
    <w:rFonts w:ascii="Times New Roman" w:eastAsia="宋体" w:hAnsi="Times New Roman"/>
    <w:sz w:val="22"/><w:szCs w:val="22"/>
  </w:rPr></w:rPrDefault></w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Normal"><w:name w:val="Normal"/></w:style>
  <w:style w:type="paragraph" w:styleId="H1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/>
    <w:pPr><w:spacing w:before="240" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr>
    <w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="H2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/>
    <w:pPr><w:spacing w:before="200" w:after="100"/><w:outlineLvl w:val="1"/></w:pPr>
    <w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="H3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/>
    <w:pPr><w:spacing w:before="160" w:after="80"/><w:outlineLvl w:val="2"/></w:pPr>
    <w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>
</w:styles>""" % _W


def _run(text, bold=False, size=None):
    text = escape(str(text))
    rpr = ""
    if bold:
        rpr += "<w:b/>"
    if size:
        rpr += '<w:sz w:val="%d"/>' % size
    rpr = "<w:rPr>%s</w:rPr>" % rpr if rpr else ""
    return '<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r>' % (rpr, text)


def _para(text, style=None, bold=False, align=None):
    ppr = ""
    if style:
        ppr += '<w:pStyle w:val="%s"/>' % style
    if align:
        ppr += '<w:jc w:val="%s"/>' % align
    ppr = "<w:pPr>%s</w:pPr>" % ppr if ppr else ""
    return "<w:p>%s%s</w:p>" % (ppr, _run(text, bold=bold))


def _table(rows):
    if not rows:
        return ""
    ncol = max(len(r) for r in rows)
    out = ['<w:tbl><w:tblPr><w:tblBorders>'
           '<w:top w:val="single" w:sz="4" w:color="999999"/>'
           '<w:left w:val="single" w:sz="4" w:color="999999"/>'
           '<w:bottom w:val="single" w:sz="4" w:color="999999"/>'
           '<w:right w:val="single" w:sz="4" w:color="999999"/>'
           '<w:insideH w:val="single" w:sz="4" w:color="999999"/>'
           '<w:insideV w:val="single" w:sz="4" w:color="999999"/>'
           '</w:tblBorders></w:tblPr>']
    for i, row in enumerate(rows):
        cells = list(row) + [""] * (ncol - len(row))
        out.append("<w:tr>")
        for cell in cells:
            out.append("<w:tc><w:tcPr><w:tcW w:w=\"%d\" w:type=\"pct\"/></w:tcPr>%s</w:tc>"
                       % (100 // ncol, _para(cell, bold=(i == 0))))
        out.append("</w:tr>")
    out.append("</w:tbl>")
    return "".join(out)


def _is_table_sep(line):
    return bool(re.match(r"^\s*\|?\s*:?-{2,}.*\|", line))


def _parse_table_row(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def convert(md_text):
    body = []
    lines = md_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].rstrip()
        if not line.strip():
            i += 1
            continue
        # 表格
        if line.lstrip().startswith("|"):
            rows = []
            while i < len(lines) and lines[i].lstrip().startswith("|"):
                if not _is_table_sep(lines[i]):
                    rows.append(_parse_table_row(lines[i]))
                i += 1
            body.append(_table(rows))
            continue
        # 标题
        m = re.match(r"^(#{1,4})\s+(.*)$", line)
        if m:
            level = len(m.group(1))
            style = {1: "H1", 2: "H2", 3: "H3", 4: "H3"}.get(level)
            body.append(_para(m.group(2).strip(), style=style))
            i += 1
            continue
        # 列表
        if line.strip().startswith("- "):
            body.append(_para("• " + line.strip()[2:]))
            i += 1
            continue
        # 引用
        if line.strip().startswith("> "):
            body.append(_para(line.strip()[2:]))
            i += 1
            continue
        if line.strip() == "---":
            body.append(_para(""))
            i += 1
            continue
        # 普通段落（去掉 ** 加粗标记，整段按普通字重）
        body.append(_para(re.sub(r"\*\*(.+?)\*\*", r"\1", line.strip())))
        i += 1
    return "".join(body)


def write_docx(md_text, path):
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document xmlns:w="%s"><w:body>%s'
                '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
                '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>'
                '</w:sectPr></w:body></w:document>' % (_W, convert(md_text)))
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", _CONTENT_TYPES)
        z.writestr("_rels/.rels", _RELS)
        z.writestr("word/_rels/document.xml.rels", _DOC_RELS)
        z.writestr("word/styles.xml", _STYLES)
        z.writestr("word/document.xml", document)
    return path
