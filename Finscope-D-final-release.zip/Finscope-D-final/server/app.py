# -*- coding: utf-8 -*-
"""FinScope D 后端服务入口。

ThreadingHTTPServer + 路由分发 + 静态文件托管。本地默认绑 127.0.0.1，
部署时用 FINSCOPE_HOST=0.0.0.0。
HTTP 层多线程收请求，重活（抽取、跑链）全部丢给 jobs 里唯一的 worker 线程串行跑。

CORS：所有 /api/* 响应都带 CORS 头（有 Origin 就回显，没有就 *），
并在 do_OPTIONS 里对预检直接返回 204。E 无论把页面托管在这里，还是自己
双击 HTML 打开，fetch 都能通。

只用 Python 标准库。

启动：
    python server/app.py            # 或双击 启动后端.bat
"""
from __future__ import annotations

import json
import mimetypes
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote

_THIS = Path(__file__).resolve()
_D_ROOT = _THIS.parent.parent
if str(_D_ROOT) not in sys.path:
    sys.path.insert(0, str(_D_ROOT))

from server import config, routes, jobs  # noqa: E402

mimetypes.add_type("text/markdown", ".md")
mimetypes.add_type("application/json", ".json")

_JSON_CT = "application/json; charset=utf-8"

# 允许 E 传的自定义头
ALLOW_HEADERS = ("Content-Type, X-Filename, X-Code, X-Year, X-Company, X-Upload-Name")


class Handler(BaseHTTPRequestHandler):
    server_version = "FinScopeD/1.0"
    protocol_version = "HTTP/1.1"

    # ---------------------------------------------------------------- CORS
    def _cors_headers(self):
        origin = self.headers.get("Origin")
        h = {
            "Access-Control-Allow-Origin": origin if origin else "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": ALLOW_HEADERS,
            "Access-Control-Max-Age": "86400",
        }
        if origin:
            h["Vary"] = "Origin"
        return h

    # ---------------------------------------------------------------- 输出
    def _send(self, resp, cors=True):
        body = resp.body if isinstance(resp.body, (bytes, bytearray)) else str(resp.body).encode("utf-8")
        self.send_response(resp.status)
        self.send_header("Content-Type", resp.content_type)
        self.send_header("Content-Length", str(len(body)))
        if cors:
            for k, v in self._cors_headers().items():
                self.send_header(k, v)
        for k, v in (resp.headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _read_body(self):
        length = self.headers.get("Content-Length")
        if not length:
            return b""
        try:
            n = int(length)
        except ValueError:
            return b""
        remaining = n
        chunks = []
        while remaining > 0:
            chunk = self.rfile.read(min(remaining, 1 << 20))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        return b"".join(chunks)

    # ---------------------------------------------------------------- 方法
    def do_OPTIONS(self):
        # 预检直接 204
        self.send_response(204)
        for k, v in self._cors_headers().items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        try:
            self._route_get()
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self._send(routes.error_resp(500, "服务器内部错误：%s" % exc))

    def do_POST(self):
        try:
            self._route_post()
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self._send(routes.error_resp(500, "服务器内部错误：%s" % exc))

    # ---------------------------------------------------------------- 路由
    def _split(self):
        u = urlparse(self.path)
        path = unquote(u.path)
        query = {k: v[-1] for k, v in parse_qs(u.query, keep_blank_values=True).items()}
        return path, query

    def _route_get(self):
        path, query = self._split()

        if path == "/api/health":
            return self._send(routes.health())
        if path == "/api/companies":
            return self._send(routes.companies())
        if path == "/api/search":
            return self._send(routes.search(query))
        if path == "/api/history":
            return self._send(routes.history())
        if path.startswith("/api/quote/"):
            code = path[len("/api/quote/"):].strip("/")
            return self._send(routes.quote(code))
        if path.startswith("/api/valuation/excel/"):
            key = path[len("/api/valuation/excel/"):].strip("/")
            return self._send(routes.valuation_excel(key))
        if path == "/api/jobs":
            return self._send(routes.jobs_list())
        if path.startswith("/api/jobs/"):
            job_id = path[len("/api/jobs/"):].strip("/")
            return self._send(routes.job_detail(job_id))
        if path.startswith("/api/unified/"):
            key = path[len("/api/unified/"):].strip("/")
            return self._send(routes.unified(key))
        if path.startswith("/api/report/"):
            key = path[len("/api/report/"):].strip("/")
            return self._send(routes.report(key, query.get("format"), query.get("style")))
        if path.startswith("/api/export/"):
            key = path[len("/api/export/"):].strip("/")
            return self._send(routes.export(key, query.get("format")))
        if path.startswith("/files/reports/"):
            name = path[len("/files/reports/"):].strip("/")
            return self._serve_report_pdf(name)
        if path.startswith("/api/"):
            return self._send(routes.error_resp(404, "未知接口：%s" % path))

        # 静态文件
        return self._serve_static(path)

    def _route_post(self):
        path, query = self._split()
        body = self._read_body()

        if path == "/api/upload":
            return self._send(routes.upload(self.headers, query, body))
        if path == "/api/qa":
            try:
                payload = json.loads(body.decode("utf-8")) if body else {}
            except (ValueError, UnicodeDecodeError) as exc:
                return self._send(routes.error_resp(400, "请求体不是合法 JSON：%s" % exc))
            return self._send(routes.qa(payload))
        if path == "/api/valuation/recalc":
            try:
                payload = json.loads(body.decode("utf-8")) if body else {}
            except (ValueError, UnicodeDecodeError) as exc:
                return self._send(routes.error_resp(400, "请求体不是合法 JSON：%s" % exc))
            return self._send(routes.valuation_recalc(payload))
        if path == "/api/analyze":
            try:
                payload = json.loads(body.decode("utf-8")) if body else {}
            except (ValueError, UnicodeDecodeError) as exc:
                return self._send(routes.error_resp(400, "请求体不是合法 JSON：%s" % exc))
            return self._send(routes.analyze(payload))
        if path.startswith("/api/jobs/") and path.endswith("/cancel"):
            job_id = path[len("/api/jobs/"):-len("/cancel")].strip("/")
            return self._send(routes.job_cancel(job_id))
        return self._send(routes.error_resp(404, "未知接口：%s" % path))

    # ---------------------------------------------------------------- 年报 PDF
    def _serve_report_pdf(self, name):
        base = config.A_ANNUAL_REPORTS.resolve()
        target = (base / name).resolve()
        if base != target and base not in target.parents:
            return self._send(routes.error_resp(403, "非法路径"), cors=False)
        if not target.is_file():
            return self._send(routes.error_resp(404, "PDF 不存在：%s" % name), cors=False)
        body = target.read_bytes()
        from urllib.parse import quote
        return self._send(routes.Response(
            status=200, body=body, content_type="application/pdf",
            headers={"Content-Disposition":
                     "inline; filename*=UTF-8''%s" % quote(target.name)}),
            cors=False)

    # ---------------------------------------------------------------- 静态
    def _serve_static(self, path):
        base = config.SERVER_STATIC.resolve()
        rel = path.lstrip("/")
        if rel in ("", "/"):
            rel = "index.html"
        target = (base / rel).resolve()
        # 防目录穿越
        if base != target and base not in target.parents:
            return self._send(routes.error_resp(403, "非法路径"), cors=False)
        if not target.is_file():
            return self._send(routes.error_resp(404, "文件不存在：/%s" % rel), cors=False)
        ctype = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/json", "application/javascript"):
            ctype += "; charset=utf-8"
        body = target.read_bytes()
        resp = routes.Response(status=200, body=body, content_type=ctype)
        return self._send(resp, cors=False)

    # ---------------------------------------------------------------- 日志
    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s - %s\n" % (self.log_date_time_string(),
                                             self.address_string(), fmt % args))


def build_server():
    config.ensure_dirs()
    # A 预期的数据目录（上传的 PDF 落点），gitignore 已忽略
    config.A_ANNUAL_REPORTS.mkdir(parents=True, exist_ok=True)
    n = jobs.mark_interrupted_on_startup()
    jobs.load_history()
    if n:
        sys.stderr.write("启动：把上次遗留的 %d 个任务标成 interrupted。\n" % n)
    return ThreadingHTTPServer((config.HOST, config.PORT), Handler)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    httpd = build_server()
    sys.stdout.write(
        "\nFinScope D 后端已启动\n"
        "  接口前缀 : http://%s:%d/api\n"
        "  静态首页 : http://%s:%d/\n"
        "  公司数据 : %s\n"
        "  停止     : Ctrl+C\n\n"
        % (config.HOST, config.PORT, config.HOST, config.PORT, config.A_EXTRACTED))
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        sys.stdout.write("\n收到中断，正在关闭……\n")
    finally:
        httpd.shutdown()
        httpd.server_close()
        sys.stdout.write("已停止。\n")


if __name__ == "__main__":
    main()
