# -*- coding: utf-8 -*-
"""D 侧调 A 的联网取数：公司检索、年报定位、PDF 下载、在线三表。

A 的 `src/online_finance.py` 已经写好三件事，D 不重复实现，只做三件包装：
  1. 在 D 的进程里安全地 import A（把 A/src 放到 sys.path 末尾，避免 A 的
     `config` 等同名模块盖掉 D 的）；
  2. 把 A 的 OnlineError 统一成 D 的错误码，HTTP 层只认一套错误格式；
  3. 下载 PDF 落到 A/data/annual_reports/，文件名的 <公司名>_<代码>_<年份>.pdf
     与 A 的 indicators.py 解析规则一致，后续抽取直接复用。
"""
from __future__ import annotations

import json
import sys
import threading
from pathlib import Path

_D_ROOT = Path(__file__).resolve().parent.parent
if str(_D_ROOT) not in sys.path:
    sys.path.insert(0, str(_D_ROOT))

from server import config

_LOCK = threading.RLock()
_MODULES = {}


class OnlineError(RuntimeError):
    def __init__(self, code, message, hint=""):
        super().__init__(message)
        self.code = code
        self.message = message
        self.hint = hint

    def as_dict(self):
        return {"code": self.code, "message": self.message, "hint": self.hint}


def _a():
    """惰性加载 A 的三个模块。A 不在包内时给出明确错误。"""
    with _LOCK:
        if "online" in _MODULES:
            return _MODULES["online"]
        if not config.A_ONLINE_FINANCE.exists():
            raise OnlineError(
                "E_A_MODULE_MISSING",
                "找不到 A 的联网取数模块：%s" % config.A_ONLINE_FINANCE,
                "确认 modules/A 完整，或设置 FINSCOPE_A_ROOT 指向 A 包",
            )
        p = str(config.A_SRC)
        if p not in sys.path:
            sys.path.append(p)          # 放末尾，避免覆盖 D 自己的同名模块
        try:
            import online_finance  # type: ignore
            import fetch_cninfo   # type: ignore
        except Exception as exc:  # noqa: BLE001
            raise OnlineError("E_A_IMPORT_FAILED",
                              "A 的联网模块加载失败：%s" % exc,
                              "检查 requirements.txt 里的 requests 是否已安装") from exc
        _MODULES["online"] = (online_finance, fetch_cninfo)
        return _MODULES["online"]


def _call(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001
        # A 的 OnlineError 自带 code/message/hint；别的异常统一包一层
        code = getattr(exc, "code", None) or "E_ONLINE_FAILED"
        msg = getattr(exc, "message", None) or str(exc)
        hint = getattr(exc, "hint", "") or "检查网络后重试，或改用上传 PDF"
        raise OnlineError(code, msg, hint) from exc


def latest_annual_year():
    online, _ = _a()
    return online.latest_annual_year()


def search(query, limit=8):
    """输入代码或公司简称，返回候选公司列表。"""
    online, _ = _a()
    rows = _call(online.search_companies, query, limit=limit)
    return [{
        "code": r.get("code"),
        "name": r.get("name"),
        "ticker": r.get("ticker"),
        "exchange": r.get("exchange"),
    } for r in rows]


def resolve(query, year=None):
    """把用户输入解析成唯一一家公司 + 目标年度。

    返回 {code, name, ticker, exchange, year, report}。
    代码精确命中时直接用；只给名称且命中多家时，取第一条并在 candidates 里留全量。
    """
    rows = search(query, limit=8)
    if not rows:
        raise OnlineError("E_CODE_NOT_FOUND", "没有匹配的 A 股公司", "换一个代码或简称")
    pick = rows[0]
    if not year:
        year = latest_annual_year()
    year = int(str(year)[:4])
    report = _call(_a()[0].find_annual_report, pick["code"], year)
    return {
        "code": pick["code"],
        "name": pick["name"],
        "ticker": pick["ticker"],
        "exchange": pick["exchange"],
        "year": year,
        "report": report,
        "candidates": rows,
    }


def download_pdf(code, name, year, force=False):
    """下载年报 PDF 到 A 的年报目录。已存在且大于 100KB 就直接复用。

    返回 {path, size, cached, report}。
    """
    online, fetch_cninfo = _a()
    dest = config.A_ANNUAL_REPORTS / ("%s_%s_%s.pdf" % (name, code, year))
    config.A_ANNUAL_REPORTS.mkdir(parents=True, exist_ok=True)

    report = _call(online.find_annual_report, code, year, force=force)
    if dest.exists() and dest.stat().st_size > 100_000 and not force:
        return {"path": str(dest), "size": dest.stat().st_size,
                "cached": True, "report": report}

    sess = online._session()
    try:
        size = fetch_cninfo.download_pdf(report["pdf_url"], dest, sess)
    except Exception as exc:  # noqa: BLE001
        raise OnlineError("E_DOWNLOAD_FAILED",
                          "年报 PDF 下载失败：%s" % exc,
                          "到巨潮公告页手动下载后改用上传模式：%s"
                          % report.get("page_url", "")) from exc
    return {"path": str(dest), "size": size, "cached": False, "report": report}


def online_snapshot(code, year):
    """东方财富年度三表 -> A 的 04 规范对象（financials 30 个 P0）。"""
    online, _ = _a()
    obj = _call(online.build_online_financials, code, year)
    obj.setdefault("data_quality", _online_quality(obj))
    obj.setdefault("coverage", _coverage(obj))
    return obj


def _coverage(obj):
    fin = obj.get("financials") or {}
    p0 = [
        "revenue", "operating_cost", "operating_profit", "pretax_profit",
        "income_tax_expense", "net_income", "net_income_parent",
        "net_income_excl_nonrecurring", "selling_expense", "admin_expense",
        "finance_expense", "interest_expense", "depreciation_amortization",
        "cash_and_equivalents", "accounts_receivable", "inventory",
        "current_assets", "total_assets", "accounts_payable",
        "current_liabilities", "short_term_borrowings", "current_portion_lt_debt",
        "long_term_borrowings", "bonds_payable", "total_liabilities",
        "equity_parent", "total_equity", "cfo", "capex", "cash_received_from_sales",
    ]
    found = [k for k in p0 if (fin.get(k) or {}).get("status") == "found"]
    return {"p0_total": len(p0), "p0_found": len(found),
            "p0_missing": [k for k in p0 if k not in found],
            "sources": len(obj.get("sources") or [])}


def _online_quality(obj):
    """在线模式的最小质量检查：缺项与三年覆盖，不做 PDF 勾稽。"""
    fin = obj.get("financials") or {}
    years = (obj.get("meta") or {}).get("years") or []
    checks = []

    missing = [k for k, r in fin.items() if r.get("status") not in ("found",)]
    checks.append({
        "code": "P0_COVERAGE",
        "status": "pass" if len(missing) == 0 else "warn",
        "detail": "在线三表缺失 %d 个科目" % len(missing),
        "metrics": missing,
    })
    checks.append({
        "code": "YEAR_COVERAGE",
        "status": "pass" if len(years) >= 3 else "warn",
        "detail": "在线三表覆盖 %d 个年度：%s" % (len(years), "、".join(map(str, years))),
    })
    # 资产负债平衡（有当期数才算）
    def v(k):
        return (fin.get(k) or {}).get("value")

    if None not in (v("total_assets"), v("total_liabilities"), v("equity_parent")):
        diff = v("total_assets") - v("total_liabilities") - v("equity_parent")
        base = abs(v("total_assets")) or 1
        ratio = abs(diff) / base
        checks.append({
            "code": "BALANCE_SHEET",
            "status": "pass" if ratio <= 0.01 else "block",
            "detail": "资产 - 负债 - 归母权益 = %.2f 元（%.2f%%）" % (diff, ratio * 100),
        })

    blocked = any(c["status"] == "block" for c in checks)
    return {
        "status": "blocked" if blocked else ("warn" if any(c["status"] == "warn" for c in checks) else "ok"),
        "blocked": blocked,
        "checks": checks,
        "mode": "online",
    }


if __name__ == "__main__":
    import argparse
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="D 侧联网取数自检")
    ap.add_argument("query", nargs="?", default="600519")
    ap.add_argument("--year", type=int)
    ap.add_argument("--download", action="store_true")
    ap.add_argument("--snapshot", action="store_true")
    a = ap.parse_args()
    hit = resolve(a.query, a.year)
    print(json.dumps({k: v for k, v in hit.items() if k != "report"},
                     ensure_ascii=False, indent=1))
    print("年报：", hit["report"].get("title"), hit["report"].get("pdf_url"))
    if a.download:
        print(download_pdf(hit["code"], hit["name"], hit["year"]))
    if a.snapshot:
        obj = online_snapshot(hit["code"], hit["year"])
        print(json.dumps(obj.get("coverage"), ensure_ascii=False, indent=1))
