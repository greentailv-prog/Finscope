# -*- coding: utf-8 -*-
"""D 端的数据常识检查：拦住“量级不可能”的抽取值。

A 已经做了一轮 data_quality，但 PDF 表格的母/合并列、行号、千分位仍可能让某个
科目落在错误列。D 不修改 A 的原始文件，只在链路内：
  1. 把明显不可能的记录标成 not_evaluable，并写清原因；
  2. 从 series 里剔除这些年份，避免 B/C 拿错数继续算；
  3. 把命中项写进 run_log，报告和页面都能看到。

只做“资产负债/金额”这类可以交叉验证的检查，不做主观判断。
"""
from __future__ import annotations

import re

AMOUNT_KEYS = {
    "revenue", "operating_cost", "operating_profit", "pretax_profit",
    "net_income", "net_income_parent", "net_income_excl_nonrecurring",
    "cash_and_equivalents", "accounts_receivable", "inventory", "current_assets",
    "total_assets", "accounts_payable", "current_liabilities", "short_term_borrowings",
    "current_portion_lt_debt", "long_term_borrowings", "bonds_payable",
    "total_liabilities", "equity_parent", "total_equity", "cfo", "capex",
    "cash_received_from_sales", "depreciation_amortization",
}


def _v(fin, key, year=None):
    rec = fin.get(key) or {}
    if year is None:
        val = rec.get("value")
    else:
        val = (rec.get("series") or {}).get(str(year))
    return val if isinstance(val, (int, float)) else None


def align_series_years(a_obj):
    """A 有的 PDF 会把“本期”写成上一年的 +1（2024 年报写成 2025/2024/2023）。

    如果多数科目的最大年份等于报告期 +1，就整体回退一年；只改 D 链路内的
    series 键，不改 A 原始文件。返回一条说明或空串。
    """
    meta = a_obj.get("meta") or {}
    period = str(meta.get("report_period") or "")
    if not period.isdigit():
        return ""
    fin = a_obj.get("financials") or {}
    max_keys = []
    for rec in fin.values():
        if not isinstance(rec, dict):
            continue
        keys = [str(k) for k in (rec.get("series") or {}) if str(k).isdigit()]
        if keys:
            max_keys.append(max(keys))
    if not max_keys:
        return ""
    want_plus = str(int(period) + 1)
    if sum(1 for k in max_keys if k == want_plus) < max(1, len(max_keys) // 2):
        return ""
    for rec in fin.values():
        if not isinstance(rec, dict):
            continue
        s = rec.get("series") or {}
        if not s:
            continue
        rec["series"] = {str(int(k) - 1) if str(k).isdigit() else k: v
                         for k, v in s.items()}
    years = meta.get("years") or []
    meta["years"] = sorted({str(int(y) - 1) for y in years if str(y).isdigit()})
    meta["series_year_alignment"] = "A 的 series 年份整体 -1（本期列写成报告期+1）"
    return "A series 年份整体回退一年：报告期 %s，原最大年份 %s" % (period, want_plus)


def normalize_units(a_obj):
    """A 偶尔把「亿元」表头的数字又乘了 1e8；用 value_original 还原。

    只在 value / value_original 接近 1e8、且 unit_raw 写「亿元」时处理，
    并给记录打 unit_corrected 标记，供质量闸门把 A 的旧检查降级。
    """
    changed = []
    for key, rec in (a_obj.get("financials") or {}).items():
        if not isinstance(rec, dict):
            continue
        v, vo = rec.get("value"), rec.get("value_original")
        if not isinstance(v, (int, float)) or not isinstance(vo, (int, float)) or vo == 0:
            continue
        if str(rec.get("unit_raw") or "") not in ("亿元", "亿"):
            continue
        ratio = abs(v / vo)
        if 1e6 <= ratio <= 1e10:
            rec["value"] = vo
            if isinstance(rec.get("prior_value"), (int, float)):
                rec["prior_value"] = rec["prior_value"] / ratio
            s = rec.get("series") or {}
            rec["series"] = {y: (x / ratio if isinstance(x, (int, float)) else x)
                             for y, x in s.items()}
            rec["unit"] = "元"
            rec["unit_raw"] = "元"
            rec["unit_corrected"] = True
            rec["status_note"] = (rec.get("status_note") or "") + "；单位已按原文还原为元"
            changed.append(key)
    return changed


def sanitize(a_obj):
    """原地清理一份 A 统一对象，返回 warnings。"""
    fin = a_obj.get("financials") or {}
    if not isinstance(fin, dict) or not fin:
        return []
    warnings = []
    fixed = normalize_units(a_obj)
    if fixed:
        warnings.append("单位换算已还原：%s" % "、".join(fixed))
    aligned = align_series_years(a_obj)
    if aligned:
        warnings.append(aligned)

    # 以总资产/总负债作为金额上限；没有就跳过对应检查
    total_assets = _v(fin, "total_assets")
    total_liabilities = _v(fin, "total_liabilities")

    def flag(key, years, why):
        rec = fin.get(key)
        if not isinstance(rec, dict):
            return
        series = rec.get("series") or {}
        for y in years:
            series.pop(str(y), None)
        if str(rec.get("period")) in [str(y) for y in years] or not series:
            rec["status"] = "not_evaluable"
            rec["value"] = None
            rec["value_original"] = None
            # 当期都被判为取错列，通常整行（含上期列）都不可信，整段 series 清掉
            rec["series"] = {}
        rec["status_note"] = why
        warnings.append("%s：%s" % (key, why))

    for key, rec in fin.items():
        if not isinstance(rec, dict):
            continue
        if rec.get("status") not in ("found",):
            continue
        if key not in AMOUNT_KEYS:
            continue

        bad_years = []
        value = rec.get("value")
        raw = str(rec.get("raw_text") or "")
        # 金额科目出现“几十/几百”这种小数，而原文同一行有亿元级金额：
        # 典型是把正文里的增长率（65.84%）当成金额。只在金额 < 100 万时判断，
        # 避免把正常的“0 元”类科目误伤。
        if key in AMOUNT_KEYS and isinstance(value, (int, float)) and 0 < abs(value) < 1e6 and raw:
            nums = []
            for tok in re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", raw):
                try:
                    nums.append(abs(float(tok.replace(",", ""))))
                except ValueError:
                    continue
            if nums and max(nums) >= 1e8:
                bad_years.append(str(rec.get("period") or ""))

        # 资产负债类不能超过总资产；借款类不能超过总负债
        limit = total_assets
        if key in ("short_term_borrowings", "current_portion_lt_debt",
                   "long_term_borrowings", "bonds_payable") and total_liabilities:
            limit = min(total_assets or total_liabilities, total_liabilities)
        if key in ("total_assets", "total_liabilities") or not limit:
            limit = None

        series = rec.get("series") or {}
        # 只有两期、且两年相差 10 倍以上：通常是上期取错列或单位错。
        # 保留本期，清掉上期和 prior_value，避免 B 算出 3268% 这种同比。
        if len(series) == 2 and key in AMOUNT_KEYS:
            pts = sorted((str(y), v) for y, v in series.items())
            v_old, v_new = pts[0][1], pts[1][1]
            # 应收/存货的两年突变门槛更低：3 倍以上多半是上期取错列
            limit_ratio = 3.0 if key in (
                "accounts_receivable", "inventory") else 10.0
            if (isinstance(v_old, (int, float)) and isinstance(v_new, (int, float))
                    and v_old not in (0, None) and v_new not in (0, None)):
                ratio = abs(v_new) / abs(v_old)
                if ratio >= limit_ratio or ratio <= 1 / limit_ratio:
                    rec["prior_value"] = None
                    rec["prior_period"] = None
                    series.pop(pts[0][0], None)
                    note = ("数据校验：上期值与本期相差 %.1f 倍，同比不可用，"
                            "已剔除上期值，请回原文核对。" % (ratio if ratio >= 1 else 1 / ratio))
                    rec["status_note"] = note
                    warnings.append("%s：%s" % (key, note))
                    continue

        for y, v in list(series.items()):
            if not isinstance(v, (int, float)):
                continue
            if limit and abs(v) > abs(limit) * 1.05:
                bad_years.append(y)
        if limit and isinstance(rec.get("value"), (int, float)) and abs(rec["value"]) > abs(limit) * 1.05:
            bad_years.append(str(rec.get("period") or ""))

        # 三年内有一个点离中位数超过 3 倍：常见于取到母公司列或摘要列。
        # 用中位数而不是相邻比，避免把“2023 是错的、2024 是对的”判成 2024 错。
        if key in ("revenue", "net_income", "net_income_parent", "cfo",
                   "cash_and_equivalents", "accounts_receivable", "inventory"):
            vals = [(y, abs(v)) for y, v in series.items()
                    if isinstance(v, (int, float)) and v]
            if len(vals) >= 3:
                ordered = sorted(v for _, v in vals)
                med = ordered[len(ordered) // 2]
                cur_period = str(rec.get("period") or "")
                for y, v in vals:
                    # 当期大幅下滑可能是真的（例如 000858），不按中位数判错；
                    # 只检查非当期的历史列，通常是摘要列/母公司列串了。
                    if y == cur_period:
                        continue
                    if med and (v / med >= 3.0 or v / med <= 1 / 3.0):
                        bad_years.append(y)

        bad_years = sorted(set(str(y) for y in bad_years if y))
        if bad_years:
            flag(key, bad_years,
                 "数据校验：%s 的数值与总资产/总负债或相邻年度量级不符，"
                 "与同一行的金额或相邻年度量级不符，已剔除，请回原文核对。"
                 % "、".join(bad_years))

    return warnings


if __name__ == "__main__":
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    obj = json.load(open(sys.argv[1], encoding="utf-8"))
    print(json.dumps(sanitize(obj), ensure_ascii=False, indent=1))
