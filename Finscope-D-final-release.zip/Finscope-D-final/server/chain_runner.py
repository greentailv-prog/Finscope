# -*- coding: utf-8 -*-
"""公共链：A 抽取结果 -> 七键统一对象。

两条路径（上传 PDF 的路径 A、选已有公司的路径 B）都汇到这一个函数。
步骤（只调用不改 A/B/C 任何代码）：

  1. to_b_input.build(a_obj)                    -> B 的输入
  2. market_data.resolve(code)                  -> 行情/可比公司
     to_c_input.build(a_obj, market)            -> C 的输入
  3. subprocess 跑 B 的 compute_ratios.py        （b_ratios）
  4. subprocess 跑 B 的 detect_risks.py          （b_risks）
  5. subprocess 跑 agent/runner/run_c_engine.py  （c_engine，内部 import C 的 engine.run）
  6. import 调 agent/orchestrator.run(...)       （adapt，含 WACC 回填 + 第二趟重判）
  7. 落 out_data/unified/<key>.json + <key>.run_log.json
  8. 可选：subprocess 调 report-skill/scripts/render_memo.py 出四种报告

本模块的 `run_chain` 是可 import 的函数，agent/runner/run_chain.py 与
server/jobs.py 都调它，不再各写一份。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# 让 `from server import config` 与 `import to_b_input`（runner 目录）都找得到
_THIS = Path(__file__).resolve()          # .../D分支文件/server/chain_runner.py
_D_ROOT = _THIS.parent.parent             # .../D分支文件
_AGENT = _D_ROOT / "agent"
_RUNNER = _AGENT / "runner"
for _p in (str(_D_ROOT), str(_AGENT), str(_RUNNER)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from server import config, market_data, catalog  # noqa: E402

# 报告 Skill 的渲染入口
REPORT_SKILL = _D_ROOT / "report-skill"
RENDER_MEMO = REPORT_SKILL / "scripts" / "render_memo.py"

# 默认工作目录（CLI 单跑时中间产物落这里）
DEFAULT_WORK_DIR = _RUNNER


class ChainError(RuntimeError):
    """链路中某一步失败。"""


# --------------------------------------------------------------------------
# 进度上报接口
# --------------------------------------------------------------------------
class ConsoleReporter:
    """命令行用的极简上报：直接打印，subprocess 同步跑。"""

    def step(self, name):
        print("\n=== %s ===" % name)

    def log(self, msg):
        if msg:
            print(msg)

    def cancelled(self):
        return False

    def run(self, cmd):
        cmd = [str(c) for c in cmd]
        print("$ %s" % " ".join('"%s"' % c if " " in c else c for c in cmd))
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        proc = subprocess.run(cmd, capture_output=True, text=True,
                              encoding="utf-8", errors="replace", env=env)
        if (proc.stdout or "").strip():
            print(proc.stdout.strip())
        if (proc.stderr or "").strip():
            print("[stderr] " + proc.stderr.strip(), file=sys.stderr)
        return proc.returncode


def _dump(path, obj, indent=2):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=indent)


def _load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _peer_financials(market, year, online, reporter, company=None):
    """按行情缓存里的 peer 列表，给 B 补同业财务。

    优先读 A 的 data/unified；没有且允许联网时用东方财富年度三表补。
    返回 [{company, financials}]，结构与目标公司 B 输入一致。取不到就少一家，
    不编造、不用目标公司自己顶替同业。
    """
    peers = (market or {}).get("peers") or []
    if not peers and company:
        # market_data 只手工维护了少数公司的 peer；没有时用 C 的行业可比池兜底
        from server import market_data
        peers = market_data.industry_peers(company) or []
        if peers:
            reporter.log("[同业] 手工名单为空，使用行业可比池：%s"
                         % "、".join(str(p.get("name") or p.get("ticker")) for p in peers[:6]))
    if not peers or not year:
        return []
    import to_b_input
    from server import catalog
    out = []
    for p in peers[:4]:
        code = p.get("ticker") or p.get("code")
        if not code:
            continue
        a_obj = None
        key = catalog.unified_key(code, year)
        path = config.A_UNIFIED / ("%s.json" % key)
        if path.exists():
            a_obj = _load(path)
        elif online:
            try:
                from server import a_online
                a_obj = a_online.online_snapshot(config.normalize_code(code), int(year))
            except Exception as exc:  # noqa: BLE001
                reporter.log("[同业] %s 取数失败，跳过：%s" % (code, exc))
                continue
        if not a_obj:
            continue
        payload, _ = to_b_input.build(a_obj)
        out.append({
            "company": payload.get("company") or {},
            "financials": payload.get("financials") or {},
        })
    return out


def _build_comparison(work_dir, target_ratios_path, peer_financials, reporter):
    """用 B 自己的 compute_ratios + build_comparison 算同业分位。

    D 不重算分位，只负责把同业财务转成 B 输入、跑 B 的两个脚本。
    失败返回 not_available，主链路继续，风险卡回退固定阈值。
    """
    empty = {"status": "not_available", "peer_set": [], "metrics": [],
             "risk_matrix": [], "thresholds": {}, "multiples": {}}
    if not peer_financials:
        return empty, None
    peer_dir = Path(work_dir) / "peer_ratios"
    input_dir = Path(work_dir) / "peer_inputs"
    peer_dir.mkdir(parents=True, exist_ok=True)
    input_dir.mkdir(parents=True, exist_ok=True)
    py = sys.executable
    n = 0
    for i, peer in enumerate(peer_financials):
        ticker = config.normalize_code((peer.get("company") or {}).get("ticker") or "peer%d" % i)
        b_input = input_dir / ("%s.json" % ticker)
        _dump(b_input, {
            "schema_version": "finradar.extraction/1.0",
            "meta": {"schema_version": "finradar.extraction/1.0",
                     "default_unit": "元", "currency": "CNY",
                     "periods": sorted({y for rec in peer["financials"].values() for y in rec}),
                     "report_period": max({y for rec in peer["financials"].values() for y in rec},
                                          default=None),
                     "industry": (peer.get("company") or {}).get("industry"),
                     "periods_note": "由 D 从 A 统一对象拼接"},
            "company": peer.get("company") or {},
            "financials": peer.get("financials") or {},
        })
        ratios = peer_dir / ("%s.json" % ticker)
        rc = reporter.run([py, config.B_COMPUTE_RATIOS, "-i", b_input, "-o", ratios, "--pretty"])
        if rc == 0 and ratios.exists():
            n += 1
        else:
            reporter.log("[同业] %s 指标计算失败，跳过" % ticker)
    if not n:
        return empty, None
    out_path = Path(work_dir) / "comparison.json"
    rc = reporter.run([py, config.B_RISK_RADAR / "scripts" / "build_comparison.py",
                       "--target", target_ratios_path, "--peers", peer_dir,
                       "--out", out_path, "--allow-cross-industry"])
    if rc != 0 or not out_path.exists():
        return empty, None
    obj = _load(out_path)
    obj.setdefault("multiples", {})
    reporter.log("[同业] comparison：%s，%d 家同业" % (obj.get("status"), n))
    return obj, out_path


def _merge_multiples(comparison, valuation):
    """C 跑完后，把倍数并进 comparison.multiples；B 不负责这块。"""
    if not comparison:
        return comparison
    comps = (valuation or {}).get("comps") or {}
    multiples = comps.get("results") or []
    if not multiples:
        return comparison
    out = comparison.setdefault("multiples", {})
    for r in multiples:
        key = r.get("multiple")
        if not key:
            continue
        out[key] = {
            "target": r.get("target"),
            "peer_median": r.get("peer_median"),
            "sample_n": r.get("sample_count") or r.get("peers_used"),
        }
    return comparison


# --------------------------------------------------------------------------
# 报告生成（可选，失败不致命）
# --------------------------------------------------------------------------
def render_report(key, unified_path, run_log_path, out_root=None, reporter=None):
    """调 report-skill 的渲染器出四种报告。返回 dict（含 ok / 说明）。

    渲染器带数字白名单校验，越界会拒绝出稿（非零退出）；这里把它当可选步骤，
    失败只回报，不抛异常。
    """
    out_root = out_root or config.OUT_REPORTS
    cmd = [sys.executable, str(RENDER_MEMO),
           "--unified", str(unified_path),
           "--run-log", str(run_log_path),
           "--out-root", str(out_root),
           "--key", key]
    if reporter is not None:
        reporter.log("$ " + " ".join(cmd))
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    proc = subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", env=env)
    ok = proc.returncode == 0
    msg = (proc.stdout or "").strip() or (proc.stderr or "").strip()
    if reporter is not None:
        reporter.log(("[报告] " if ok else "[报告失败] ") + msg)
    return {
        "ok": ok,
        "returncode": proc.returncode,
        "message": msg,
        "dir": str(config.report_dir(key)),
    }


# --------------------------------------------------------------------------
# 主链路
# --------------------------------------------------------------------------
def run_chain(a_obj, *, code=None, online=False, gap_fill="none", work_dir=None,
              reporter=None, out_path=None, log_path=None, key=None,
              want_report=False, report_out_root=None, extra_warnings=None,
              flagged_metrics=None, source_mode=None):
    """跑公共链，返回结果 dict。

    参数
      a_obj        A 的抽取结果（对象）
      code         A 的股票代码；缺省取 a_obj.company.ticker
      reporter     进度上报对象（step / log / cancelled / run）；缺省用 ConsoleReporter
      work_dir     中间产物目录；缺省 runner/；传 None 则用临时目录
      out_path     统一对象输出路径；缺省 out_data/unified/<key>.json
      log_path     运行日志输出路径；缺省 <out_path 去扩展>.run_log.json
      key          统一对象的键；缺省由 company.ticker+report_period 推
      want_report  是否顺手出报告（默认否）
    返回
      {unified, run_log, key, unified_path, run_log_path, report, market_source,
       summary}
    """
    reporter = reporter or ConsoleReporter()
    a_obj = a_obj or {}
    code = code or (a_obj.get("company") or {}).get("ticker")

    # 键：优先显式传入，其次由 A 对象推（与 catalog 同一套规则）
    key = key or catalog.key_of_a_obj(a_obj)
    if not key:
        raise ChainError("无法确定统一对象的键：A 结果缺 company.ticker / report_period。")

    if work_dir is None:
        work_dir = Path(tempfile.mkdtemp(prefix="finscope_chain_"))
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    out_path = Path(out_path) if out_path else config.unified_path(key)
    if log_path is None:
        log_path = out_path.with_name(out_path.stem + ".run_log.json")
    log_path = Path(log_path)

    suffix = "" if gap_fill == "none" else "_" + gap_fill

    # 运行日志（与 orchestrator 的 log 合并后一起落盘）
    chain_log = {"steps": [], "notes": [], "warnings": [], "gap_fill": gap_fill,
                 "key": key, "a_input": None}
    # 上游（如抽取后校验）来的警告，先并进来，随 run_log 一起落盘
    for w in (extra_warnings or []):
        chain_log["warnings"].append(w)

    # ---- 0. 行情与可比公司：三档优先级 ----
    market, market_source, market_warns = market_data.resolve(code, online=online)
    if market is not None:
        market["_source"] = market_source
    chain_log["market_source"] = market_source
    chain_log["market_code"] = config.normalize_code(code)
    for w in market_warns:
        chain_log["warnings"].append(w)
    chain_log["notes"].append("行情来源：%s（code=%s）"
                              % (market_source, config.normalize_code(code)))
    reporter.log("[行情] 来源=%s code=%s" % (market_source, config.normalize_code(code)))

    # gap-fill demo 的对照来源（仅调试用）
    gap_source = _load(config.C_DEMO_INPUT) if gap_fill == "demo" else None

    # ---- 0.0 D 常识校验：先拦住量级不可能的抽取值 ----
    from server import data_sanity
    sanity_warnings = data_sanity.sanitize(a_obj)
    for w in sanity_warnings:
        chain_log["warnings"].append("[数据常识] " + w)
        reporter.log("[数据常识] " + w)

    # ---- 0.1 同业财务：B 的动态阈值和 comparison 要用 ----
    peer_fin = _peer_financials(market, catalog.strip_year(
        (a_obj.get("company") or {}).get("report_period") or
        (a_obj.get("meta") or {}).get("report_period")), online, reporter,
        company=a_obj.get("company") or {})
    if peer_fin:
        reporter.log("[同业] 已准备 %d 家同业财务：%s"
                     % (len(peer_fin), "、".join(
                         (p.get("company") or {}).get("ticker") or "?" for p in peer_fin)))
        _dump(work_dir / "peer_financials.json", peer_fin)
    else:
        reporter.log("[同业] 没有可用的同业财务，B 回退固定阈值。")

    # ---- 1. 转换器：A -> B 输入、A + 行情 -> C 输入 ----
    import to_b_input
    import to_c_input

    b_input, b_report = to_b_input.build(a_obj, peer_financials=peer_fin)
    b_input_path = work_dir / ("b_input%s.json" % suffix)
    _dump(b_input_path, b_input)
    chain_log["notes"].append("A -> B 输入：期间 %s，给 %d 个科目，缺 %d 个。"
                              % (b_report["periods"], b_report["given_count"],
                                 b_report["missing_count"]))
    chain_log["b_input_given"] = b_report["given_fields"]
    chain_log["b_input_missing"] = b_report["missing_fields"]

    c_input, c_sources, c_years, c_warnings = to_c_input.build(
        a_obj, market, gap_fill, gap_source)
    c_input_path = work_dir / ("c_input%s.json" % suffix)
    _dump(c_input_path, c_input)
    chain_log["c_input_field_sources"] = c_sources
    chain_log["c_input_years"] = c_years
    chain_log["valuation_warnings"] = c_warnings
    for w in c_warnings:
        chain_log["warnings"].append(w)
    reporter.log("[转换] A->B 给 %d 科目；A->C 年份 %s"
                 % (b_report["given_count"], c_years))

    py = sys.executable

    def _run(cmd, step_name, label):
        """跑一步：报步骤、跑子进程、非零退出抛错。"""
        if reporter.cancelled():
            raise ChainError("任务已取消")
        reporter.step(step_name)
        reporter.log("[%s] %s" % (step_name, label))
        rc = reporter.run(cmd)
        if rc != 0:
            raise ChainError("步骤失败：%s（returncode=%s）" % (step_name, rc))
        return rc

    # ---- 2. B 指标（第一趟，wacc 为空） ----
    b_ratios_path = work_dir / ("b_ratios%s.json" % suffix)
    _run([py, config.B_COMPUTE_RATIOS, "-i", b_input_path, "-o", b_ratios_path, "--pretty"],
         "b_ratios", "B 指标 compute_ratios")

    # ---- 2.1 同业对比：B 的分位与动态阈值输入 ----
    comparison, comparison_path = _build_comparison(
        work_dir, b_ratios_path, peer_fin, reporter)
    chain_log["comparison_status"] = comparison.get("status")
    chain_log["comparison_peers"] = len(comparison.get("peer_set") or [])
    if comparison.get("status") == "not_available":
        chain_log["warnings"].append("同业数据不足，B 的 5 条动态阈值回退固定阈值。")

    # ---- 3. B 风险（第一趟，WACC 相关规则 not_evaluable） ----
    b_risks_path = work_dir / ("b_risks%s.json" % suffix)
    risk_cmd = [py, config.B_DETECT_RISKS, "--ratios", b_ratios_path,
                "--rules", config.B_RISK_RULES,
                "--output", b_risks_path, "--pretty"]
    if comparison_path:
        risk_cmd += ["--comparison", comparison_path]
    _run(risk_cmd, "b_risks", "B 风险 detect_risks")

    # ---- 4. C 估值（产出 WACC） ----
    c_out_path = work_dir / ("c_output%s.json" % suffix)
    _run([py, config.RUN_C_ENGINE, "--c-dir", config.C_VALUATION,
          "--input", c_input_path, "--out", c_out_path],
         "c_engine", "C 估值 engine.run")

    # 把 D 侧的行情缺口 warning 并进 C 输出，随 valuation.warnings 进统一对象
    if c_warnings:
        c_out = _load(c_out_path)
        c_out["warnings"] = list(c_warnings) + list(c_out.get("warnings") or [])
        _dump(c_out_path, c_out, indent=1)

    # ---- 5. D 适配层（含 WACC 回填 + 第二趟重判），直接 import 调 ----
    reporter.step("adapt")
    reporter.log("[adapt] D 适配层 orchestrator.run（WACC 回填 + 第二趟重判）")
    if reporter.cancelled():
        raise ChainError("任务已取消")

    from orchestrator import run as orchestrate  # agent/ 在 sys.path 上

    unified, run_log = orchestrate(a_obj, _load(b_ratios_path), _load(b_risks_path),
                                   _load(c_out_path), comparison=comparison)
    unified["comparison"] = _merge_multiples(unified.get("comparison") or comparison,
                                             unified.get("valuation") or {})

    # 抽取后校验命中的科目（只处理「量级异常」这一判据）：在统一对象里标 not_evaluable，
    # 让它带着「待核验」的状态流到报告，而不是悄悄当成正常值。不改 A 的数据。
    if flagged_metrics:
        marked = []
        fin = unified.get("financials") or {}
        for m in flagged_metrics:
            rec = fin.get(m)
            if isinstance(rec, dict):
                rec["status"] = "not_evaluable"
                rec["_d_extract_check"] = "抽取后校验：疑似抽到占比列或取错列，待核验"
                marked.append(m)
        if marked:
            run_log.setdefault("warnings", []).append(
                "[抽取后校验] 已在统一对象内把 %s 标为 not_evaluable（仅报告，未改 A 数据）。"
                % "、".join(marked))
            reporter.log("[抽取后校验] 已标 not_evaluable：%s" % "、".join(marked))

    # ---- 5.1 D 的数据质量闸门 + 异动分析 ----
    from server import quality_gate
    quality = quality_gate.evaluate(unified)
    if sanity_warnings:
        quality["checks"].insert(0, {
            "code": "D_SANITY", "status": "warn",
            "detail": "；".join(sanity_warnings[:3]),
            "origin": "D",
        })
        quality["warn_reasons"] = [quality["checks"][0]["detail"]] + list(quality.get("warn_reasons") or [])
        quality["counts"]["warn"] = quality["counts"].get("warn", 0) + 1
        if quality.get("status") == "ok":
            quality["status"] = "warn"
    unified["data_quality"] = quality
    if quality.get("blocked"):
        run_log.setdefault("warnings", []).append(
            "[数据质量] 阻断：%s。估值结论降级为仅供核对，不得单独引用。"
            % "；".join(quality.get("block_reasons") or []))
        val = unified.setdefault("valuation", {})
        val["conclusion_gate"] = {
            "status": "blocked",
            "reason": "；".join(quality.get("block_reasons") or []),
            "note": "数据自相矛盾，估值数可以展示，但不能据此下结论。",
        }
    elif quality.get("status") == "warn":
        val = unified.setdefault("valuation", {})
        val["conclusion_gate"] = {
            "status": "warn",
            "reason": "；".join((quality.get("warn_reasons") or [])[:3]),
            "note": "可以展示估值，但结论要带不确定性说明。",
        }

    try:
        from changes import attach as attach_changes
    except ImportError:
        from agent.changes import attach as attach_changes
    unified = attach_changes(unified)
    try:
        from outlook import attach as attach_outlook
    except ImportError:
        from agent.outlook import attach as attach_outlook
    unified = attach_outlook(unified)
    run_log.setdefault("notes", []).append(
        "D 质量闸门：%s（pass %d / warn %d / block %d）；异动卡 %d 张；前景测算 %s。"
        % (quality.get("status"), quality["counts"]["pass"],
           quality["counts"]["warn"], quality["counts"]["block"],
           len(unified.get("changes") or []),
           "有" if unified.get("outlook") else "无"))

    # 元信息补齐：A 没给的，D 按统一对象里的已知事实补，不编造来源
    meta = unified.setdefault("meta", {})
    meta.setdefault("key", key)
    meta.setdefault("source_mode", source_mode or ("online" if online else "upload"))
    meta.setdefault("report_period", (unified.get("company") or {}).get("report_period"))
    meta.setdefault("period_type", "annual")
    meta.setdefault("currency", (unified.get("company") or {}).get("currency") or "CNY")
    meta.setdefault("amount_unit", "元")
    meta.setdefault("generated_at", __import__("datetime").datetime.now().astimezone().isoformat(timespec="seconds"))
    if not meta.get("years"):
        years = set()
        for rec in (unified.get("financials") or {}).values():
            years.update((rec.get("series") or {}).keys())
        meta["years"] = sorted(y for y in years if str(y).isdigit())

    # 合并两层日志（链路层 + 编排层）
    merged = dict(run_log)
    merged.setdefault("steps", [])
    merged["steps"] = list(chain_log["steps"]) + list(run_log.get("steps") or [])
    merged.setdefault("notes", []).extend(chain_log["notes"])
    merged.setdefault("warnings", []).extend(chain_log["warnings"])
    merged["market_source"] = market_source
    merged["market_code"] = config.normalize_code(code)
    merged["chain"] = chain_log
    merged["key"] = key
    merged["a_input"] = chain_log.get("a_input")
    merged["data_quality"] = {
        "status": quality.get("status"),
        "blocked": quality.get("blocked"),
        "counts": quality.get("counts"),
    }
    merged["changes"] = len(unified.get("changes") or [])

    # ---- 6. 落盘：统一对象 + 运行日志 ----
    _dump(out_path, unified, indent=1)
    _dump(log_path, merged, indent=1)
    reporter.log("[落盘] 统一对象 -> %s" % out_path)

    # ---- 7. 可选：出报告 ----
    report = None
    if want_report:
        try:
            report = render_report(key, out_path, log_path,
                                   out_root=report_out_root, reporter=reporter)
        except Exception as exc:  # noqa: BLE001 报告失败不拖垮整链
            report = {"ok": False, "returncode": None,
                      "message": "报告生成异常：%s" % exc,
                      "dir": str(config.report_dir(key))}

    summary = _summarize(unified, market_source, merged)
    summary["report"] = report
    return {
        "unified": unified,
        "run_log": merged,
        "key": key,
        "unified_path": str(out_path),
        "run_log_path": str(log_path),
        "report": report,
        "market_source": market_source,
        "summary": summary,
    }


def _summarize(unified, market_source, run_log):
    val = unified.get("valuation") or {}
    dcf = val.get("dcf") or {}
    comps = val.get("comps") or {}
    blended = val.get("blended") or {}
    return {
        "company": (unified.get("company") or {}).get("name"),
        "ticker": (unified.get("company") or {}).get("ticker"),
        "financials": len(unified.get("financials") or {}),
        "ratios": sum(len(v) for v in (unified.get("ratios") or {}).values()),
        "risks": len(unified.get("risks") or []),
        "rules_evaluated": len(unified.get("rules_evaluated") or []),
        "sources": len(unified.get("sources") or []),
        "b_passes": run_log.get("b_passes"),
        "wacc": (dcf.get("inputs") or {}).get("wacc"),
        "dcf_range": [(dcf.get("valuation_range") or {}).get("low"),
                      (dcf.get("valuation_range") or {}).get("high")],
        "comps_peers_used": len(comps.get("peer_companies") or []),
        "blended_per_share": blended.get("blended_per_share"),
        "verdict": blended.get("verdict"),
        "market_source": market_source,
        "valuation_warnings": val.get("warnings") or [],
        "changes": len(unified.get("changes") or []),
        "quality_status": (unified.get("data_quality") or {}).get("status"),
        "quality_blocked": (unified.get("data_quality") or {}).get("blocked"),
        "quality_counts": (unified.get("data_quality") or {}).get("counts"),
        "comparison_status": (unified.get("comparison") or {}).get("status"),
        "comparison_peers": len((unified.get("comparison") or {}).get("peer_set") or []),
    }


if __name__ == "__main__":
    # 命令行小自检：对 A 已抽取的茅台跑一遍公共链
    import argparse
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="公共链自检")
    ap.add_argument("--a", default=str(config.A_EXTRACTED / "贵州茅台_600519_2025.json"))
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()
    res = run_chain(_load(args.a), want_report=args.report)
    print("\n" + "=" * 50)
    for k, v in res["summary"].items():
        print("  %-22s %s" % (k, v))
    print("统一对象 -> %s" % res["unified_path"])
