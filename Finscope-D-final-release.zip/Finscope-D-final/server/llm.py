# -*- coding: utf-8 -*-
"""可选的大模型问答。

本地没有配 `DEEPSEEK_API_KEY` 时，问答仍走 `server/qa.py` 的确定性规则，
断网也能回答核心数字。配了密钥就把统一对象压成一份事实清单，交给模型
组织语言；模型只负责表达，不允许补造数字。

密钥只从环境变量读，不写进任何文件。
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

DEFAULT_BASE = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-chat"
MAX_CONTEXT = 14000


def available():
    return bool(os.environ.get("DEEPSEEK_API_KEY"))


def _yi(v):
    return None if not isinstance(v, (int, float)) else round(v / 1e8, 2)


def _context(unified):
    """把统一对象压成模型能读的事实清单，不传内部字段名。"""
    company = unified.get("company") or {}
    fin = unified.get("financials") or {}
    ratios = unified.get("ratios") or {}
    risks = unified.get("risks") or []
    valuation = unified.get("valuation") or {}
    changes = unified.get("changes") or []

    facts = []
    for key, rec in fin.items():
        if not isinstance(rec, dict) or rec.get("value") is None:
            continue
        label = rec.get("label") or key
        row = {"科目": label, "本期": _yi(rec["value"]), "单位": "亿元",
               "状态": rec.get("status") or "found"}
        if rec.get("prior_value") is not None:
            row["上期"] = _yi(rec["prior_value"])
        if rec.get("page") is not None:
            row["页码"] = rec["page"]
        facts.append(row)

    ratio_rows = []
    for items in ratios.values():
        for key, rec in (items or {}).items():
            if not isinstance(rec, dict):
                continue
            label = rec.get("label") or rec.get("name") or key
            if rec.get("value") is None:
                missing = [k for k, v in (rec.get("inputs") or {}).items() if v is None]
                ratio_rows.append({"指标": label, "状态": "未取到",
                                   "缺的输入": missing})
            else:
                ratio_rows.append({"指标": label, "数值": rec.get("value"),
                                   "单位": rec.get("unit"),
                                   "上期": rec.get("prev"),
                                   "页码": rec.get("page")})

    risk_rows = [{
        "风险": r.get("risk_name"),
        "等级": r.get("severity_tag") or r.get("severity"),
        "解释": r.get("explanation"),
        "建议": r.get("suggested_action"),
    } for r in risks[:8]]

    v = valuation or {}
    dc = v.get("dcf") or {}
    comps = v.get("comps") or {}
    bl = v.get("blended") or {}
    val = {
        "融合每股价值": bl.get("blended_per_share"),
        "现价": bl.get("current_price"),
        "空间": bl.get("upside"),
        "判断": bl.get("verdict"),
        "DCF每股": dc.get("per_share"),
        "WACC": dc.get("wacc"),
        "永续增长": dc.get("terminal_growth"),
        "相对估值每股": comps.get("implied_per_share"),
        "状态": v.get("status"),
    }

    payload = {
        "公司": {
            "名称": company.get("name_short") or company.get("name"),
            "代码": company.get("ticker"),
            "报告期": company.get("report_period"),
            "行业": company.get("industry"),
        },
        "财务科目": facts,
        "指标": ratio_rows,
        "风险": risk_rows,
        "估值": val,
        "异动": [{"标题": c.get("title"), "读数": c.get("reading"),
                  "分析": c.get("analysis"), "关注": c.get("watch")}
                 for c in changes[:6]],
        "数据质量": {
            "状态": (unified.get("data_quality") or {}).get("status"),
            "阻断": (unified.get("data_quality") or {}).get("blocked"),
        },
    }
    text = json.dumps(payload, ensure_ascii=False)
    if len(text) > MAX_CONTEXT:
        text = text[:MAX_CONTEXT] + "…（以下省略）"
    return text


SYSTEM = """你是 FinScope 的财报研究助手。只根据给出的数据回答，不得编造任何数字，
不得给出买卖建议。回答用中文，分点写，先给结论，再给依据。数字后面标明年报页码（如果有）。
用户问“为什么算不出/为什么没有”时，要指出缺的具体年报科目，并说明这不是 0。
不要出现 A/B/C/D、脚本名、字段名（如 net_income_parent）这类开发术语。
数据里没有的，直接说“当前数据里没有这一项”。"""


def answer(unified, question):
    """调用 DeepSeek；失败抛异常，由调用方回退到规则问答。"""
    key = os.environ.get("DEEPSEEK_API_KEY")
    if not key:
        raise RuntimeError("没有配置 DEEPSEEK_API_KEY")
    base = os.environ.get("DEEPSEEK_BASE_URL") or DEFAULT_BASE
    model = os.environ.get("DEEPSEEK_MODEL") or DEFAULT_MODEL
    body = {
        "model": model,
        "temperature": 0.2,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": "数据：\n%s\n\n问题：%s" % (_context(unified), question)},
        ],
    }
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + key,
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=25) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return (data.get("choices") or [{}])[0].get("message", {}).get("content", "").strip()
