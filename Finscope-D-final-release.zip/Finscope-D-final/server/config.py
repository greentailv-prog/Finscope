# -*- coding: utf-8 -*-
"""FinScope D 终期包：路径与端口的唯一硬编码点。

目录约定（全部相对本包根目录，换机器不用改代码）：

    Finscope-D-final/
      server/           D 的 HTTP 服务
      agent/            D 的适配层与编排
      report-skill/     D 的报告渲染
      modules/A|B|C     打进来的 A/B/C 交付代码
      output/           运行产物（unified / reports / exports / logs）
      state/            任务进度、上传暂存
      market_data/      行情缓存
      web/              前端页面

可用环境变量覆盖，便于 A/B/C 各自更新后单独指过去：

    FINSCOPE_MODULES   modules 根目录
    FINSCOPE_A_ROOT    A 包根目录（含 src/ 与 data/）
    FINSCOPE_B_ROOT    B 包根目录（含 financial-diagnosis/ 与 risk-radar/）
    FINSCOPE_C_ROOT    C 包根目录（含 valuation/）
    FINSCOPE_OUTPUT    output 根目录
    FINSCOPE_PORT      HTTP 端口，默认 8790
"""
from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------
# 包根目录
# --------------------------------------------------------------------------
SERVER_DIR = Path(__file__).resolve().parent          # .../server
D_ROOT = SERVER_DIR.parent                            # Finscope-D-final
PROJECT_ROOT = D_ROOT.parent                          # 终期文件（旧布局时 A/B/C 在同级）

MODULES_DIR = Path(os.environ.get("FINSCOPE_MODULES") or (D_ROOT / "modules"))

# --------------------------------------------------------------------------
# D 自己
# --------------------------------------------------------------------------
AGENT_DIR = D_ROOT / "agent"
RUNNER_DIR = AGENT_DIR / "runner"
RUN_PIPELINE = AGENT_DIR / "run_pipeline.py"
ORCHESTRATOR = AGENT_DIR / "orchestrator.py"
RUN_CHAIN = RUNNER_DIR / "run_chain.py"
RUN_C_ENGINE = RUNNER_DIR / "run_c_engine.py"

# --------------------------------------------------------------------------
# A：年报检索、下载、PDF 抽取、在线三表
# --------------------------------------------------------------------------
def _first_existing(*paths):
    for p in paths:
        if p and Path(p).exists():
            return Path(p)
    return Path(paths[0])


A_ROOT = Path(os.environ.get("FINSCOPE_A_ROOT") or _first_existing(
    MODULES_DIR / "A",
    PROJECT_ROOT / "A分支文件" / "A",
    PROJECT_ROOT / "Finscope-A-new" / "A_交付包" / "A_交付包",
))
A_SRC = A_ROOT / "src"
A_DATA = A_ROOT / "data"
A_EXTRACTED = A_DATA / "extracted"                    # A 的 17 科抽出结果
A_UNIFIED = A_DATA / "unified"                        # A 的 04 规范统一对象
A_ANNUAL_REPORTS = A_DATA / "annual_reports"          # 上传 PDF 落点
A_ONLINE_DIR = A_DATA / "online"                      # 在线三表缓存
A_PDF_PAGEMAP = A_SRC / "pdf_pagemap.py"
A_INDICATORS = A_SRC / "indicators.py"
A_ONLINE_FINANCE = A_SRC / "online_finance.py"

# --------------------------------------------------------------------------
# B：指标与风险
# --------------------------------------------------------------------------
B_ROOT = Path(os.environ.get("FINSCOPE_B_ROOT") or _first_existing(
    MODULES_DIR / "B",
    PROJECT_ROOT / "B分支文件" / "Finscope-main",
    PROJECT_ROOT / "Finscope-B-",
))
B_DIAGNOSIS = B_ROOT / "financial-diagnosis"
B_RISK_RADAR = B_ROOT / "risk-radar"
B_COMPUTE_RATIOS = B_DIAGNOSIS / "scripts" / "compute_ratios.py"
B_DETECT_RISKS = B_RISK_RADAR / "scripts" / "detect_risks.py"
B_RISK_RULES = B_RISK_RADAR / "risk_rules.json"

# --------------------------------------------------------------------------
# C：估值
# --------------------------------------------------------------------------
C_ROOT = Path(os.environ.get("FINSCOPE_C_ROOT") or _first_existing(
    MODULES_DIR / "C",
    PROJECT_ROOT / "C分支文件" / "Finscope-C-Comps-DCF",
    PROJECT_ROOT / "Finscope-C-Comps-DCF",
))
C_VALUATION = C_ROOT / "valuation"
C_DEMO_INPUT = C_VALUATION / "demo" / "input_ashare_600519.json"

# --------------------------------------------------------------------------
# 运行产物（用户要求统一放 output/）
# --------------------------------------------------------------------------
OUTPUT_DIR = Path(os.environ.get("FINSCOPE_OUTPUT") or (D_ROOT / "output"))
OUT_UNIFIED = OUTPUT_DIR / "unified"
OUT_REPORTS = OUTPUT_DIR / "reports"
OUT_EXPORTS = OUTPUT_DIR / "exports"
OUT_LOGS = OUTPUT_DIR / "logs"
OUT_QA = OUTPUT_DIR / "qa"

MARKET_DATA = D_ROOT / "market_data"
MARKET_DATA_README = MARKET_DATA / "README.md"

WEB_DIR = D_ROOT / "web"
SERVER_STATIC = WEB_DIR
SERVER_STATE = D_ROOT / "state"
STATE_UPLOADS = SERVER_STATE / "uploads"
STATE_JOBS = SERVER_STATE / "jobs"

# --------------------------------------------------------------------------
# 服务参数
# --------------------------------------------------------------------------
# 本地默认只绑回环；部署到老师服务器时用 FINSCOPE_HOST=0.0.0.0。
HOST = os.environ.get("FINSCOPE_HOST") or "127.0.0.1"
# 老师服务器通常注入 PORT；本地仍可用 FINSCOPE_PORT。
PORT = int(os.environ.get("PORT") or os.environ.get("FINSCOPE_PORT") or 8790)
API_PREFIX = "/api"

_RUNTIME_DIRS = (
    OUT_UNIFIED, OUT_REPORTS, OUT_EXPORTS, OUT_LOGS, OUT_QA,
    MARKET_DATA, SERVER_STATE, STATE_UPLOADS, STATE_JOBS,
)


def ensure_dirs():
    for d in _RUNTIME_DIRS:
        d.mkdir(parents=True, exist_ok=True)
    return _RUNTIME_DIRS


# --------------------------------------------------------------------------
# 路径小工具
# --------------------------------------------------------------------------
def market_cache_path(code):
    return MARKET_DATA / ("%s.json" % normalize_code(code))


def unified_path(key):
    return OUT_UNIFIED / ("%s.json" % key)


def report_dir(key):
    return OUT_REPORTS / key


def export_dir(key):
    return OUT_EXPORTS / key


def normalize_code(code):
    """'600519.SH' / 'sh600519' / '600519' -> '600519'。"""
    if code is None:
        return ""
    s = str(code).strip().upper()
    for suf in (".SH", ".SZ", ".BJ", "SH", "SZ", "BJ"):
        s = s.replace(suf, "")
    return s.strip()


def ticker_with_suffix(code):
    c = normalize_code(code)
    if not c:
        return ""
    if c.startswith("6"):
        return c + ".SH"
    if c.startswith(("0", "3")):
        return c + ".SZ"
    if c.startswith(("4", "8", "9")):
        return c + ".BJ"
    return c


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    for name in ("D_ROOT", "MODULES_DIR", "A_ROOT", "A_EXTRACTED", "A_UNIFIED",
                 "B_ROOT", "C_ROOT", "C_VALUATION", "OUTPUT_DIR",
                 "OUT_UNIFIED", "MARKET_DATA", "WEB_DIR"):
        print("%-14s = %s" % (name, globals()[name]))
    print("PORT           =", PORT)
