# -*- coding: utf-8 -*-
"""行情与可比公司缓存：三档优先级。

A 的抽取只出财务科目，行情（股价 / 股本 / 市值 / beta）与可比公司（peers）
它抽不出来。这层负责把这块补齐，优先级：

  1. 本地缓存   market_data/<code>.json   —— 主路径，手工维护，可核对
  2. 联网兜底   akshare                    —— 默认关闭，只有显式 online=True 才走；整段 try/except，失败回落
  3. 都没有     market=None                —— 交给 to_c_input 留空并记 warning，绝不套用别家公司

联网只补行情标量（price / shares / market_cap），beta 要指数回归，不自动生成。
peers 优先读 `market_data/<code>.json` 的手工名单；没有时用 C 的
`config/industry_peers.json` 按行业关键词兜底。兜底名单只是候选，
还要有同业财务快照或联网年度三表，B 的同业对比才会真正算出来。

只用标准库（akshare 是可选、延迟 import）。
"""
from __future__ import annotations

import json
import os

try:                       # 作为包导入：from server import market_data
    from . import config
except ImportError:        # 直接运行：python server/market_data.py
    import config

# 缓存里允许被 to_c_input 直接采信的字段
_SCALAR_FIELDS = ("price", "shares_outstanding", "market_cap", "beta")
_PASSTHRU_FIELDS = ("peers", "assumptions", "relative_multiples", "sources",
                    "price_date", "market", "currency", "sector", "industry",
                    "name", "ticker")


def _read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_cached(code):
    """读 market_data/<code>.json。没有返回 None。"""
    path = config.market_cache_path(code)
    if not path.exists():
        return None
    obj = _read_json(path)
    obj.setdefault("code", config.normalize_code(code))
    obj["_source"] = "cache:%s" % path.name
    return obj


def industry_peers(company):
    """从 C 的行业可比公司池里取候选 peer。

    `market_data/<code>.json` 里的 peers 是手工维护的，只有少数公司有。
    没有手工名单时，用 C 的 `config/industry_peers.json` 按行业关键词匹配，
    给 B 的同业对比和 C 的 Comps 一个候选名单。取不到返回空列表，不编造。
    """
    company = company or {}
    text = "%s %s" % (company.get("industry") or "", company.get("name") or "")
    if not text.strip():
        return []
    try:
        from . import config as _config
    except ImportError:  # 直接运行
        import config as _config
    path = _config.C_VALUATION / "config" / "industry_peers.json"
    if not path.exists():
        return []
    try:
        data = _read_json(path)
    except (OSError, ValueError):
        return []
    theme = None
    for entry in data.get("industry_keyword_map") or []:
        kws = entry.get("keywords") or []
        if any(k and k in text for k in kws):
            theme = entry.get("theme")
            break
    if not theme:
        return []
    block = (data.get("themes") or {}).get(theme) or {}
    target = str(company.get("ticker") or "").split(".")[0]
    out = []
    for p in block.get("peers") or []:
        code = str(p.get("code") or "").strip()
        if not code or code == target:
            continue
        out.append({
            "ticker": code,
            "name": p.get("name"),
            "reason": p.get("reason"),
            "theme": theme,
        })
    return out


def fetch_online(code):
    """联动 akshare 取行情标量。默认不走；任何异常都吞掉返回 None。

    成功返回的 dict 里 peers 为空列表、beta 为 None —— 这两项不自动生成，
    缺 peers 时 C 的 Comps 依旧不出，属预期。
    """
    try:
        import akshare as ak  # 延迟 import：没装也不影响本模块
    except Exception:
        return None
    try:
        norm = config.normalize_code(code)
        info = ak.stock_individual_info_em(symbol=norm)
        # info 是 DataFrame，列 [item, value]，转成 dict
        kv = {str(r["item"]): r["value"] for _, r in info.iterrows()}

        def _num(*keys):
            for k in keys:
                if k in kv:
                    try:
                        return float(kv[k])
                    except (TypeError, ValueError):
                        return None
            return None

        out = {
            "code": norm,
            "name": kv.get("股票简称"),
            "shares_outstanding": _num("总股本"),
            "market_cap": _num("总市值"),
            "industry": kv.get("行业"),
        }
        out["price"] = None
        out["beta"] = None
        out["peers"] = []
        out["assumptions"] = {}
        out["relative_multiples"] = ["pe", "ps", "pb"]
        out["sources"] = [{"name": "akshare·东方财富", "as_of": None,
                           "official": False, "purpose": "行情（联网兜底）"}]
        # 至少要有市值或股价，否则视为失败
        if not (out.get("market_cap") or out.get("price")):
            return None
        return out
    except Exception:
        return None


def fetch_quote(code):
    """东方财富实时行情：只取价格、总市值、总股本。

    返回 {price, market_cap, shares_outstanding, price_date, source} 或 None。
    失败一律返回 None，不抛异常，分析照常走缓存。
    """
    try:
        import requests
    except Exception:
        return None
    norm = config.normalize_code(code)
    if not norm:
        return None
    secid = ("1." if norm.startswith(("6", "9")) else "0.") + norm
    try:
        r = requests.get(
            "https://push2.eastmoney.com/api/qt/stock/get",
            params={"secid": secid,
                    "fields": "f43,f57,f58,f116,f117,f162,f167,f86"},
            headers={"User-Agent": "Mozilla/5.0", "Referer": "https://quote.eastmoney.com/"},
            timeout=8,
        )
        data = (r.json() or {}).get("data") or {}
        raw_price = data.get("f43")
        # f43 是价格 ×100 的整数；停牌/无报价时为 "-"
        price = (raw_price / 100.0) if isinstance(raw_price, (int, float)) and raw_price > 0 else None
        cap = data.get("f116") if isinstance(data.get("f116"), (int, float)) else None
        if price is None and cap is None:
            return None
        shares = (cap / price) if (cap and price) else None
        from datetime import datetime
        return {
            "price": price,
            "market_cap": cap,
            "shares_outstanding": shares,
            "price_date": datetime.now().strftime("%Y-%m-%d"),
            "price_source": "东方财富实时行情",
        }
    except Exception:
        return None


def refresh_cached_quote(cached, code):
    """缓存里的行情按天刷新；拿不到就保留原值。"""
    if not cached:
        return cached
    q = fetch_quote(code)
    if not q:
        return cached
    out = dict(cached)
    for k in ("price", "market_cap", "shares_outstanding", "price_date", "price_source"):
        if q.get(k) is not None:
            out[k] = q[k]
    out["_quote_refreshed"] = True
    return out


def resolve(code, online=False):
    """三档优先级入口。返回 (market, source, warnings)。

    market 为 None 表示缓存与联网都没有，调用方应留空并记 warning。
    """
    warnings = []
    if not code:
        return None, "none", ["缺股票代码，无法取行情缓存。"]

    cached = load_cached(code)
    if cached is not None:
        if online:
            from datetime import datetime
            today = datetime.now().strftime("%Y-%m-%d")
            if cached.get("price_date") != today and cached.get("price"):
                refreshed = refresh_cached_quote(cached, code)
                if refreshed.get("_quote_refreshed"):
                    warnings.append("行情已按 %s 收盘/实时价刷新（原 %s）。"
                                    % (refreshed.get("price_date"), cached.get("price_date")))
                    return refreshed, "cache:%s+quote" % config.normalize_code(code), warnings
        return cached, cached.get("_source", "cache"), warnings

    if online:
        q = fetch_quote(code)
        if q is not None:
            market = {
                "code": config.normalize_code(code),
                "price": q.get("price"),
                "shares_outstanding": q.get("shares_outstanding"),
                "market_cap": q.get("market_cap"),
                "price_date": q.get("price_date"),
                "price_source": q.get("price_source"),
                "beta": None,
                "peers": [],
                "assumptions": {},
                "relative_multiples": ["pe", "ps", "pb"],
                "sources": [{"name": "东方财富实时行情", "as_of": q.get("price_date"),
                             "official": False, "purpose": "行情（联网兜底）"}],
            }
            return market, "eastmoney(quote)", warnings
        fetched = fetch_online(code)
        if fetched is not None:
            return fetched, "akshare(online)", warnings
        warnings.append("联网兜底失败或未取到行情（东方财富/akshare），回落为空。")

    warnings.append("market_data/%s.json 缓存不存在。" % config.normalize_code(code))
    return None, "none", warnings


def merge_missing(market, code, online=False):
    """缓存存在但缺字段时，可选联网补缺（默认不用）。返回合并后的 market。

    保守：只在缓存确实缺 price / shares_outstanding / market_cap 时联网，
    且联网值只补空位，不覆盖缓存里已有的值。
    """
    if market is None or not online:
        return market
    missing = [k for k in ("price", "shares_outstanding", "market_cap")
               if not market.get(k)]
    if not missing:
        return market
    fetched = fetch_online(code)
    if not fetched:
        return market
    merged = dict(market)
    for k in missing:
        if fetched.get(k):
            merged[k] = fetched[k]
            merged.setdefault("_online_filled", []).append(k)
    return merged


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    for c in ("600519", "000333"):
        m, src, w = resolve(c)
        print("%s -> source=%s warnings=%s" % (c, src, w))
        if m:
            print("   price=%s shares=%s cap=%s beta=%s peers=%d"
                  % (m.get("price"), m.get("shares_outstanding"),
                     m.get("market_cap"), m.get("beta"), len(m.get("peers") or [])))
