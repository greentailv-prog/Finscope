@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================
echo   FinScope 财报研究工作台
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [错误] 没有找到 python。请先安装 Python 3.11 以上版本。
  pause
  exit /b 1
)

python -c "import sys; raise SystemExit(0 if sys.version_info>=(3,11) else 1)" >nul 2>nul
if errorlevel 1 (
  echo [错误] Python 版本太低，需要 3.11 以上。
  python --version
  pause
  exit /b 1
)

python -c "import requests, pdfplumber, numpy, pandas, openpyxl, akshare, bs4, lxml, html5lib" >nul 2>nul
if errorlevel 1 (
  echo [提示] 依赖不全，正在安装 requirements.txt ...
  python -m pip install -r requirements.txt
  if errorlevel 1 (
    echo [错误] 依赖安装失败，请检查网络后重试。
    pause
    exit /b 1
  )
)

set PYTHONIOENCODING=utf-8
echo 启动本地服务：http://127.0.0.1:8790/
start "" "http://127.0.0.1:8790/"
python -X utf8 server\app.py

pause
