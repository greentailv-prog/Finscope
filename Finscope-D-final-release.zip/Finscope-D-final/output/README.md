# output

运行产物目录。服务启动后自动创建子目录。

| 目录 | 内容 |
| --- | --- |
| `unified/` | 统一数据对象 `<ticker>_<year>.json` 与 `<ticker>_<year>.run_log.json` |
| `reports/` | 每家公司一份投研简报：`memo.md / memo.html / memo.json / memo.csv / render_log.json` |
| `exports/` | Word（`.docx`）与报告包（`.zip`） |
| `logs/` | 预留，运行日志 |
| `qa/` | 预留，问答记录 |

`unified` 和 `reports` 是前端“历史分析”的数据来源。删掉某个目录等同于清空对应历史；
服务重启不会自动重建已有公司，需要重新分析。
