# FinScope D · 终期包

D 负责编排、数据质量闸门、异动分析、投研报告与本地服务。这个包把 A/B/C 的代码一起打进来，
换一台 Windows 机器，装好 Python 和依赖后双击 `start.bat` 就能跑，不需要再改路径。

**注意：当前是“本地服务”形态，不是双击 HTML 就能用。** 用户机器需要 Python 3.11+
（`start.bat` 会自动检查并安装 `requirements.txt`）。如果答辩机器不允许装 Python，
需要另外用 PyInstaller 打成 exe，这一步要单独做。

## 一分钟启动

1. 安装 Python 3.11+（这台机器验证用的是 3.13）。
2. 在本目录打开命令行，执行：

```bat
pip install -r requirements.txt
start.bat
```

3. 浏览器自动打开 `http://127.0.0.1:8790/`。
4. 输入 `600519` 或 `贵州茅台`，选年份，点“开始分析”。

只跑后端、不打开浏览器：

```bat
python server\app.py
```

## 目录

```
Finscope-D-final/
  server/            HTTP 服务、任务队列、联网取数、质量闸门、问答、导出
  agent/             适配层（A/B/C -> 统一对象）、异动分析、编排
  report-skill/      确定性投研简报（md/html/json/csv）
  modules/A|B|C      打进来的 A/B/C 交付代码
  web/               本地工作台页面（7 个区块 + 右侧研究助手）
  output/            运行产物
    unified/         统一数据对象 <ticker>_<year>.json 与 run_log
    reports/         投研简报 memo.md/html/json/csv
    exports/         Word / zip 导出
    logs/ qa/        预留
  state/             任务进度、上传的 PDF 暂存
  market_data/       行情与可比公司缓存
  tests/             冒烟测试与回归脚本
  docs/              接口、部署、改动说明
```

## 三条分析路径

| 模式 | 入口 | 做什么 |
| --- | --- | --- |
| `code` | 输入代码/简称 | 巨潮检索 → 定位年报 → 下载 PDF → 页码映射 → 抽取 → 统一对象 → B/C → 报告。PDF 失败自动回退东方财富年度三表 |
| `upload` | 上传 PDF | 文件名 `公司名_代码_年份.pdf` → 同一套抽取链路 |
| `existing` | 选已分析公司 | 直接读 A 的 `data/unified`（优先）或旧抽取结果 |

`meta.source_mode` 区分 `online` / `upload`。单条记录还有 `source_type=pdf|online`。
在线三表没有印刷页码，页面和报告都会明确标注，不假装有。

## 主要接口

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| GET | `/api/health` | 自检：A/B/C 脚本、报告器、可分析公司数 |
| GET | `/api/search?q=&year=&with_report=1` | 公司检索；带年报定位 |
| POST | `/api/analyze` | `{"mode":"code","query":"600519","year":2025}` / `upload` / `existing` |
| GET | `/api/jobs/<id>` | 进度、日志、结果 |
| POST | `/api/jobs/<id>/cancel` | 取消 |
| POST | `/api/upload` | 原始 PDF 字节流，`X-Filename` 传文件名 |
| GET | `/api/history` | 已分析公司与缓存入口 |
| GET | `/api/quote/<code>` | 东方财富实时价，失败回行情缓存 |
| GET | `/api/unified/<key>` | 统一对象全文 |
| GET | `/api/report/<key>?format=md\|html\|json\|csv` | 报告；HTML 可加 `&style=academic\|business` |
| GET | `/api/export/<key>?format=docx\|zip` | Word / 报告包 |
| POST | `/api/qa` | `{"key":"600519.SH_2025","question":"..."}` |
| POST | `/api/valuation/recalc` | 敏感性网格取最近格点，供滑块使用 |
| GET | `/files/reports/<文件名>` | 本地年报 PDF，证据页跳转 |

错误统一返回 `{"ok":false,"error":"...","code":"...","hint":"..."}`。

## 统一对象

顶层：

```
company / financials / ratios / risks / rules_evaluated / valuation / sources
+ meta / data_quality / coverage / changes
```

- `financials` 用 04 规范的 canonical 键，每条带 `value / prior_value / series /
  source_id / page / pdf_page / raw_text / status`
- `changes` 是 D 的异动卡，字段见 `agent/changes.py`
- `data_quality` 是 D 的质量闸门，`status=blocked` 时报告不给估值结论

## 已知边界

- 首次分析一份新年报通常 2–5 分钟，取决于 PDF 页数与机器；已下载的公司会复用 PDF，
  但仍会重新解析，保证数据是新的。
- 在线三表模式没有页码；PDF 模式才有。
- C 因数据复核（`review_required`）可能不给融合结论。D 不替 C 重算，只把各方法每股价值
  摆成“参考区间”，并标注来源。
- 右侧研究助手默认走规则问答，不依赖大模型。要接 DeepSeek，在服务端加一个 OpenAI 兼容
  调用即可，页面不用改。
- 本包不包含前端 E 的 7 页模板。`web/index.html` 是 D 的联调工作台，E 可以直接换成
  自己的页面，接口不变。

## 测试

```bat
python tests\smoke.py
python tests\regression.py --limit 3
```

`regression.py` 会拿 `modules/A/data/unified` 里的公司跑完整链路，检查统一对象七键、
异动卡、质量闸门和报告渲染。

## 文档

- [docs/交付状态.md](docs/交付状态.md)：已完成、已验证、还依赖谁
- [docs/终期改动说明.md](docs/终期改动说明.md)：对照中期 demo 和 `想法.txt` 改了什么
- [docs/接口说明.md](docs/接口说明.md)：接口与字段
- [docs/本地部署.md](docs/本地部署.md)：换机器、换端口、接老师接口
- [docs/老师接口对接.md](docs/老师接口对接.md)：老师接口对齐清单
