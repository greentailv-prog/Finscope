# {{company_name}}（{{ticker}}）投资研究简报

报告期：{{report_period}} 年　行业：{{industry}}　上市地：{{exchange}}　币种：{{currency_label}}

> 本简报基于公司年度报告与公开市场数据。正文数字均标注出处，可回到年报页码或数据源核对；估值部分依赖假设，仅供研究参考，不构成投资建议。

## 一、结论摘要

- {{conclusion_line}}
- {{valuation_summary_line}}
- 估值构成：DCF（收益法）每股 {{dcf_ps}} 元，权重 {{dcf_weight}}；相对估值（市场法）每股 {{comps_ps}} 元，权重 {{comps_weight}}。
- 财务表现：营业收入 {{revenue}}，{{revenue_growth|growth}}；归母净利润 {{ni_parent}}，{{ni_growth|growth}}；加权 ROE {{roe}}，较上期变动 {{roe_delta}} 个百分点。
- 主要风险：

{{#top_risks}}
  - 【{{severity_tag}}】{{risk_name}}（评分 {{score}}）
{{/top_risks}}

## 二、关键指标仪表盘

> 本表只列目标年份的数值；上期只用于计算变动，不再单独展示。部分科目因年报未单独列示或口径受限，无数据时显示“-”。

| 指标 | 类别 | 本期 | 变动（金额/百分点） | 状态 |
| --- | --- | --- | --- | --- |
{{#dashboard}}
| {{label}} | {{category}} | {{value_str}} | {{delta_str}} | {{status_str}} |
{{/dashboard}}

## 三、经营情况与变化归因

### 本期异动分析（{{n_changes}} 项）

> 以下异动按同比变化、指标阈值与风险触发情况筛出。每项写明读数、可能原因和下一期要盯的点；置信度低的事项只作提示，不作结论。

{{#changes}}
- 【{{severity_tag}}】{{title}}（{{dimension}}）：{{reading}} 可能原因：{{analysis}} 下一期关注：{{watch}}（出处页：{{page_str}}）
{{/changes}}

### 收入线

- 营业收入 {{revenue}}，{{revenue_growth|growth}}。
- 归母净利润 {{ni_parent}}，{{ni_growth|growth}}。

### 成本费用线

- 营业成本 {{operating_cost}}，{{cost_growth|growth}}。
- 毛利率 {{gross_margin}}，较上期变动 {{gross_margin_delta}} 个百分点。

### 现金流线

- 经营活动现金流净额 {{ocf}}，{{ocf_growth|growth}}。
- 净现比（经营现金流 ÷ 归母净利润）{{cfo_to_ni}}；自由现金流 {{fcf}}。

### 变化归因

> 以下归因来自财务指标变动与年报证据链，按杜邦分解和现金流桥展开。

{{#dupont_available}}
杜邦分解（ROE 变动 {{dupont_roe_delta}} 个百分点）：净利率贡献 {{dupont_net_margin}}、总资产周转贡献 {{dupont_asset_turnover}}、权益乘数贡献 {{dupont_leverage}} 个百分点。
{{/dupont_available}}

现金流桥（单位：亿元）：

{{#cashflow_bridge}}
- {{item}}：{{amount_yi}}
{{/cashflow_bridge}}

## 四、风险雷达

> 触发风险共 {{risk_count}} 项，按严重度（重大 > 关注 > 提示）再按评分降序排列。

### 同业对比（{{comparison_status}}）

同业样本：{{comparison_peer_names}}。样本少于 3 家时只作参考，不下“显著高于/低于同业”的结论。

| 指标 | 目标 | 同业下四分位 | 中位数 | 同业上四分位 | 样本 |
| --- | --- | --- | --- | --- | --- |
{{#comparison_metrics}}
| {{label}} | {{target}} | {{peer_p25}} | {{peer_median}} | {{peer_p75}} | {{sample_n}} |
{{/comparison_metrics}}

{{#risks}}
### 【{{severity_tag}}】{{risk_name}}

- 类别：{{category}}　评分：{{score}}
- 触发条件：{{trigger}}
- 阈值来源：{{threshold_str}}
- 涉及数值：{{involved_str}}
- 数字证据：{{numeric_evidence}}
- 解释：{{explanation}}
- 建议动作：{{suggested_action}}

{{/risks}}

## 五、预测与估值

### 估值假设（DCF）

- 预测期 {{forecast_years}} 年；WACC {{wacc}}；永续增长率 {{terminal_growth}}；所得税率 {{tax_rate}}。
- 收入基数 {{revenue_base}}；EBIT 利润率 {{ebit_margin}}。

### 预测表（DCF 口径）

> 如实说明：这里只列 DCF 需要的收入、EBIT、FCFF 三行预测，**没有完整的资产负债表与现金流量表预测**，它不是完整的「预测三表」。

| 年度 | 营业收入 | EBIT | FCFF |
| --- | --- | --- | --- |
{{#forecast}}
| {{year}} | {{revenue_yi}} | {{ebit_yi}} | {{fcff_yi}} |
{{/forecast}}

### 估值区间（元/股）

- DCF（收益法）：{{dcf_low}} 至 {{dcf_high}}，中值 {{dcf_mid}}。
- DDM/剩余收益：{{ddm_ps}} 元/股（仅银行/保险/证券适用）。
- 相对估值（市场法）：{{comps_low}} 至 {{comps_high}}，中值 {{comps_mid}}。
- {{valuation_summary_line}}
- {{conclusion_line}}
- 融合不可用时的参考区间：{{reference_line}}。这是各方法每股价值的范围，用于核对，不是定价结论。
- 终值占比：终值占企业价值 {{tv_pct}}，解读须结合下方敏感性与估值假设。

### 三情景

| 情景 | 每股价值（元/股） | 第一年收入增速 | EBIT 利润率 | WACC |
| --- | --- | --- | --- | --- |
{{#scenarios}}
| {{label}} | {{per_share}} | {{growth_y1}} | {{ebit_margin}} | {{wacc}} |
{{/scenarios}}

### 利润情景测算（{{outlook_year}} 年，非公司指引）

> {{outlook_commentary}}

| 情景 | 营业收入（亿元） | 归母净利润（亿元） | 收入增速 | 归母净利率 |
| --- | --- | --- | --- | --- |
{{#outlook_rows}}
| {{label}} | {{revenue_yi}} | {{net_income_yi}} | {{growth}} | {{net_margin}} |
{{/outlook_rows}}

### 敏感性（每股价值，元/股）

行＝WACC，列＝永续增长率。

| WACC \ 永续增长 | {{sens_header_cells}} |
| --- | --- |
{{#sensitivity_rows}}
| {{wacc}} | {{cells}} |
{{/sensitivity_rows}}

## 六、数据来源与免责声明

### 数据来源

| 文件名 | 页码 | 获取时间 |
| --- | --- | --- |
{{#sources}}
| {{file_name}} | {{page}} | {{retrieved_at}} |
{{/sources}}

{{source_note}}

### 免责声明

{{disclaimer}}

{{group_disclaimer}}
