# -*- coding: utf-8 -*-
"""export_json.py — memo.json，带数字溯源。

结构：
  meta            报告标识、渲染时间、引擎说明
  columns         七个栏目标题（固定结构）
  scalars         每个标量占位符：用了哪个点路径、原值、格式化后的值
  collections     每个循环集合：每一项每个字段的点路径与原值
  numbers         成稿里出现的每个数字 → 出自哪些点路径（数字溯源索引）
  compliance      禁用词命中记录
  validation      数字白名单校验结果
"""

import json

COLUMNS = [
    "① 结论摘要",
    "② 关键指标仪表盘",
    "③ 经营情况与变化归因",
    "④ 风险雷达",
    "⑤ 预测与估值",
    "⑥ 数据来源与免责声明",
]


def build(result, apply_fmt):
    state = result["state"]
    company = result.get("company") or {}

    scalars = []
    for s in state.scalars:
        scalars.append({
            "placeholder": s["placeholder"],
            "source_path": s["path"],
            "raw_value": s["raw"],
            "formatted": s["formatted"],
        })

    collections = []
    for cname, items in result["collections"].items():
        entry = {"name": cname, "items": []}
        for idx, item in enumerate(items):
            fields = {}
            for fname, fd in item.items():
                fields[fname] = {
                    "source_path": fd["path"],
                    "raw_value": fd["value"],
                    "formatted": apply_fmt(fd["fmt"], fd["value"]),
                }
            entry["items"].append(fields)
        collections.append(entry)

    numbers = []
    for canon, paths in sorted(state.num_index.items(), key=lambda kv: kv[0]):
        numbers.append({
            "token": canon,
            "sources": sorted(paths),
        })

    return {
        "meta": {
            "key": result["key"],
            "company_name": company.get("name"),
            "ticker": company.get("ticker"),
            "report_period": company.get("report_period"),
            "generated_at": result["generated_at"],
            "engine": "deterministic-template-v1（不使用大模型，数字全部代码注入）",
        },
        "columns": COLUMNS,
        "scalars": scalars,
        "collections": collections,
        "numbers": numbers,
        "compliance": {"hits": result["compliance_hits"]},
        "validation": result["validation"],
    }


def write_json(result, path, apply_fmt):
    doc = build(result, apply_fmt)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    return path
