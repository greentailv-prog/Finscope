# 行情与可比公司缓存

A 分支的抽取只产财务科目，产不出**行情**（股价、股本、市值、beta）与**可比公司**
（peers）。估值引擎 C 又必须要这些才能做相对估值（Comps）。这块缺口由本目录补齐。

## 怎么用

- 文件名 `market_data/<代码>.json`，代码是 6 位股票代码（`600519`、`000333`），
  不带交易所后缀。代码从 A 抽取结果的 `company.ticker` 来。
- 估值链（`agent/runner/run_chain.py`）按代码查这个目录：
  有缓存就用缓存；没有缓存、又没开 `--online`，就把行情留空、peers 传空，
  并在 `valuation.warnings` 里记一条「Comps 未产出：缺行情与可比公司」。
- **绝不套用别家公司的行情。** 没缓存就是没缓存，宁缺毋滥。

## 单位（全项目统一，写缓存时必须遵守）

| 类型 | 单位 |
|---|---|
| 金额（市值、资金来源） | 元 |
| 股本 | 股 |
| 股价 | 元/股 |
| 比率、beta | 小数（beta 0.55 写 `0.55`，不是 55） |
| 倍数（pe/ps/pb/ev_ebitda） | 倍（8.25 写 `8.25`） |

## 字段说明

### 身份与日期

| 字段 | 必填 | 说明 |
|---|---|---|
| `code` | 是 | 6 位代码，与文件名一致 |
| `name` | 否 | 公司名，缺省用 A 的 |
| `ticker` | 否 | 带后缀代码（`600519.SH`），缺省用 A 的 |
| `market` | 否 | `"A"` 或 `"US"`，决定 C 用哪套市场默认参数，缺省 `"A"` |
| `currency` | 否 | `CNY` / `USD`，缺省 `CNY` |
| `industry` / `sector` | 否 | 行业，缺省用 A 的 industry |
| `price_date` | 是 | 股价对应日期，`YYYY-MM-DD`。报告里要标价格时点 |

### 行情（A 抽不出，必须人工填）

| 字段 | 必填 | 说明 |
|---|---|---|
| `price` | 是 | 最新收盘价，元/股 |
| `shares_outstanding` | 是 | 稀释后总股本，股。用「总股本」不是「流通股本」 |
| `market_cap` | 是 | 总市值，元。约等于 `price × shares_outstanding`，填完自己对一下 |
| `beta` | 否 | 含杠杆 beta（市场观测值），小数。留空则 C 用 CAPM 默认 beta |

### 可比公司

| 字段 | 必填 | 说明 |
|---|---|---|
| `peers` | 估 Comps 时是 | 数组，**至少 3 家**，建议 4–6 家。缺的倍数写 `null`，别填 0 |

每家 peer 的字段（能填多少填多少，C 只用 `pe/ps/pb/ev_ebitda`）：

```json
{"name": "五粮液", "ticker": "000858",
 "pe": 8.25, "ps": 3.07, "pb": 2.01, "ev_ebitda": 5.6,
 "revenue_growth": 0.05, "ebitda_margin": 0.42,
 "note": "为什么选它做可比（一句话）"}
```

选可比公司的原则：同行业、相近商业模式、相近体量或价格带。`note` 写清选取依据，
报告栏目里会用到。

### 估值假设与来源

| 字段 | 必填 | 说明 |
|---|---|---|
| `assumptions` | 否 | 传给 C 的假设，缺省走 C 的 RULES 默认值。常用 `forecast_years`(3–10)、`terminal_growth` |
| `relative_multiples` | 否 | 用哪些倍数做相对估值，缺省 `["pe","ps","pb"]`。可选 `pe/ps/pb/ev_ebitda` |
| `sources` | 否 | 数据来源，交付时必须填。每项 `{name, as_of, official, purpose}` |

## 补一家新公司

1. 新建 `market_data/<代码>.json`，代码不带后缀。
2. 填 `price / shares_outstanding / market_cap / price_date`（行情四件套），
   再填 `peers`（至少 3 家）与 `assumptions`。
3. 自查：`market_cap ≈ price × shares_outstanding`；倍数与占比类字段是小数。
4. 跑 `python agent/runner/run_chain.py --a <该公司 A 抽取结果>`，
   看 `valuation.comps` 是否出了结果、`valuation.warnings` 是否干净。

   `--out` / `--log` 可以不传，落点会按 A 的公司代码与年份自动推到
   `out_data/unified/<代码>.<交易所>_<年份>.json`（下游唯一会扫的目录）。
   要落到别处才显式给。早先这里写的是必须显式传 `--out`，
   现在默认值已经改成按公司落盘，不传也不会互相覆盖了。

   **注意 `shares_outstanding` 必须填。** C 的每股价值 = 权益价值 ÷ 股本，
   缺股本连 DCF 的每股都算不出来，`blended` 会整块空掉——不是只有 Comps 受影响。

## 已知限制

- **peers 有两层来源。** 优先读本目录手工维护的名单；没有时 D 会用
  `modules/C/valuation/config/industry_peers.json` 的行业可比池兜底。
  兜底只给候选代码，B 的同业对比仍需要同业财务快照（`modules/A/data/unified`）
  或联网年度三表；两者都没有时 comparison 仍是 `not_available`。
- **beta 不自动生成。** 缺 beta 时 C 用 CAPM 默认值。
- 缺 peers 时，C 的 `engine/methods.py` 直接跳过相对估值，`blended` 会缺一块
  （只剩 DCF 权重），这是**预期行为**，不是 bug，warning 里会写明。
- 缓存的行情有价格时点，过期要更新 `price_date` 与 `price`，否则估值口径陈旧。
