# -*- coding: utf-8 -*-
"""前景测算：把 C 的三情景翻译成“收入 / 归母净利润”的区间。

这不是公司指引，也不是 D 新造一套盈利预测。做法只有两步：
  1. 用 C 的情景收入增速，推下一年收入；
  2. 用最近三年的归母净利率，叠加情景里 EBIT 利润率的变化，推归母净利润。
每一步都在输出里写明假设来源，报告用“情景测算”四个字，不写成确定预测。
"""
from __future__ import annotations


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _avg(vals):
    vals = [v for v in vals if isinstance(v, (int, float))]
    return sum(vals) / len(vals) if vals else None


def _fmt_yi(v):
    return None if v is None else round(v / 1e8, 2)


def build(unified):
    # 只在这份数据质量干净时做情景测算；warn/blocked 都不做，避免把错数推成“预测”
    q = unified.get("data_quality") or {}
    if q.get("status") != "ok" or q.get("blocked"):
        return None
    fin = unified.get("financials") or {}
    val = unified.get("valuation") or {}
    dcf = val.get("dcf") or {}
    scen = val.get("scenarios") or {}

    rev_rec = fin.get("revenue") or {}
    ni_rec = fin.get("net_income_parent") or {}

    def series_of(rec):
        s = {str(k): v for k, v in (rec.get("series") or {}).items()
             if isinstance(v, (int, float))}
        if not s and isinstance(rec.get("value"), (int, float)):
            s[str(rec.get("period"))] = rec["value"]
            if isinstance(rec.get("prior_value"), (int, float)):
                s[str(rec.get("prior_period"))] = rec["prior_value"]
        return s

    rev_series = series_of(rev_rec)
    ni_series = series_of(ni_rec)
    if not rev_series:
        return None
    years = sorted(rev_series)
    latest_year = years[-1]
    latest_rev = rev_series[latest_year]

    # 近三年净利率（归母 / 收入）
    margins = []
    for y in years[-3:]:
        r = rev_series.get(y)
        n = ni_series.get(y)
        if isinstance(r, (int, float)) and r and isinstance(n, (int, float)):
            margins.append(n / r)
    base_margin = _avg(margins) or (ni_rec.get("value") / latest_rev
                                    if _num(ni_rec.get("value")) and latest_rev else None)
    if base_margin is None:
        return None

    forecast = dcf.get("forecast") or []
    base_growth = None
    if forecast:
        base_growth = _num(forecast[0].get("growth"))
    if base_growth is None:
        base_growth = _num(((unified.get("ratios") or {}).get("growth") or {})
                           .get("revenue_growth_yoy", {}).get("value"))
    if base_growth is None:
        base_growth = 0.0

    ref_ebit_margin = _num((dcf.get("inputs") or {}).get("ebit_margin"))
    rows = []
    for key, label in (("bull", "乐观"), ("base", "基准"), ("bear", "悲观")):
        s = scen.get(key) or {}
        g = _num(s.get("growth_y1"))
        if g is None:
            g = base_growth if key == "base" else None
        if g is None:
            continue
        ebit = _num(s.get("ebit_margin"))
        margin = base_margin
        if ebit is not None and ref_ebit_margin is not None:
            # EBIT 利润率每变化 1 个百分点，归母净利率按 0.75 传导（留出税与少数股东）
            margin = base_margin + (ebit - ref_ebit_margin) * 0.75
        rev = latest_rev * (1 + g)
        ni = rev * margin
        rows.append({
            "key": key,
            "label": label,
            "growth": round(g, 4),
            "revenue": rev,
            "revenue_yi": _fmt_yi(rev),
            "net_margin": round(margin, 4),
            "net_income": ni,
            "net_income_yi": _fmt_yi(ni),
        })

    if not rows:
        return None
    # 基准缺失时用中位
    base = next((r for r in rows if r["key"] == "base"), None)
    if base is None:
        rows.sort(key=lambda r: r["net_income"])
        base = rows[len(rows) // 2]

    ordered = sorted(rows, key=lambda r: r["net_income"])
    low, high = ordered[0], ordered[-1]
    next_year = str(int(latest_year) + 1) if latest_year.isdigit() else "下一年"

    return {
        "period": latest_year,
        "next_year": next_year,
        "currency": "CNY",
        "unit": "元",
        "method": "C 情景收入增速 + 近三年归母净利率 + EBIT 利润率传导（0.75）",
        "base_margin": round(base_margin, 4),
        "rows": rows,
        "base": base,
        "range": {"low": low["net_income"], "high": high["net_income"],
                  "low_yi": low["net_income_yi"], "high_yi": high["net_income_yi"],
                  "low_label": low["label"], "high_label": high["label"]},
        "commentary": (
            "按%s情景，%s 年营业收入约 %.2f 亿元，归母净利润约 %.2f 亿元；"
            "区间 %.2f 至 %.2f 亿元由%s与%s情景给出。"
            "该测算是情景推演，不是公司指引，也不构成盈利预测；"
            "实际结果取决于需求、价格、成本与一次性损益。"
            % (base["label"], next_year, base["revenue_yi"], base["net_income_yi"],
               low["net_income_yi"], high["net_income_yi"], low["label"], high["label"])
        ),
        "confidence": "中" if len(rows) >= 3 else "低",
        "disclaimer": "情景测算，不是公司指引，不构成投资建议。",
    }


def attach(unified):
    out = build(unified)
    if out:
        unified["outlook"] = out
    return unified


if __name__ == "__main__":
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    path = sys.argv[1] if len(sys.argv) > 1 else "tests/fixtures/unified/600519.SH_2025.json"
    obj = json.load(open(path, encoding="utf-8"))
    print(json.dumps(build(obj), ensure_ascii=False, indent=1))
