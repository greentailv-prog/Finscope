# -*- coding: utf-8 -*-
"""异动分析：把「同比变了多少」变成「哪里变了、为什么值得看、下一期盯什么」。

D 不重新算财务指标，所有数值都从统一对象的 financials / ratios / valuation 里取。
每张异动卡都带点路径式的出处（source_id / page / pdf_page / raw_text），
报告和前端点一下就能回到原文。

输出 changes[]，可直接放进统一对象，也供报告模板的「三、异动分析」栏目使用。
"""
from __future__ import annotations

import re

SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2}
SEVERITY_TAG = {"critical": "重大", "warning": "关注", "info": "提示"}


def _public(text):
    """把团队内部叫法换成投资者看得懂的话。报告里不出现 A/B/C/D、引擎名。"""
    if not text:
        return text
    s = str(text)
    s = s.replace("该风险由 B 的规则引擎触发，已进入风险雷达；这里只做摘要，不重复叙述。",
                  "这条风险已列入风险雷达，具体证据见风险章节。")
    s = s.replace("向 C 明确：", "估值时注意：")
    s = s.replace("cash_flow_bridge", "现金流桥")
    s = s.replace("operating_profit_bridge", "营业利润桥")
    s = re.sub(r"[ABCD]\s*的", "", s)
    s = re.sub(r"[ABCD]\s*端", "数据端", s)
    s = re.sub(r"\b[ABCD]\b", "", s)
    s = s.replace("  ", " ").strip()
    return s


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _ratio(ratios, group, key):
    return ((ratios or {}).get(group) or {}).get(key) or {}


def _fin(financials, key):
    return (financials or {}).get(key) or {}


def _growth(cur, prev):
    if cur is None or prev in (None, 0):
        return None
    return (cur - prev) / abs(prev)


def _fmt_money(v):
    if v is None:
        return "-"
    return "%.2f 亿元" % (v / 1e8)


def _fmt_pct(v):
    return "-" if v is None else "%.2f%%" % (v * 100)


def _growth_text(v):
    if v is None:
        return "-"
    return "%s %.2f%%" % ("同比增长" if v >= 0 else "同比下降", abs(v) * 100)


def _evidence(rec):
    return {
        "source_id": rec.get("source_id"),
        "page": rec.get("page"),
        "pdf_page": rec.get("pdf_page"),
        "raw_text": rec.get("raw_text"),
        "source_url": rec.get("source_url"),
        "source": rec.get("source"),
    }


def _linked_risks(risks, metric_names):
    out = []
    for card in risks or []:
        blob = " ".join(str(x) for x in (
            card.get("risk_name"), card.get("trigger"),
            " ".join(str(v.get("metric")) for v in card.get("involved_values") or []),
        ))
        if any(m and m in blob for m in metric_names):
            out.append(card.get("risk_id"))
    return [x for x in out if x][:3]


def _add(out, *, cid, dimension, title, direction, severity, metric, metric_label,
         value, prior_value, delta, change_pct, unit, period, prior_period,
         evidence, reading, analysis, watch, linked_risks=None, confidence="中"):
    out.append({
        "id": cid,
        "dimension": dimension,
        "title": _public(title),
        "direction": direction,
        "severity": severity,
        "severity_tag": SEVERITY_TAG[severity],
        "metric": metric,
        "metric_label": metric_label,
        "value": value,
        "prior_value": prior_value,
        "delta": delta,
        "change_pct": change_pct,
        "unit": unit,
        "period": period,
        "prior_period": prior_period,
        "evidence": evidence or {},
        "reading": _public(reading),
        "analysis": _public(analysis),
        "watch": _public(watch),
        "linked_risks": linked_risks or [],
        "confidence": confidence,
    })


def build_changes(unified, limit=8):
    """从统一对象生成异动卡。没有足够数据就返回空列表，不硬编故事。"""
    fin = unified.get("financials") or {}
    ratios = unified.get("ratios") or {}
    risks = unified.get("risks") or []
    val = unified.get("valuation") or {}
    company = unified.get("company") or {}
    period = str(company.get("report_period") or "")
    prior_period = str(int(period) - 1) if period.isdigit() else ""
    out = []

    # ---------------- 成长 ----------------
    rev_g = _num(_ratio(ratios, "growth", "revenue_growth_yoy").get("value"))
    rev, rev_prev = _fin(fin, "revenue").get("value"), _fin(fin, "revenue").get("prior_value")
    if rev_g is not None:
        if rev_g <= -0.10:
            sev, title = "critical", "营业收入明显下滑"
        elif rev_g <= -0.03:
            sev, title = "warning", "营业收入同比转负"
        elif rev_g <= -0.005:
            sev, title = "info", "营业收入小幅下滑"
        elif rev_g >= 0.30:
            sev, title = "info", "营业收入高速增长"
        else:
            sev, title = None, ""
        if sev:
            _add(out, cid="CH01", dimension="成长", title=title,
                 direction="down" if rev_g < 0 else "up", severity=sev,
                 metric="revenue", metric_label="营业收入",
                 value=rev, prior_value=rev_prev,
                 delta=(rev - rev_prev) if None not in (rev, rev_prev) else None,
                 change_pct=rev_g, unit="元", period=period, prior_period=prior_period,
                 evidence=_evidence(_fin(fin, "revenue")),
                 reading="营业收入 %s，%s。" % (_fmt_money(rev), _growth_text(rev_g)),
                 analysis=("收入端出现收缩。先分清楚是价格、销量还是并表范围变化："
                           "如果毛利率同步下降，更像降价换量；如果毛利率稳定，更像需求或份额问题。"
                           if rev_g < 0 else
                           "收入增长较快。需要确认增长来自主业还是并表、贸易或低毛利业务，"
                           "并对照应收账款和存货增速，看增长有没有靠放宽信用条件换来。"),
                 watch="下一期看收入增速能否延续、毛利率是否被摊薄、应收账款增速是否超过收入增速。",
                 linked_risks=_linked_risks(risks, ["revenue"]),
                 confidence="高")

    ni_g = _num(_ratio(ratios, "growth", "net_income_growth_yoy").get("value"))
    ni, ni_prev = _fin(fin, "net_income_parent").get("value"), _fin(fin, "net_income_parent").get("prior_value")
    if ni_g is not None:
        if ni_g <= -0.20:
            sev, title = "critical", "归母净利润大幅下滑"
        elif ni_g <= -0.05:
            sev, title = "warning", "归母净利润同比下降"
        elif ni_g <= -0.01:
            sev, title = "info", "归母净利润小幅下降"
        elif ni_g >= 0.50:
            sev, title = "info", "归母净利润快速增长"
        else:
            sev, title = None, ""
        if sev:
            _add(out, cid="CH02", dimension="盈利", title=title,
                 direction="down" if ni_g < 0 else "up", severity=sev,
                 metric="net_income_parent", metric_label="归母净利润",
                 value=ni, prior_value=ni_prev,
                 delta=(ni - ni_prev) if None not in (ni, ni_prev) else None,
                 change_pct=ni_g, unit="元", period=period, prior_period=prior_period,
                 evidence=_evidence(_fin(fin, "net_income_parent")),
                 reading="归母净利润 %s，%s。" % (_fmt_money(ni), _growth_text(ni_g)),
                 analysis=("利润下滑幅度需要和收入、毛利率、费用率一起看。"
                           "若收入降幅小于利润降幅，通常是毛利率或费用端出了问题；"
                           "若两者同步，更多是需求收缩。"
                           if ni_g < 0 else
                           "利润增长快于收入时，要确认是毛利率改善、费用率下降，"
                           "还是一次性收益或税率变化。"),
                 watch="下一期看扣非净利润是否同步、非经常性损益占比、经营现金流能否跟上利润。",
                 linked_risks=_linked_risks(risks, ["net_income", "profit"]),
                 confidence="高")

    # ---------------- 盈利质量 ----------------
    gm = _ratio(ratios, "profitability", "gross_margin")
    gm_v, gm_p = _num(gm.get("value")), _num(gm.get("prev"))
    if gm_v is not None and gm_p is not None:
        d = gm_v - gm_p
        if abs(d) >= 0.03:
            _add(out, cid="CH03", dimension="盈利",
                 title="毛利率明显改善" if d > 0 else "毛利率明显下滑",
                 direction="up" if d > 0 else "down",
                 severity="info" if d > 0 else "warning",
                 metric="gross_margin", metric_label="毛利率",
                 value=gm_v, prior_value=gm_p, delta=d, change_pct=None,
                 unit="小数", period=period, prior_period=prior_period,
                 evidence=_evidence(_fin(fin, "operating_cost")) or _evidence(_fin(fin, "revenue")),
                 reading="毛利率 %s，较上期 %s 个百分点。"
                         % (_fmt_pct(gm_v), ("%+.2f" % (d * 100))),
                 analysis=("毛利率变动超过 3 个百分点，已经不是正常波动。"
                           "向上要区分产品结构升级、原材料降价还是一次性因素；"
                           "向下要警惕价格战、成本上涨或低毛利业务占比上升。"),
                 watch="下一期看毛利率能否稳住，以及销售费用率是否被动上升。",
                 linked_risks=_linked_risks(risks, ["gross_margin", "margin"]),
                 confidence="高")

    # ---------------- 现金流 ----------------
    c2ni = _ratio(ratios, "cashflow_quality", "cfo_to_net_income")
    c2ni_v, c2ni_p = _num(c2ni.get("value")), _num(c2ni.get("prev"))
    if c2ni_v is not None and (c2ni_v < 0.8 or (c2ni_p is not None and c2ni_v - c2ni_p <= -0.3)):
        _add(out, cid="CH04", dimension="现金流", title="利润的现金含量下降",
             direction="down", severity="warning" if c2ni_v >= 0.5 else "critical",
             metric="cfo_to_net_income", metric_label="净现比",
             value=c2ni_v, prior_value=c2ni_p,
             delta=(c2ni_v - c2ni_p) if c2ni_p is not None else None,
             change_pct=None, unit="倍", period=period, prior_period=prior_period,
             evidence=_evidence(_fin(fin, "cfo")),
             reading="经营现金流 / 归母净利润 = %.2f 倍，上期 %s。"
                     % (c2ni_v, ("%.2f 倍" % c2ni_p) if c2ni_p is not None else "-"),
             analysis=("净现比低于 1，说明利润没有等量变成现金。常见原因是应收账款、"
                       "存货或合同资产占用增加，也可能是一次性税费、保证金或票据结算。"
                       "如果连续两期低于 0.8，利润质量要打问号。"),
             watch="下一期看应收账款周转天数、存货周转天数、销售商品收到的现金 / 营业收入。",
             linked_risks=_linked_risks(risks, ["ocf", "cfo", "cash"]),
             confidence="高")

    # ---------------- 营运 ----------------
    ar_g = _num(_ratio(ratios, "efficiency", "accounts_receivable_growth").get("value") or
                _ratio(ratios, "growth", "accounts_receivable_growth").get("value"))
    inv_g = _num(_ratio(ratios, "efficiency", "inventory_growth").get("value") or
                 _ratio(ratios, "growth", "inventory_growth").get("value"))
    if rev_g is not None and ar_g is not None and ar_g - rev_g >= 0.15:
        _add(out, cid="CH05", dimension="营运", title="应收账款增速快于收入",
             direction="up", severity="warning",
             metric="accounts_receivable", metric_label="应收账款",
             value=_fin(fin, "accounts_receivable").get("value"),
             prior_value=_fin(fin, "accounts_receivable").get("prior_value"),
             delta=None, change_pct=ar_g, unit="元", period=period,
             prior_period=prior_period,
             evidence=_evidence(_fin(fin, "accounts_receivable")),
             reading="应收账款%s，收入%s，前者快 %.2f 个百分点。"
                     % (_growth_text(ar_g), _growth_text(rev_g), (ar_g - rev_g) * 100),
             analysis=("应收增速持续快于收入，通常意味着回款变慢或客户结构变差。"
                       "需要看账龄结构和坏账准备计提比例，排除并表范围变化。"),
             watch="下一期看应收账款周转天数、坏账准备计提比例、经营现金流是否继续恶化。",
             linked_risks=_linked_risks(risks, ["receivable", "dso"]),
             confidence="中")
    if rev_g is not None and inv_g is not None and inv_g - rev_g >= 0.15:
        _add(out, cid="CH06", dimension="营运", title="存货增速快于收入",
             direction="up", severity="warning",
             metric="inventory", metric_label="存货",
             value=_fin(fin, "inventory").get("value"),
             prior_value=_fin(fin, "inventory").get("prior_value"),
             delta=None, change_pct=inv_g, unit="元", period=period,
             prior_period=prior_period,
             evidence=_evidence(_fin(fin, "inventory")),
             reading="存货%s，收入%s，前者快 %.2f 个百分点。"
                     % (_growth_text(inv_g), _growth_text(rev_g), (inv_g - rev_g) * 100),
             analysis=("存货增长快于收入，可能是备货、原材料涨价，也可能是产品滞销。"
                       "要结合存货周转天数和跌价准备判断，不能只看绝对额。"),
             watch="下一期看存货周转天数、跌价准备计提、毛利率是否被存货成本拖累。",
             linked_risks=_linked_risks(risks, ["inventory", "dio"]),
             confidence="中")

    # ---------------- 偿债 ----------------
    debt = _ratio(ratios, "solvency", "debt_to_asset_ratio")
    debt_v, debt_p = _num(debt.get("value")), _num(debt.get("prev"))
    if debt_v is not None and debt_p is not None and debt_v - debt_p >= 0.05:
        _add(out, cid="CH07", dimension="偿债", title="资产负债率上升",
             direction="up", severity="warning",
             metric="debt_to_asset_ratio", metric_label="资产负债率",
             value=debt_v, prior_value=debt_p, delta=debt_v - debt_p, change_pct=None,
             unit="小数", period=period, prior_period=prior_period,
             evidence=_evidence(_fin(fin, "total_liabilities")),
             reading="资产负债率 %s，较上期 %+.2f 个百分点。"
                     % (_fmt_pct(debt_v), (debt_v - debt_p) * 100),
             analysis=("杠杆上升 5 个百分点以上，要看是短期借款、应付债券还是经营性负债增加。"
                       "经营性负债上升未必是坏事，有息负债上升才直接增加财务压力。"),
             watch="下一期看有息负债规模、利息保障倍数、短期借款占比。",
             linked_risks=_linked_risks(risks, ["debt", "leverage"]),
             confidence="高")

    # ---------------- 估值 ----------------
    # 数据质量闸门阻断时，不给“高估/低估”的异动结论；数字仍留在估值页供核对
    blocked = bool((unified.get("data_quality") or {}).get("blocked"))
    blended = val.get("blended") or {}
    upside = _num(blended.get("upside"))
    if not blocked and upside is not None and abs(upside) >= 0.20:
        _add(out, cid="CH08", dimension="估值",
             title="估值相对现价偏高" if upside < 0 else "估值相对现价有空间",
             direction="down" if upside < 0 else "up",
             severity="warning" if upside < 0 else "info",
             metric="blended_per_share", metric_label="融合每股价值",
             value=blended.get("blended_per_share"), prior_value=blended.get("current_price"),
             delta=None, change_pct=upside, unit="元/股", period=period,
             prior_period=period,
             evidence={"source_url": (unified.get("meta") or {}).get("pdf_url")},
             reading="融合每股价值 %.2f 元，现价 %.2f 元，空间 %s。"
                     % (blended.get("blended_per_share") or 0,
                        blended.get("current_price") or 0, _fmt_pct(upside)),
             analysis=("估值结论依赖假设，不能当成确定的价格判断。"
                       "空间超过 20% 时，先检查 WACC、永续增长率和可比公司选择是否合理；"
                       "如果 DCF 与相对估值分歧很大，结论只能作为区间参考。"),
             watch="下一期看假设是否被业绩验证、可比公司估值中枢是否移动、股价是否已反映。",
             linked_risks=_linked_risks(risks, ["valuation", "wacc"]),
             confidence="低")

    # ---------------- 重大风险兜底 ----------------
    covered_risk_ids = {rid for c in out for rid in (c.get("linked_risks") or [])}
    for card in sorted(risks, key=lambda r: (
            {"high": 0, "medium": 1, "low": 2}.get(r.get("severity"), 3),
            -(r.get("score") or 0)))[:3]:
        if card.get("severity") not in ("high", "medium"):
            continue
        if card.get("risk_id") in covered_risk_ids:
            continue
        _add(out, cid="CH09", dimension="风险", title=card.get("risk_name") or "重大风险",
             direction="down", severity="critical" if card.get("severity") == "high" else "warning",
             metric=(card.get("involved_values") or [{}])[0].get("metric"),
             metric_label=card.get("category") or "风险",
             value=None, prior_value=None, delta=None, change_pct=None,
             unit=None, period=period, prior_period=prior_period,
             evidence=(card.get("text_evidence") or {}),
             reading=card.get("explanation") or card.get("numeric_evidence") or "",
             analysis="该风险由 B 的规则引擎触发，已进入风险雷达；这里只做摘要，不重复叙述。",
             watch=card.get("suggested_action") or "按风险卡的建议动作核查原文。",
             linked_risks=[card.get("risk_id")], confidence="中")

    # 去重、排序、截断
    seen, unique = set(), []
    for c in out:
        key = (c["dimension"], c["title"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(c)
    unique.sort(key=lambda c: (SEVERITY_ORDER.get(c["severity"], 9),
                               -abs(c.get("change_pct") or 0)))
    for i, c in enumerate(unique, 1):
        c["id"] = "CH%02d" % i
    return unique[:limit]


def attach(unified, limit=8):
    """写入 unified['changes']，返回同一对象。"""
    unified["changes"] = build_changes(unified, limit=limit)
    return unified


if __name__ == "__main__":
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    path = sys.argv[1] if len(sys.argv) > 1 else "tests/fixtures/unified/600519.SH_2025.json"
    obj = json.load(open(path, encoding="utf-8"))
    changes = build_changes(obj)
    print(json.dumps(changes, ensure_ascii=False, indent=1))
