# -*- coding: utf-8 -*-
"""统一对象出稿前的两件清理：增速变动、模板占位符。

B 的规则文案里有 `{ar_and_inventory_to_assets:.1%}` 这类占位符。B 在部分场景
没有替换就透传出来，报告和页面会直接显示花括号。D 在统一对象落盘前统一处理：

  1. 能从上一年数据算出「上一年增速」的，补上前一年增速和增速变动（百分点）；
  2. 规则文案里的占位符，有值就填，没值就把整个括号删掉，不留下 `{.1%}`。

只改展示文本和 ratios 的 prev/delta，不改 A/B 的原始数值。
"""
from __future__ import annotations

import re

from adapters.from_b import MULTIPLE_KEYS, RATIO_RENAME

PLACEHOLDER = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)(?::([^{}]+))?\}")
PAREN_WITH_PLACEHOLDER = re.compile(
    r"（[^（）]*\{[^{}]*\}[^（）]*）|\([^()]*\{[^{}]*\}[^()]*\)"
)

# 成长类指标 -> 用来算上一年增速的财务科目
GROWTH_BASE = {
    "revenue_growth_yoy": "revenue",
    "net_income_total_growth": "net_income",
    "net_income_growth_yoy": "net_income_parent",
    "net_income_excl_nonrecurring_growth_yoy": "net_income_excl_nonrecurring",
    "cost_of_revenue_growth": "operating_cost",
    "total_assets_growth": "total_assets",
    "equity_parent_growth": "equity_parent",
    "ocf_growth": "cfo",
}

# 模板里常见、但 ratios 里没有现成字段的派生值
DERIVED_SUFFIXES = ("_prev", "_delta", "_delta_pp")


def _num(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _year(v):
    try:
        return int(str(v)[:4])
    except (TypeError, ValueError):
        return None


def _prior_growth(rec, period):
    """用财务科目的三年序列算上一年增速：(上年值 - 前年值) / |前年值|。"""
    series = rec.get("series") or {}
    y = _year(period)
    if y is None:
        return None
    prior = _num(series.get(str(y - 1)))
    base = _num(series.get(str(y - 2)))
    if prior is None or base in (None, 0):
        return None
    return (prior - base) / abs(base)


def enrich_growth(unified):
    """给成长类指标补 prev/delta。delta 是增速的变动，单位是百分点。"""
    ratios = unified.get("ratios") or {}
    growth = ratios.get("growth") or {}
    fin = unified.get("financials") or {}
    period = (unified.get("company") or {}).get("report_period") or (
        unified.get("meta") or {}).get("report_period")

    for key, base_key in GROWTH_BASE.items():
        rec = growth.get(key)
        if not isinstance(rec, dict) or _num(rec.get("value")) is None:
            continue
        if _num(rec.get("delta")) is not None:
            continue
        base = fin.get(base_key) or {}
        pg = _prior_growth(base, rec.get("period") or period)
        if pg is None:
            continue
        rec["prev"] = round(pg, 4)
        rec["delta"] = round(rec["value"] - pg, 4)

    # 收入与利润增速剪刀差：上一年剪刀差 = 上年收入增速 - 上年利润增速
    scissors = growth.get("profit_revenue_scissors")
    if isinstance(scissors, dict) and _num(scissors.get("value")) is not None:
        if _num(scissors.get("delta")) is None:
            rev_prev = _num((growth.get("revenue_growth_yoy") or {}).get("prev"))
            ni_prev = _num((growth.get("net_income_growth_yoy") or {}).get("prev"))
            if rev_prev is not None and ni_prev is not None:
                prior_scissors = rev_prev - ni_prev
                scissors["prev"] = round(prior_scissors, 4)
                scissors["delta"] = round(scissors["value"] - prior_scissors, 4)

    return unified


def _format_value(value, spec):
    if _num(value) is None:
        return None
    try:
        return format(value, spec) if spec else str(value)
    except (TypeError, ValueError):
        return None


def build_values(unified):
    """收集模板占位符能用的值：B 的比率、财务科目亿元口径、审计意见等。"""
    values = {}
    ratios = unified.get("ratios") or {}
    for items in ratios.values():
        for key, rec in (items or {}).items():
            if not isinstance(rec, dict):
                continue
            v = _num(rec.get("value"))
            if v is not None:
                values[key] = v
            prev = _num(rec.get("prev"))
            if prev is not None:
                values[key + "_prev"] = prev
            delta = _num(rec.get("delta"))
            if delta is not None:
                values[key + "_delta"] = delta
                values[key + "_delta_pp"] = delta * 100
                values[key + "_delta_pp_value"] = delta * 100

    # B 的模板用原始键名（revenue_growth / debt_to_assets / dso_delta ...），
    # 适配后统一对象里是规范键，这里补一份反向别名。
    for raw, canonical in RATIO_RENAME.items():
        for suffix in ("", "_prev", "_delta", "_delta_pp"):
            src = canonical + suffix
            dst = raw + suffix
            if src in values and dst not in values:
                values[dst] = values[src]
        # 反向：规范键也能被模板用（少数规则直接写规范名）
        for suffix in ("", "_prev", "_delta", "_delta_pp"):
            src = raw + suffix
            dst = canonical + suffix
            if src in values and dst not in values:
                values[dst] = values[src]

    fin = unified.get("financials") or {}
    for key, rec in fin.items():
        if not isinstance(rec, dict):
            continue
        v = _num(rec.get("value"))
        if v is not None:
            values.setdefault(key, v)
            values.setdefault(key + "_yi", v / 1e8)
        pv = _num(rec.get("prior_value"))
        if pv is not None:
            values.setdefault(key + "_prev", pv)
            values.setdefault(key + "_prev_yi", pv / 1e8)

    company = unified.get("company") or {}
    if company.get("audit_opinion"):
        values["audit_opinion"] = company["audit_opinion"]

    valuation = unified.get("valuation") or {}
    wacc = ((valuation.get("dcf") or {}).get("inputs") or {}).get("wacc")
    if _num(wacc) is not None:
        values.setdefault("wacc", wacc)
        values.setdefault("wacc_pp", wacc * 100)
    return values


def _render(text, values):
    def paren(match):
        block = match.group(0)
        keys = [k for k, _ in PLACEHOLDER.findall(block)]
        if keys and all(k in values for k in keys):
            return PLACEHOLDER.sub(
                lambda m: _format_value(values[m.group(1)], m.group(2)) or "", block)
        return ""

    s = PAREN_WITH_PLACEHOLDER.sub(paren, text)
    s = PLACEHOLDER.sub(
        lambda m: _format_value(values.get(m.group(1)), m.group(2)) or "", s)
    s = re.sub(r"[ \t]{2,}", " ", s)
    return s.strip()


def _plain_text(text):
    s = text.replace("meta.industry_gross_margin_benchmark", "行业毛利率基准")
    s = s.replace("industry_gross_margin_benchmark", "行业毛利率基准")
    s = s.replace("由 从可比公司池", "由估值模块从可比公司池")
    s = s.replace("roic_minus_wacc", "ROIC 与 WACC 的差值")
    return s


def _clean_node(node, values):
    if isinstance(node, dict):
        for key, val in list(node.items()):
            if isinstance(val, str):
                val = _plain_text(val)
                node[key] = _render(val, values) if "{" in val else val
            else:
                _clean_node(val, values)
    elif isinstance(node, list):
        for i, val in enumerate(node):
            if isinstance(val, str):
                val = _plain_text(val)
                node[i] = _render(val, values) if "{" in val else val
            else:
                _clean_node(val, values)


def clean_texts(unified, values=None):
    """递归清理 risks / rules_evaluated / changes 里的模板占位符。

    B 的占位符不只在 explanation / suggested_action，也可能藏在
    evidence_chain、trigger 等嵌套字段里，因此整棵子树都扫一遍。
    """
    values = values or build_values(unified)
    for group in ("risks", "rules_evaluated", "changes"):
        _clean_node(unified.get(group) or [], values)
    return unified


def fix_ratio_units(unified):
    """B 把流动比率、权益乘数也标成 ratio，D 统一对象里要改成「倍」。"""
    for items in (unified.get("ratios") or {}).values():
        for key, rec in (items or {}).items():
            if isinstance(rec, dict) and key in MULTIPLE_KEYS and rec.get("unit") == "小数":
                rec["unit"] = "倍"
    return unified


def label_involved(unified):
    """给风险的「涉及数值」补中文名，报告不再显示 current_ratio 这类字段名。"""
    labels = {"industry_gross_margin_benchmark": "行业毛利率基准"}
    for items in (unified.get("ratios") or {}).values():
        for key, rec in (items or {}).items():
            if isinstance(rec, dict):
                labels[key] = rec.get("label") or rec.get("name") or key
    for raw, canonical in RATIO_RENAME.items():
        if canonical in labels:
            labels.setdefault(raw, labels[canonical])
        if raw in labels:
            labels.setdefault(canonical, labels[raw])

    def _label_for(metric):
        if metric in labels:
            return labels[metric]
        for suffix in ("_delta_pp", "_delta", "_prev"):
            if metric.endswith(suffix):
                base = metric[:-len(suffix)]
                if base in labels:
                    return labels[base] + ("变动" if "delta" in suffix else "上期")
        return None

    for group in ("risks", "rules_evaluated"):
        for item in unified.get(group) or []:
            if not isinstance(item, dict):
                continue
            for iv in item.get("involved_values") or []:
                if not isinstance(iv, dict):
                    continue
                if not iv.get("label"):
                    iv["label"] = _label_for(iv.get("metric"))
                if iv.get("metric") in MULTIPLE_KEYS:
                    iv["unit"] = "倍"
    return unified


def apply(unified):
    """出稿前统一调用。顺序：单位 -> 增速 -> 中文名 -> 模板文本。"""
    fix_ratio_units(unified)
    enrich_growth(unified)
    label_involved(unified)
    clean_texts(unified)
    return unified
