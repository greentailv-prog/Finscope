#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""跑 C 的估值引擎，只调 engine.run，不碰 Excel 渲染（避免额外依赖）。

C 的官方入口 cli.py 的 run 子命令还会调 excel.render 生成 xlsx 并写到 C 的
output/ 目录。本脚本直接 import 它的 engine.run，把结果写到我们指定的路径，
不改 C 的任何代码。

用法：
    python run_c_engine.py --c-dir <C 的 valuation 目录> --input <c_input.json> --out <c_output.json>
"""
from __future__ import annotations

import argparse
import json
import os
import sys


def main():
    ap = argparse.ArgumentParser(description="跑 C 的估值引擎 engine.run")
    ap.add_argument("--c-dir", required=True, help="C 的 valuation 目录（内含 engine/）")
    ap.add_argument("--input", required=True, help="C 输入 JSON")
    ap.add_argument("--out", required=True, help="C 输出 JSON")
    args = ap.parse_args()

    c_dir = os.path.abspath(args.c_dir)
    # C 的 v3 包结构是 valuation/core/engine.py，按包导入才能让相对导入生效
    c_root = os.path.dirname(c_dir) if os.path.basename(c_dir) == "valuation" else c_dir
    sys.path.insert(0, c_root)
    try:
        from valuation.core.engine import run as c_run  # noqa: E402
    except ImportError:
        sys.path.insert(0, c_dir)
        from engine import run as c_run  # noqa: E402

    with open(args.input, "r", encoding="utf-8") as f:
        payload = json.load(f)
    result = c_run(payload)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
        f.write("\n")

    dcf = result.get("dcf") or {}
    rel = result.get("relative") or {}
    bl = result.get("blended") or {}
    print("[OK] C 估值 -> %s" % args.out)

    def _f(x, nd=2):
        return ("%.*f" % (nd, x)) if isinstance(x, (int, float)) and not isinstance(x, bool) else "None"

    if dcf.get("ok") and dcf.get("per_share") is not None:
        print("     DCF  每股 %s  WACC %s  g %s"
              % (_f(dcf.get("per_share")), _f(dcf.get("wacc"), 4), _f(dcf.get("terminal_growth"), 4)))
    elif dcf.get("ok"):
        print("     DCF  已算但无每股（多半缺股本 shares_outstanding）")
    else:
        print("     DCF  未产出: %s" % dcf.get("error"))
    if rel.get("ok"):
        print("     Comps 每股 %s（%d 家可比）" % (_f(rel.get("implied_per_share")), rel.get("peers_used", 0)))
    else:
        print("     Comps 未产出: %s" % rel.get("error"))
    if bl.get("ok"):
        print("     融合 每股 %s  结论 %s" % (_f(bl.get("blended_per_share")), bl.get("verdict")))
    else:
        print("     融合 未产出: %s" % bl.get("error"))
    warns = result.get("warnings") or []
    print("     警告 %d 条" % len(warns))
    return 0


if __name__ == "__main__":
    sys.exit(main())
