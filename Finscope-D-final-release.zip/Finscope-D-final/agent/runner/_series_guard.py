#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""剔掉 A 的 series 里明显不是金额的值。

为什么要有这个：A 的抽取结果里，个别公司的 series 混进了百分比。
例：格力电器 `financials.revenue.series` = {2025: 170447058533.57,
2024: 189163654064.64, 2023: -9.89} —— 2023 那个 -9.89 是同比增速，
不是营业收入。类似的还有 net_profit_attr、equity_attr、cfo。

这类值喂给 C 的估值引擎会算出复数（负数开分数次方），
`valuation/engine/methods.py` 顺手就 TypeError 崩掉。整条链断在最后一步。

判据：同一科目的多个年份里，绝对值量级与中位数差 6 个数量级以上，
判为异常，剔掉。6 个数量级是刻意放宽的——正常的同比波动不会跨这么多。

**只剔不补。** 剔掉的年份在结果里是 None，由下游按缺失处理。
绝不编造任何数值，也绝不改动 A 的原始文件。
"""
from __future__ import annotations

import math

# 量级差的阈值（数量级）。10^6 倍。
MAG_GAP = 6.0


def _log10_mag(v):
    """取绝对值量级。非数值、零、负数以外的异常一律返回 None（不参与判定）。"""
    try:
        fv = float(v)
    except (TypeError, ValueError):
        return None
    if fv == 0 or not math.isfinite(fv):
        return None
    return math.log10(abs(fv))


def scrub_series(series, key, warnings):
    """返回剔除异常值之后的新 dict。原 dict 不动。

    series   : {年份: 值}
    key      : 科目名，只用来写 warning
    warnings : 列表，命中时往里追加一条说明
    """
    if not series or len(series) < 2:
        return dict(series or {})

    mags = {}
    for y, v in series.items():
        m = _log10_mag(v)
        if m is not None:
            mags[str(y)] = m
    if len(mags) < 2:
        return dict(series)

    vals = sorted(mags.values())
    n = len(vals)
    median = vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2.0

    dropped = {}
    kept = {}
    for y, v in series.items():
        sy = str(y)
        if sy in mags and abs(mags[sy] - median) >= MAG_GAP:
            dropped[sy] = v
        else:
            kept[y] = v
    if not dropped:
        return dict(series)
    detail = "、".join("%s=%s" % (y, dropped[y]) for y in sorted(dropped))
    warnings.append(
        "[序列校验] %s 的 series 有 %d 个值和其他年份差 6 个数量级以上，已剔除：%s。"
        "疑似 A 把百分比写进了金额字段，需要回原表核对。" % (key, len(dropped), detail))
    return kept
