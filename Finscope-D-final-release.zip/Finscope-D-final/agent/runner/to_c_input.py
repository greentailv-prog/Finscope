#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""A（+ 行情缓存）-> C（估值引擎）输入。

C 要「元 + 小数 + 股 + 年份数组」的扁平结构（见 C 的 INPUT_SCHEMA.md）。
本脚本把 A 的 series 摊成逐年数组；行情类（price / shares_outstanding /
market_cap / beta）与 peers / assumptions / sources 等非财务脚手架，
取自 market 参数（通常由 server/market_data.py 按代码读 market_data/<code>.json
缓存；缓存没有则由调用方决定是否联网兜底，本模块只消费结果、不自己做 I/O）。

行情缺口的三档优先级（本函数只负责第 3 档的“留空 + 记 warning”）：
  1. 有 market           -> 用 market 的 price/shares/market_cap/beta/peers
  2. 没 market 但联网有  -> 调用方把联网结果拼成 market 传进来
  3. 都没有              -> 行情留空、peers 传空列表、warning 里写明，
                            **绝不套用别家公司（更不是茅台 demo）的股价**。

A 只抽 17 个科目，C 要的 ebit / pretax_income / tax_provision / da /
delta_nwc / total_debt / minority_interest / preferred_stock / total_equity
A 没有。默认（strict）不填这些，交给 C 的引擎默认值/空值处理——
这是「缺的科目标 not_evaluable」定案在 C 侧的落地，不编造。
--gap-fill demo 可把 A 缺的财务字段用 gap_source（对照样例）补齐，仅作对照。

只读 A 与传入的 market 文件，不跑 C 的代码。只用标准库。

用法：
    python to_c_input.py --a <A.json> [--market <行情缓存.json>] --out <c_input.json>
    python to_c_input.py --a <A.json> --online          # 缓存没有时联网兜底
    python to_c_input.py --a <A.json> --gap-fill demo --gap-source <样例.json>
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

from _series_guard import scrub_series

# C 的逐年数组字段 -> A 的科目键（按顺序取第一个有数据的；兼容旧键与 canonical 键）
ARRAY_MAP = {
    "revenue": ("revenue",),
    "cogs": ("operating_cost",),
    "net_income": ("net_profit", "net_income"),
    "capex": ("capex",),
    # 以下三项 A 的 04 统一对象有，补上后 C 不必用默认值
    "ebit": ("operating_profit", "ebit"),
    "pretax_income": ("pretax_profit", "pretax_income"),
    "tax_provision": ("income_tax_expense", "tax_provision"),
    "interest_expense": ("interest_expense",),
    "da": ("depreciation_amortization", "da"),
}

# A 的单期标量 -> C 的标量字段（取 series 最新一年）
SCALAR_MAP = {
    "total_assets": ("total_assets",),
    "cash": ("cash", "cash_and_equivalents"),
    "total_equity": ("total_equity",),
}

# 行情标量：C 的字段名 == 缓存的字段名
MARKET_SCALARS = ("price", "shares_outstanding", "market_cap", "beta",
                  "price_date", "price_source")

# A 没有、C 需要的财务字段。strict 模式不留；--gap-fill demo 时用 gap_source 补。
DEMO_FILL_ARRAY = ["ebit", "pretax_income", "tax_provision", "interest_expense",
                   "sbc", "da", "delta_nwc"]
DEMO_FILL_SCALAR = ["total_debt", "minority_interest", "preferred_stock",
                    "total_equity"]

# Comps 缺口的 warning 文案（多处引用，保持一字不差）
WARN_NO_COMPS = ("Comps 未产出：缺行情与可比公司"
                 "（缺 %s）。C 的 engine/methods.py 在没有 peers 时直接跳过"
                 "相对估值，blended 只剩下 DCF 的权重，属预期行为，不是 bug。")


def strip_year(raw):
    if raw is None:
        return None
    m = re.match(r"^(\d{4})", str(raw).strip())
    return m.group(1) if m else str(raw)


def series_of(rec, key=None, warnings=None):
    series = rec.get("series") or {}
    out = {}
    for y, v in series.items():
        if v is not None:
            out[str(y)] = v
    if not out and rec.get("status") == "found" and rec.get("value") is not None:
        y = strip_year(rec.get("period"))
        if y:
            out[y] = rec["value"]
    if key and warnings is not None:
        out = scrub_series(out, key, warnings)
    return out


def latest(series):
    """取最新一年的值（年份最大）。"""
    if not series:
        return None
    y = max(series, key=lambda s: int(s) if str(s).isdigit() else -1)
    return series[y]


def build(a_obj, market=None, gap_fill="none", gap_source=None):
    """A 抽取结果 (+ 行情缓存) -> C 输入。

    返回 (payload, sources, years, warnings)。
      market      : 行情/可比公司 dict，缺则行情留空、peers=[]、记 warning
      gap_fill    : "none" 或 "demo"
      gap_source  : gap_fill=="demo" 时的补数来源（对照样例），否则不用
    """
    warnings = []
    fin = a_obj.get("financials", {}) or {}
    a_company = a_obj.get("company", {}) or {}
    mkt = market or {}
    gap_fin = ((gap_source or {}).get("financials") or {}) if gap_fill == "demo" else {}

    # 1) 年份数组：A 所有 series 的年份并集，升序。
    #    先逐科目过一遍序列校验，剔掉混进金额字段的百分比（见 _series_guard）。
    #    只在这一处做一次，避免同一科目被反复剔、warning 重复。
    scrubbed = {}
    years_set = set()
    for a_key, rec in fin.items():
        s = series_of(rec, a_key, warnings)
        scrubbed[a_key] = s
        years_set.update(s.keys())
    years = sorted(int(y) for y in years_set)

    c_fin = {"years": years}
    sources = {}  # 字段 -> 来源标签

    def pick(candidates):
        """按候选键顺序取第一个有数据的 series。"""
        for k in candidates:
            s = scrubbed.get(k) or {}
            if s:
                return s, k
        return {}, None

    # 2) 逐年数组从 A 的 series 摊开
    for c_field, candidates in ARRAY_MAP.items():
        s, used = pick(candidates)
        c_fin[c_field] = [s.get(str(y)) for y in years]
        sources[c_field] = ("A:%s" % used) if s else None

    # 3) 资产负债表标量取 A 最新一期
    for c_field, candidates in SCALAR_MAP.items():
        s, used = pick(candidates)
        c_fin[c_field] = latest(s)
        sources[c_field] = ("A:%s" % used) if s else None

    # 3.1) 有息负债与少数股东权益：A 的 canonical 科目能拼就拼，缺项留空
    debt_keys = ("short_term_borrowings", "current_portion_lt_debt",
                 "long_term_borrowings", "bonds_payable")
    if any(scrubbed.get(k) for k in debt_keys):
        total_debt = 0.0
        complete = True
        for k in debt_keys:
            v = latest(scrubbed.get(k) or {})
            if v is None:
                # 短期/长期借款确实可能为 0，但缺失与 0 分不清；只要有一项能取就先加，
                # 并在来源标签里写明不完整，C 的可靠性评分会扣分。
                complete = False
                continue
            total_debt += v
        c_fin["total_debt"] = total_debt
        sources["total_debt"] = "A:%s%s" % ("+".join(debt_keys),
                                            "" if complete else "（部分缺项）")
    eq_total = c_fin.get("total_equity")
    eq_parent = latest(scrubbed.get("equity_parent") or {})
    if eq_total is not None and eq_parent is not None:
        c_fin["minority_interest"] = eq_total - eq_parent
        sources["minority_interest"] = "A:total_equity-equity_parent"

    # 4) 行情类：只从 market 取；market 缺就留空，绝不套用别家
    market_label = mkt.get("_source") or ("market_data" if mkt else None)
    for k in MARKET_SCALARS:
        if mkt.get(k) is not None:
            c_fin[k] = mkt[k]
            sources[k] = market_label

    # 5) A 缺的财务字段：strict 不填；gap-fill demo 时按年份对齐补上（对照用）
    if gap_fill == "demo" and gap_fin:
        for k in DEMO_FILL_ARRAY:
            vals = gap_fin.get(k)
            if isinstance(vals, list):
                dyears = gap_fin.get("years") or []
                m = {int(y): v for y, v in zip(dyears, vals)}
                c_fin[k] = [m.get(y) for y in years]
                sources[k] = "gap_source（A 无此字段）"
        for k in DEMO_FILL_SCALAR:
            if gap_fin.get(k) is not None:
                c_fin[k] = gap_fin[k]
                sources[k] = "gap_source（A 无此字段）"

    # 6) peers / 脚手架：只从 market 取；没有就传空
    peers = list(mkt.get("peers") or [])
    assumptions = dict(mkt.get("assumptions") or {})
    relative_multiples = list(mkt.get("relative_multiples") or ["pe", "ps", "pb"])
    market_sources = list(mkt.get("sources") or [])
    sources["peers"] = market_label if peers else None
    sources["assumptions"] = market_label if assumptions else None
    sources["relative_multiples"] = market_label if mkt.get("relative_multiples") else None
    sources["sources"] = market_label if market_sources else None

    # 7) Comps 缺口：没 peers（或压根没行情）就明说，不悄悄套用别家股价
    if not peers:
        missing = []
        if not any(mkt.get(k) is not None for k in ("price", "shares_outstanding",
                                                    "market_cap")):
            missing.append("行情缓存（price/shares_outstanding/market_cap）")
        missing.append("可比公司 peers")
        warnings.append(WARN_NO_COMPS % "、".join(missing))
    if not mkt:
        warnings.append("未提供任何行情：price/shares_outstanding/market_cap/beta "
                        "一律留空，peers 传空列表；未套用任何别家公司行情。")

    # 8) company：基本身份取 A，市场脚手架取 market
    company = {
        "name": a_company.get("name") or mkt.get("name"),
        "ticker": a_company.get("ticker") or mkt.get("ticker"),
        "market": mkt.get("market", "A"),
        "currency": mkt.get("currency", "CNY"),
        "industry": a_company.get("industry") or mkt.get("industry"),
        "sector": mkt.get("sector", ""),
        "report_period": mkt.get("report_period")
        or (str(years[-1]) + "-12-31" if years else ""),
        "price_date": mkt.get("price_date", ""),
    }

    payload = {
        "company": company,
        "financials": c_fin,
        "peers": peers,
        "assumptions": assumptions,
        "relative_multiples": relative_multiples,
        "sources": market_sources,
        "meta": {
            "assembled_by": "D/runner/to_c_input.py",
            "financials_from": "A（missing 字段在 strict 模式下留空）",
            "market_from": market_label or "无（行情留空、peers 传空）",
            "gap_fill": gap_fill,
            "_field_sources": sources,
            "_warnings": warnings,
        },
    }
    return payload, sources, years, warnings


def _load_market(args, a_obj):
    """按优先级给 build 备好 market：显式 --market > 按代码查缓存（可选联网）。"""
    if args.market:
        with open(args.market, "r", encoding="utf-8") as f:
            m = json.load(f)
        m.setdefault("_source", "file:%s" % os.path.basename(args.market))
        return m, []

    here = os.path.dirname(os.path.abspath(__file__))
    d_root = os.path.dirname(os.path.dirname(here))  # agent/runner -> D分支文件
    if d_root not in sys.path:
        sys.path.insert(0, d_root)
    from server import market_data  # noqa: E402

    code = (a_obj.get("company") or {}).get("ticker")
    market, src, warns = market_data.resolve(code, online=args.online)
    if market is not None:
        market["_source"] = src
    return market, warns


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description="A -> C 输入转换器")
    ap.add_argument("--a", required=True, help="A 的抽取结果 JSON")
    ap.add_argument("--market", help="行情缓存 JSON；缺省按 A 的代码查 market_data/<code>.json")
    ap.add_argument("--online", action="store_true", help="缓存没有时允许联网兜底（默认关）")
    ap.add_argument("--gap-fill", choices=["none", "demo"], default="none",
                    help="A 缺的财务字段：none 留空（默认） / demo 用样例补（对照）")
    ap.add_argument("--gap-source", help="gap-fill=demo 的补数来源 JSON")
    ap.add_argument("--out", default=os.path.join(here, "c_input.json"))
    args = ap.parse_args()

    with open(args.a, "r", encoding="utf-8") as f:
        a_obj = json.load(f)

    market, market_warns = _load_market(args, a_obj)

    gap_source = None
    if args.gap_fill == "demo" and args.gap_source:
        with open(args.gap_source, "r", encoding="utf-8") as f:
            gap_source = json.load(f)

    payload, sources, years, warnings = build(a_obj, market, args.gap_fill, gap_source)
    warnings = list(market_warns or []) + warnings

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.write("\n")

    print("[OK] A -> C 输入 -> %s  （gap_fill=%s）" % (args.out, args.gap_fill))
    print("     年份: %s" % years)
    for k, v in sources.items():
        print("       %-22s <- %s" % (k, v))
    for w in warnings:
        print("     [warning] %s" % w)
    return 0


if __name__ == "__main__":
    sys.exit(main())
