# -*- coding: utf-8 -*-
"""回归：拿 A 的统一对象跑完整链路，检查统一对象、异动、质量闸门和报告。

用法：
    python tests/regression.py --limit 3
    python tests/regression.py --limit 9 --no-report
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "agent"))
sys.path.insert(0, str(ROOT / "agent" / "runner"))

from server import config, chain_runner  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=3)
    ap.add_argument("--no-report", action="store_true")
    args = ap.parse_args()

    files = sorted(config.A_UNIFIED.glob("*.SH_*.json")) + sorted(config.A_UNIFIED.glob("*.SZ_*.json"))
    files = [p for p in files if not p.name.endswith(".run_log.json")][: args.limit]
    if not files:
        print("A unified 目录没有样本：%s" % config.A_UNIFIED)
        return 1

    tmp = ROOT / "tests" / "tmp"
    tmp.mkdir(parents=True, exist_ok=True)
    rows = []
    failed = 0
    for path in files:
        key = path.stem
        print("\n=== %s ===" % key)
        try:
            a_obj = json.loads(path.read_text(encoding="utf-8"))
            res = chain_runner.run_chain(
                a_obj,
                key=key,
                work_dir=tmp / key,
                out_path=tmp / ("%s.json" % key),
                log_path=tmp / ("%s.run_log.json" % key),
                want_report=not args.no_report,
                report_out_root=tmp / "reports",
                source_mode="regression",
            )
            s = res["summary"]
            u = res["unified"]
            checks = {
                "七键": {"company", "financials", "ratios", "risks",
                         "rules_evaluated", "valuation", "sources"} <= set(u),
                "financials>=20": len(u.get("financials") or {}) >= 20,
                "changes": bool((u.get("data_quality") or {}).get("blocked"))
                           or len(u.get("changes") or []) > 0,
                "quality": (u.get("data_quality") or {}).get("status") in ("ok", "warn", "blocked"),
                "report": True if args.no_report else (res.get("report") or {}).get("ok") is True,
            }
            ok = all(checks.values())
            failed += 0 if ok else 1
            rows.append((key, ok, s.get("quality_status"), len(u.get("changes") or []),
                         len(u.get("risks") or []), s.get("blended_per_share"),
                         (res.get("report") or {}).get("ok")))
            print("  结果：%s  quality=%s changes=%s risks=%s blended=%s report=%s"
                  % ("OK" if ok else "FAIL", s.get("quality_status"),
                     len(u.get("changes") or []), len(u.get("risks") or []),
                     s.get("blended_per_share"), (res.get("report") or {}).get("ok")))
            for k, v in checks.items():
                if not v:
                    print("    未通过：%s" % k)
        except Exception as exc:  # noqa: BLE001
            failed += 1
            rows.append((key, False, "ERROR", 0, 0, None, False))
            print("  异常：%s" % exc)

    print("\n\n%-18s %-6s %-9s %-8s %-6s %-10s %s"
          % ("key", "结果", "quality", "changes", "risks", "blended", "report"))
    for r in rows:
        print("%-18s %-6s %-9s %-8s %-6s %-10s %s" % r)
    print("\n%d 家，失败 %d 家" % (len(rows), failed))
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
