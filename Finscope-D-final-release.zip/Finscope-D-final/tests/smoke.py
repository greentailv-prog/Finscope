# -*- coding: utf-8 -*-
"""冒烟测试：不联网、不跑 B/C，只检查包结构、适配层、质量闸门、异动和报告器。"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from server import config, quality_gate  # noqa: E402
from agent.adapters.from_a import adapt_a  # noqa: E402
from agent import changes  # noqa: E402


def check(name, cond, detail=""):
    print(("  OK  " if cond else " FAIL ") + name + (("  " + detail) if detail else ""))
    return bool(cond)


def main():
    ok = True
    print("1. 路径")
    for name, p in [
        ("A src", config.A_SRC), ("A unified", config.A_UNIFIED),
        ("B compute_ratios", config.B_COMPUTE_RATIOS),
        ("B detect_risks", config.B_DETECT_RISKS),
        ("C engine", config.C_VALUATION / "core" / "engine.py"),
        ("report renderer", ROOT / "report-skill" / "scripts" / "render_memo.py"),
        ("frontend", config.WEB_DIR / "index.html"),
    ]:
        ok &= check(name, p.exists(), str(p))

    print("2. A 统一对象适配")
    sample = config.A_UNIFIED / "600519.SH_2025.json"
    if not sample.exists():
        sample = next(config.A_UNIFIED.glob("*.json"))
    obj = json.loads(sample.read_text(encoding="utf-8"))
    part = adapt_a(obj)
    ok &= check("company.ticker 有交易所后缀", str(part["company"].get("ticker") or "").count(".") == 1,
                str(part["company"].get("ticker")))
    ok &= check("financials >= 30", len(part["financials"]) >= 30, str(len(part["financials"])))
    ok &= check("sources 非空", len(part["sources"]) > 0, str(len(part["sources"])))

    print("3. 质量闸门")
    unified = {
        "company": part["company"],
        "financials": part["financials"],
        "sources": part["sources"],
        "meta": part["meta"],
    }
    q = quality_gate.evaluate(unified)
    ok &= check("status 是 ok/warn/blocked 之一",
                q["status"] in ("ok", "warn", "blocked"), q["status"])
    ok &= check("checks 非空", len(q["checks"]) > 0, str(len(q["checks"])))

    print("4. 异动分析")
    full_fixture = ROOT / "tests" / "fixtures" / "unified" / "600519.SH_2025.json"
    target = json.loads(full_fixture.read_text(encoding="utf-8")) if full_fixture.exists() else unified
    target["data_quality"] = {"status": "ok", "blocked": False}
    cs = changes.build_changes(target)
    ok &= check("异动卡非空", len(cs) > 0, "%d 张" % len(cs))
    ok &= check("异动卡字段完整", all({"id", "title", "severity", "reading", "watch"} <= set(c) for c in cs),
                "%d 张" % len(cs))
    ok &= check("没有内部代号 A/B/C/D",
                all(not any(t in (c.get("analysis") or "") + (c.get("watch") or "") for t in ("B 的", "C 的", "D 的"))
                    for c in cs))

    print("5. 前景测算")
    from agent import outlook
    o = outlook.build(target)
    ok &= check("前景测算有三情景", bool(o and o.get("rows")),
                "%s 行" % (len(o.get("rows") or []) if o else 0))
    ok &= check("前景测算有区间", bool(o and o.get("range", {}).get("low_yi") is not None))

    print("6. 报告渲染器自检")
    selftest = ROOT / "report-skill" / "scripts" / "selftest.py"
    proc = subprocess.run([sys.executable, str(selftest)], capture_output=True, text=True,
                          encoding="utf-8", errors="replace")
    ok &= check("selftest 退出码 0", proc.returncode == 0,
                (proc.stdout or proc.stderr or "").strip()[:120])

    print()
    print("通过" if ok else "有失败项")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
