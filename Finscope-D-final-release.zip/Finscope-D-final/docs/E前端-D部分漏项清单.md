# E 前端 D 部分漏项清单（对照 Final.html）

时间：2026-11-10
对照文件：`终期文件/Final.html`

## 先说结论

`Final.html` 是一个静态演示页，D 的数据基本都嵌进去了：

- 公司概览、财务诊断、同业对比、风险雷达、估值、证据、报告都有
- `changes` 有，显示在“本期异动”
- `outlook` 有，质量 `ok` 的公司显示“下一年情景测算”
- `comparison` 有，显示同业样本、分位、阈值
- `data_quality` 有，显示通过 / 提示 / 阻断

但它没有接 D 的 API，所以下面这些 D 能力在页面上是用不了的：

- 联网检索公司
- 下载年报
- 上传 PDF 并解析
- 估值滑块重算
- 任意问题问答
- Word / zip / Excel 导出
- 实时行情

这不是打包漏了文件，是 `Final.html` 本身就是静态版。E 说“不能联网查询年报”，原因就在这里：页面里没有任何 `/api/` 调用，也没有 `fetch`，搜索框只在本地 15 家公司里切换。

## P0：不接后端就没法用的功能

### 1. 联网检索与年报下载

**Final.html 现状**

- 搜索框只在 `window.FINSCOPE_COMPANIES` 的 15 家里匹配。
- 没有调用 `/api/search`、`/api/analyze`。
- 页面文案也写了“当前静态版把已完成的产物直接读进界面”。

**D 已有**

```http
GET  /api/search?q=600519&year=2025&with_report=1
POST /api/analyze  {"mode":"code","query":"600519","year":2025}
GET  /api/jobs/<id>
```

**E 要补**

- 搜索框改为调用 `/api/search`。
- 开始研究调用 `/api/analyze`，轮询 `/api/jobs/<id>`。
- 进度用 `job.percent`、`job.step`、`job.log`。

### 2. 上传 PDF 解析

**Final.html 现状**

- 上传框只做“文件校验”，页面明确写“只在本机校验，不上传、不解析”。

**D 已有**

```http
POST /api/upload?code=600519&year=2025
X-Filename: <URL 编码文件名>
Body: PDF 字节
POST /api/analyze  {"mode":"upload","upload_id":"...","code":"600519","year":2025}
```

**E 要补**

- 上传后先拿 `upload_id`，再发起 analyze。
- 上传进度和解析进度都走 `/api/jobs/<id>`。

### 3. 估值滑块与“运行估值”

**Final.html 现状**

- 页面 5 没有 `input[type=range]`。
- “运行估值”按钮是 `disabled`。
- 敏感性矩阵是静态表格，只能看，不能拖。

**D 已有**

```http
POST /api/valuation/recalc
{"key":"600519.SH_2025","wacc":0.06,"growth":0.025}
```

返回最近格点的 `per_share`、`wacc`、`growth`、`source`。

**E 要补**

- `valuation.dcf.sensitivity` 存在时，加 WACC / g 两个滑块。
- 拖动调用 `/api/valuation/recalc`，显示返回的最近格点。
- 标注“网格值”，不要写成重新建模。
- 没有 `sensitivity.matrix` 时置灰并解释，不要显示“重算失败”。

### 4. 导出

**Final.html 现状**

- 页面 5 的“导出 Excel 底稿”按钮是 `disabled`。
- 页面 6 只有“打印 / 导出 PDF”。
- 没有 Word 导出，没有报告包下载。

**D 已有**

```http
GET /api/export/<key>?format=docx
GET /api/export/<key>?format=zip
GET /api/valuation/excel/<key>
GET /api/report/<key>?format=html&style=classic|academic|business
```

**E 要补**

- Excel 按钮：有 `valuation.excel_path` 时启用，指向 `/api/valuation/excel/<key>`。
- 加“导出 Word”“下载报告包”。
- 报告中心加三套样式切换：classic / academic / business。

## P1：静态页有替代品，但没接 D 的真实能力

### 5. 问答

**Final.html 现状**

- Agent 面板只有 14 道预置题，答案靠本地检索。
- 没有调用 `/api/qa`，所以问“加权 ROE 为什么算不出”“缺输入是什么意思”“杜邦为什么没有”不会返回 D 的解释。

**D 已有**

```http
POST /api/qa
{"key":"600519.SH_2025","question":"主要风险有哪些"}
```

返回 `answer`、`facts`、`refs`、`suggested`；配置 `DEEPSEEK_API_KEY` 后走大模型，失败回退规则问答。

**E 要补**

- 输入框改成调 `/api/qa`。
- 保留 `suggested` 快捷问题。
- `answer` 按换行渲染，保留 `【标题】` 和 `•`。
- `refs[].page` 点击跳年报。

### 6. 实时行情

**Final.html 现状**

- 现价是嵌入数据里的固定值（例如茅台 1,453.00），不会刷新。

**D 已有**

```http
GET /api/quote/<code>
```

**E 要补**

- 概览和估值页的现价调用 `/api/quote/<code>`。
- 失败时用 `valuation.market_data.price`，并标 `price_date`。

### 7. 年报原文链接

**Final.html 现状**

- 证据页写“原文 PDF 未随交付包提供在线地址”“file:// 下不能自动跳到第 6 页”。

**D 已有**

```http
GET /files/reports/<文件名>#page=6
```

**E 要补**

- 后端部署后，页码改成 `/files/reports/<文件名>#page=<印刷页>`。
- 在线三表模式没有页码时显示“在线数据源”，不要拼假链接。

### 8. 报告样式

**Final.html 现状**

- 只有一套报告版式。

**D 已有**

- `?format=html&style=classic`
- `?format=html&style=academic`
- `?format=html&style=business`

**E 要补**

- 报告中心加样式切换，或者三个下载入口。

## P1：D 数据里还有内部词，E 要兜一层

`Final.html` 现在直接显示了这些：

- `cash_and_equivalents`
- `depreciation_amortization`
- `accounts_receivable`
- `P0 科目已取到`
- `cash_flow_bridge`
- `向 C 明确`
- `risk_id` / “编号 C01”

D 正在把这些改成中文（货币资金、折旧与摊销、应收账款、核心科目、现金流桥、估值时注意）。E 侧也建议加一层兜底：

```js
function human(text) {
  return String(text || '')
    .replace(/cash_and_equivalents/g, '货币资金')
    .replace(/depreciation_amortization/g, '折旧与摊销')
    .replace(/accounts_receivable/g, '应收账款')
    .replace(/cash_flow_bridge/g, '现金流桥')
    .replace(/向 C 明确/g, '估值时注意')
    .replace(/P0/g, '核心科目');
}
```

报告表格里的“权重 数据缺失”建议统一改成 `-`；“编号 C01”这类内部规则编号建议隐藏，只保留等级、风险名、评分。

## P2：可以不改，但要知道

### 9. 异动分析没有独立入口

`changes` 现在放在“公司概览”的“本期异动”和报告第③节里，没有单独的导航页。功能没丢，只是入口合并了。如果答辩要单独讲异动分析，可以加一个“异动分析”导航，或者保留现在的位置。

### 10. 同业对比的可比性提示

页面 3 显示“可比性：弱，行业剖面未识别（general）”。这是 B 的行业剖面识别结果，不是 D 漏数据。E 不要自己改结论，只展示。

### 11. 估值页“缺少股价/股本”的提示不准确

600519 的 `valuation.market_data` 里有 `price=1453`、`shares_outstanding=1250081601`，不是缺股价/股本。融合结论为空是因为 C 的数据复核没有给出权重，页面应显示：

```text
融合结论未给出，参考区间 650.57–3,319.83 元/股
```

不要写“缺少股价/股本”。

## 建议 E 的优先级

1. 先接 `/api/search`、`/api/analyze`、`/api/jobs`，让联网检索和上传能跑。
2. 再接 `/api/valuation/recalc` 和三个导出接口。
3. 再接 `/api/qa`，替换 14 道预置题。
4. 最后统一文案：内部字段、`数据缺失`、`risk_id`。

## 如果 E 没有 Python

`Final.html` 静态版可以继续做 UI 演示，但联网检索、上传解析、估值重算、问答、导出都需要后端。两个办法：

- 用老师服务器部署后的网址，E 只调 `/api/*`。
- 或者把 `Finscope-D-final-release.zip` 给 E，本机起 `python server/app.py`。

没有后端时，不要把这些按钮做成可点击但报错；直接标注“需本地服务”，比假装能用好。
