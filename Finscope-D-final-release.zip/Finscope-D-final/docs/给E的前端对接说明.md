# 给 E 的前端对接说明

写给：E（前端负责人）
更新时间：2026-11-08
服务地址：`http://127.0.0.1:8790`
完整接口清单：`docs/接口说明.md`（这份文档更偏前端落地）

## 目录

1. D 已经交付了什么
2. 本地启动与样例
3. 页面信息架构（输入、进度、概览、异动、指标、同业、风险、估值、证据、报告、问答）
4. API 速查
5. 统一对象字段速查
6. 展示规则（单位、同比、缺失、禁用词）
7. 状态与异常
8. 验收清单
9. 已知限制
10. 前端可以复用的文件

## 0. 一句话

D 已经把 A 的抽取、B 的指标与风险、C 的估值串成一条链，统一输出一个 JSON 对象和一份报告。E 不需要读 PDF、不需要算指标、不需要调 B/C 的代码，只需要调用 D 的 API 并渲染结果。

## 1. D 已经交付了什么

### 1.1 数据输入

- 输入股票代码或公司简称，联网到巨潮检索、定位年报、下载 PDF、建立页码索引、抽取数据。
- 用户上传 PDF，文件名建议 `公司名_代码_年份.pdf`，可以自动解析代码和年份。
- PDF 失败时回退东方财富年度三表，页面和报告会标“无页码”。
- 已经分析过的公司直接读缓存，前端传 `force=true` 才重跑。

### 1.2 分析链路

```text
A 抽数
→ D 数据常识校验（单位、跨年错位、两年突变）
→ B 指标与风险（含同业动态阈值）
→ C 估值（DCF / 相对估值 / DDM / 情景 / 敏感性）
→ D 质量闸门、异动分析、前景测算
→ D 统一对象 + 报告
```

### 1.3 输出

- 统一对象：`/api/unified/<key>`
- 报告：Markdown / HTML / JSON / CSV
- 导出：Word（docx）、报告包（zip）、估值 Excel 底稿
- 问答：规则问答；配置 `DEEPSEEK_API_KEY` 后自动改走大模型
- 行情：东方财富实时价，失败保留缓存
- 本地启动：`start.bat`，端口 8790

## 2. 本地启动与样例

```bash
# Windows
start.bat

# 或
python -X utf8 server/app.py
```

打开 `http://127.0.0.1:8790/`。

已经跑过的样例（`/api/history` 能看到）：

```text
600519.SH_2025  贵州茅台
000333.SZ_2025  美的集团
000651.SZ_2025  格力电器
000858.SZ_2025  五粮液
002415.SZ_2025  海康威视
002594.SZ_2025  比亚迪
002709.SZ_2025  天赐材料
300750.SZ_2025  宁德时代
600031.SH_2025  三一重工
600309.SH_2025  万华化学
600887.SH_2025  伊利股份
600900.SH_2025  长江电力
600660.SH_2024  福耀玻璃（数据阻断，用来演示异常状态）
600660.SH_2025  福耀玻璃
```

## 3. 页面信息架构

建议按下面 7 个区域 + 右侧问答来做。现有 `web/index.html` 已经是这个结构，可以直接参考。

### 3.1 输入区

- 股票代码/简称输入框
- 年份下拉框：最近一期、2026–2020
- 开始分析
- 刷新结果
- 强制重跑
- 上传年报 PDF（拖拽或选择文件）
- 上传后显示文件名解析结果：公司名、代码、年份

### 3.2 六步进度

后端 `job.step` 的取值和页面文案：

| step | 页面文案 |
| --- | --- |
| `resolve` | 检索公司 |
| `download` | 下载年报 |
| `pagemap` | 建立页码索引 |
| `indicators` | 抽取财务数据 |
| `b_ratios` | 计算财务指标 |
| `b_risks` | 检查风险 |
| `c_engine` | 估值 |
| `adapt` | 生成报告 |

`job.percent` 是 0–100，`job.log` 是字符串数组。日志里可能有命令、路径、内部步骤名，前端只展示面向用户的行，不要把 `$`、`.py`、`F:\`、`modules\` 这类内容直接显示。

### 3.3 公司概览

数据来自 `company`、`financials`、`data_quality`、`valuation.blended`、`valuation.reference`。

建议卡片：

- 营业收入
- 归母净利润
- 毛利率
- 加权 ROE
- 经营现金流
- 资产负债率
- 融合每股价值 / 估值区间
- 现价与空间

重要数字加粗、用绿色；缺失显示 `-`。

### 3.4 异动分析

数据来自 `changes[]`。

每张卡展示：

- 严重度标签：`critical` → 重大，`warning` → 关注，`info` → 提示
- 维度：成长 / 盈利 / 现金流 / 营运 / 偿债 / 估值 / 风险
- 标题
- 读数 `reading`
- 可能原因 `analysis`（默认折叠）
- 下一期关注 `watch`
- 置信度 `confidence`
- 原文页码 `evidence.page` / `evidence.pdf_page`

### 3.5 财务诊断

数据来自 `ratios`，六组：

```text
growth              成长
profitability       盈利
solvency            偿债
efficiency          营运
cashflow_quality    现金流
banking             银行（只有银行股才有内容）
```

每条指标展示：

- `label` 中文名
- `value` 本期值
- `prev` 上期值
- `delta` 变动
- `status` 状态
- `page` 页码

建议每组最多展示 9 条，其余折叠。

### 3.6 同业对比

数据来自 `comparison`。

- `comparison.status`：`ok` / `partial` / `not_available`
- `comparison.peer_set[]`：可比公司
- `comparison.metrics[]`：目标值、同业 P25 / 中位数 / P75、样本数
- `comparison.risk_matrix[]`：风险矩阵
- `comparison.thresholds{}`：动态阈值
- `comparison.multiples{}`：估值倍数

样本少于 3 家时只展示数值，不要下“显著高于/低于同业”的结论。`not_available` 时显示“暂无同业样本，风险阈值回退固定值”。

D 的 peer 来源顺序：先读 `market_data/<code>.json` 的手工名单，没有时按行业关键词从 C 的行业可比池兜底；联网模式会逐家取同业年度三表。离线且本地没有同业财务快照时，仍可能 `not_available`。

### 3.7 风险雷达

数据来自 `risks[]` 和 `rules_evaluated[]`。

风险卡展示：

- `severity_tag`：重大 / 关注 / 提示
- `risk_name`
- `category`
- `score`
- `trigger`
- 阈值文案由前端用 `threshold_value`、`threshold_source`、`peer_sample_n` 拼（统一对象里没有 `threshold_str` 字段）
- `involved_values[]`：涉及指标、数值、单位、页码
- `explanation`
- `suggested_action`
- `text_evidence.page`：点“原文”跳到年报页

不要在页面上显示 `risk_id`、`rule_id`、`_trigger_expr`。

阈值来源的显示：

| 值 | 显示 |
| --- | --- |
| `fixed` | 固定阈值 |
| `fixed_fallback` | 样本不足，回退固定阈值 |
| `peer_p25` / `peer_p75` | 同业下/上四分位 |
| `peer_median` | 同业中位数 |
| `industry_*` | 行业基准 |

### 3.8 估值实验室

数据来自 `valuation`。

- `valuation.status`：`ok` / `partial` / `unsupported`
- `valuation.industry_support`：`full` / `limited`
- `valuation.gate_reason`：银行等特殊行业的原因
- `valuation.dcf`：DCF 每股、WACC、永续增长、预测表、敏感性
- `valuation.comps`：相对估值每股、可比公司、倍数
- `valuation.ddm`：银行/保险/证券适用
- `valuation.blended`：融合每股价值、现价、空间、判断
- `valuation.reference`：融合结论不可用时的参考区间
- `valuation.scenarios`：三情景
- `valuation.excel_path`：Excel 底稿是否存在

滑块：

- 只有 `valuation.dcf.sensitivity.matrix` 存在时才可拖动
- 拖动调用 `POST /api/valuation/recalc`，返回最近格点
- 页面必须标注“网格值”，不能写成重新建模
- 没有敏感性矩阵时，滑块置灰并解释“该标的只采用相对估值/DDM，或缺少行情”，不要显示“重算失败”

### 3.9 年报证据

数据来自 `sources[]` 和 `financials` 每条记录的 `page` / `pdf_page`。

- 有页码时，点页码打开 `/files/reports/<文件名>#page=<印刷页>`
- 在线三表模式没有印刷页码，显示“在线数据源”
- 不要在前端拼 PDF 路径，后端已经做好目录穿越防护

### 3.10 投研报告

- 预览：`GET /api/report/<key>?format=html&style=classic`
- 三种样式：`classic` / `academic` / `business`
- Markdown：`GET /api/report/<key>?format=md`
- 报告 JSON：`GET /api/report/<key>?format=json`
- Word：`GET /api/export/<key>?format=docx`
- 报告包：`GET /api/export/<key>?format=zip`
- 估值 Excel：`GET /api/valuation/excel/<key>`，只有 `valuation.excel_path` 存在时显示按钮

### 3.11 右侧问答

`POST /api/qa`

```json
{"key":"600519.SH_2025","question":"毛利率为什么下降"}
```

展示：

- `answer`：按换行渲染，保留 `【标题】` 和 `•` 分点
- `facts[]`：小卡片，显示 label / value / page
- `refs[]`：页码可点
- `suggested[]`：快捷问题
- `disclaimer`：底部免责声明

不要把 `engine`、`intent`、内部字段名显示给用户。

## 4. API 速查

### 4.1 搜索

```http
GET /api/search?q=600519&year=2025&with_report=1
```

普通搜索不访问公告接口；`with_report=1` 才定位年报。

### 4.2 发起分析

```http
POST /api/analyze
Content-Type: application/json

{"mode":"code","query":"600519","year":2025}
{"mode":"upload","upload_id":"...","code":"600519","year":2025}
{"mode":"existing","code":"600519","year":2025}
```

返回 202：

```json
{"ok":true,"job_id":"...","job":{"status":"queued","percent":0,"step":"resolve"}}
```

有缓存时直接返回：

```json
{"ok":true,"cached":true,"key":"600519.SH_2025","unified_url":"/api/unified/600519.SH_2025"}
```

要强制重跑，传 `"force": true`。

### 4.3 任务

```http
GET  /api/jobs/<id>
POST /api/jobs/<id>/cancel
GET  /api/jobs
```

轮询 `GET /api/jobs/<id>`，直到 `status` 是 `done` / `error` / `cancelled`。

### 4.4 上传

```http
POST /api/upload?code=600519&year=2025
X-Filename: <URL 编码后的文件名>
Body: PDF 原始字节
```

返回 `upload_id`。

### 4.5 统一对象

```http
GET /api/unified/<key>
```

### 4.6 报告与导出

| 路径 | 用途 |
| --- | --- |
| `/api/report/<key>?format=md` | Markdown |
| `/api/report/<key>?format=html` | HTML，可直接 iframe |
| `/api/report/<key>?format=html&style=academic` | 学术风 |
| `/api/report/<key>?format=html&style=business` | 商务风 |
| `/api/report/<key>?format=json` | 带数字溯源 |
| `/api/report/<key>?format=csv` | 指标表 |
| `/api/export/<key>?format=docx` | Word |
| `/api/export/<key>?format=zip` | 报告包 |
| `/api/valuation/excel/<key>` | 估值 Excel |

### 4.7 问答

```http
POST /api/qa
Content-Type: application/json

{"key":"600519.SH_2025","question":"主要风险有哪些"}
```

### 4.8 估值滑块

```http
POST /api/valuation/recalc
Content-Type: application/json

{"key":"600519.SH_2025","wacc":0.06,"growth":0.025}
```

返回最近格点的 `per_share`、`wacc`、`growth`、`source`。这是网格取值，不是重新建模。

### 4.9 历史、行情、PDF

```http
GET /api/history
GET /api/quote/<code>
GET /files/reports/<文件名>#page=6
```

## 5. 统一对象字段速查

下面是为了说明字段结构截取的示例，数字不代表某家公司的真实值；真实值以 `/api/unified/<key>` 为准。

完整示例见 `/api/unified/600519.SH_2025`。

### 5.1 company

```json
{
  "name": "贵州茅台",
  "ticker": "600519.SH",
  "industry": "食品饮料-白酒",
  "report_period": "2025",
  "exchange": "上海证券交易所",
  "report_type": "年度报告",
  "currency": "CNY",
  "amount_unit": "元",
  "scope": "合并报表",
  "source_url": "..."
}
```

### 5.2 financials

```json
{
  "revenue": {
    "value": 168838102514.79,
    "unit": "元",
    "period": "2025",
    "prior_value": 150000000000.0,
    "prior_period": "2024",
    "series": {"2023": 0, "2024": 0, "2025": 0},
    "page": 6,
    "pdf_page": 6,
    "source_id": "S02",
    "raw_text": "...",
    "status": "found",
    "status_note": null,
    "unit_corrected": false
  }
}
```

E 只读 `value` / `prior_value` / `series` / `status` / `page`，不要重新算财务指标。

### 5.3 ratios

```json
{
  "gross_margin": {
    "value": 0.9118,
    "unit": "小数",
    "label": "毛利率",
    "prev": 0.9182,
    "delta": -0.0064,
    "status": "ok",
    "page": 61,
    "inputs": {"revenue": 0, "cost_of_revenue": 0}
  }
}
```

`status` 可能的值：

| status | 页面显示 |
| --- | --- |
| `ok` | 正常 |
| `not_evaluable` | 未取到 |
| `not_applicable` | 不适用 |
| `not_found` | 未找到 |
| `not_meaningful` | 口径不适用 |

### 5.4 risks

```json
{
  "risk_name": "净现比偏低",
  "severity": "high",
  "severity_tag": "重大",
  "score": 85,
  "category": "盈利质量",
  "trigger": "经营现金流 / 归母净利润 < 0.8",
  "threshold_value": 0.8,
  "threshold_source": "fixed",
  "peer_sample_n": 0,
  "involved_values": [
    {"metric": "cfo_to_net_income", "label": "净现比", "value": 0.75,
     "unit": "倍", "page": 6}
  ],
  "numeric_evidence": "...",
  "explanation": "...",
  "suggested_action": "...",
  "text_evidence": {"page": 6, "pages": [6], "sources": []}
}
```

### 5.5 changes

```json
{
  "id": "CH01",
  "dimension": "现金流",
  "title": "利润的现金含量下降",
  "severity": "warning",
  "severity_tag": "关注",
  "direction": "down",
  "metric": "cfo_to_net_income",
  "metric_label": "净现比",
  "value": 0.7474,
  "prior_value": 1.0723,
  "delta": -0.3249,
  "unit": "倍",
  "period": "2025",
  "prior_period": "2024",
  "evidence": {"page": 6, "pdf_page": 6, "source_id": "S12", "raw_text": "..."},
  "reading": "...",
  "analysis": "...",
  "watch": "...",
  "linked_risks": ["C01"],
  "confidence": "高"
}
```

### 5.6 valuation

```json
{
  "status": "ok",
  "industry_support": "full",
  "gate_reason": null,
  "dcf": {
    "ok": true,
    "per_share": 59.42,
    "wacc": 0.0469,
    "terminal_growth": 0.025,
    "sensitivity": {
      "wacc_values": [0.0369, 0.0419, 0.0469, 0.0519, 0.0569],
      "terminal_growth_values": [0.015, 0.02, 0.025, 0.03, 0.035],
      "matrix": [[...], [...]],
      "base_wacc": 0.0469,
      "base_growth": 0.025
    }
  },
  "comps": {"implied_per_share": 18.31, "peers_used": 4},
  "blended": {
    "blended_per_share": 18.31,
    "current_price": 29.91,
    "upside": -0.3877,
    "verdict": "显著高估"
  },
  "excel_path": "...",
  "excel_format": "...",
  "excel_generated_at": "..."
}
```

`blended` 为空时用 `valuation.reference`：

```json
{"low": 18.0, "high": 22.0, "methods": [{"method": "DCF", "per_share": 20.0}]}
```

### 5.7 comparison

```json
{
  "status": "partial",
  "peer_set": [{"ticker": "000858.SZ", "name": "五粮液"}],
  "metrics": [
    {"metric": "gross_margin", "label": "毛利率",
     "target": 0.91, "peer_p25": 0.8, "peer_median": 0.85, "peer_p75": 0.9,
     "sample_n": 1}
  ],
  "risk_matrix": [],
  "thresholds": {},
  "multiples": {}
}
```

### 5.8 data_quality

```json
{
  "status": "warn",
  "blocked": false,
  "block_reasons": [],
  "warn_reasons": ["..."],
  "counts": {"pass": 21, "warn": 4, "block": 0},
  "checks": [
    {"code": "PERIOD_CONSISTENCY", "status": "pass", "detail": "..."}
  ]
}
```

- `blocked=true`：页面顶部显示阻断原因，隐藏估值结论和前景测算
- `warn`：可以展示，但估值结论要带“仅作参考”
- 数据体检明细默认折叠

### 5.9 sources / meta / coverage

- `sources[]`：页码、文件名、来源链接、检索时间
- `meta`：`key`、`source_mode`、`report_period`、`years`、`pdf_url`
- `coverage`：核心科目覆盖情况

### 5.10 outlook

只有 `data_quality.status === "ok"` 时才有内容；否则是 `{}`。

```json
{
  "next_year": "2026",
  "rows": [{"label": "乐观", "growth": 0.08, "revenue_yi": 1828.35,
            "net_margin": 0.51, "net_income_yi": 940.46}],
  "base": {...},
  "range": {"low_yi": 836.54, "high_yi": 940.46},
  "commentary": "...",
  "confidence": "中",
  "disclaimer": "情景测算，不是公司指引，不构成投资建议。"
}
```

## 6. 展示规则

### 6.1 单位

| 数据 | 单位 | 展示 |
| --- | --- | --- |
| `financials.value` | 元 | 亿元，两位小数 |
| `ratios.unit=小数` | 小数 | 百分比，两位小数 |
| `ratios.unit=倍` | 倍 | 两位小数 + “倍” |
| `ratios.unit=次` | 次 | 两位小数 + “次” |
| `ratios.unit=天` | 天 | 两位小数 + “天” |
| `ratios.unit=元` | 元 | 亿元或万元 |

变动：

- 小数：`+2.53 个百分点`
- 元：`-96.32 亿元`
- 倍/次/天：`+0.01 倍` / `+0.00 次` / `-1.20 天`

### 6.2 同比

不要只写“同比 16.65%”，要写：

```text
同比增长 16.65%
同比下降 4.53%
```

### 6.3 缺失

统一显示 `-`，不要写“数据缺失”“待核验”“N/A”。

状态标签用“未取到 / 不适用 / 未找到 / 口径不适用”，并在 `title` 里写原因。

### 6.4 不要出现的东西

页面上不要出现：

- `A/B/C/D` 这类模块代号
- `net_income_parent`、`cfo_to_net_income`、`roic_minus_wacc` 这类字段名
- `D_SANITY`、`row_present_without_value`、`not_evaluable` 这类内部状态
- `risk_id`、`rule_id`
- 脚本名、命令行、绝对路径

### 6.5 不要在前端算数

- 不要用 PDF 原文重算指标
- 不要自己算估值
- 不要自己判断风险
- 不要自己补缺失值

前端只做格式化、排序、折叠、跳转。

## 7. 状态与异常

### 7.1 任务状态

| status | 页面 |
| --- | --- |
| `queued` | 排队中 |
| `running` | 按 `percent` 和 `step_label` 展示进度 |
| `done` | 读 `result.key`，加载统一对象 |
| `error` | 显示 `error`，提供重试 |
| `cancelled` | 显示“已取消” |

### 7.2 数据阻断

`data_quality.blocked === true`：

- 顶部黄色/红色提示
- 显示 `block_reasons`
- 隐藏估值结论、前景测算
- 异动卡可以展示，但不要写“低估/高估”

### 7.3 没有估值

- `valuation.blended` 为空：展示 `valuation.reference` 区间
- 两者都为空：显示“当前数据不足，未给出估值结论”
- 不要显示“估值失败”

### 7.4 没有敏感性网格

- 滑块置灰
- 文案：“该标的没有 DCF 敏感性网格，通常因为只采用相对估值/DDM，或缺少行情；滑块不参与计算。”
- 不要显示“重算失败”

### 7.5 没有同业

`comparison.status === "not_available"`：

- 显示“暂无同业样本”
- 风险阈值显示“固定阈值”或“样本不足，回退固定阈值”

### 7.6 没有行情

- `valuation.blended.current_price` 为空
- 不显示“空间”
- 显示“行情未取到，估值结论仅作区间参考”

## 8. 验收清单

按下面顺序走一遍：

1. 打开首页，历史里点贵州茅台，秒开。
2. 看概览 KPI，数字加粗，单位正确。
3. 看异动卡，展开一张，能看到原因、关注点、页码。
4. 看财务诊断，六组指标；缺项显示“未取到”+ 原因。
5. 看风险雷达，阈值来源显示“固定阈值/同业 P75/中位数”。
6. 看估值实验室，拖 WACC 和 g，显示“网格值”。
7. 右侧问“主要风险有哪些”，回答分点，页码可点。
8. 右侧问“加权 ROE 为什么算不出”，回答列出缺的科目。
9. 报告中心切换学术风/商务风，导出 Word。
10. 输入一个新代码，看六步进度，跑完后自动加载。
11. 上传一个 PDF，看文件名解析和进度。
12. 找一个 `data_quality.blocked` 的样例（600660 2024），确认不显示估值结论。

## 9. 已知限制

- **600900 长江电力**：A 只抽到 2025 和 2023 两期归母净资产，缺 2024，加权 ROE 和杜邦分解显示“未取到”。问答会解释缺哪一项。
- **600660 福耀玻璃 2024**：资产负债勾稽差 16.2%，`data_quality.blocked=true`，报告不给估值结论。这是上游数据问题，不是前端。
- **600660 2025**：短期借款/长期借款被 A 抽成正文里的百分比，D 已标“未取到”并剔除，相关指标为空。
- **同业对比**：本机代理不通时在线同业取不到，`comparison.status=not_available`，风险阈值回退固定值，不报错。
- **大模型问答**：本地默认走规则问答；配置 `DEEPSEEK_API_KEY` 后自动走 DeepSeek，失败回退规则问答。
- **老师接口**：如果老师给的是固定 endpoint/schema，需要在 `server/routes.py` 外层做映射，前端接口不变。

## 10. 前端可以复用的文件

- `web/index.html`：现有工作台，可以直接改样式
- `web/`：静态资源
- `output/unified/*.json`：样例统一对象
- `output/reports/*/memo.html`：样例报告
- `docs/接口说明.md`：完整接口
- `docs/交付状态.md`：D 侧改动记录

有字段对不上，先看 `/api/unified/600519.SH_2025` 的真实返回，不要猜。
