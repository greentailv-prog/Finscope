# 给 B 的三点确认

D 的最终口径，按这个改，不用再猜。

## ① threshold_source

D 全部接收，不校验、不改写。枚举：

| 值 | 含义 | D 显示 |
| --- | --- | --- |
| `fixed` | 固定阈值 | 固定阈值 |
| `fixed_fallback` | 样本不足，回退固定阈值 | 样本不足，回退固定阈值 |
| `peer_p25` | 同业下四分位 | 同业 P25 |
| `peer_p75` | 同业上四分位 | 同业 P75 |
| `peer_median` | 同业中位数 | 同业中位数 |
| `industry_median` / `industry_p25` / `industry_p75` / `industry_p10` / `industry_p90` | 离线行业基准 | 行业基准·对应分位 |

**结论：`peer_median` 收。** B06 净息差按中位数判，就写 `peer_median`；
如果 B06 用的是离线行业池而不是当次同业，写 `industry_median`，D 也收。
其他 5 条动态规则仍按规范用 `peer_p25` / `peer_p75`，不要为了统一而改口径。

`peer_sample_n` 填本次实际参与分位的样本数。固定阈值写 0。

## ② peer_financials 与 comparison

**D 实际传 `peer_financials`。** 位置：`b_input.json` 顶层，与 `company` / `financials` 平级。

```json
{
  "schema_version": "finradar.extraction/1.0",
  "meta": {"periods": ["2023", "2024", "2025"], "default_unit": "元"},
  "company": {"name": "贵州茅台酒股份有限公司", "ticker": "600519.SH"},
  "financials": {
    "revenue": {"2025": {"value": 168838102514.79, "unit": "元", "page": 6}}
  },
  "peer_financials": [
    {
      "company": {"name": "宜宾五粮液股份有限公司", "ticker": "000858.SZ", "industry": "白酒"},
      "financials": {
        "revenue": {"2025": {"value": 89175178322.7, "unit": "元", "page": 12}}
      }
    }
  ]
}
```

规则：

1. `peer_financials` 是数组，一家一条；结构与目标 `financials` 完全一样：
   `指标 → 期间 → {value, unit, source, page}`。
2. 只放当期需要的 3 年，不把同业全部原文塞进来。
3. 没有同业就是空数组 `[]`，B 回退固定阈值，不要报错。
4. D 另外落一份 `peer_financials.json` 在任务工作目录，方便追溯；B 读 `b_input.json` 里的即可。

**comparison 放统一对象顶层，不放进 `valuation`。**

- 链路中间 B 输出一份 `comparison.json`（单独文件），D 原样合并到统一对象的 `comparison`。
- 最终统一对象：`company / financials / ratios / risks / rules_evaluated / valuation / sources / comparison`
- `comparison.multiples` 由 D 在 C 跑完后补，B 不碰。
- `comparison.peer_set` 的 ticker 要和 C 的 `valuation.comps.peer_companies` 对得上；
  名单由 C/D 给，B 只回显。

## ③ 子进程还是服务

**B 不起服务，D 用子进程调。** 工作台、任务队列、进度都在 D；B 只提供 CLI 和 JSON。

D 的实际调用顺序：

```text
1. D 写 b_input.json（含 peer_financials）
2. python compute_ratios.py -i b_input.json -o b_ratios.json --pretty
3. D 给每个 peer 写 peer_inputs/<ticker>.json
4. python compute_ratios.py -i peer_inputs/<ticker>.json -o peer_ratios/<ticker>.json --pretty
5. python build_comparison.py --target b_ratios.json --peers peer_ratios --out comparison.json --allow-cross-industry
6. python detect_risks.py --ratios b_ratios.json --rules risk_rules.json --comparison comparison.json -o b_risks.json --pretty
```

- **代码 → JSON 是 D 做**：`agent/runner/to_b_input.py`。B 不读 PDF、不读 A 的原始输出。
- **同业名单**：优先用行情缓存里的 `peers`；D 用 A 的统一对象补财务，A 没有的再联网取。
- **分位与 comparison 是 B 做**：D 不重算分位，只跑你的 `build_comparison.py`。
- **比较基准写死**：`--target` 是目标公司 ratios，`--peers` 是目录；D 已经按这个传。
- 需要 B 加的唯一入口是：`build_comparison.py` 接受目录（现在已支持），
  以及 `detect_risks.py` 接受 `--comparison`（现在已支持）。不需要新服务。

## from_b.py 透传

D 已经改好，B 按原字段输出即可：

| B 字段 | D 落点 | 用途 |
| --- | --- | --- |
| `name` | `ratios.<组>.<键>.name` | 指标中文名 |
| `role` | 同上 `.role` | core / diagnostic |
| `source_fields` | 同上 `.source_fields` | 指标展开时显示来源科目 |
| `source_pages` | 同上 `.source_pages` | 指标展开时显示页码 |
| `threshold_value` | `risks[]` / `rules_evaluated[]` 同名 | 实际阈值 |
| `threshold_source` | 同上 | 固定/同业分位/中位数 |
| `peer_sample_n` | 同上 | 样本数 |

D 不覆盖 B 的 `name`，只补一个 `label`（优先用 `name`，没有才查 B 的 `metric_labels.json`）。
