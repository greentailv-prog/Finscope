> **FinScope C v3.1 审慎估值修订优先级提示（2026-11-04）**：本文部分旧版 v2/v3 规则已失效，尤其包括“无同业使用板块代理”“默认 Gordon 与退出倍数取中点”“市场隐含 WACC 默认校准”“缺分部构造单一整体业务”“总部费用按收入 2%×8 倍默认扣减”。上述规则不得再作为上线依据。请优先遵循工程根目录的《估值后端v3_1_审计修订与联调手册.md》及当前代码与测试。原文作为历史基线保留，不代表当期执行规则。

---
name: finscope-valuation-lab-v3
version: 3.0
owner: FinScope C 模块
purpose: 将统一年报财务对象转换为可追溯的 DCF、Comps、SOTP、DDM 估值与可解释图表/Excel 底稿
---

# FinScope C v3 估值 Agent Skill

## 角色与输入边界

本 Skill 用于已装入 FinScope C v3 的 AI 代理与实现负责人，不可凭外部通用知识补造企业实际经营数据。对于 A 股上市公司，优先接受 D 统一对象 `company / financials / ratios / comparison / market_data / sources / data_quality`，这些字段由 A、B、D 等模块填充；C 只能调整估值未来假设与估值方法。若 C 独立调试，允许使用 C 内置的公开行情与年报取数，但必须记录来源与日期，并且将结果标识为开发/演示模式。

## 典型触发场景

- 用户选择综合估值、DCF、Comps、SOTP 或金融行业 DDM。
- 用户询问“为什么选择这些可比公司？”、“可以把五粮液替换成洋河吗？”
- 用户改变 WACC、永续增长率、收入增速、EBIT 利润率、CAPEX 或营运资本假设。
- 用户询问为什么各方法估值出现分歧，或股价相对内在价值的空间及不确定性。
- 用户请求导出带历史财务与预测公式的估值 Excel 底稿。

## 每次处理的标准工作流

1. **锁定标的与口径**。识别六位股票代码/公司名、交易所、最近有效年报、报告期、币种、合并/母公司口径、现价日期。已有 D 统一对象时永远不用 C 内置源重新覆盖。
2. **检查财务证据链**。历史收入、EBIT、CFO、CAPEX、折旧摊销、现金、债务、股本和来源元数据逐条审查；缺失字段标识，不把 null 当零。只有 3 年历史不能强制显示 5 年真实数据。
3. **检查行业门槛**。普通工业企业适用 FCFF DCF、Comps、SOTP（如有分部）；银行/保险/券商应使用 DDM/RI 与 PE/PB Comps，不能不加说明硬用 WACC-DCF；地产等行业以 rules 的 gate 为准。
4. **列出并确认假设**。按 `core/assumptions.py` 规则产生收入增长、税率、EBIT 利润率、CAPEX/Revenue、D&A/Revenue、ΔNWC/Revenue、WACC/g；每项要列来源、适用期和信心，不要把估算写为审计原值。
5. **选择同业并解释可比性**。先行业、经营模式、规模，后成长/利润率/会计口径；展示同业具体代码及 `selection_reason`、评分与不足、所用倍数。不能用股价或表观 PE 相似作为唯一选择依据。
6. **计算模型**。五年收入→EBIT→NOPAT→FCFF→EV/Equity；Comps 倍数与折价；SOTP 分部 EV 桥；必要时 DDM/RI。输出预测五年表和历史已观测率与未来假设率的图。
7. **交叉验证**。核查 WACC≤g、终值占比过高、CAPM/隐含 WACC 差异、方法间分歧、同业过少/异常倍数、SOTP 收入覆盖、财务数据质量阻断；选择区间或适当降级，不做机械平均。
8. **撰写分析**。每段以观点句开头，再列实测数值和假设，最后解释为何影响估值与不确定性。按照“结论→数据→原因→适用边界”的形式，避免仅堆数字或重复产品说明。
9. **可视化与导出**。历史/预测图数据直接使用 `history` / `dcf.rows` / `presentation.charts`；悬停显示年度、单位、实际或预测和来源；Excel 公式引用参数表、历史来源表、预测表与估值表。首次运行或修改假设后先刷新后端估值结果，用户点击导出才基于同一次会话的已保存结果生成 Excel；不做第二次取数。
10. **Agent 回答与更改**。若用户仅询问，不修改参数或可比；用户明确要求“调到/更换/增加”时先将意图映射为 `assumptions`、`peer_set`，调用 `/session/{id}/recalculate`，再引用本次结果解释变化。严禁让 LLM 口头宣称“已调整”却未实际运行代码。

## 重要公式与单位

- 历史财报存储单位为元，前端展示/Excel 统一转换到亿元；每股价值单位元，股本为股或亿股须一致。
- `FCFF = EBIT×(1−税率) + D&A − CAPEX − ΔNWC`。
- `WACC = Ke×E/(D+E)+Kd×(1−T)×D/(D+E)`，其中 Ke 通常以 CAPM 为基础，若有市场校准必须单列。
- `PV(Fn)=Fn/(1+WACC)^(n−0.5)`；`TVg=FCFF_last×(1+g)/(WACC−g)`，终值折现指数取模型实现规则。
- `EquityValue=EV + Cash − Debt − MinorityInterest − PreferredStock`；每股除以总股本。
- Comps 至少区分 PE、EV/EBITDA、PB、PS 的适用条件，不能把企业价值倍数直接乘股东利润。

## 前端交互与排版要求

- 页面分为“研究任务/标的”“方法选择”“假设设定台”“方法结果”“可比详情”“DCF 历史+未来”“历史率与预测率”“SOTP”“敏感性”“三情景”“风险核验”以及固定右侧 Chat。
- 两列分析卡在同一行**等高并对齐**；不能出现 10px 以下主要数据字或低对比度灰字。
- 图表 tooltip 为深蓝浮层、白色高对比度文字、橙色标题和左边框；包含会计期、数据名、元/股或亿元单位、真实/预测标识、为何影响估值。
- 结构化表格先给核心结论再给数据与因果解释；不能用三个指标小卡替代完整有证据的估值分析。
- 对细小触控/手机屏采用单列，但桌面 1440–1920px 优先展示三栏工作台。

## Backend 可调用地址

参见 `../ABC_对接说明.md`：`POST /api/valuation/from-workflow`、`POST /api/valuation/session`、`POST /api/valuation/session/{id}/run`、`POST /api/valuation/session/{id}/recalculate`、`GET /api/valuation/session/{id}/excel`、`POST /api/valuation/assistant`。

## 禁止事项

- 不得伪造未获取的三大报表科目、5 年历史或“完整未来三大报表”。
- 不得在 C 使用 D 统一数据后再取一套行情改写股价。
- 不得把 ChatGPT Plus 登录态说成已接入任意网页，也不得在 HTML 放 API KEY。
- 不得在未真实重算前展示“已完成修改”的新价格。
- 不得把单点估值、低置信度情景或代理同业倍数包装成确定性目标价。
- 不得声称已复制打不开的 Workbuddy 参考站源代码。

## 核验入口

从仓库根目录执行 `python -m valuation.tests.test_v3_integration` 和
`python -m valuation.tests.test_delivery_rules`。后者覆盖 D 的 C1–C4：
银行 `partial/limited/gate_reason`、无行情每股值为 null、分业务驱动路径的
敏感性与三情景、`excel_path` 相对路径且文件存在。通过以后再对 000333 美的集团、
600036 招商银行、000858 五粮液和其他行业验证完整同业、分部、DDM、敏感性及 Excel 每格对账。

## 对话风险控制（v3 增补）

- 问句以“解释/为什么/如果/若/我想知道”开头时，即使包含调整例子也只解释，不修改当前会话。
- “请把 WACC 从 6% 改到 7.5%”必须提取 **7.5%** 为目标值；含两个以上指标时分段匹配，不把其他指标的百分比误赋给 WACC。
- “降低 0.5 个百分点”未支持单独差量规则时必须要求明确目标值，不得当作 WACC=0.5%。
- 每次参数确实修改后重新运行模型；LLM 只负责解释，不得代替 Python 估值引擎。
- `llm_connected` 仅表示服务端 API Key 已配置，`llm_used` 表示本次成功取得模型回复；前端不要误报 ChatGPT Plus 已连接。
